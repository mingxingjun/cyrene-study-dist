"""更新检查 / 下载 / 暂存（昔涟自习室）。

分工（重要）：
  本模块只负责「拿清单 → 下载 → 校验 → 解压到 out\\updates\\staged」，
  **运行中绝不替换任何文件**。
  真正把暂存目录换到 `app\\` 上的动作在 `app\\bootstrap_update.py`，
  它必须在 `import dsh_solver` **之前**执行 —— 否则包已按旧路径缓存，
  换完目录也还是旧代码。

更新包只覆盖 `app\\`；`out\\`（配置/日志/登录档案）、`截图\\`、`runtime\\`
一律不碰。exe / runtime 有变更时清单里 `requires_full=true`，客户端只提示
重新下载整包，不做增量。

安全底线：
  * 只接受 https；
  * 清单字段严格校验（schema / build / 大小上限 / sha256 格式）；
  * 下载后核对 sha256 与字节数；
  * 解压只允许 `app/` 前缀，拒绝 `..`、绝对路径，并限制解压总量。
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

__all__ = [
    "DEFAULT_MANIFEST_URLS", "local_build", "load_settings", "save_settings",
    "check", "download", "stage", "pending", "clear_pending", "compare_build",
    "update_dir", "MAX_ZIP_BYTES",
]

CHANNEL_REPO = "mingxingjun/cyrene-study-dist"
CHANNEL_BRANCH = "main"
CDN = f"https://cdn.jsdelivr.net/gh/{CHANNEL_REPO}@{CHANNEL_BRANCH}"

# jsDelivr 有多个骨干节点，其中一个被污染时换下一个；最后兜底 GitHub raw。
DEFAULT_MANIFEST_URLS = (
    f"{CDN}/updates/version.json",
    f"https://fastly.jsdelivr.net/gh/{CHANNEL_REPO}@{CHANNEL_BRANCH}/updates/version.json",
    f"https://gcore.jsdelivr.net/gh/{CHANNEL_REPO}@{CHANNEL_BRANCH}/updates/version.json",
    f"https://raw.githubusercontent.com/{CHANNEL_REPO}/{CHANNEL_BRANCH}/updates/version.json",
)

MAX_MANIFEST_BYTES = 64 * 1024
MAX_ZIP_BYTES = 20 * 1024 * 1024      # 正常约 1 MB，留足余量
MAX_UNPACKED_BYTES = 64 * 1024 * 1024  # 解压总量上限，防 zip 炸弹
USER_AGENT = "CyreneStudy/1.1 (+update)"

DEFAULT_SETTINGS = {
    "enabled": True,          # 启动时静默检查
    "auto_download": True,    # 发现新版本就在后台下好
    "check_hours": 6,         # 检查间隔（小时）
    "manifest_urls": list(DEFAULT_MANIFEST_URLS),
}


# ---------------------------------------------------------------- 路径 / 状态

def update_dir(out_dir: str | Path) -> Path:
    return Path(out_dir) / "updates"


def _settings_file(out_dir: str | Path) -> Path:
    return update_dir(out_dir) / "settings.json"


def _state_file(out_dir: str | Path) -> Path:
    return update_dir(out_dir) / "state.json"


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: dict) -> None:
    """原子写：先写 .tmp 再 replace，断电不会留半截 JSON。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def load_settings(out_dir: str | Path) -> dict:
    cfg = dict(DEFAULT_SETTINGS)
    cfg.update({k: v for k, v in _read_json(_settings_file(out_dir)).items()
                if k in DEFAULT_SETTINGS})
    return cfg


def save_settings(out_dir: str | Path, patch: dict) -> dict:
    cfg = load_settings(out_dir)
    cfg.update({k: v for k, v in (patch or {}).items() if k in DEFAULT_SETTINGS})
    _write_json(_settings_file(out_dir), cfg)
    return cfg


# ---------------------------------------------------------------- 版本号

def local_build(app_dir: str | Path) -> str:
    """读 `app\\build.json`；没有就返回 "dev"（开发目录不参与自动更新）。"""
    info = _read_json(Path(app_dir) / "build.json")
    return str(info.get("build") or "dev")


def compare_build(a: str, b: str) -> int:
    """按数字段比较两个 build 号，返回 -1 / 0 / 1。

    合法 build 形如 2026.10.28.1（日期 + 当日序号）。
    段数不同（比如手工写的 1.1.0）时按段比较、缺的补 0，仍能给出稳定结果。
    """
    def parts(s: str) -> list[int]:
        out: list[int] = []
        for seg in re.split(r"[^0-9]+", str(s or "")):
            if seg:
                out.append(int(seg))
        return out

    pa, pb = parts(a), parts(b)
    n = max(len(pa), len(pb))
    pa += [0] * (n - len(pa))
    pb += [0] * (n - len(pb))
    return (pa > pb) - (pa < pb)


def is_newer(remote: str, local: str) -> bool:
    if not remote or local == "dev":
        return False
    return compare_build(remote, local) > 0


# ---------------------------------------------------------------- 网络

def _bust(url: str) -> str:
    """给 jsDelivr 加按小时变的缓存键。

    同一小时内所有用户共享 CDN 缓存，整点后自动取新 —— 不需要依赖 purge 接口。
    raw.githubusercontent.com 不支持 query 也无所谓，加上不影响。
    """
    if "jsdelivr.net" not in url:
        return url
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}t={int(time.time()) // 3600}"


def _get(url: str, timeout: float, limit: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read(limit + 1)
    if len(data) > limit:
        raise ValueError("响应过大")
    return data


def _valid_manifest(m: dict) -> bool:
    if not isinstance(m, dict) or int(m.get("schema") or 0) != 1:
        return False
    if not re.fullmatch(r"\d{4}\.\d{2}\.\d{2}\.\d+", str(m.get("build") or "")):
        return False
    app = m.get("app") or {}
    if not isinstance(app, dict):
        return False
    url = str(app.get("url") or "")
    if not url.startswith("https://"):
        return False
    size = app.get("size")
    if not isinstance(size, int) or not (0 < size <= MAX_ZIP_BYTES):
        return False
    if not re.fullmatch(r"[0-9a-fA-F]{64}", str(app.get("sha256") or "")):
        return False
    return True


def fetch_manifest(urls, timeout: float = 2.5) -> tuple[dict | None, str]:
    """按顺序试每个端点，返回 (manifest, 错误描述)。"""
    errors: list[str] = []
    for url in urls:
        try:
            raw = _get(_bust(url), timeout, MAX_MANIFEST_BYTES)
            m = json.loads(raw.decode("utf-8"))
            if not _valid_manifest(m):
                raise ValueError("清单字段不合法")
            return m, ""
        except Exception as e:  # noqa: BLE001 —— 任何失败都换下一个端点
            host = url.split("/")[2] if "//" in url else url
            errors.append(f"{host}:{type(e).__name__}")
    return None, "；".join(errors[-4:])


# ---------------------------------------------------------------- 检查

def check(out_dir: str | Path, app_dir: str | Path, force: bool = False,
          timeout: float = 2.5) -> dict:
    """查一次更新。

    返回 dict：
      ok       本轮是否拿到清单
      dev      是不是开发目录（没有 build.json → 不参与更新）
      skipped  是否因为节流/关闭而跳过
      local    本地 build
      latest   远端 build
      manifest 清单原文（ok 时）
      error    失败原因（给人看的短句）
    """
    local = local_build(app_dir)
    cfg = load_settings(out_dir)
    st = _state_file(out_dir)
    state = _read_json(st)

    if local == "dev":
        return {"ok": True, "dev": True, "skipped": True, "local": local,
                "latest": "", "manifest": None, "error": ""}

    if not cfg["enabled"] and not force:
        return {"ok": True, "dev": False, "skipped": True, "local": local,
                "latest": "", "manifest": None, "error": ""}

    hours = float(cfg.get("check_hours") or 0)
    last = float(state.get("last_check") or 0)
    if not force and hours > 0 and (time.time() - last) < hours * 3600:
        return {"ok": True, "dev": False, "skipped": True, "local": local,
                "latest": str(state.get("latest") or ""), "manifest": None,
                "error": ""}

    m, err = fetch_manifest(cfg.get("manifest_urls") or DEFAULT_MANIFEST_URLS, timeout)
    state["last_check"] = time.time()
    state["last_error"] = err
    if m:
        state["latest"] = m["build"]
    _write_json(st, state)

    if not m:
        return {"ok": False, "dev": False, "skipped": False, "local": local,
                "latest": "", "manifest": None, "error": err or "网络不可用"}

    return {"ok": True, "dev": False, "skipped": False, "local": local,
            "latest": m["build"], "manifest": m, "error": ""}


# ---------------------------------------------------------------- 下载 / 暂存

def download(manifest: dict, out_dir: str | Path, progress=None,
             timeout: float = 30.0) -> Path:
    """下载并校验更新包，返回本地 zip 路径。失败抛异常。"""
    app = manifest["app"]
    url, size, sha = str(app["url"]), int(app["size"]), str(app["sha256"]).lower()
    if not url.startswith("https://"):
        raise ValueError("更新地址不是 https")
    if not (0 < size <= MAX_ZIP_BYTES):
        raise ValueError("更新包大小异常")

    ddir = update_dir(out_dir) / "download"
    ddir.mkdir(parents=True, exist_ok=True)
    part = ddir / f"{manifest['build']}.zip.part"
    final = ddir / f"{manifest['build']}.zip"

    h = hashlib.sha256()
    got = 0
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, open(part, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                got += len(chunk)
                if got > MAX_ZIP_BYTES:
                    raise ValueError("更新包超过大小上限")
                h.update(chunk)
                f.write(chunk)
                if progress:
                    try:
                        progress(got, size)
                    except Exception:
                        pass
        if got != size:
            raise ValueError(f"字节数不符（{got} != {size}）")
        if h.hexdigest() != sha:
            raise ValueError("sha256 校验失败")
        os.replace(part, final)
        return final
    except Exception:
        try:
            part.unlink()
        except Exception:
            pass
        raise


def stage(zip_path: str | Path, out_dir: str | Path, build: str) -> Path:
    """把更新包解压到 out\\updates\\staged\\<build>\\app，写 pending.json。

    返回暂存的 app 目录。校验失败抛异常，且不会留下半成品 pending。
    """
    upd = update_dir(out_dir)
    staged_root = upd / "staged" / str(build)
    if staged_root.exists():
        shutil.rmtree(staged_root, ignore_errors=True)
    staged_root.mkdir(parents=True, exist_ok=True)
    root = staged_root.resolve()

    unpacked = 0
    try:
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                name = info.filename.replace("\\", "/")
                if name.endswith("/"):
                    continue
                parts = [p for p in name.split("/") if p not in ("", ".")]
                if not parts or any(p == ".." for p in parts):
                    raise ValueError(f"非法路径：{name}")
                if parts[0] != "app":
                    raise ValueError(f"更新包只允许 app/ 前缀：{name}")
                target = (staged_root / Path(*parts)).resolve()
                if root not in target.parents:
                    raise ValueError(f"路径越界：{name}")
                unpacked += int(info.file_size or 0)
                if unpacked > MAX_UNPACKED_BYTES:
                    raise ValueError("解压总量超过上限")
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    except Exception:
        shutil.rmtree(staged_root, ignore_errors=True)
        raise

    app = staged_root / "app"
    if not (app / "server.py").is_file():
        shutil.rmtree(staged_root, ignore_errors=True)
        raise ValueError("更新包里没有 app/server.py")
    try:
        info = json.loads((app / "build.json").read_text(encoding="utf-8"))
    except Exception:
        info = {}
    if str(info.get("build") or "") != str(build):
        shutil.rmtree(staged_root, ignore_errors=True)
        raise ValueError("更新包 build 号与清单不一致")

    _write_json(upd / "pending.json", {
        "build": str(build),
        "staged": str(app),
        "sha256": str(manifest_sha(zip_path)),
        "at": time.time(),
    })
    return app


def manifest_sha(zip_path: str | Path) -> str:
    h = hashlib.sha256()
    with open(zip_path, "rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def pending(out_dir: str | Path) -> dict:
    info = _read_json(update_dir(out_dir) / "pending.json")
    return info if info else {}


def clear_pending(out_dir: str | Path) -> None:
    upd = update_dir(out_dir)
    try:
        (upd / "pending.json").unlink()
    except Exception:
        pass
    shutil.rmtree(upd / "staged", ignore_errors=True)