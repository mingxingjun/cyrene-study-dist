# -*- coding: utf-8 -*-
"""自测运行器 —— 用本地伪造页跑一遍关键路径，输出通过/失败摘要。

为什么要有它（文档 P0 改动点 0 的建议）：
  没有它，每次验收都得手动开网页、手点、肉眼看。
  有了它，改完代码跑一条命令就知道"扫描/落笔/进度"这些核心能力有没有被弄坏。

用法（注意路径 —— 本文件在包内）
-------------------------------
  源码仓库里：
      .venv\\Scripts\\python.exe dsh_solver\\selftest.py

  打包后的软件目录里：
      runtime\\python.exe app\\dsh_solver\\selftest.py

  只跑某一组 / 列出用例：
      ... selftest.py scan
      ... selftest.py --list

⚠ 这些用例**只用本地伪造页**（file:// 或本地 http），
  绝不对真实平台页面做开发测试 —— 那既是合规问题，也没法稳定复现。

⚠ 交付版里**不含自测页**（属于开发资产），所以那里运行会提示"没找到自测页"。
  要跑自测请在源码仓库里执行。
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
# ⚠ 两种情况都要能用：
#   ① 从软件根跑 `app\selftest.py`（打包后的布局）→ 包目录是 app\dsh_solver
#   ② 从源码仓库跑 `dsh_solver\selftest.py`（开发布局）→ 包目录就是它自己
#   这里把"包含 dsh_solver 包的那一层"找出来塞进 sys.path。
for _cand in (APP_DIR, APP_DIR.parent):
    if (_cand / "dsh_solver" / "__init__.py").exists():
        if str(_cand) not in sys.path:
            sys.path.insert(0, str(_cand))
        break
else:
    # 本文件就在包里时，直接让它的父目录可导入
    if str(APP_DIR.parent) not in sys.path:
        sys.path.insert(0, str(APP_DIR.parent))

# 站点目录：优先用软件目录下的 out\selftest\site，其次用源码仓库的 tests\site
#
# ⚠ 打包后的软件目录布局是
#       <根>\app\dsh_solver\selftest.py
#       <根>\out\selftest\site\*.html
#   也就是站点在**上两层**的 out\selftest\site 里。
#   这里以前只找 `APP_DIR.parent\out\selftest\site`（= app\out\...），
#   在软件目录里必然找不到，于是自测**永远报"没找到自测页"**。
#   实测就是这么发现的：--list 能列用例，一跑就说没自测页。
_CANDIDATES = [
    APP_DIR.parent / "out" / "selftest" / "site",
    APP_DIR.parent / "tests" / "site",
    APP_DIR.parent.parent / "tests" / "site",
    APP_DIR.parent.parent / "out" / "selftest" / "site",
]


def site_dir() -> Path:
    for p in _CANDIDATES:
        if p.is_dir():
            return p
    return _CANDIDATES[0]


def url_of(name: str) -> str:
    return (site_dir() / name).resolve().as_uri()


# ---------------------------------------------------------------------------
# 用例：每个都是 (名字, 分组, 说明, 函数)
#   函数返回 (ok: bool, detail: str)
#   ⚠ 用例必须**自包含**：自己开浏览器、自己关，不依赖外部状态。
# ---------------------------------------------------------------------------
CASES: list[tuple[str, str, str, object]] = []


def case(name: str, group: str, desc: str):
    def deco(fn):
        CASES.append((name, group, desc, fn))
        return fn
    return deco


# ---- 扫描 ----
@case("scan-basic", "scan", "普通表单页能扫出题目与选项")
def _c_scan_basic(d):
    # ⚠ 别忘 open —— 用例必须自己把页面打开（浏览器是新起的，默认空白页）
    d.open(url_of("exam.html"))
    d.wait_for_load()
    st = d.scan()
    if not st.questions:
        return False, "一道题都没扫到"
    q = st.questions[0]
    n = len(q.options) if isinstance(q.options, list) else 0
    return (n >= 2), f"题 {len(st.questions)} 道，首题 {n} 个选项"


@case("scan-shadow", "scan", "open shadow DOM 里的题能扫到（零成本手段）")
def _c_scan_shadow(d):
    d.open(url_of("shadow_only.html"))
    d.wait_for_load()
    st = d.scan()
    n = len(st.questions)
    return (n >= 1), f"扫到 {n} 道（期望 ≥1；0 说明 shadow 穿透失效）"


@case("scan-aria", "scan", "纯 ARIA 组件题能扫到（页面上无原生控件）")
def _c_scan_aria(d):
    d.open(url_of("aria_only.html"))
    d.wait_for_load()
    st = d.scan()
    n = len(st.questions)
    return (n >= 1), f"扫到 {n} 道"


@case("scan-empty", "scan", "空白页应扫出 0 题（并记一次盲区埋点）")
def _c_scan_empty(d):
    d.open("data:text/html,<html><body><p>空的</p></body></html>")
    d.wait_for_load()
    st = d.scan()
    ok = (len(st.questions) == 0 and len(st.fields) == 0)
    return ok, f"题 {len(st.questions)} / 填空 {len(st.fields)}"


# ---- 落笔 ----
@case("choose-native", "choose", "原生 radio 能点中")
def _c_choose_native(d):
    d.open(url_of("exam.html"))
    d.wait_for_load()
    st = d.scan()
    if not st.questions:
        return False, "没扫到题"
    out = d.choose(0, [1])
    hit = any("✔" in str(x) for x in out)
    return hit, (out[0][:70] if out else "(无返回)")


@case("choose-shadow", "choose", "shadow DOM 里的选项能点中（落笔+回读都穿透）")
def _c_choose_shadow(d):
    d.open(url_of("shadow_only.html"))
    d.wait_for_load()
    st = d.scan()
    if not st.questions:
        return False, "shadow 里的题没扫到（扫描先失效了）"
    out = d.choose(0, [1])
    hit = any("✔" in str(x) for x in out)
    return hit, (out[0][:70] if out else "(无返回)")


# ---- 平台进度 ----
@case("progress-yes", "progress", "平台标「已完成」时能读出来")
def _c_prog_yes(d):
    d.open(url_of("course_legacy_progress.html"))
    d.wait_for_load()
    from dsh_solver.core import pick_adapter
    ad = pick_adapter(d.page.url, driver=d, log=lambda s: None)
    p = ad.progress(d.page, None)
    return p.complete, p.describe()[:70]


@case("progress-no", "progress", "平台没标完成时不应误判")
def _c_prog_no(d):
    d.open(url_of("course_legacy_progress.html"))
    d.wait_for_load()
    d.page.evaluate("""() => {
        document.querySelectorAll('.child-check').forEach(e => e.remove());
        const pt = document.getElementById('prog');
        if (pt) pt.textContent = '正在学习';
    }""")
    from dsh_solver.core import pick_adapter
    ad = pick_adapter(d.page.url, driver=d, log=lambda s: None)
    p = ad.progress(d.page, None)
    return (not p.complete), p.describe()[:70]


# ---- 课中弹题 ----
@case("quiz-detect", "quiz", "能检测到弹题（含 iframe 里的）")
def _c_quiz_detect(d):
    d.open(url_of("quiz_in_iframe.html"))
    d.wait_for_load()
    from dsh_solver.course import CourseRunner
    r = CourseRunner.__new__(CourseRunner)
    r.driver = d
    r.log = lambda s: None
    hit = r._ai_quiz_visible()
    probe = r._quiz_probe()
    return hit, f"判据={probe.get('sel')}"


@case("quiz-none", "quiz", "没有弹题时不应误报")
def _c_quiz_none(d):
    d.open(url_of("course_legacy_progress.html"))
    d.wait_for_load()
    from dsh_solver.course import CourseRunner
    r = CourseRunner.__new__(CourseRunner)
    r.driver = d
    r.log = lambda s: None
    hit = r._ai_quiz_visible()
    return (not hit), "无弹题页 → 未误报" if not hit else "误报了！"


@case("quiz-trap-title", "quiz",
      "可见的章节标题（.topic-title）不能被当成课中弹题")
def _c_quiz_trap_title(d):
    r"""★ 这是"一次误判 = 白等 15 分钟 + 丢一节课"的回归。

    ⚠ 背景：`.topic-title` 原来在**强判据**里（命中即算、不看有没有选项），
      注释写着"智慧树老版课中弹题题面"。但智慧树里 **"topic" 也是"章节"** ——
      课程页把章节名渲染成可见的 `.topic-title` 时，
      `_quiz_probe()` 就会一路命中。

      后果不是"多等一下"：
        暂停视频 → 等 COURSE_QUIZ_MAX_WAIT_MIN（默认 15 分钟）
                → 仍不消失 → reason="课中弹题等待超时（可能误判）" → **整节跳过**。

      修法：**弹题一定带选项** —— 这比任何 CSS 类名都硬。
      `.topic-title` 这类"标题/通用容器型"判据要求
      本元素或上溯 3 层内真的有 ≥2 个选项；再加一道护栏：
      一页里出现 ≥3 个可见的同名标题 → 那是**目录**，不是题。
    """
    from dsh_solver.course import CourseRunner
    r = CourseRunner.__new__(CourseRunner)
    r.driver = d
    r.log = lambda s: None
    d.open(url_of("course_trap_visible_topic_title.html"))
    d.wait_for_load()
    probe = r._quiz_probe()
    if probe.get("found"):
        return False, (f"误判了！判据={probe.get('sel')} "
                       f"题面={probe.get('title')!r} —— "
                       f"会让这一节白等 15 分钟再整个跳过")
    return True, "只有章节标题、没有选项 → 正确地不认"


@case("quiz-title-needs-options", "quiz",
      "真正的 .topic-title 弹题（附近有选项）仍然要认出来")
def _c_quiz_title_needs_options(d):
    """上一条的反面：别为了防误判把真弹题也挡掉了。"""
    from dsh_solver.course import CourseRunner
    r = CourseRunner.__new__(CourseRunner)
    r.driver = d
    r.log = lambda s: None
    d.open(url_of("quiz_in_iframe.html"))
    d.wait_for_load()
    probe = r._quiz_probe()
    if not probe.get("found"):
        return False, "真弹题被漏掉了！"
    return True, (f"判据={probe.get('sel')} 选项={probe.get('opts')} "
                  f"题面={(probe.get('title') or '')[:24]!r}")


# ---------------------------------------------------------------------------
# 课中弹题「自动作答」（videoquiz.py）
#
# ⚠ 这里只做**能不能读题**的轻量检查；完整的落笔/回读/安全边界在
#   tools/check_videoquiz.py（46 项）。放在 selftest 里是为了让用户
#   在交付环境里也能一键确认"这两家的弹题 DOM 认不认"。
# ---------------------------------------------------------------------------
@case("quiz-read-zhihuishu", "quiz", "智慧树弹题：题面与 4 个选项都能读出来")
def _c_quiz_read_zhs(d):
    from dsh_solver.videoquiz import scan_quiz
    d.open(url_of("videoquiz_zhihuishu.html"))
    d.wait_for_load()
    q = scan_quiz(d.page.main_frame, ".topic-title")
    if q is None:
        return False, "扫不到智慧树弹题"
    if len(q.options) != 4:
        return False, f"选项数 {len(q.options)}（期望 4）"
    if "Agent" not in q.stem:
        return False, f"题面不对：{q.stem[:30]}"
    # 选项文字不能带着字母圈（否则模型会看到 `B. B …`）
    if q.options[1]["text"].startswith("B"):
        return False, f"字母圈没剥掉：{q.options[1]['text'][:26]}"
    return True, f"{len(q.options)} 个选项，题面={q.stem[:22]!r}"


@case("quiz-read-chaoxing", "quiz", "学习通弹题：判断题（对/错）两项要能读出来")
def _c_quiz_read_cx(d):
    from dsh_solver.videoquiz import scan_quiz
    d.open(url_of("videoquiz_chaoxing.html"))
    d.wait_for_load()
    q = scan_quiz(d.page.main_frame, ".ans-videoquiz-box")
    if q is None:
        return False, "扫不到学习通弹题"
    if len(q.options) != 2:
        return False, f"选项数 {len(q.options)}（期望 2）"
    return True, f"判断题 2 项，题面={q.stem[:20]!r}"


# ---------------------------------------------------------------------------
# 跨 frame 定位（"填空错位"回归）
#
# 背景：SCAN_JS 是在**每个 frame 里各跑一遍**的，编号每帧从 0 开始，
#       合并到 Python 侧才加偏移 —— 所以帧内 DOM 标记 ≠ Python 编号。
#       标记没重贴对时，症状是**静默**的：
#         · 一个 iframe 里有 3 个空格 → 答案写进别的格子（错位）
#         · 一个 iframe 里有多道题 → 点到别的题上（串题）
#       上面这些用例就是钉住这两类，避免再回归。
# ---------------------------------------------------------------------------
@case("frame-essay-each", "scan", "3 个 iframe 各 1 个作答区：题干与落笔各归各位")
def _c_frame_essay_each(d):
    d.open(url_of("frame_essay_each_iframe.html"))
    d.wait_for_load()
    st = d.scan()
    if len(st.fields) != 3:
        return False, f"字段数 {len(st.fields)}（期望 3）"
    for f in st.fields:
        d.fill(f.fid, f"答案{f.fid}")
    vals = []
    for fr in d.page.frames[1:]:
        try:
            vals.append(fr.evaluate(
                "() => { const e = document.querySelector("
                "'[contenteditable=true]'); return e ? (e.innerText||'') : ''; }"))
        except Exception:
            vals.append("")
    ok = vals == ["答案0", "答案1", "答案2"]
    return ok, f"各 iframe 内容 {vals}"


@case("frame-multi-blank", "choose", "一个 iframe 里多个空格不能写错格子")
def _c_frame_multi_blank(d):
    d.open(url_of("frame_multi_blank.html"))
    d.wait_for_load()
    st = d.scan()
    if len(st.fields) != 3:
        return False, f"字段数 {len(st.fields)}（期望 3）"
    for f in st.fields:
        d.fill(f.fid, f"答案{f.fid}")
    vals = d.page.frames[1].evaluate(
        "() => [].slice.call(document.querySelectorAll('input'))"
        ".map(e => e.value)")
    ok = vals == ["答案0", "答案1", "答案2"]
    return ok, f"三个空格 {vals}"


@case("frame-multi-native", "choose", "一个 iframe 里两道原生题：标记不能串")
def _c_frame_multi_native(d):
    d.open(url_of("frame_multi_native_question.html"))
    d.wait_for_load()
    st = d.scan()
    if len(st.questions) != 2:
        return False, f"题目数 {len(st.questions)}（期望 2）"
    qids = d.page.frames[1].evaluate(
        "() => Array.from(new Set([].slice.call("
        "document.querySelectorAll('[data-dsh-qid]'))"
        ".map(e => e.getAttribute('data-dsh-qid'))))")
    ok = sorted(str(x) for x in qids) == ["0", "1"]
    return ok, f"帧内 qid 集合 {qids}"


@case("frame-multi-custom", "choose", "一个 iframe 里两道自定义题：不能点到别的题")
def _c_frame_multi_custom(d):
    d.open(url_of("frame_multi_custom_question.html"))
    d.wait_for_load()
    st = d.scan()
    if len(st.questions) != 2:
        return False, f"题目数 {len(st.questions)}（期望 2）"
    for i in (0, 1):
        d.choose(i, [1])
    got = d.page.frames[1].evaluate(r"""() => {
        const qs = document.querySelectorAll('.q');
        return Array.prototype.map.call(qs, function (q) {
            const opts = q.querySelectorAll('[role=radio]');
            for (let i = 0; i < opts.length; i++) {
                if (opts[i].getAttribute('aria-checked') === 'true') return i;
            }
            return -1;
        });
    }""")
    ok = list(got) == [1, 1]
    return ok, f"两题选中下标 {got}（期望 [1, 1]）"


# ---- 刷课：学习通新版「横向栏目」章节页 ----
def _runner_on(d, **kw):
    """把自测框架已经开好的浏览器借给 `CourseRunner` 用。

    ⚠ 为什么不直接写 `CourseRunner(...)`：它的 `__init__` 会
      `sync_playwright().start()`，再自己开一个浏览器。自测里每个用例
      本来就已经有一个了，再开一个既慢，又可能出现两个 sync_playwright
      实例在同一个线程里打架。这里绕开 `__init__`，只补上跑这条路径
      真正会用到的字段（`_run_chaoxing_tabs_course` 那条链上要用的）。
    """
    from dsh_solver.course import CourseRunner
    cr = CourseRunner.__new__(CourseRunner)
    cr.driver = d
    cr.log = kw.get("log") or (lambda _s: None)
    cr.status = kw.get("status") or (lambda _s: None)
    cr.stop = None
    cr.client = None
    cr.auto_quiz = False
    # ⚠ 2026-10-23 修：字段名要和 course.py 现在的 `__init__` 对齐。
    #   原来只补了 quiz_answered / quiz_failed（旧版小结字段），
    #   而 course.py 之后改成了 chapter_quiz_done / chapter_quiz_failed /
    #   last_quiz_submitted / last_quiz_blocked —— 自测又用 `__new__` 绕开
    #   `__init__`，于是「播完 1 节收尾」时读 chapter_quiz_done 直接
    #   AttributeError，自测得到 23/24 而产品本身没问题。
    #   这里四个都补上：自测 24/24，且不影响任何真实运行路径。
    cr.quiz_answered = 0
    cr.quiz_failed = 0
    cr.chapter_quiz_done = 0
    cr.chapter_quiz_failed = 0
    cr.last_quiz_submitted = False
    cr.last_quiz_blocked = False
    return cr


@case("course-cx-tabs", "course",
      "学习通新版「横向栏目」：认得出栏目条、点得动、点完能找到视频")
def _c_course_cx_tabs(d):
    d.open(url_of("chaoxing_tabs.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    # ① 老判据必须判否 —— 这正是 2026-10-16 那次
    #    "页面上找不到可播放的视频（当前页面：章节详情）"的根因。
    #    页面里真的一个 .jobCount 都没有，判真了说明用例前提被破坏了。
    if cr._is_chaoxing_course():
        return False, "老判据判真了：这一版页面本来就不该有 .jobCount"

    # ② 新判据要认出来
    if not cr._is_chaoxing_tabs_course():
        return False, "没能按「横向栏目」认出这一页"

    texts = cr._cx_tab_texts()
    want = ["本章导读", "目标与导学", "学习视频", "小节测验", "电子课件", "扩展阅读"]
    joined = " | ".join(texts)
    if len(texts) != 6 or not all(w in joined for w in want):
        return False, f"栏目条读成了 {len(texts)} 条：{joined}"

    # ③ 点之前：整个页面（含所有 iframe）不该有可播视频
    if cr._any_video().get("found"):
        return False, "还没点「学习视频」就已经有视频了，用例前提不成立"

    # ④ 点「学习视频」。文字里带序号（"3 学习视频"），所以按读到的原文点。
    target = next((t for t in texts if "学习视频" in t), "")
    if not cr._cx_click_tab_text(target):
        return False, f"点「{target}」以后页面指纹没变化（没点中）"

    # ⑤ 点完能找到 <video> —— 视频在两层 iframe 下面
    info: dict = {}
    for _ in range(20):
        info = cr._any_video()
        if info.get("found"):
            break
        time.sleep(0.5)
    if not info.get("found"):
        return False, "点了「学习视频」仍然找不到 <video>"

    # ⑥ ★ 用户实测的那个坑：播放器停在封面上，duration 读出来是 0。
    #    程序原来的判据是"found 且 duration>0"，于是干等 20 秒判"没有可播视频"。
    if float(info.get("duration") or 0) > 0:
        return False, "用例前提不成立：没点播放按钮就已经有时长了"

    note = cr._cx_press_play(info.get("_frame"))
    if not note:
        return False, "点了播放但那一下没生效（没返回任何说明）"

    info = cr._any_video()
    dur = float(info.get("duration") or 0)
    if dur <= 0:
        return False, f"点播放后仍然读不到时长（{note}）"

    return True, f"栏目 {len(texts)} 条；点「{target}」→ {note} → 时长 {dur:.0f} 秒"


@case("course-cx-tabs-next", "course",
      "「下一节」只长在某一栏里时也能找到并点动")
def _c_course_cx_tabs_next(d):
    d.open(url_of("chaoxing_tabs.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    # 先切到「学习视频」栏。用户截图里这一栏底部**没有**「下一节」，
    # 正是这次误判"已到最后一节"的场景。
    texts = cr._cx_tab_texts()
    video_tab = next((t for t in texts if "学习视频" in t), "")
    if not cr._cx_click_tab_text(video_tab):
        return False, f"没点开「{video_tab}」"
    if cr._find_next():
        return False, "用例前提不成立：学习视频栏里居然已经有「下一节」"

    nxt = cr._cx_find_next_across_tabs(cr._cx_tab_rows()[0]["items"])
    if not nxt:
        return False, "跨栏目也没找到「下一节」"

    before = str(d.page.evaluate("() => document.getElementById('secTitle').textContent"))
    if not cr._click_next(nxt):
        return False, "找到了「下一节」但点不动"
    time.sleep(1.2)
    after = str(d.page.evaluate("() => document.getElementById('secTitle').textContent"))
    if before == after:
        return False, f"点了「下一节」但章节没换（仍是 {after}）"
    return True, f"「{before}」→「{after}」"


@case("course-cx-tabs-resume", "course",
      "视频被平台按停后能自动恢复并播完（复刻「刚开始就暂停了」）")
def _c_course_cx_tabs_resume(d):
    d.open(url_of("chaoxing_tabs.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    texts = cr._cx_tab_texts()
    target = next((t for t in texts if "学习视频" in t), "")
    if not cr._cx_click_tab_text(target):
        return False, f"没点开「{target}」"

    info: dict = {}
    for _ in range(20):
        info = cr._any_video()
        if info.get("found"):
            break
        time.sleep(0.5)
    if not info.get("found"):
        return False, "打开视频栏后找不到 <video>"

    fr = info.get("_frame")
    # 先把封面点开（不点就没有时长），再**手动模拟平台把视频按停** ——
    # 这正是用户看到的"视频刚开始就暂停了"。此后脚本 `v.play()` 一律无效，
    # 只有真实鼠标点中播放按钮才当数。
    cr._cx_press_play(fr)
    if float(cr._any_video().get("duration") or 0) <= 0:
        return False, "没能点开封面（读不到时长），用例前提不成立"
    fr.evaluate("() => { if (window.__dshSimPlatformPause) window.__dshSimPlatformPause(); }")
    time.sleep(0.5)
    if not cr._any_video().get("paused"):
        return False, "用例前提不成立：没能把视频按停"

    # ★ 整条播放逻辑要能自己发现"被按停"、用真实点击恢复、并播到结尾。
    #   改坏了的写法是：只调 `v.play()`（无效）并且每轮都把 1.5× 塞回去
    #   （把平台惹毛了再按停一次）→ 50 秒里进度停在 1s/640s。
    r = cr._ai_play_video(2.0, True, "按停后恢复", prev_percent=None,
                          prev_src="", card_dur=0.0)
    if not r.finished:
        return False, f"没能恢复并播完：{r.note or '（没有说明）'}"
    return True, f"按停后自动恢复并播完（{r.duration:.0f} 秒，倍速 {r.rate}×）"


@case("course-cx-tabs-guard", "course",
      "老版「任务点式」页面不会被「横向栏目」新路径抢走")
def _c_course_cx_tabs_guard(d):
    d.open(url_of("chaoxing_course.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    if not cr._is_chaoxing_course():
        return False, "老版页面没被老判据认出来（回归了）"
    if cr._is_chaoxing_tabs_course():
        return False, "老版页面被新路径抢走了，会走错分支"
    return True, "老判据认它、新判据不抢它"


@case("course-cx-globalnav", "course",
      "顶部「目录/讨论/笔记/标注」全站导航不会被当成横向栏目条")
def _c_course_cx_globalnav(d):
    """用户 2026-10-23 19:30 真机日志的回归用例。

    那一页的横向文字其实是全站导航（政策导读/目录/讨论/笔记/标注），
    旧版本按「栏目名打分 + 同一水平行」把它认成了本章栏目条，
    于是把「目录」「讨论」当栏目逐条点开，最后报"共 0 节"。

    ⚠ 用例的**前提**要成立：这排文字必须先被几何扫描扫出来
      （否则测试的是"扫不到"，而不是"扫到了但不该认"）。
    """
    d.open(url_of("chaoxing_global_nav.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    rows = cr._cx_tab_rows()
    if not rows:
        return False, "那排导航没被几何扫描扫出来 —— 用例前提不成立"
    texts = [str(x.get("text") or "") for x in (rows[0].get("items") or [])]
    if cr._is_chaoxing_tabs_course():
        return False, ("全站导航被当成栏目条了（2026-10-23 日志里的误判）："
                       + " / ".join(texts))
    return True, f"扫到 {len(texts)} 条导航但判否（{' / '.join(texts)}）"


@case("course-cx-sectabs", "course",
      "一个章节挂多个分节测验时，能读到全部标签并切到第 2 个")
def _c_course_cx_sectabs(d):
    """用户 2026-10-26 真机：「一个页面有多个章节测验，1 可以，2、3 就不行」。

    三个测验是同一章节下的分节标签，页面一次只挂一份 iframe。
    这个用例验证两件事：标签能全部读出来；点第 2 个之后它真的变成 active，
    并且下面的 iframe 换成了第 2 份内容。
    """
    d.open(url_of("chaoxing_section_tabs.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    tabs = cr._cx_section_tabs()
    if len(tabs) != 3:
        return False, f"读到 {len(tabs)} 个分节标签（期望 3）"
    if not tabs[0].get("active"):
        return False, "第 1 个分节没被标成 active（页面前提不对）"
    if not cr._cx_click_section_tab(1):
        return False, "点第 2 个分节后没变成 active"
    tabs = cr._cx_section_tabs()
    if not (len(tabs) == 3 and tabs[1].get("active")):
        return False, ("第 2 个分节仍然不是 active："
                       + str([t.get("active") for t in tabs]))
    src = ""
    for fr in cr._frames():
        try:
            s = fr.evaluate(
                "() => { const f = document.getElementById('iframe');"
                " return f ? f.src : ''; }")
            if s:
                src = str(s)
                break
        except Exception:
            pass
    if "tab=1" not in src:
        return False, f"点完第 2 个分节，iframe 没换成 tab=1（{src[:90]}）"
    return True, ("3 个分节标签；切到第 2 个后 iframe="
                  + src.rsplit("?", 1)[-1])


@case("course-cx-rightrail", "course",
      "屏幕右侧那排「目录/讨论/笔记/标注」不会被当成章节栏目条")
def _c_course_cx_rightrail(d):
    """用户 2026-10-26：「有时候会点击右边的讨论和笔记」。

    右侧栏是一排短文字块，几何上和内容区栏目条一模一样；
    个别页面的右侧栏里还有「学习视频 / 章节测验」这类**能命中栏目名打分**的词，
    于是旧几何判据会把整排右侧栏当成栏目条去点。
    新判据：整排都在屏幕右侧 62% 以外 → 不是内容区栏目条。
    """
    d.open(url_of("chaoxing_right_rail.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    rows = cr._cx_tab_rows()
    if rows:
        texts = [str(x.get("text") or "") for x in (rows[0].get("items") or [])]
        return False, "右侧栏被当成栏目条了：" + " / ".join(texts)
    return True, "右侧那排被正确排除（0 条栏目条）"


@case("course-cx-discuss", "course",
      "讨论区：生成回复、填进「回复话题」并提交成功")
def _c_course_cx_discuss(d):
    """用户 2026-10-26：「讨论还不能自动刷」。

    真机结构：讨论任务点 → insertbbs → bbscircle → 话题详情（groupweb），
    回复框是 `textarea[placeholder=回复话题]`，提交按钮 `.addReply`。
    这里用本地页复刻这两个元素，把「生成 → 填入 → 提交 → 核验」整条链路跑一遍
    （模型用假客户端，不联网）。
    """
    d.open(url_of("chaoxing_discuss.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    class _FakeClient:
        def chat(self, messages, **kw):
            class _R:
                text = ("我觉得人工智能会改变电气工程的学习方式，"
                        "我打算先把数学和编程基础打牢，再结合专业方向慢慢深入。")
            return _R()

    cr.client = _FakeClient()
    ok = cr._cx_answer_discussion_page(
        url_of("chaoxing_discuss.html"), "测试讨论", "测试描述")
    last = str(getattr(cr, "_last_discuss_reply", "") or "")
    if not ok:
        return False, "页面没显示回复内容（提交链路没打通）"
    if "数学" not in last:
        return False, f"回填内容不对：{last[:40]!r}"
    return True, f"生成 → 填入 → 提交成功（{len(last)} 字）"


@case("course-cx-discuss-force", "course",
      "讨论强制模式：目录已打勾的也处理，普通模式跳过")
def _c_course_cx_discuss_force(d):
    """2026-10-26 用户：目录打勾但讨论没真做。

    单页模式会把已打勾的也处理；普通刷课模式仍然跳过，避免重复回复。
    """
    d.open(url_of("chaoxing_discuss.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    cr.auto_quiz = True
    cr.client = object()          # 只要求非 None
    calls = []
    cr._cx_discuss_targets = lambda: [
        {"url": "u1", "title": "已打勾的讨论", "desc": "d", "finished": True}]
    cr._cx_answer_discussion_page = lambda url, title, desc: (
        calls.append(url) or True)

    n_force = cr._cx_answer_discussions(force=True)
    n_norm = cr._cx_answer_discussions()
    if n_force != 1 or calls != ["u1"]:
        return False, f"强制模式没处理：n={n_force} calls={calls}"
    if n_norm != 0:
        return False, f"普通模式不该处理已完成的讨论（返回 {n_norm}）"
    return True, "强制=处理 1 条；普通=跳过"


@case("course-cx-single", "course",
      "单页模式：只处理当前页，跑完就停（不翻章）")
def _c_course_cx_single(d):
    """单页自动：在普通页面上也只会跑一遍并正常收尾，不会去翻章。"""
    from dsh_solver.course import CourseResult
    d.open(url_of("chaoxing_discuss.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    cr.auto_quiz = False           # 无模型也要能跑完（只跳过测验/讨论）
    cr.single_page = True
    res = cr._run_single_page(CourseResult(), 2.0, True, 1, time.time())
    if res.stopped_reason != "单页模式完成":
        return False, f"停止原因不对：{res.stopped_reason!r}"
    return True, "单页模式正常收尾"


@case("course-cx-single-work", "course",
      "单页自动：当前页是作业/试卷时直接交给答题引擎")
def _c_course_cx_single_work(d):
    """2026-10-26 用户：停在 mooc2/work/dowork 作业页点单页自动，旧版只会
    说「不是课程页面」。现在要先识别页面类型，卷子页直接作答。"""
    from dsh_solver.course import CourseResult
    d.open(url_of("chaoxing_work.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    cr.single_page = True
    calls = []
    cr._run_single_page_quiz = lambda res, t0, title="": (calls.append(title) or res)
    res = cr._run_single_page(CourseResult(), 2.0, True, 1, time.time())
    if not calls:
        return False, "作业页没有走答题引擎（被当成课程页/普通页了）"
    return True, f"识别为作业页并转交答题引擎（标题：{calls[0]!r}）"


@case("course-cx-single-exam", "course",
      "单页自动：考试页面明确拒绝，不代做")
def _c_course_cx_single_exam(d):
    from dsh_solver.course import CourseResult
    d.open(url_of("chaoxing_exam.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    cr.single_page = True
    calls = []
    cr._run_single_page_quiz = lambda res, t0, title="": (calls.append(title) or res)
    res = cr._run_single_page(CourseResult(), 2.0, True, 1, time.time())
    if res.stopped_reason != "考试页面不代做":
        return False, f"没有拒绝考试页：{res.stopped_reason!r}"
    if calls:
        return False, "考试页竟然走了答题引擎"
    return True, "考试页被明确拒绝"


@case("course-cx-tabs-inframe", "course",
      "栏目条在 #iframe 里面时也要找得到、点得动")
def _c_course_cx_tabs_inframe(d):
    d.open(url_of("chaoxing_tabs_inframe.html"))
    d.wait_for_load()
    cr = _runner_on(d)

    if not cr._is_chaoxing_tabs_course():
        return False, "栏目条套在 #iframe 里时没认出来（只扫了主文档？）"

    texts = cr._cx_tab_texts()
    if len(texts) != 6:
        return False, f"栏目条读成了 {len(texts)} 条：{' | '.join(texts)}"

    target = next((t for t in texts if "学习视频" in t), "")
    if not cr._cx_click_tab_text(target):
        return False, f"点「{target}」以后页面指纹没变化（跨框架点击没生效）"

    info: dict = {}
    for _ in range(20):
        info = cr._any_video()
        if info.get("found"):
            break
        time.sleep(0.5)
    if not info.get("found"):
        return False, "跨框架点开了「学习视频」，但找不到 <video>"

    # 顺带验一下：播放按钮的**真实鼠标点击**也要能跨框架换算到正确坐标
    note = cr._cx_press_play(info.get("_frame"))
    if not note or float(cr._any_video().get("duration") or 0) <= 0:
        return False, f"跨框架点播放没生效（{note or '没有任何说明'}）"

    dur = float(cr._any_video().get("duration") or 0)
    return True, f"栏目 {len(texts)} 条（在子框架里）；点「{target}」→ {note} → 时长 {dur:.0f} 秒"


@case("course-cx-tabs-run", "course",
      "「横向栏目」整条路径能跑通：点栏目 → 播视频 → 记成一节")
def _c_course_cx_tabs_run(d):
    from dsh_solver.course import CourseResult
    d.open(url_of("chaoxing_tabs.html"))
    d.wait_for_load()
    cr = _runner_on(d)
    # max_lessons=1：点开「学习视频」播完就停 —— 自测里不跑满整门课。
    # 栏目排序把"视频"那条放最前，所以这里只用点一次栏目。
    res = cr._run_chaoxing_tabs_course(CourseResult(), 4.0, True, 1, time.time())
    if not res.ok or not res.lessons:
        return False, f"没播成：{res.stopped_reason or '（没有停止原因）'}"
    r0 = res.lessons[0]
    if not r0.finished or r0.duration <= 0:
        return False, (f"播了但没算完成：finished={r0.finished} "
                       f"duration={r0.duration:.0f} note={r0.note}")
    return True, f"共 {len(res.lessons)} 节，首节 {r0.duration:.0f} 秒"


# ---------------------------------------------------------------------------
def run(only: str = "") -> int:
    from dsh_solver.browser import BrowserDriver

    sd = site_dir()
    print(f"\n  自测页目录：{sd}")
    if not sd.is_dir():
        print("  ✘ 找不到自测页目录，无法运行")
        return 2

    todo = [c for c in CASES if not only or c[1] == only or c[0] == only]
    if not todo:
        print(f"  ✘ 没有匹配的用例（筛选条件 {only!r}）")
        return 2

    print(f"  共 {len(todo)} 个用例\n")
    passed = failed = 0
    fails: list[str] = []
    for name, group, desc, fn in todo:
        d = None
        try:
            d = BrowserDriver(headless=True)
            ok, detail = fn(d)                       # type: ignore[misc]
        except Exception as e:
            ok, detail = False, f"{type(e).__name__}: {e}"
            if "-v" in sys.argv:
                traceback.print_exc()
        finally:
            if d is not None:
                try:
                    d.close()
                except Exception:
                    pass
        mark = "✔" if ok else "✘"
        print(f"  {mark} [{group}] {name:<16} {detail}")
        if ok:
            passed += 1
        else:
            failed += 1
            fails.append(name)

    print()
    print(f"  {passed} / {passed + failed} 通过")
    if fails:
        print(f"  失败：{', '.join(fails)}")
    return 0 if failed == 0 else 1


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if "--list" in sys.argv:
        print("\n  可用用例：")
        for name, group, desc, _ in CASES:
            print(f"    [{group}] {name:<16} {desc}")
        print()
        return 0
    if not (site_dir() / "exam.html").exists():
        print("\n  ⚠ 没找到自测页（exam.html）。")
        print("    源码仓库里它们是 tests\\site\\；打包后的交付版不含这些文件。")
        print("    要用自测功能，请在源码仓库里运行本脚本。\n")
        return 2
    return run(args[0] if args else "")


if __name__ == "__main__":
    sys.exit(main())
