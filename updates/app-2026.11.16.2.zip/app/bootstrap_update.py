"""启动前把暂存的新版本换到 `app\\` 上（昔涟自习室）。

为什么单独一个文件、而且不 import `dsh_solver`：
  `server.py` 必须在**导入任何 dsh_solver 模块之前**跑完这一步。
  否则包已经按旧路径进了 sys.modules / sys.path，目录换完了，跑的还是旧代码。

流程（全部是本地文件操作，不联网）：
  1. 读 out\\updates\\pending.json（update.py 下载并解压后写的）
  2. 校验暂存目录在 out\\updates 之内、build 号对得上、server.py 在
  3. app → app.old（旧的挪开，留作回滚）
  4. out\\updates\\staged\\<build>\\app → app
  5. 成功写 last.json、删 pending；失败自动把 app.old 换回去

任何异常都只写日志、不抛给启动流程 —— 更新坏了绝不能连累软件打不开。
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

LOG_NAME = "update.log"


def _log(out_dir: Path, text: str) -> None:
    try:
        upd = out_dir / "updates"
        upd.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(upd / LOG_NAME, "a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {text}\n")
    except Exception:
        pass


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def apply_pending(app_dir: str | Path, out_dir: str | Path | None = None) -> str | None:
    """有暂存更新就换上去，返回新 build 号；没有/失败返回 None。"""
    app_dir = Path(app_dir).resolve()
    if out_dir is None:
        out_dir = Path(os.environ.get("DSHS_OUT_DIR") or (app_dir.parent / "out"))
    out_dir = Path(out_dir).resolve()
    upd = out_dir / "updates"

    pending = _read_json(upd / "pending.json")
    if not pending:
        return None

    build = str(pending.get("build") or "")
    try:
        staged = Path(str(pending.get("staged") or "")).resolve()
    except Exception:
        staged = Path("")

    # ---- 校验 ----
    try:
        staged.relative_to(upd.resolve())
    except Exception:
        _log(out_dir, f"放弃：暂存路径越界 {staged}")
        _drop_pending(upd)
        return None

    if not build or not staged.is_dir() or not (staged / "server.py").is_file():
        _log(out_dir, f"放弃：暂存目录不完整（build={build!r}，{staged}）")
        _drop_pending(upd)
        return None

    info = _read_json(staged / "build.json")
    if str(info.get("build") or "") != build:
        _log(out_dir, f"放弃：暂存 build 号不符（{info.get('build')!r} != {build!r}）")
        _drop_pending(upd)
        return None

    old_build = str(_read_json(app_dir / "build.json").get("build") or "")
    if old_build == build:
        _log(out_dir, f"跳过：已经是 {build}")
        _drop_pending(upd)
        return None

    # ---- 换目录（带回滚） ----
    bak = app_dir.with_name(app_dir.name + ".old")
    renamed = True
    try:
        if bak.exists():
            shutil.rmtree(bak)
        os.rename(app_dir, bak)
    except Exception as e:  # 旧目录挪不开（被别的进程当 cwd / 权限）
        renamed = False
        _log(out_dir, f"整目录改名失败（{type(e).__name__}: {e}），改走就地覆盖")

    if not renamed:
        return _apply_inplace(app_dir, staged, build, out_dir)

    try:
        shutil.move(str(staged), str(app_dir))
    except Exception as e:
        _log(out_dir, f"替换失败：{type(e).__name__}: {e}，开始回滚")
        try:
            if app_dir.exists():
                shutil.rmtree(app_dir)
            os.rename(bak, app_dir)
            _log(out_dir, "回滚完成，仍是旧版本")
        except Exception as e2:
            _log(out_dir, f"⚠ 回滚也失败：{type(e2).__name__}: {e2}；"
                          f"旧版本在 {bak}")
        return None

    # ---- 成功 ----
    _write_json(upd / "last.json", {
        "build": build, "from": old_build, "at": time.time(),
    })
    _log(out_dir, f"更新完成：{old_build or '未知'} → {build}")
    _drop_pending(upd)
    # 暂存和下载缓存都不必留着（回滚靠 app.old）
    shutil.rmtree(upd / "staged", ignore_errors=True)
    shutil.rmtree(upd / "download", ignore_errors=True)
    return build


def _apply_inplace(app_dir: Path, staged: Path, build: str,
                   out_dir: Path) -> str | None:
    """兜底：目录挪不开时，把暂存的 `app\\` 逐个文件覆盖到现有的 `app\\` 上。

    为什么会走到这里：
      程序自己就住在 `app\\` 里（进程 cwd 是它，或者已加载的模块句柄），
      Windows 于是拒绝 `os.rename(app_dir, app_dir.old)` —— 报 WinError 32
      「另一个程序正在使用此文件」。而**逐个文件覆盖是允许的**：
      Python 把源码读进内存之后就不再锁着 `.py` 文件了。

    代价（可接受）：
      ① 没有 `app.old` 可回滚 —— 更新包已通过 sha256 校验，风险很低；
      ② 旧版里多出来、新版里没有的文件会留下 —— 它们不会被 import，无害。
    """
    upd = out_dir / "updates"
    n = 0
    for src in sorted(staged.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(staged)
        dst = app_dir / rel
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            n += 1
        except Exception as e:
            _log(out_dir, f"就地覆盖失败 {rel}：{type(e).__name__}: {e}")
            return None

    info = _read_json(app_dir / "build.json")
    if str(info.get("build") or "") != build:
        # 文件都覆盖完了但版本号没落上 —— 说明包不对，仍按失败处理
        _log(out_dir, f"就地覆盖后 build 号仍是 {info.get('build')!r}，按失败处理")
        return None

    _write_json(upd / "last.json", {"build": build, "mode": "inplace",
                                    "files": n, "at": time.time()})
    _log(out_dir, f"更新完成（就地覆盖 {n} 个文件）→ {build}")
    _drop_pending(upd)
    shutil.rmtree(upd / "staged", ignore_errors=True)
    shutil.rmtree(upd / "download", ignore_errors=True)
    return build


def _drop_pending(upd: Path) -> None:
    try:
        (upd / "pending.json").unlink()
    except Exception:
        pass
    shutil.rmtree(upd / "staged", ignore_errors=True)