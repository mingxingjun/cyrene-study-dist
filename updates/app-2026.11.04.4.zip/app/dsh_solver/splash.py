# -*- coding: utf-8 -*-
r"""开屏动画（splash）—— 双击图标到界面出现之间的那几秒，别让用户干瞪眼。

## 为什么必须有它

启动链是：双击 exe → 启动器找浏览器、起 python → python 起本地服务 →
启动器再用 Edge 的 `--app` 开一个独立窗口 → 页面加载完才算"出来了"。
python 自己（0.3 秒）和本地服务（优化后 0.2 秒）都很快，
**慢的是两头**：启动器自己的准备，以及 Edge 冷启动（常常 2~5 秒）。
这段时间屏幕上什么都没有 —— 用户看到的就是"点了没反应"。

## 为什么是 ctypes + Win32，而不是别的

- **tkinter 用不了**：内置运行时里没有 `_tkinter.pyd`，也没有 `tcl` 目录，
  `import tkinter` 直接 `ModuleNotFoundError`（实测）。
- **不在页面里做**：页面要等浏览器窗口开出来才存在，而这几秒正是
  窗口还没出现的时候。要盖住这段空白，只能**从 python 进程里**弹一个原生窗口。
- **不引第三方库**：这是"拷贝即用"的便携软件，多一个依赖就多一份会坏的东西。

## 为什么画法这么绕（关键坑）

GDI 在 32 位 DIB 上**不写 alpha 通道**。指望用 `RoundRect` + GDI 画一个
带透明圆角的面板，出来的圆角一定是**硬锯齿**（而且整块要么全不透明、
要么靠颜色键抠洞，边缘一样毛）。

所以这里分两步：

1. **面板（渐变底 + 抗锯齿圆角 + 边框 + 进度条底槽）在 Python 里逐像素算一次**。
   只有 460×264 ≈ 12 万像素，一次算完约 0.1 秒，之后每帧直接复用。
2. **文字先用 GDI 画成灰度遮罩**（黑底白字、灰度抗锯齿），读回像素后
   按覆盖率把它合成到面板上 —— 白字就有了抗锯齿，也不必自己做字形。

`UpdateLayeredWindow` 走 `AC_SRC_ALPHA`，要求像素是**预乘 alpha**
（RGB 已经乘过 alpha），所以下面写入时一律预乘。

## 另外两个必须处理的坑

- **句柄是 64 位的**。ctypes 对没声明 `restype` 的函数按 `c_int` 处理，
  HDC/HBITMAP 这类句柄会被**截断成 32 位**，之后传给别的 API 就是垃圾 ——
  症状是 `argtypes` 报 `OverflowError: int too long to convert`。
  所以下面 `_bind()` 里把用到的手柄函数全都声明齐。
- **进程必须是 DPI 感知的**。否则 Windows 会把我们的窗口**位图拉伸**，
  150% 缩放下全是模糊的。所以开工前先设一次 per-monitor DPI 感知。

## 可靠性

全程 `try/except`。开屏动画坏了**绝不能影响启动** —— 顶多是没有动画。
窗口在独立线程里跑（Win32 窗口要有自己的消息循环），主流程只通过
`request_close()` 通知它淡出。
"""
from __future__ import annotations

import ctypes
import math
import threading
import time
from ctypes import wintypes

# ---------------------------------------------------------------------------
# Win32
# ---------------------------------------------------------------------------
_user32 = ctypes.WinDLL("user32", use_last_error=True)
_gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
# ⚠ GetModuleHandleW 在 kernel32 里，不在 user32（第一次就写错了，
#   报错是 "function 'GetModuleHandleW' not found"，很容易看岔）
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
SW_SHOWNOACTIVATE = 4
WS_EX_LAYERED = 0x00080000
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_NOACTIVATE = 0x08000000
ULW_ALPHA = 0x00000002
AC_SRC_OVER = 0x00
AC_SRC_ALPHA = 0x01
DIB_RGB_COLORS = 0
BI_RGB = 0
TRANSPARENT = 1
ANTIALIASED_QUALITY = 4
FW_SEMIBOLD = 600
IDC_ARROW = 32512
LOGPIXELSX = 88
DPI_PER_MONITOR_V2 = -4

WM_DESTROY = 0x0002
WM_TIMER = 0x0113

LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT,
                             wintypes.WPARAM, wintypes.LPARAM)


class _POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class _SIZE(ctypes.Structure):
    _fields_ = [("cx", wintypes.LONG), ("cy", wintypes.LONG)]


class _BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


class _WNDCLASSEXW(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("style", wintypes.UINT),
                ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                ("cbWndExtra", ctypes.c_int), ("hInstance", wintypes.HINSTANCE),
                ("hIcon", wintypes.HICON), ("hCursor", wintypes.HANDLE),
                ("hbrBackground", wintypes.HBRUSH), ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR), ("hIconSm", wintypes.HICON)]


def _bind() -> None:
    """把用到的手柄函数声明齐。

    ⚠ 不声明就会出事：ctypes 默认按 `c_int`（32 位）处理 64 位句柄，
      拿到的 HDC/HBITMAP 已经被截断，再传回去就是"句柄无效"或
      `OverflowError: int too long to convert` —— 而且报错位置离真正的原因很远。
    """
    u, g = _user32, _gdi32
    _kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    _kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    u.GetDC.restype = wintypes.HDC
    u.GetDC.argtypes = [wintypes.HWND]
    u.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
    u.GetSystemMetrics.argtypes = [ctypes.c_int]
    u.LoadCursorW.argtypes = [wintypes.HINSTANCE, ctypes.c_void_p]
    u.LoadCursorW.restype = wintypes.HANDLE
    u.RegisterClassExW.argtypes = [ctypes.POINTER(_WNDCLASSEXW)]
    u.UnregisterClassW.argtypes = [wintypes.LPCWSTR, wintypes.HINSTANCE]
    u.CreateWindowExW.restype = wintypes.HWND
    u.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT,
                                 wintypes.WPARAM, wintypes.LPARAM]
    u.DefWindowProcW.restype = LRESULT
    u.DestroyWindow.argtypes = [wintypes.HWND]
    u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u.SetTimer.argtypes = [wintypes.HWND, ctypes.c_size_t, wintypes.UINT, ctypes.c_void_p]
    u.SetTimer.restype = ctypes.c_size_t
    u.KillTimer.argtypes = [wintypes.HWND, ctypes.c_size_t]
    u.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                              wintypes.UINT, wintypes.UINT]
    u.GetMessageW.restype = ctypes.c_int
    u.UpdateLayeredWindow.argtypes = [
        wintypes.HWND, wintypes.HDC, ctypes.POINTER(_POINT), ctypes.POINTER(_SIZE),
        wintypes.HDC, ctypes.POINTER(_POINT), wintypes.DWORD,
        ctypes.POINTER(_BLENDFUNCTION), wintypes.DWORD]
    u.UpdateLayeredWindow.restype = wintypes.BOOL
    u.FillRect.argtypes = [wintypes.HDC, ctypes.POINTER(wintypes.RECT), wintypes.HBRUSH]
    u.FillRect.restype = ctypes.c_int
    u.DrawTextW.argtypes = [wintypes.HDC, wintypes.LPCWSTR, ctypes.c_int,
                            ctypes.POINTER(wintypes.RECT), wintypes.UINT]
    u.DrawTextW.restype = ctypes.c_int

    g.CreateCompatibleDC.restype = wintypes.HDC
    g.CreateCompatibleDC.argtypes = [wintypes.HDC]
    g.DeleteDC.argtypes = [wintypes.HDC]
    g.SelectObject.restype = wintypes.HGDIOBJ
    g.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
    g.CreateDIBSection.restype = wintypes.HBITMAP
    g.CreateDIBSection.argtypes = [
        wintypes.HDC, ctypes.POINTER(_BITMAPINFO), wintypes.UINT,
        ctypes.POINTER(ctypes.c_void_p), wintypes.HANDLE, wintypes.DWORD]
    g.CreateSolidBrush.restype = wintypes.HBRUSH
    g.CreateFontW.restype = wintypes.HFONT
    g.CreateFontW.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
        wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
        wintypes.LPCWSTR]
    g.DeleteObject.argtypes = [wintypes.HGDIOBJ]
    g.SetBkMode.argtypes = [wintypes.HDC, ctypes.c_int]
    g.SetTextColor.argtypes = [wintypes.HDC, wintypes.COLORREF]
    g.GetDeviceCaps.argtypes = [wintypes.HDC, ctypes.c_int]


_bind()


def _enable_dpi_awareness() -> str:
    """让本进程对高 DPI 感知 —— 否则窗口会被系统位图拉伸，150% 下全糊。"""
    try:
        if _user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(DPI_PER_MONITOR_V2)):
            return "per-monitor v2"
    except Exception:
        pass
    try:
        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        # 返回 HRESULT：0 = 成功，E_ACCESSDENIED = "已经设过了"（也算成功）
        if int(shcore.SetProcessDpiAwareness(2)) in (0, -2147024891):
            return "per-monitor"
    except Exception:
        pass
    try:
        if _user32.SetProcessDPIAware():
            return "system"
    except Exception:
        pass
    return ""



# ---------------------------------------------------------------------------
# 视觉参数（**严格对齐界面 style.css 里的 :root 配色**）
#
# ⚠ 一开始这组颜色我按"深蓝 + 蓝紫"配的，和真实界面撞得厉害 ——
#   界面的主题其实是**深绿底 + 浅绿强调**（`--bg:#0e1410` / `--accent:#c0f090`）。
#   开屏和主界面颜色对不上，衔接的那一下会特别明显。所以这里逐个对着抄。
#
# ★ 2026-10-26：界面换成 theme-cyrene.css（昔涟粉紫毛玻璃），这里同步改：
#   深紫底 `#150f1b` + 玫粉强调 `#ef6ba8` / 浅粉 `#f7a6cd`。
#   开屏和主界面必须继续一致 —— 下面每个值都对着 theme-cyrene.css 的 :root 抄。
# ---------------------------------------------------------------------------
_W_BASE, _H_BASE = 460, 264          # 96 DPI 下的逻辑尺寸
_RADIUS = 18.0

# ★ 2026-11-03：界面新增「青瓷月白」主题（web/theme-celadon.css，宣纸底 + 青瓷绿）。
#   开屏必须跟着主界面走 —— 一块粉紫的开屏淡出成米白的书房，那一下会很突兀。
#   两套调色板都留在这里，**改一行 SPLASH_PALETTE 就能切**，不用再翻绘图代码：
#     "celadon" → theme-celadon.css 的 :root
#     "cyrene"  → theme-cyrene.css 的 :root（旧的粉紫毛玻璃）
_PALETTES = {
    "cyrene": {
        # 夜色紫底 + 玫粉强调
        "bg_top": (34, 20, 36),          # 比 --bg 略亮
        "bg_bottom": (21, 15, 27),       # --bg       #150f1b
        "border": (74, 44, 68),          # --line 实色近似 #4a2c44
        "title": (249, 238, 244),        # --text     #f9eef4
        "sub": (217, 185, 202),          # --text-dim #d9b9ca
        "track": (44, 26, 42),           # --panel 实色近似 #2c1a2a
        "accent_a": (239, 107, 168),     # --accent-2 #ef6ba8
        "accent_b": (247, 166, 205),     # --accent   #f7a6cd
    },
    "celadon": {
        # 宣纸底 + 青瓷绿（浅色开屏：深墨字压在米白卡上）
        "bg_top": (251, 250, 245),       # #FBFAF5 纸面
        "bg_bottom": (238, 236, 227),    # #EEECE3 纸底偏暖
        "border": (198, 205, 195),       # #C6CDC3 一圈很淡的墨绿灰
        "title": (27, 38, 32),           # #1B2620 墨
        "sub": (84, 97, 91),             # #54615B 次级
        "track": (223, 224, 214),        # #DFE0D6 进度槽
        "accent_a": (63, 117, 99),       # #3F7563 青瓷
        "accent_b": (110, 156, 136),     # #6E9C88 浅青
    },
}
SPLASH_PALETTE = "celadon"           # ← 换界面主题时同步改这里

_PALETTE = _PALETTES.get(SPLASH_PALETTE, _PALETTES["cyrene"])
_BG_TOP = _PALETTE["bg_top"]
_BG_BOTTOM = _PALETTE["bg_bottom"]
_BORDER = _PALETTE["border"]
_TITLE_COLOR = _PALETTE["title"]
_SUB_COLOR = _PALETTE["sub"]
_TRACK = _PALETTE["track"]
_ACCENT_A = _PALETTE["accent_a"]
_ACCENT_B = _PALETTE["accent_b"]
_PERIOD = 1.85                       # 进度条来回一趟的秒数
_FADE_IN = 0.26
_FADE_OUT = 0.22
_MAX_ALIVE = 25.0                    # 兜底：再久也得自己消失
# ⚠ 90 → 25（2026-10-23 用户反馈"启动动画很久才消失"）。
#   开屏本来应该由页面调 `/api/ready` 关掉；但那条链路是
#   "/api/hello → /api/config → /api/state → ready"，任何一步慢都会拖住它。
#   90 秒的兜底意味着"哪怕前端彻底挂了，也要压着屏幕一分半"—— 用户会觉得
#   软件卡死。25 秒足够覆盖慢机器冷启动，又不至于让人以为它不动了。
_TITLE = "昔涟自习室 · Cyrene Study"


# ---------------------------------------------------------------------------
_CLOSE = threading.Event()
_STARTED = threading.Event()
_STATE = {"ok": False, "why": ""}


def available() -> bool:
    """开屏动画起来了没有（给日志/自检用）。"""
    return bool(_STATE.get("ok"))


def start(title: str = _TITLE, subtitle: str = "正在启动…") -> bool:
    """把开屏动画弹出来。**立刻返回**，动画在后台线程里跑。

    重复调用只生效一次。任何失败都只是"没有动画"，不影响启动。
    """
    if _STARTED.is_set():
        return _STATE.get("ok", False)
    _STARTED.set()
    try:
        t = threading.Thread(target=_run, args=(title, subtitle),
                             name="dsh-splash", daemon=True)
        t.start()
        # 稍等一下，好让调用方知道到底成没成（也就一百多毫秒）
        for _ in range(90):
            if _STATE.get("ok") or _STATE.get("why"):
                break
            time.sleep(0.01)
    except Exception as e:
        _STATE["why"] = f"{type(e).__name__}: {e}"
    return bool(_STATE.get("ok"))


def request_close() -> None:
    """请求淡出并销毁。可以重复调用。"""
    _CLOSE.set()


# ---------------------------------------------------------------------------
# 绘制
# ---------------------------------------------------------------------------
def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _smooth(t: float) -> float:
    """smoothstep：两头慢中间快，用来做"丝滑"的缓动。"""
    t = max(0.0, min(1.0, t))
    return t * t * (3.0 - 2.0 * t)


def _ease_out(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1.0 - (1.0 - t) ** 3


def _over(dst: int, src: int, alpha: float) -> int:
    return int(round(dst + (src - dst) * alpha))


def _render_base(w: int, h: int, dpi_scale: float) -> bytearray:
    """画静态底图（RGBA，未预乘，逐像素）。

    只算一次。圆角用"到圆角矩形的有符号距离"求覆盖率，
    这样边缘是**抗锯齿**的，而不是 GDI 那种硬锯齿。
    """
    buf = bytearray(w * h * 4)
    r = _RADIUS * dpi_scale
    # 圆角矩形的"内缩矩形"：四条边各内缩 r，角上按到内缩矩形的距离算
    lx, ty, rx, by = r, r, w - r, h - r
    for y in range(h):
        # 竖直渐变
        t = y / max(1, h - 1)
        bg = (_lerp(_BG_TOP[0], _BG_BOTTOM[0], t),
              _lerp(_BG_TOP[1], _BG_BOTTOM[1], t),
              _lerp(_BG_TOP[2], _BG_BOTTOM[2], t))
        fy = float(y)
        for x in range(w):
            fx = float(x)
            dx = lx - fx if fx < lx else (fx - rx if fx > rx else 0.0)
            dy = ty - fy if fy < ty else (fy - by if fy > by else 0.0)
            dist = math.hypot(dx, dy)
            # 覆盖率：距离边界 1 像素内做线性过渡 → 抗锯齿
            cov = 1.0 if dist <= r - 0.5 else (
                0.0 if dist >= r + 0.5 else (r + 0.5 - dist))
            if cov <= 0.0:
                continue
            rr, gg, bb = bg
            # 边框：距离边缘 1.2px 以内的提亮一点，看起来更"精致"
            if dist >= r - 1.4:
                k = 0.55 * (1.0 - abs(dist - (r - 1.4)) / 1.4)
                k = max(0.0, min(0.55, k))
                rr, gg, bb = (_over(rr, _BORDER[0], k),
                              _over(gg, _BORDER[1], k),
                              _over(bb, _BORDER[2], k))
            o = (y * w + x) * 4
            buf[o] = int(rr)
            buf[o + 1] = int(gg)
            buf[o + 2] = int(bb)
            buf[o + 3] = int(round(255 * cov))
    return buf


def _text_mask(lines, w: int, h: int, hdc_screen) -> bytes:
    """用 GDI 把文字画成"黑底白字"的灰度遮罩，读回像素。

    为什么绕这一下：字形交给系统（好看、不用自己描边），
    但 GDI 不给 alpha —— 拿灰度当覆盖率再自己合成，两边的好处都占上。
    """
    bmi = _BITMAPINFO()
    bmi.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth = w
    bmi.bmiHeader.biHeight = -h              # 负 = 自上而下
    bmi.bmiHeader.biPlanes = 1
    bmi.bmiHeader.biBitCount = 32
    bmi.bmiHeader.biCompression = BI_RGB

    bits = ctypes.c_void_p()
    hbm = _gdi32.CreateDIBSection(hdc_screen, ctypes.byref(bmi), DIB_RGB_COLORS,
                                  ctypes.byref(bits), None, 0)
    if not hbm or not bits:
        return b""
    memdc = _gdi32.CreateCompatibleDC(hdc_screen)
    old_bm = _gdi32.SelectObject(memdc, hbm)
    try:
        # 黑底
        rect = wintypes.RECT(0, 0, w, h)
        brush = _gdi32.CreateSolidBrush(0x000000)
        _user32.FillRect(memdc, ctypes.byref(rect), brush)
        _gdi32.DeleteObject(brush)
        _gdi32.SetBkMode(memdc, TRANSPARENT)
        _gdi32.SetTextColor(memdc, 0x00FFFFFF)
        for (text, size, weight, x, y, tw) in lines:
            if not text:
                continue
            font = _gdi32.CreateFontW(
                -int(round(size)), 0, 0, 0, weight, 0, 0, 0, 0, 0, 0,
                ANTIALIASED_QUALITY, 0, "Microsoft YaHei UI")
            old_f = _gdi32.SelectObject(memdc, font)
            rc = wintypes.RECT(int(x), int(y), int(x + tw), int(y + size * 2))
            _user32.DrawTextW(memdc, text, -1, ctypes.byref(rc), 0)
            _gdi32.SelectObject(memdc, old_f)
            _gdi32.DeleteObject(font)
        return ctypes.string_at(bits, w * h * 4)
    finally:
        _gdi32.SelectObject(memdc, old_bm)
        _gdi32.DeleteObject(hbm)
        _gdi32.DeleteDC(memdc)


def _composite_text(buf: bytearray, mask: bytes, color, w: int, box) -> None:
    """把灰度遮罩按覆盖率合成到 buf 上（不透明度不变，只改颜色）。"""
    if not mask:
        return
    x0, y0, x1, y1 = box
    cr, cg, cb = color
    for y in range(max(0, y0), min(buf.__len__() // (w * 4), y1)):
        row = y * w
        for x in range(max(0, x0), min(w, x1)):
            a = mask[(row + x) * 4]           # 蓝色通道 = 覆盖率（灰度）
            if not a:
                continue
            k = a / 255.0
            o = (row + x) * 4
            buf[o] = _over(buf[o], cr, k)
            buf[o + 1] = _over(buf[o + 1], cg, k)
            buf[o + 2] = _over(buf[o + 2], cb, k)


def _draw_progress(buf: bytearray, bw: int, geom, phase: float) -> None:
    """在**进度条那一条**的缓冲区上画会动的那截（局部坐标）。

    ⚠ 只在这么一小块上重画，是这套实现能跑到 40fps 的关键：
      整帧 690×396 逐像素预乘一次要 36 毫秒，每帧都做的话 CPU 直接吃满。
      这里只碰约 460×10 的一小条（≈1 毫秒）。
    """
    tx0, ty0, tx1, ty1 = geom["track"]
    track_h = ty1 - ty0
    span = tx1 - tx0
    seg_w = int(span * 0.34)
    # 来回一趟：smoothstep 缓动，两头会自然减速
    tri = abs((phase % 2.0) - 1.0)        # 0→1→0
    pos = _smooth(tri)
    sx = tx0 + int((span - seg_w) * pos)
    rad = track_h / 2.0
    for y in range(ty0, ty1):
        fy = y + 0.5
        row = y * bw
        for x in range(sx, sx + seg_w):
            fx = x + 0.5
            # 两端半圆 → 胶囊形状，边缘 1px 抗锯齿
            dx = 0.0
            if fx < sx + rad:
                dx = (sx + rad) - fx
            elif fx > sx + seg_w - rad:
                dx = fx - (sx + seg_w - rad)
            dy = abs(fy - (ty0 + rad))
            dist = math.hypot(dx, dy)
            cov = 1.0 if dist <= rad - 0.5 else (
                0.0 if dist >= rad + 0.5 else (rad + 0.5 - dist))
            if cov <= 0.0:
                continue
            # 胶囊内部再叠一层横向渐变，中间亮一点
            g = (fx - sx) / max(1, seg_w)
            g = 1.0 - abs(g - 0.5) * 1.6
            g = max(0.0, min(1.0, g))
            col = (_lerp(_ACCENT_A[0], _ACCENT_B[0], g),
                   _lerp(_ACCENT_A[1], _ACCENT_B[1], g),
                   _lerp(_ACCENT_A[2], _ACCENT_B[2], g))
            o = (row + x) * 4
            buf[o] = _over(buf[o], col[0], cov)
            buf[o + 1] = _over(buf[o + 1], col[1], cov)
            buf[o + 2] = _over(buf[o + 2], col[2], cov)
            buf[o + 3] = max(buf[o + 3], int(round(255 * cov)))


def _premultiply(buf: bytearray) -> bytearray:
    """RGBA → 预乘 alpha 的 BGRA（UpdateLayeredWindow 要求的格式）。"""
    out = bytearray(len(buf))
    for i in range(0, len(buf), 4):
        a = buf[i + 3]
        if a == 255:
            out[i] = buf[i + 2]
            out[i + 1] = buf[i + 1]
            out[i + 2] = buf[i]
            out[i + 3] = 255
        elif a:
            out[i] = (buf[i + 2] * a) // 255
            out[i + 1] = (buf[i + 1] * a) // 255
            out[i + 2] = (buf[i] * a) // 255
            out[i + 3] = a
    return out


def _slice_band(rgba: bytes, w: int, band) -> bytes:
    """从整帧 RGBA 里抠出进度条那一条（跨多行，逐行取）。"""
    x0, y0, x1, y1 = band
    bw = (x1 - x0) * 4
    out = bytearray()
    for y in range(y0, y1):
        off = (y * w + x0) * 4
        out += rgba[off:off + bw]
    return bytes(out)


# ---------------------------------------------------------------------------
# 窗口线程
# ---------------------------------------------------------------------------
def _system_scale() -> float:
    try:
        dpi = int(_user32.GetDpiForSystem())
        if dpi > 0:
            return dpi / 96.0
    except Exception:
        pass
    try:
        hdc = _user32.GetDC(0)
        dpi = int(_gdi32.GetDeviceCaps(hdc, 88))       # LOGPIXELSX
        _user32.ReleaseDC(0, hdc)
        if dpi > 0:
            return dpi / 96.0
    except Exception:
        pass
    return 1.0


def _run(title: str, subtitle: str) -> None:
    try:
        _run_inner(title, subtitle)
        _STATE["ok"] = True
    except Exception as e:
        import traceback
        _STATE["why"] = f"{type(e).__name__}: {e}"
        _STATE["trace"] = traceback.format_exc()
    finally:
        _STATE.setdefault("why", "done")

def _run_inner(title: str, subtitle: str) -> None:      # noqa: C901
    _STATE["dpi"] = _enable_dpi_awareness()
    scale = _system_scale()
    w = max(320, int(_W_BASE * scale))
    h = max(200, int(_H_BASE * scale))

    t0 = time.time()
    base = _render_base(w, h, scale)

    hdc_screen = _user32.GetDC(0)
    # ---- 文字遮罩 ----
    pad = int(38 * scale)
    title_size = int(25 * scale)
    sub_size = int(13.5 * scale)
    title_y = int(74 * scale)
    sub_y = title_y + int(40 * scale)
    box_w = w - pad * 2
    mask = _text_mask(
        [(title, title_size, FW_SEMIBOLD, pad, title_y, box_w),
         (subtitle, sub_size, 400, pad, sub_y, box_w)],
        w, h, hdc_screen)
    _composite_text(base, mask, _TITLE_COLOR, w,
                    (pad, title_y, pad + box_w, title_y + title_size * 2))
    _composite_text(base, mask, _SUB_COLOR, w,
                    (pad, sub_y, pad + box_w, sub_y + sub_size * 3))

    # ---- 进度条底槽（也画进静态底图）----
    track_w = int(300 * scale)
    track_h = max(4, int(6 * scale))
    tx0 = (w - track_w) // 2
    ty0 = h - int(64 * scale)
    _fill_track(base, w, tx0, ty0, track_w, track_h, scale)
    geom = {"track": (tx0, ty0, tx0 + track_w, ty0 + track_h)}

    # ---- 把"静态帧"和"进度条那一条"准备好 ----
    # ⚠ 整帧预乘只做一次（约 36ms）。每帧只重画那一小条并单独预乘，
    #   否则 40fps × 36ms 会把 CPU 吃满，动画反而更卡。
    band = (max(0, tx0 - 2), max(0, ty0 - 2),
            min(w, tx0 + track_w + 2), min(h, ty0 + track_h + 2))
    static_premul = bytes(_premultiply(base))
    band_rgba = _slice_band(bytes(base), w, band)
    band_w = band[2] - band[0]
    band_h = band[3] - band[1]
    band_geom = {"track": (tx0 - band[0], ty0 - band[1],
                           tx0 + track_w - band[0], ty0 + track_h - band[1])}

    # ---- 窗口 ----
    hinst = ctypes.c_void_p(_kernel32.GetModuleHandleW(None))
    cls_name = "DshSplashWnd"
    holder = {}

    def _wndproc(hwnd, msg, wp, lp):
        try:
            if msg == WM_TIMER:
                _on_timer(hwnd, holder)
                return 0
            if msg == WM_DESTROY:
                _user32.PostQuitMessage(0)
                return 0
        except Exception:
            pass
        return _user32.DefWindowProcW(hwnd, msg, wp, lp)

    proc = WNDPROC(_wndproc)
    wc = _WNDCLASSEXW()
    wc.cbSize = ctypes.sizeof(_WNDCLASSEXW)
    wc.style = 0
    wc.lpfnWndProc = proc
    wc.hInstance = hinst
    wc.hCursor = _user32.LoadCursorW(None, ctypes.c_void_p(IDC_ARROW))
    wc.lpszClassName = cls_name
    _user32.RegisterClassExW(ctypes.byref(wc))

    sw = int(_user32.GetSystemMetrics(0))
    sh = int(_user32.GetSystemMetrics(1))
    px = (sw - w) // 2
    py = int(sh * 0.34)

    hwnd = _user32.CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
        cls_name, title, WS_POPUP, px, py, w, h, None, None, hinst, None)
    if not hwnd:
        raise RuntimeError(f"CreateWindowExW 失败：{ctypes.get_last_error()}")
    # ⚠ 一定要显式显示。`CreateWindowExW` 不带 `WS_VISIBLE` 时窗口是**隐藏**的，
    #   而 `UpdateLayeredWindow` 在隐藏窗口上照样"成功" —— 于是代码不报错、
    #   截图里却什么都没有（实测就是这么踩的，查了好一阵）。
    _user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)

    # ---- 后备 DIB ----
    bmi = _BITMAPINFO()
    bmi.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth = w
    bmi.bmiHeader.biHeight = -h
    bmi.bmiHeader.biPlanes = 1
    bmi.bmiHeader.biBitCount = 32
    bmi.bmiHeader.biCompression = BI_RGB
    bits = ctypes.c_void_p()
    hbm = _gdi32.CreateDIBSection(hdc_screen, ctypes.byref(bmi), DIB_RGB_COLORS,
                                  ctypes.byref(bits), None, 0)
    memdc = _gdi32.CreateCompatibleDC(hdc_screen)
    _gdi32.SelectObject(memdc, hbm)

    holder.update({"hwnd": hwnd, "memdc": memdc, "bits": bits, "w": w, "h": h,
                   "static_premul": static_premul,
                   "band": band, "band_rgba": band_rgba, "band_w": band_w,
                   "band_h": band_h, "band_geom": band_geom,
                   "t0": t0, "phase0": time.time(), "fading": None})

    _user32.SetTimer(hwnd, 1, 25, None)         # ~40fps：够顺，也不烧 CPU
    # 先画一帧再进消息循环，免得窗口先以"全透明"露一下脸
    _on_timer(hwnd, holder)
    # ★ 到这里窗口已经在屏幕上了 —— 现在才算"开屏动画起来了"
    _STATE["ok"] = True

    # ---- 消息循环 ----
    msg = wintypes.MSG()
    while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        _user32.TranslateMessage(ctypes.byref(msg))
        _user32.DispatchMessageW(ctypes.byref(msg))

    try:
        _user32.KillTimer(hwnd, 1)
        _gdi32.DeleteDC(memdc)
        _gdi32.DeleteObject(hbm)
        _user32.ReleaseDC(0, hdc_screen)
        _user32.UnregisterClassW(cls_name, hinst)
    except Exception:
        pass


def _fill_track(buf: bytearray, w: int, x0: int, y0: int, tw: int, th: int,
                scale: float) -> None:
    """进度条底槽：胶囊形，抗锯齿。"""
    rad = th / 2.0
    for y in range(y0, y0 + th):
        fy = y + 0.5
        for x in range(x0, x0 + tw):
            fx = x + 0.5
            dx = 0.0
            if fx < x0 + rad:
                dx = (x0 + rad) - fx
            elif fx > x0 + tw - rad:
                dx = fx - (x0 + tw - rad)
            dy = abs(fy - (y0 + rad))
            dist = math.hypot(dx, dy)
            cov = 1.0 if dist <= rad - 0.5 else (
                0.0 if dist >= rad + 0.5 else (rad + 0.5 - dist))
            if cov <= 0.0:
                continue
            o = (y * w + x) * 4
            buf[o] = _over(buf[o], _TRACK[0], cov)
            buf[o + 1] = _over(buf[o + 1], _TRACK[1], cov)
            buf[o + 2] = _over(buf[o + 2], _TRACK[2], cov)


def _on_timer(hwnd, holder) -> None:
    now = time.time()
    age = now - holder["t0"]
    if holder["fading"] is None and (_CLOSE.is_set() or age > _MAX_ALIVE):
        holder["fading"] = now
    alpha = 255.0
    if holder["fading"] is None:
        alpha = 255.0 * _ease_out(age / _FADE_IN)
    else:
        alpha = 255.0 * (1.0 - _ease_out((now - holder["fading"]) / _FADE_OUT))
        if alpha <= 2.0:
            _user32.DestroyWindow(hwnd)
            return

    w, h = holder["w"], holder["h"]
    # 整帧从"静态预乘结果"拷一份（C 级 memcpy，很快）
    frame = bytearray(holder["static_premul"])
    # 只重画进度条那一条：局部坐标系下重画 → 局部预乘 → 贴回整帧
    bw, bh = holder["band_w"], holder["band_h"]
    b = bytearray(holder["band_rgba"])
    _draw_progress(b, bw, holder["band_geom"], (now - holder["phase0"]) / _PERIOD)
    pb = _premultiply(b)
    bx, by = holder["band"][0], holder["band"][1]
    for r in range(bh):
        off = ((by + r) * w + bx) * 4
        frame[off:off + bw * 4] = pb[r * bw * 4:(r + 1) * bw * 4]
    ctypes.memmove(holder["bits"], bytes(frame), len(frame))

    blend = _BLENDFUNCTION(AC_SRC_OVER, 0, int(max(0, min(255, alpha))), AC_SRC_ALPHA)
    size = _SIZE(w, h)
    src = _POINT(0, 0)
    _user32.UpdateLayeredWindow(
        hwnd, None, None, ctypes.byref(size), holder["memdc"], ctypes.byref(src),
        0, ctypes.byref(blend), ULW_ALPHA)
