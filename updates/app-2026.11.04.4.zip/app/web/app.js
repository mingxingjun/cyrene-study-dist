/* ===== 昔涟自习室 · Cyrene Study · 前端逻辑 =====
   与后端通过两种通道通信：
     - SSE(/api/events)：日志、状态、截图、作答记录、运行态
     - fetch POST：保存设置、启动/停止任务、测试模型
   刻意不引入任何前端框架，双击即可运行，离线也不缺东西。 */

const $ = (id) => document.getElementById(id);

/* ---------------- 全局错误兜底 ----------------
   为什么要有：用户反馈"点了只是变色、什么都没发生" —— 最常见的原因就是
   某个 click 处理器里**先改了 class（所以会变色）、紧接着抛了异常**，
   而浏览器把异常吞在控制台里，界面上一点提示都没有。
   把这类异常显式写到右下角日志 + 弹一次 toast，用户才能把"点不动"变成
   一句可反馈的话；我们也能从日志里直接看到是哪一行。
   ⚠ 自己绝不能再抛 —— 否则会变成错误死循环。 */
let _lastUiErr = 0;
const _BENIGN_ERR = /AbortError|The user aborted|Failed to fetch|Load failed|NetworkError/i;
function reportUiError(where, msg) {
  try {
    const text = String(msg || "未知错误");
    if (_BENIGN_ERR.test(text)) return;          // 停止任务时的正常中断，不报
    if (typeof addLog === "function") addLog("error", `界面脚本出错（${where}）：${text}`);
    const now = Date.now();
    if (now - _lastUiErr > 5000) {                // 同一条错别刷屏
      _lastUiErr = now;
      if (typeof toast === "function") toast("界面脚本出错，详情见右侧日志", "error", 8000);
    }
  } catch (e) { /* 兜底自己不能再抛 */ }
}
window.addEventListener("error", (e) => {
  try {
    reportUiError("window", (e && (e.message || (e.error && e.error.message))) || e);
  } catch (x) { /* ignore */ }
});
window.addEventListener("unhandledrejection", (e) => {
  try {
    const r = e && e.reason;
    reportUiError("promise", (r && (r.message || r)) || "未处理的 Promise 拒绝");
  } catch (x) { /* ignore */ }
});

/* ---------------- 视图切换 ---------------- */
document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    // ★ 先确认目标视图存在，再动 class。
    //
    //   原来的顺序是"先给按钮加 active、再取 #view-xxx" —— 一旦安装包里
    //   index.html 与 app.js 不是同一版（少了一节 / 改了 data-view），
    //   `$("view-"+...)` 返回 null，`classList` 抛 TypeError：
    //   **按钮变绿了，页面却什么都没换**，控制台里只有一行红字。
    //   实测（把 usage 的 data-view 改成不存在的名字）：
    //     视图 view-settings → None，导航变绿，异常 Cannot read properties of null
    const target = $("view-" + btn.dataset.view);
    if (!target) {
      reportUiError("nav", `找不到视图 view-${btn.dataset.view}（安装包不完整？）`);
      return;
    }
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
    btn.classList.add("active");
    target.classList.add("active");
    // ★ 2026-10-26：切页时把内容区滚回顶部。
    //   新版外壳的滚动容器还是 .main（`.view` 自己不滚），
    //   在「设置」里滚到一半再切到别的页，新页面会保持旧滚动位置，
    //   看起来像"标题丢失/页面从中间开始"。
    const _sc = document.querySelector(".main");
    if (_sc) _sc.scrollTop = 0;
    // 进「用量监控」就刷一次数据；其余视图没有额外动作
    if (btn.dataset.view === "usage") refreshUsage();
    // 进「关于」刷一次更新状态（更新卡片在那儿，别让用户看到过期数字）
    if (btn.dataset.view === "about") refreshUpdate();
  });
});

/* ---------------- Toast ---------------- */
function toast(text, level = "info", ms = 4200) {
  const el = document.createElement("div");
  el.className = "toast " + level;
  el.textContent = text;
  $("toasts").appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .3s, transform .3s";
    el.style.opacity = "0";
    el.style.transform = "translateX(16px)";
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/* ---------------- 日志 ---------------- */
const MAX_LOG = 800;
function addLog(level, text) {
  const box = $("log");
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
  const t = new Date().toLocaleTimeString("zh-CN", { hour12: false });
  const row = document.createElement("div");
  row.className = "ln " + (level || "info");
  const tEl = document.createElement("span");
  tEl.className = "t";
  tEl.textContent = t;
  const mEl = document.createElement("span");
  mEl.className = "m";
  mEl.textContent = text;
  row.appendChild(tEl);
  row.appendChild(mEl);
  box.appendChild(row);
  while (box.childElementCount > MAX_LOG) box.removeChild(box.firstChild);
  if (atBottom) box.scrollTop = box.scrollHeight;
}

/* ---------------- 状态 ---------------- */
function setStatus(text, kind) {
  const chip = $("statusChip");
  chip.textContent = text;
  chip.className = "status-chip" + (kind ? " " + kind : "");
}

function setRunning(running) {
  $("btnStart").disabled = running;
  $("btnStop").disabled = !running;
  // ★ 网址随时可改：一次运行用的是启动那一刻的值，改它不影响已经在跑的任务；
  //   原来运行期间禁用输入框，用户想"先改好下一轮的网址"就被卡住了。
}

/* ---------------- 截图 ---------------- */
function refreshShot() {
  const img = $("shot");
  img.src = "/api/latest-shot?t=" + Date.now();
}
$("btnShot").addEventListener("click", refreshShot);
$("shot").addEventListener("load", () => {
  $("shot").classList.add("on");
  $("shotEmpty").style.display = "none";
});

/* ---------------- 作答记录 ---------------- */
let ansCount = 0;
// 条数上限：和日志的 MAX_LOG 同理 —— 只限高还不够，DOM 节点也得有上限，
// 否则一次几千题的作业会让页面越来越卡。
const MAX_ANS = 300;

// ★ 2026-10-22：多收 reason / confidence。
//
//   为什么：提示词一直要求模型返回 reason，`Decision` 也一直带着，
//   但旧版界面只画一个字母 —— 这条数据白白浪费了。
//   低置信度整行标黄（阈值和落笔门槛一致），做成复核台的雏形。
const LOW_CONF = 0.35;

function addAnswer(stem, answer, reason, confidence) {
  if (ansCount === 0) $("ansList").innerHTML = "";
  ansCount++;

  // 外层包一层：这样 `.ans-row` 的样式一行不用改
  const item = document.createElement("div");
  item.className = "ans-item";

  const row = document.createElement("div");
  row.className = "ans-row";
  const a = document.createElement("span");
  a.className = "a";
  a.textContent = answer || "?";
  const q = document.createElement("span");
  q.className = "q";
  q.textContent = stem || "(无题干)";
  q.title = stem || "";
  row.appendChild(a);
  row.appendChild(q);

  // 置信度徒标（新增；没传就不画，不影响老调用）
  const numConf = Number(confidence);
  if (isFinite(numConf) && numConf > 0) {
    const c = document.createElement("span");
    c.className = "ans-conf";
    c.textContent = numConf.toFixed(2);
    c.title = "模型置信度（低于 " + LOW_CONF + " 时程序不落笔）";
    row.appendChild(c);
    if (numConf < LOW_CONF) item.classList.add("is-low");
  }
  item.appendChild(row);

  // 解析（新增）
  if (reason && String(reason).trim()) {
    const w = document.createElement("div");
    w.className = "ans-why";
    w.textContent = "解析：" + String(reason).trim();
    item.appendChild(w);
  }

  const box = $("ansList");
  // 只有用户本来就停在底部时才自动跟着滚 ——
  // 他正在往上翻看历史时，别把视口拽走（和日志同一个策略）。
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
  box.appendChild(item);
  while (box.childElementCount > MAX_ANS) box.removeChild(box.firstChild);
  if (atBottom) box.scrollTop = box.scrollHeight;
}

/* ---------------- SSE ---------------- */
let es = null;
function connect() {
  if (es) es.close();
  es = new EventSource("/api/events");

  es.onopen = () => {
    $("dotConn").className = "dot on";
    $("connText").textContent = "已连接";
  };

  es.onerror = () => {
    $("dotConn").className = "dot bad";
    $("connText").textContent = "连接断开，重连中…";
  };

  es.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    const d = msg.data || {};
    switch (msg.kind) {
      case "log":
        addLog(d.level, d.text);
        break;
      case "status":
        setStatus(d.text, "run");
        break;
      case "run":
        setRunning(d.state === "running" || d.state === "starting");
        if (d.state === "running") setStatus("运行中", "run");
        else if (d.state === "starting") setStatus("启动中", "run");
        else {
          setStatus(d.reason ? "已结束（" + d.reason + "）" : "空闲", "");
          setRunning(false);
        }
        break;
      case "shot":
        setTimeout(refreshShot, 250);
        break;
      case "answer":
        // ★ 2026-10-22：把解析与置信度一起传过去
        addAnswer(d.stem, d.answer, d.reason, d.confidence);
        break;
      case "toast":
        toast(d.text, d.level);
        break;
      case "result": {
        // 刷课任务和答题任务共用 result 事件，用 kind 区分
        if (d.kind === "course") {
          $("cLessons").textContent = d.lessons || 0;
          $("cDone").textContent = d.finished || 0;
          setCourseUI(false);
          const bits = ["共 " + (d.lessons || 0) + " 节",
                        "播完 " + (d.finished || 0) + " 节"];
          if (d.reason) bits.push("停止原因：" + d.reason);
          if (d.error) bits.push("问题：" + d.error);
          $("cReason").textContent = bits.join("　·　");
          addLog(d.ok ? "ok" : "warn", "===== 刷课结束：" + bits.join("，") + " =====");
          toast(d.ok ? ("刷课结束：播完 " + (d.finished || 0) + " 节")
                     : "刷课结束（未播完任何一节）", d.ok ? "ok" : "warn", 7000);
          break;
        }
        const parts = [];
        // ⚠ PC 模式没有"题"的概念，用"步"；否则 answered=0 会落到
        //   "无作答结果"那一支，跑了 20 步也看不出来。
        if (d.kind === "pc") {
          if (d.steps) parts.push("已执行 " + d.steps + " 步");
          if (d.seconds) parts.push("用时 " + d.seconds + "s");
          if (d.error) parts.push("问题：" + d.error);
          addLog(d.ok ? "ok" : "warn",
                 "===== PC 任务结束：" + (parts.join("，") || "未执行任何动作") + " =====");
          if (d.failed_items && d.failed_items.length) {
            d.failed_items.forEach((x) => {
              addLog("warn", "  需复核 " + (x.ref || "?") + "：" + (x.why || ""));
            });
          }
          toast(d.ok ? "任务完成" : "任务结束，请查看日志", d.ok ? "ok" : "warn", 6000);
          break;
        }
        if (d.answered) parts.push("成功 " + d.answered + " 题");
        if (d.failed) parts.push("需复核 " + d.failed + " 题");
        if (d.seconds) parts.push("用时 " + d.seconds + "s");
        if (d.error) parts.push("问题：" + d.error);
        addLog(d.ok ? "ok" : "warn", "===== 任务结束：" + (parts.join("，") || "无作答结果") + " =====");
        if (d.failed_items && d.failed_items.length) {
          d.failed_items.forEach((x) => {
            addLog("warn", "  需复核 " + (x.ref || "?") + "：" + (x.why || "") +
                   "（我的答案 " + (x.answer || "空") + "）");
          });
        }
        toast(d.ok ? "任务完成" : "任务结束，请查看日志", d.ok ? "ok" : "warn", 6000);
        break;
      }
      default:
        break;
    }
  };
}

/* ---------------- 配置 ---------------- */
let keyAlreadySet = false;

/* ---------------- 运行模式（网页 / PC 视觉） ----------------
   按《视觉化改造》铁律一：**DOM 优先、视觉兜底**。
   所以网页模式是默认，PC 模式要用户主动选，并且会弹确认。
   ---------------------------------------------------------- */
function currentMode() {
  const r = document.querySelector('input[name="mode"]:checked');
  return r ? r.value : "web";
}

function applyMode(mode) {
  const m = mode === "pc" ? "pc" : "web";
  document.querySelectorAll('input[name="mode"]').forEach((r) => {
    r.checked = r.value === m;
  });
  // PC 模式用任务描述代替网址：两者互斥，避免用户以为填了网址就够
  $("pcBox").hidden = m !== "pc";
  document.querySelector("#url").closest(".field").hidden = m === "pc";
  $("btnStart").textContent = m === "pc" ? "开始（接管鼠标键盘）" : "开始答题";
  if ($("prepTag")) {
    // PC 模式不走"打开浏览器登录"那一步
    document.querySelector("#step1").style.display = m === "pc" ? "none" : "";
  }
}

document.querySelectorAll('input[name="mode"]').forEach((r) => {
  r.addEventListener("change", () => applyMode(r.value));
});


function applyProviderUI(provider) {
  document.querySelectorAll('input[name="provider"]').forEach((r) => {
    r.checked = r.value === provider;
  });
  // 每个来源只显示自己那张配置卡，避免一屏全是输入框看花眼
  const cards = {
    deepseek: "dsCard",
    kimi: "kimiCard",
    custom: "customCard",
    lmstudio: "lmCard",
  };
  Object.values(cards).forEach((id) => {
    const el = $(id);
    if (el) el.style.display = "none";
  });
  const show = cards[provider];
  if (show && $(show)) $(show).style.display = "";

  const names = {
    deepseek: "DeepSeek API",
    kimi: "Kimi API",
    custom: "自定义接口",
    lmstudio: "本机 LM Studio",
  };
  if ($("brandSub")) $("brandSub").textContent = names[provider] || provider;
}

document.querySelectorAll('input[name="provider"]').forEach((r) => {
  r.addEventListener("change", () => applyProviderUI(r.value));
});

/* ---------------- 统一接口请求 ----------------
   ⚠ 审计 C-7：原来每个按钮各写一遍 `await (await fetch(...)).json()`，
   而 `fetch` 在"服务已退出 / 端口被防火墙拦 / 网络栈抖动"时会**直接 reject**。
   有些处理函数包了 try/catch，有些没包 —— 没包的那些一失败就**没有任何反馈**
   （比如「保存设置」：用户以为存上了，其实 API Key 根本没发出去）。

   这个助手保证：**永远不抛异常**，失败也返回一个带 `ok:false` 和 `error` 的对象。
   已有 `if (r.ok) ... else toast(r.error)` 写法的调用点不用改就自动变正确。

   ⚠⚠ 它**一律用 POST**（这个程序的后端接口全都是 POST）。
   2026-10-16 实测踩到的坑，值得写在这儿：
     原来写的是"没有 body 就不带 method" —— 于是 `api("/api/stop")`
     实际发出去的是 **GET /api/stop**。do_GET 里没有这个端点，
     服务端回 404 `{"error":"unknown endpoint"}`，界面就弹
     「停止请求没送到：unknown endpoint」。
     用户看到的是"点「停止刷课」没反应"，而**服务端日志里一条记录都没有**
     （请求根本没进 do_POST，`/api/stop` 里那行日志自然也不会打）——
     两侧都"看起来正常"，极难排查。
     同样中招的还有 `api("/api/clear-shots")`（清空截图）。
   所以现在：无论有没有 body，都是 POST；body 传 `undefined` 表示空 body。 */
async function api(path, body) {
  try {
    const opts = { method: "POST" };
    if (body !== undefined) {
      opts.headers = { "Content-Type": "application/json" };
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(path, opts);
    if (!res.ok) {
      // 服务端返回了非 2xx（含 500）—— 尽量把它的解释带出来
      let detail = "";
      try { detail = (await res.json()).error || ""; } catch (e) { /* 非 JSON */ }
      return { ok: false, error: detail || ("服务返回 " + res.status) };
    }
    const j = await res.json();
    // 服务端约定用 ok 字段表示业务结果；没有该字段就当作成功
    return (j && typeof j === "object") ? j : { ok: true, data: j };
  } catch (e) {
    return { ok: false, error: "无法连接程序（" + (e.message || e) + "）" };
  }
}

async function loadConfig() {
  try {
    const cfg = await (await fetch("/api/config")).json();    $("url").value = cfg.url || "";
    $("optHeadless").checked = !!cfg.headless;
    $("optAutoNext").checked = cfg.auto_next !== false;
    $("optAutoSubmit").checked = !!cfg.auto_submit;
    $("optDryRun").checked = !!cfg.dry_run;
    $("optBatch").value = cfg.batch_size || 1;
    $("optPages").value = cfg.max_pages || 80;

    $("dsModel").value = cfg.deepseek_model || "deepseek-flash";
    if (![...$("dsModel").options].some((o) => o.value === $("dsModel").value)) {
      const o = document.createElement("option");
      o.value = cfg.deepseek_model;
      o.textContent = cfg.deepseek_model;
      $("dsModel").appendChild(o);
      $("dsModel").value = cfg.deepseek_model;
    }
    $("dsBase").value = cfg.deepseek_base_url || "";
    $("dsThinking").checked = !!cfg.deepseek_thinking;
    // ---- Kimi ----
    $("kimiModel").value = cfg.kimi_model || "";
    $("kimiBase").value = cfg.kimi_base_url || "";
    // ---- 自定义 ----
    $("cuBase").value = cfg.custom_base_url || "";
    $("cuModel").value = cfg.custom_model || "";
    // ---- LM Studio ----
    $("lmBase").value = cfg.lm_base_url || "";
    $("lmModel").value = cfg.lm_model || "";
    $("shotDir").value = cfg.shot_dir || "";
    // ---- 自动刷课 ----
    $("courseUrl").value = cfg.course_url || "";
    $("courseSpeed").value = String(cfg.course_speed || 2);
    $("courseMute").checked = cfg.course_mute !== false;
    if ($("courseQuizSubmit")) {
      // 默认开：`!== false` 而不是 `=== true` ——
      // 老配置文件里没有这个键时要当"开"，不能当"关"。
      $("courseQuizSubmit").checked = cfg.course_quiz_submit !== false;
    }
    if ($("coursePresenceGuard")) {
      // 同上：老配置里没有这个键时当"开"
      $("coursePresenceGuard").checked = cfg.course_presence_guard !== false;
    }
    if ($("courseQuizAuto")) {
      $("courseQuizAuto").checked = cfg.course_quiz_auto !== false;
    }
    $("courseAutoNext").checked = cfg.course_auto_next !== false;
    $("courseKeepalive").checked = cfg.course_keepalive !== false;
    $("courseMax").value = cfg.course_max_lessons || 60;
    // ---- 运行模式（网页 / PC 视觉）----
    applyMode(cfg.mode || "web");
    $("pcTask").value = cfg.pc_task || "";
    $("pcSteps").value = String(cfg.pc_max_steps || 25);
    $("optClearShots").checked = cfg.clear_shots !== false;
    // ---- 关闭窗口时 ----
    if ($("closeAction")) $("closeAction").value = cfg.close_action || "tray";

    // Key 一律只回传"是否已设置 + 掩码"，不回传明文
    keyAlreadySet = !!cfg.deepseek_api_key_set;
    $("keyState").textContent = keyAlreadySet ? "已保存 " + cfg.deepseek_api_key_masked : "未设置";
    $("keyState").className = "tag" + (keyAlreadySet ? " ok" : "");
    const kimiSet = !!cfg.kimi_api_key_set;
    if ($("kimiKeyState")) {
      $("kimiKeyState").textContent = kimiSet ? "已保存 " + cfg.kimi_api_key_masked : "未设置";
      $("kimiKeyState").className = "tag" + (kimiSet ? " ok" : "");
    }
    const cuSet = !!cfg.custom_api_key_set;
    if ($("cuKeyState")) {
      $("cuKeyState").textContent = cuSet ? "已保存 " + cfg.custom_api_key_masked : "未设置";
      $("cuKeyState").className = "tag" + (cuSet ? " ok" : "");
    }
    $("cfgPath").textContent = "配置文件：" + (cfg.config_file || "");

    applyProviderUI(cfg.provider || "deepseek");
    // 自助答疑页顶部的「当前模型 / Key」提示（沿用同一份配置，不另设 Key）
    updateSupportHint(cfg);
  } catch (e) {
    toast("读取配置失败：" + e.message, "error");
  }
}

function collectConfig() {
  const provider = (document.querySelector('input[name="provider"]:checked') || {}).value || "deepseek";
  const out = {
    provider,
    url: $("url").value.trim(),
    headless: $("optHeadless").checked,
    auto_next: $("optAutoNext").checked,
    auto_submit: $("optAutoSubmit").checked,
    dry_run: $("optDryRun").checked,
    batch_size: parseInt($("optBatch").value || "1", 10),
    max_pages: parseInt($("optPages").value || "80", 10),
    deepseek_model: $("dsModel").value,
    deepseek_base_url: $("dsBase").value.trim(),
    deepseek_thinking: $("dsThinking").checked,
    kimi_model: $("kimiModel").value.trim(),
    kimi_base_url: $("kimiBase").value.trim(),
    custom_base_url: $("cuBase").value.trim(),
    custom_model: $("cuModel").value.trim(),
    lm_base_url: $("lmBase").value.trim(),
    lm_model: $("lmModel").value.trim(),
    shot_dir: $("shotDir").value.trim(),
    clear_shots: $("optClearShots").checked,
    // ---- 自动刷课 ----
    course_url: $("courseUrl").value.trim(),
    course_speed: parseFloat($("courseSpeed").value) || 2,
    course_mute: $("courseMute").checked,
    course_quiz_auto: $("courseQuizAuto") ? $("courseQuizAuto").checked : true,
    course_quiz_submit: $("courseQuizSubmit") ? $("courseQuizSubmit").checked : true,
    course_presence_guard: $("coursePresenceGuard") ? $("coursePresenceGuard").checked : true,
    course_auto_next: $("courseAutoNext").checked,
    course_keepalive: $("courseKeepalive").checked,
    course_max_lessons: parseInt($("courseMax").value, 10) || 60,
    // ---- 关掉界面窗口后怎么办 ----
    close_action: currentCloseAction(),
  };
  // Key 留空 = 不改动已保存的；填了才覆盖
  const pairs = [
    ["dsKey", "deepseek_api_key"],
    ["kimiKey", "kimi_api_key"],
    ["cuKey", "custom_api_key"],
  ];
  pairs.forEach(([elId, field]) => {
    const el = $(elId);
    const v = el ? el.value.trim() : "";
    if (v) out[field] = v;
  });
  return out;
}

async function saveConfig(silent) {
  // 走 api() 助手：服务不可达时**不再抛异常**，
  // 而是返回 {ok:false, error:"无法连接程序（…）"} ——
  // 于是下面那句 toast 会正常弹出，用户能立刻知道"没保存上"（审计 C-7）。
  // 原实现里的 `await fetch` + `res.json()` 一 reject，
  // 「保存设置」按钮就完全没有反馈，Key 悄悄没存进去。
  const j = await api("/api/config", collectConfig());
  if (!silent) toast(j.ok ? "设置已保存" : ("保存失败：" + (j.error || "")),
                     j.ok ? "ok" : "error");
  if (j.ok) {
    // 保存成功后清空 Key 输入框（界面不保留明文）
    ["dsKey", "kimiKey", "cuKey"].forEach((id) => {
      if ($(id)) $(id).value = "";
    });
    await loadConfig();
  }
  return j;
}

$("btnSave").addEventListener("click", async () => {
  const btn = $("btnSave");
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = "保存中…";
  try {
    await saveConfig(false);
  } finally {
    // 无论成功失败都要恢复按钮 —— 否则一次失败就永久禁用
    btn.disabled = false;
    btn.textContent = old;
  }
});

/* ---------------- 测试模型 ---------------- */
$("btnTest").addEventListener("click", async () => {
  const btn = $("btnTest");
  btn.disabled = true;
  btn.textContent = "测试中…";
  const out = $("testOut");
  out.className = "test-out on";
  out.innerHTML = '<div class="muted">正在请求模型，请稍候…</div>';
  try {
    await saveConfig(true);
    const r = await (await fetch("/api/test", { method: "POST" })).json();
    let html = "";
    html += line(r.ok, "整体连通", (r.provider || "") + " / " + (r.model || ""));
    (r.steps || []).forEach((s) => { html += line(s.ok, s.name, s.detail); });
    if (r.error) {
      html += '<div class="test-line fail"><span class="badge">错误</span><span>' +
              escapeHtml(r.error) + "</span></div>";
    }
    out.innerHTML = html;
    toast(r.ok ? "模型可用" : "模型有问题，详见下方", r.ok ? "ok" : "error");
    const dot = r.ok ? "on" : "bad";
    $("dotModel").className = "dot " + dot;
    $("modelText").textContent = (r.model || "模型") + (r.vision ? " · 可看图" : " · 纯文本");
    $("modelText").title = (r.provider || "") + " " + (r.base_url || "");
  } catch (e) {
    out.innerHTML = '<div class="test-line fail"><span class="badge">异常</span><span>' +
                    escapeHtml(e.message) + "</span></div>";
  } finally {
    btn.disabled = false;
    btn.textContent = "测试模型连接";
  }
});

function line(ok, name, detail) {
  return '<div class="test-line ' + (ok ? "pass" : "fail") + '">' +
         '<span class="badge">' + (ok ? "通过" : "失败") + "</span>" +
         "<span>" + escapeHtml(name) + "</span>" +
         '<span class="d">' + escapeHtml(detail || "") + "</span></div>";
}

function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));
}

/* ---------------- 准备阶段（打开浏览器登录） ---------------- */
function setPrepUI(prep) {
  const running = !!(prep && prep.running);
  $("btnPrepOpen").textContent = running ? "重新打开" : "打开浏览器";
  $("btnPrepClose").style.display = running ? "" : "none";
  $("prepTag").textContent = running ? "已打开，请登录" : "未开始";
  $("step1").className = "step" + (running ? " done" : "");
  $("step2").className = "step" + (running ? " active" : "");
  $("prepHint").textContent = running
    ? "浏览器已就绪（" + (prep.browser || "浏览器") + "）。登录后直接点「开始答题」。"
    : "";
}

$("btnPrepOpen").addEventListener("click", async () => {
  const btn = $("btnPrepOpen");
  btn.disabled = true;
  btn.textContent = "正在打开…";
  try {
    const r = await (await fetch("/api/prep/open", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: $("url").value.trim() }),
    })).json();
    if (!r.ok) toast(r.error || "打开浏览器失败", "error", 7000);
    setPrepUI(r.ok ? { running: true, browser: r.browser } : { running: false });
  } catch (e) {
    toast("打开浏览器失败：" + e.message, "error");
  } finally {
    btn.disabled = false;
  }
});

$("btnPrepClose").addEventListener("click", async () => {
  await fetch("/api/prep/close", { method: "POST" });
  setPrepUI({ running: false });
  toast("已关掉准备阶段的浏览器", "info");
});

async function refreshPrep() {
  try {
    const p = await (await fetch("/api/prep/status")).json();
    setPrepUI(p);
  } catch { /* 忽略 */ }
}

/* ---------------- 截图目录设置 ---------------- */
async function refreshShotDir() {
  try {
    const r = await (await fetch("/api/shot-dir")).json();
    $("shotDirState").textContent = r.exists ? "生效中" : "目录不存在";
    $("shotDirState").className = "tag" + (r.exists ? " ok" : "");
    $("shotCount").textContent = "当前 " + r.count + " 张：" + r.dir;
  } catch { /* 忽略 */ }
}

$("btnPickDir").addEventListener("click", async () => {
  const btn = $("btnPickDir");
  btn.disabled = true;
  btn.textContent = "选择中…";
  try {
    const r = await (await fetch("/api/pick-folder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ initial: $("shotDir").value.trim() }),
    })).json();
    if (r.ok && r.dir) {
      $("shotDir").value = r.dir;
      await saveConfig(true);
      await refreshShotDir();
      toast("截图位置已改为：" + r.dir, "ok", 5000);
    } else if (!r.ok) {
      // 对话框不可用（极少见）→ 提示手填，功能不受影响
      toast("系统文件夹对话框不可用，请直接手动输入路径", "warn", 5000);
      $("shotDir").focus();
    }
  } catch (e) {
    toast("选择文件夹失败：" + e.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "浏览…";
  }
});

$("btnOpenDir").addEventListener("click", async () => {
  // 走 api()：服务不可达时不会 reject，会返回 {ok:false,error}（审计 C-7）
  const r = await api("/api/open-folder", { which: "shots" });
  if (!r.ok) toast("打不开目录：" + (r.error || "未知原因"), "error");
});

$("btnClearShots").addEventListener("click", async () => {
  const r = await api("/api/clear-shots");
  toast(r.ok ? ("已删除 " + r.deleted + " 张截图") : ("清空失败：" + (r.error || "")),
        r.ok ? "ok" : "error");
  refreshShotDir();
  refreshShot();
});

/* ---------------- 使用教程：目录跳转 ----------------
   `.view` 不是滚动容器（`.main` 才是），所以浏览器默认的锚点跳转
   不会滚动到正确位置。这里手动滚，并留一点顶部间距。 */
document.querySelectorAll(".guide-toc a").forEach((a) => {
  a.addEventListener("click", (e) => {
    const id = (a.getAttribute("href") || "").slice(1);
    const target = id && document.getElementById(id);
    if (!target) return;
    e.preventDefault();
    const scroller = document.querySelector(".main") || document.scrollingElement;
    const top = target.offsetTop - 12;
    try {
      scroller.scrollTo({ top, behavior: "smooth" });
    } catch {
      scroller.scrollTop = top;
    }
  });
});

/* ---------------- 用量监控 ---------------- */
function fmtInt(n) {
  return (Number(n) || 0).toLocaleString("zh-CN");
}
function fmtMoney(n) {
  const v = Number(n) || 0;
  // 花费常常是零点几元，保留 4 位才有意义
  if (v === 0) return "¥0";
  if (v < 0.0001) return "¥" + v.toExponential(2);
  return "¥" + v.toFixed(v >= 1 ? 3 : 4);
}
function fmtTime(ts) {
  if (!ts) return "—";
  const d = new Date(ts * 1000);
  const p = (x) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} `
       + `${p(d.getHours())}:${p(d.getMinutes())}`;
}

function renderUsage(u) {
  const t = u.totals || {};
  $("uCalls").textContent = fmtInt(t.calls);
  $("uIn").textContent = fmtInt(t.prompt_tokens);
  $("uOut").textContent = fmtInt(t.completion_tokens);
  $("uTotal").textContent = fmtInt(t.total_tokens);
  $("uHit").textContent = fmtInt(t.cached_tokens);
  $("uCost").textContent = fmtMoney(t.cost_est);

  $("priceNote").textContent = u.price_note
    ? "花费为" + u.price_note + "；官方接口不提供价格字段，余额消耗栏才是准的。"
    : "";
  $("uSince").textContent = t.calls
    ? "统计开始于 " + fmtTime(u.first_ts) + "，最近更新 " + fmtTime(u.updated_ts)
    : "还没有调用记录。跑一次任务后这里就会有数据。";

  // 按模型
  const tb = $("perModel").querySelector("tbody");
  const rows = Object.entries(u.per_model || {});
  if (!rows.length) {
    tb.innerHTML = '<tr><td colspan="5" class="muted">还没有用量记录</td></tr>';
  } else {
    tb.innerHTML = rows.map(([m, d]) =>
      `<tr><td>${escapeHtml(m)}</td><td>${fmtInt(d.calls)}</td>`
      + `<td>${fmtInt(d.prompt_tokens)}</td><td>${fmtInt(d.completion_tokens)}</td>`
      + `<td>${fmtMoney(d.cost_est)}</td></tr>`).join("");
  }

  // 余额
  const b = u.balance || {};
  if (b.last === null || b.last === undefined) {
    $("balanceVal").textContent = "—";
    $("balanceUnit").textContent = "";
    $("balanceNote").textContent = u.is_cloud
      ? "点「刷新余额」查询官方接口"
      : "当前用的是本机模型，不产生余额消耗";
    $("balanceGranted").textContent = "—";
    $("balanceTopped").textContent = "—";
    $("balanceAvail").textContent = "—";
  } else {
    $("balanceVal").textContent = Number(b.last).toFixed(2);
    $("balanceUnit").textContent = b.currency || "CNY";
    $("balanceNote").textContent = "更新于 " + fmtTime(b.ts);
  }

  // 余额消耗
  if (b.spent_by_balance === null || b.spent_by_balance === undefined) {
    $("spentVal").textContent = "—";
    $("spentUnit").textContent = "";
    if (b.baseline !== null && b.baseline !== undefined) {
      $("spentNote").textContent = "基线 " + Number(b.baseline).toFixed(2)
        + "（" + fmtTime(b.baseline_ts) + "），刷新余额后即可算出消耗。";
    } else {
      $("spentNote").textContent =
        "记录一次基线后，之后的余额下降量就是实际花掉的钱 —— 这是官方数据，最准。";
    }
  } else {
    $("spentVal").textContent = Number(b.spent_by_balance).toFixed(2);
    $("spentUnit").textContent = b.currency || "CNY";
    $("spentNote").textContent = "自 " + fmtTime(b.baseline_ts) + " 的基线 "
      + Number(b.baseline).toFixed(2) + " 起算。";
  }
}

async function refreshUsage() {
  try {
    const u = await (await fetch("/api/usage")).json();
    renderUsage(u);
    return u;
  } catch (e) {
    toast("用量读取失败：" + e.message, "error");
    return null;
  }
}

$("btnBalance").addEventListener("click", async () => {
  const btn = $("btnBalance");
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = "查询中…";
  try {
    const r = await (await fetch("/api/balance/refresh", { method: "POST" })).json();
    if (r.ok) {
      $("balanceGranted").textContent = Number(r.granted_balance || 0).toFixed(2);
      $("balanceTopped").textContent = Number(r.topped_up_balance || 0).toFixed(2);
      $("balanceAvail").textContent = r.is_available ? "可用" : "不可用";
      toast("余额：" + r.total_balance + " " + (r.currency || ""), "ok");
    } else {
      $("balanceNote").textContent = r.error || "查询失败";
      toast(r.error || "余额查询失败", "error", 6500);
    }
    await refreshUsage();
  } catch (e) {
    toast("余额查询失败：" + e.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
});

$("btnBaseline").addEventListener("click", async () => {
  // 先确保有余额数据，否则基线无从记起
  const cur = await refreshUsage();
  if (!cur || cur.balance.last === null || cur.balance.last === undefined) {
    const r = await (await fetch("/api/balance/refresh", { method: "POST" })).json();
    if (!r.ok) { toast(r.error || "先刷新余额", "warn", 6000); return; }
  }
  const r = await (await fetch("/api/balance/baseline")).json();
  if (r.ok) toast("已记录基线：" + r.baseline, "ok");
  else toast(r.error || "记录失败", "error");
  refreshUsage();
});

$("btnUsageReset").addEventListener("click", async () => {
  if (!confirm("确定把本地累计的 token 统计清零吗？（余额不受影响）")) return;
  await fetch("/api/usage/reset", { method: "POST" });
  toast("用量统计已清零", "ok");
  refreshUsage();
});

/* ---------------- 作答记录导出 ----------------
   后端只读 out\runs\*.json + out\answer_cache.json，写 out\notes\*.md；
   不联网、不调模型。失败时后端回 ok:false + error，api() 本身也永不抛，
   所以这里用 try/finally 复位按钮就够（不会再出现"按钮卡在导出中"）。 */
const btnExportNote = $("btnExportNote");
if (btnExportNote) {
  btnExportNote.addEventListener("click", async () => {
    const old = btnExportNote.textContent;
    btnExportNote.disabled = true;
    btnExportNote.textContent = "导出中…";
    try {
      const r = await api("/api/export/notebook", { mode: "record" });
      const note = $("exportNote");
      if (r.ok) {
        const n = Array.isArray(r.files) ? r.files.length : 0;
        const text = "已导出 " + n + " 篇作答记录（共 " + (r.total_questions || 0)
          + " 题）到：" + r.dir;
        if (note) note.textContent = text;
        toast("已导出到 " + r.dir, "ok", 7000);
      } else {
        const msg = r.error || "导出失败";
        if (note) note.textContent = msg;
        toast(msg, "error", 7000);
      }
    } finally {
      btnExportNote.disabled = false;
      btnExportNote.textContent = old;
    }
  });
}

/* ---------------- 自动刷课 ---------------- */
function courseCfg() {
  return {
    course_url: $("courseUrl").value.trim(),
    course_speed: parseFloat($("courseSpeed").value) || 2,
    course_mute: $("courseMute").checked,
    course_quiz_auto: $("courseQuizAuto") ? $("courseQuizAuto").checked : true,
    course_quiz_submit: $("courseQuizSubmit") ? $("courseQuizSubmit").checked : true,
    course_presence_guard: $("coursePresenceGuard") ? $("coursePresenceGuard").checked : true,
    course_auto_next: $("courseAutoNext").checked,
    course_keepalive: $("courseKeepalive").checked,
    course_max_lessons: parseInt($("courseMax").value, 10) || 60,
  };
}

/* ---------------- 关闭窗口时：完全退出 / 最小化到托盘 ----------------
   ⚠ 窗口的关闭按钮在**预编译的启动器**里（托盘图标也是），源码不在仓库，
      改不了那个 X。能改的是"页面被关掉"这件事 —— 浏览器关闭/刷新页面时
      会触发 pagehide，我们借它告诉服务端一声。

   两个坑，各有一条对策：
     ① 刷新（F5）也会触发 pagehide → 所以服务端只是**预约**退出，
        新页面加载完第一件事就是调 /api/hello 把它取消（宽限 15 秒）。
     ② 关闭时页面可能已经在拆了，普通 fetch 会被中断 →
        用 `navigator.sendBeacon()`，它就是为这个场景设计的。 */
function currentCloseAction() {
  return $("closeAction") ? $("closeAction").value : "tray";
}

window.addEventListener("pagehide", () => {
  // 只有选了「完全退出」才上报；托盘模式什么都不做（= 以前的行为）
  if (currentCloseAction() !== "exit") return;
  try {
    const blob = new Blob([JSON.stringify({ at: Date.now() })],
                          { type: "application/json" });
    navigator.sendBeacon("/api/pagehide", blob);
  } catch (e) {
    // sendBeacon 不可用就退化成 keepalive fetch（同样能在卸载时发出去）
    try {
      fetch("/api/pagehide", { method: "POST", keepalive: true });
    } catch (e2) { /* 关都关了，失败也只能算了 */ }
  }
});

function bindQuitButton() {
  const b = $("btnQuit");
  if (!b) return;
  b.addEventListener("click", async () => {
    if (!window.confirm("确定要完全退出程序吗？\n\n"
        + "正在跑的答题 / 刷课会一起结束；浏览器窗口也会被收掉。")) {
      return;
    }
    b.disabled = true;
    b.textContent = "正在退出…";
    const r = await api("/api/quit", {});
    // 正常情况：服务端已经死了，下面这句多半看不到。
    // 还能看到，说明没退成 —— 如实告诉用户，别让他以为关掉了。
    toast(r.ok ? "已请求退出" : ("退出请求没送到：" + (r.error || "")),
          r.ok ? "warn" : "error");
  });
}

function setCourseUI(running) {
  $("btnCourseStart").disabled = running;
  if ($("btnCourseOnce")) $("btnCourseOnce").disabled = running;
  $("cState").textContent = running ? "刷课中…" : "空闲";
  $("cState").style.color = running ? "var(--accent)" : "";
}

$("btnCoursePrep").addEventListener("click", async () => {
  const btn = $("btnCoursePrep");
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = "打开中…";
  try {
    const r = await (await fetch("/api/prep/open", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: $("courseUrl").value.trim() }),
    })).json();
    if (r.ok) toast("浏览器已打开，请登录并进入课程页", "ok", 6000);
    else toast(r.error || "打开失败", "error", 6000);
  } catch (e) {
    toast("打开失败：" + e.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
});

$("btnCourseStart").addEventListener("click", async () => {
  const cfg = courseCfg();
  if (!cfg.course_url || !/^https?:/i.test(cfg.course_url)) {
    toast("课程地址看起来不是 http(s) 网址，请检查", "warn", 6000);
  }
  await saveConfig(true);
  try {
    const r = await (await fetch("/api/course/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cfg),
    })).json();
    if (r.ok) {
      $("cLessons").textContent = "0";
      $("cDone").textContent = "0";
      $("cReason").textContent = "";
      setCourseUI(true);
      toast("开始刷课", "ok");
      // 切到日志页更好观察（这里不强制跳，用户可自行切）
    } else {
      toast(r.error || "启动失败", "error");
    }
  } catch (e) {
    toast("启动失败：" + e.message, "error");
  }
});

$("btnCourseOnce") && $("btnCourseOnce").addEventListener("click", async () => {
  // 单页自动：只处理浏览器当前这一页
  const cfg = courseCfg();
  await saveConfig(true);
  try {
    const r = await (await fetch("/api/course/once", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cfg),
    })).json();
    if (r.ok) {
      setCourseUI(true);
      toast("单页自动已开始（只处理当前页）", "ok");
    } else {
      toast(r.error || "单页自动启动失败", "error", 7000);
    }
  } catch (e) {
    toast("无法连接程序：" + e.message, "error");
  }
});

$("btnCourseStop").addEventListener("click", async () => {
  // 停止请求必须给出反馈：服务不可达时也要告诉用户，
  // 否则他以为"已停止"，实际刷课还在跑（审计 C-7）。
  const r = await api("/api/stop");
  toast(r.ok ? "已请求停止" : ("停止请求没送到：" + (r.error || "")),
        r.ok ? "warn" : "error");
});

/* ---------------- 启动 / 停止 ---------------- */
$("btnStart").addEventListener("click", async () => {
  const mode = currentMode();
  const payload = collectConfig();

  if (mode === "pc") {
    // PC 模式用「任务描述」代替网址
    const task = ($("pcTask").value || "").trim();
    if (!task) {
      toast("请先填写 PC 模式的任务描述", "warn");
      $("pcTask").focus();
      return;
    }
    // ⚠ 二次确认：PC 模式会**真的**移动鼠标、敲键盘。
    //   文档把它列为硬约束（默认关闭 + 二次确认 + 步数上限）。
    const ok = confirm(
      "PC 模式会接管你的真实鼠标和键盘。\n\n" +
      "· 运行期间请不要碰电脑，也不要把别的窗口切到前台\n" +
      "· 它只做你描述的任务，不做考试自动作答\n" +
      "· 随时可以点「停止」中断\n\n" +
      "任务：" + task + "\n\n确定开始吗？"
    );
    if (!ok) return;
    payload.pc_confirm_ok = 1;
  } else {
    const url = $("url").value.trim();
    if (!url) { toast("请先填写作业网页地址", "warn"); $("url").focus(); return; }
    if (!/^https?:\/\//i.test(url) && !/^file:\/\//i.test(url)) {
      toast("网址要以 http:// 、https:// 或 file:// 开头", "warn");
      return;
    }
  }

  setRunning(true);
  setStatus("启动中", "run");
  ansCount = 0;
  $("ansList").innerHTML = '<div class="muted">等待第一道题…</div>';
  // ⚠ 这个 fetch 必须包 try/catch/finally —— 服务退出、端口被防火墙拦、
  //   网络栈抖动时它会直接 reject，`setRunning(false)` 永不执行，
  //   于是按钮**永久禁用**、状态栏永远停在"启动中"，只能刷新页面
  //   （审计 C-7 说的就是这个）。
  try {
    const r = await (await fetch("/api/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })).json();
    if (!r.ok) {
      toast(r.error || "启动失败", "error");
      setRunning(false);
      setStatus("空闲", "");
    }
  } catch (e) {
    toast("无法连接程序：" + e.message, "error");
    setRunning(false);
    setStatus("空闲", "");
  }
});

$("btnStop").addEventListener("click", async () => {
  $("btnStop").disabled = true;
  await fetch("/api/stop", { method: "POST" });
});

$("btnClear").addEventListener("click", async () => {
  $("log").innerHTML = "";
  await fetch("/api/clear", { method: "POST" });
});

/* ---------------- 自助解答（侧栏 AI 聊天） ----------------
   和「自动答题 / 自动刷课」完全解耦：
     · 只调 /api/support/chat 和 /api/support/kb（本地资料索引），
       模型与 Key 由后端沿用「设置」里的配置；
     · 会话 id 在本页生成，服务端只存内存；「新对话」= 换一个 id；
     · 渲染时先 escapeHtml 再做最小 markdown（粗体 / 行内代码 / 换行），
       不直接 innerHTML 模型原文，避免把网页标签带进界面。
   ---------------------------------------------------------------- */
const SUPPORT_WELCOME =
  "你好，我是 **昔涟**，这间自习室的看门人。\n" +
  "我能回答**这个软件**的使用、配置、排障，回答依据是随包发布的 README / docs，例如：\n" +
  "• 第一次怎么配置、API Key 填在哪\n" +
  "• 自动答题 / 自动刷课怎么开始\n" +
  "• 日志在哪、某个报错怎么排查\n" +
  "• 当前版本 / 更新说明里写了什么\n\n" +
  "直接描述你卡住的地方就行。如果模型还没配好，提问时会提示你先去「设置」配置。";

let supportSession = "";
let supportBusy = false;
let supportWelcomeShown = false;
let supportKb = null;
let supportKbBusy = false;
let supportKbTried = false;

function newSupportSession() {
  try {
    if (window.crypto && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
  } catch (e) { /* 老浏览器兜底 */ }
  return "sup-" + Date.now().toString(36) + "-" +
         Math.random().toString(36).slice(2, 10);
}

/* 模型原文只做三种安全转换；剩余的 HTML 全部转义 */
function supportFormat(text) {
  let h = escapeHtml(String(text || ""));
  h = h.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
  h = h.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  return h.replace(/\n/g, "<br>");
}

function addSupportMsg(role, text, opts) {
  opts = opts || {};
  const log = $("supportLog");
  if (!log) return null;
  const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;

  const box = document.createElement("div");
  box.className = "msg " + (role === "user" ? "user" : "ai") + (opts.error ? " error" : "");

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (opts.typing) {
    bubble.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  } else if (role === "user") {
    bubble.textContent = text;
  } else {
    bubble.innerHTML = supportFormat(text);
  }
  box.appendChild(bubble);

  // 时间 / 用时：只做轻量提示，不抢回答的注意力
  const meta = document.createElement("div");
  meta.className = "meta";
  if (opts.typing) {
    meta.textContent = "";
  } else if (role === "user") {
    meta.textContent = "你　" + new Date().toLocaleTimeString("zh-CN", { hour12: false });
  } else {
    let s = "答疑助手";
    if (opts.seconds) s += "　·　" + opts.seconds + "s";
    if (opts.error) s += "　·　未能回答";
    meta.textContent = s;
    if (opts.needKey) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "fix-link";
      b.textContent = "去设置填写 Key";
      b.addEventListener("click", () => {
        document.querySelector('.nav-item[data-view="settings"]').click();
        if ($("dsKey")) $("dsKey").focus();
      });
      meta.appendChild(b);
    }
  }
  if (meta.textContent || meta.childElementCount) box.appendChild(meta);

  log.appendChild(box);
  if (atBottom) log.scrollTop = log.scrollHeight;
  return box;
}

function updateSupportHint(cfg) {
  const el = $("supportModel");
  if (!el || !cfg) return;
  const p = cfg.provider || "deepseek";
  const names = {
    deepseek: "DeepSeek", kimi: "Kimi",
    custom: "自定义接口", lmstudio: "本机 LM Studio",
  };
  let model = "";
  if (p === "deepseek") model = cfg.deepseek_model || "deepseek-flash";
  else if (p === "kimi") model = cfg.kimi_model || "kimi-latest";
  else if (p === "custom") model = cfg.custom_model || "";
  else if (p === "lmstudio") model = cfg.lm_model || "自动选择已加载模型";

  let keyText = "";
  if (p === "lmstudio") keyText = "本机运行，无需 Key";
  else if (p === "custom" && !cfg.custom_api_key_set) keyText = "Key 未填（内网端点可能不需要）";
  else keyText = cfg[p + "_api_key_set"] ? "Key 已保存" : "Key 未设置";

  el.textContent = "当前模型：" + (names[p] || p) +
                   (model ? " · " + model : "") + " · " + keyText;
  el.style.color = (p !== "lmstudio" && !cfg[p + "_api_key_set"] &&
                    p !== "custom") ? "var(--warn)" : "";
}

/* 本地资料状态条：只读软件包内的 README / docs，不联网、不阻塞聊天。 */
function setSupportKbUI(kb, loading, err) {
  const dot = $("supportKbDot");
  const text = $("supportKbText");
  const box = $("supportKb");
  if (!text) return;

  if (loading) {
    if (dot) dot.className = "kb-dot wait";
    text.textContent = "正在读取软件包内资料…";
    return;
  }

  if (kb && kb.ok) {
    const ver = kb.version ? "v" + String(kb.version).replace(/^v/i, "") : "";
    const bits = ["本地资料" + (ver ? "：" + ver : "")];
    bits.push((kb.files || 0) + " 个文件 / " + (kb.chunks || 0) + " 个片段");
    text.textContent = bits.join(" · ");
    if (dot) dot.className = "kb-dot ok";
    if (box) box.title = (kb.sources || []).join("\n");
    return;
  }

  if (dot) dot.className = "kb-dot bad";
  const reason = String(err || (kb && kb.error) || "").trim();
  text.textContent = "本地资料读取失败" +
    (reason ? "（" + reason.slice(0, 60) + "）" : "（软件包里没找到 README / docs）") +
    "，可点「重读资料」";
  if (box) box.title = reason;
}

async function refreshSupportKb(force) {
  if (supportKbBusy) return;
  supportKbBusy = true;
  supportKbTried = true;
  setSupportKbUI(supportKb, true);
  const r = await api("/api/support/kb", { reload: !!force });
  supportKbBusy = false;
  if (r && r.ok) {
    supportKb = r;
    setSupportKbUI(r, false);
  } else {
    setSupportKbUI(null, false, (r && r.error) || "未知错误");
  }
}

function initSupportView() {
  if (!supportSession) supportSession = newSupportSession();
  if (!supportWelcomeShown) {
    addSupportMsg("ai", SUPPORT_WELCOME);
    supportWelcomeShown = true;
  }
  // 首次打开（或页面加载）时建一次本地索引；失败不自动重试，等用户点「重读资料」
  if (!supportKbTried) refreshSupportKb(false);
}

async function sendSupport(raw) {
  const input = $("supportInput");
  const text = String(raw != null ? raw : (input ? input.value : "")).trim();
  if (!text) {
    if (input) input.focus();
    return;
  }
  if (supportBusy) {
    toast("上一个问题还在回答，请稍等", "info", 2200);
    return;
  }
  supportBusy = true;
  const btn = $("btnSupportSend");
  if (btn) { btn.disabled = true; btn.textContent = "回答中…"; }
  if (input) {
    input.value = "";
    input.style.height = "";
  }

  addSupportMsg("user", text);
  const holder = addSupportMsg("ai", "", { typing: true });
  try {
    const r = await api("/api/support/chat", {
      message: text,
      session: supportSession,
    });
    if (holder) holder.remove();
    if (r && r.ok) {
      if (r.session) supportSession = r.session;
      addSupportMsg("ai", r.answer || "（模型没有返回内容）", { seconds: r.seconds });
    } else {
      addSupportMsg("ai", (r && r.error) || "答疑请求失败，请稍后再试。", {
        error: true,
        needKey: !!(r && r.need_key),
      });
      if (r && r.detail) addLog("debug", "答疑失败详情：" + r.detail);
    }
  } finally {
    supportBusy = false;
    if (btn) { btn.disabled = false; btn.textContent = "发送"; }
    if (input) input.focus();
  }
}

function resetSupport() {
  if (supportBusy) {
    toast("正在回答，等这一条结束再开新对话", "info", 2400);
    return;
  }
  supportSession = newSupportSession();
  supportWelcomeShown = false;
  const log = $("supportLog");
  if (log) log.innerHTML = "";
  initSupportView();
  const input = $("supportInput");
  if (input) input.focus();
}

if ($("btnSupportSend")) {
  $("btnSupportSend").addEventListener("click", () => sendSupport());
}
if ($("btnSupportClear")) {
  $("btnSupportClear").addEventListener("click", resetSupport);
}
if ($("btnSupportKbReload")) {
  $("btnSupportKbReload").addEventListener("click", () => refreshSupportKb(true));
}
if ($("supportInput")) {
  const input = $("supportInput");
  input.addEventListener("keydown", (e) => {
    // isComposing：中文输入法选词时按 Enter 不能当发送
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      sendSupport();
    }
  });
  input.addEventListener("input", () => {
    input.style.height = "auto";
    input.style.height = Math.min(150, Math.max(46, input.scrollHeight)) + "px";
  });
}
document.querySelectorAll("#supportQuick .chip").forEach((b) => {
  b.addEventListener("click", () => {
    sendSupport(b.dataset.q || b.textContent);
  });
});
const _navSupport = document.querySelector('.nav-item[data-view="support"]');
if (_navSupport) {
  _navSupport.addEventListener("click", () => {
    initSupportView();
    setTimeout(() => {
      if (!$("supportInput")) return;
      // preventScroll：新外壳的输入框在页面下部，默认 focus() 会把 .main
      // 直接滚到输入框，页头"自助解答"标题就被顶出去了。只取焦、不滚动。
      try { $("supportInput").focus({ preventScroll: true }); }
      catch { $("supportInput").focus(); }
    }, 40);
  });
}
initSupportView();

/* ---------------- 启动时初始化 ---------------- */
// ★ 任何一步都不许"无限等"。
//
//   开屏动画（原生窗口）要等页面调 `/api/ready` 才淡出，而这一步原来在
//   初始化链的**最后**：`/api/hello` → `/api/config` → `/api/state`。
//   这三条 fetch 都没有超时 —— 机器慢、杀毒软件正在扫、服务端刚好在忙，
//   任何一条卡住，开屏就会一直压在屏幕上（服务端还有 90 秒兜底，
//   用户看到的就是"启动动画很久都不消失"）。
//   实测用户反馈："启动动画需要很久才消失" + "点击只变色没反应"。
const _withTimeout = (p, ms, fallback) => Promise.race([
  p, new Promise((r) => setTimeout(() => r(fallback), ms)),
]);

/* ---------------- 版本与更新 ----------------
   后端只在 out\updates 里暂存，运行中不替换任何文件；
   点「重启并应用」才会退出并重新拉起启动器，由 bootstrap_update 换目录。
   ⚠ 进度用 700ms 轮询，不新开 SSE —— 下载就几秒，没必要多一条长连接。 */
let _updPoll = null;

function _updRender(u) {
  if (!u) return;
  const now = $("updNow");
  if (now) now.textContent = u.dev ? "开发版" : (u.build || "未知");
  const hint = $("updHint");
  if (hint) hint.textContent = u.dev ? "（开发副本，不参与自动更新）" : "";
  const auto = $("updAuto");
  if (auto && document.activeElement !== auto) auto.checked = !!u.enabled;

  const bar = $("updBar"), fill = $("updFill");
  const dl = $("btnUpdDownload"), rest = $("btnUpdRestart"), chk = $("btnUpdCheck");
  const msg = $("updMsg");

  const manual = $("updManual");
  if (manual && u.manual_url) {
    manual.href = u.manual_url;
    manual.title = u.manual_password ? ("提取码：" + u.manual_password) : "";
  }

  const downloading = u.phase === "downloading";
  const staged = u.phase === "staged" || !!u.pending;
  if (dl) dl.hidden = !(u.newer && !downloading && !staged);
  if (rest) rest.hidden = !staged;
  if (chk) chk.disabled = downloading;

  if (bar && fill) {
    bar.hidden = !downloading;
    fill.style.width = (downloading ? (u.pct || 0) : 0) + "%";
  }

  if (msg) {
    if (downloading) msg.textContent = `正在下载 ${u.latest || ""}… ${u.pct || 0}%`;
    else if (staged) msg.textContent = `新版本 ${u.pending_build || u.latest || ""} 已下载好，重启后生效。`;
    else if (u.phase === "error") msg.textContent = "上次更新失败：" + (u.error || "未知原因") + "（可以再点一次「下载更新」重试）";
    else if (u.dev) msg.textContent = "这是开发副本（没有 build.json），不参与自动更新。";
    else if (u.newer) msg.textContent = `发现新版本 ${u.latest}（当前 ${u.build}）。`;
    else if (u.latest) msg.textContent = (u.latest === u.build) ? "已是最新版本。" : `远端版本 ${u.latest}，当前 ${u.build}。`;
    else msg.textContent = "还没检查过更新。更新只替换程序本体，配置、日志、登录状态都不会动。";
  }
}

async function refreshUpdate(silent) {
  try {
    const u = await (await fetch("/api/update")).json();
    _updRender(u);
    if (u && u.phase === "downloading") {
      if (!_updPoll) _updPoll = setInterval(() => refreshUpdate(true), 700);
    } else if (_updPoll) {
      clearInterval(_updPoll);
      _updPoll = null;
    }
    return u;
  } catch (e) {
    if (!silent && typeof addLog === "function") addLog("info", "读不到更新状态（服务未就绪？）");
    return null;
  }
}

async function checkUpdate() {
  const btn = $("btnUpdCheck");
  if (btn) { btn.disabled = true; btn.textContent = "检查中…"; }
  try {
    const r = await api("/api/update/check");
    if (!r || r.ok === false) {
      toast((r && r.error) || "检查更新失败", "warn", 6000);
      return;
    }
    _updRender(r);
    if (r.check_error) toast("检查失败：" + r.check_error, "warn", 7000);
    else if (r.newer) toast("发现新版本 " + r.latest, "info", 6000);
    else if (r.skipped === false && r.latest) toast("已是最新版本", "ok");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "检查更新"; }
  }
}

async function downloadUpdate() {
  const r = await api("/api/update/download");
  if (!r || r.ok === false) { toast((r && r.error) || "下载失败", "warn", 7000); return; }
  toast(r.message || "开始下载更新…", "info");
  refreshUpdate();
}

async function restartForUpdate() {
  toast("正在重启以应用更新…", "info", 5000);
  await api("/api/update/restart");
}

function bindUpdateUI() {
  const c = $("btnUpdCheck");
  if (c) c.addEventListener("click", () => { checkUpdate().catch((e) => reportUiError("update", e)); });
  const d = $("btnUpdDownload");
  if (d) d.addEventListener("click", () => { downloadUpdate().catch((e) => reportUiError("update", e)); });
  const r = $("btnUpdRestart");
  if (r) r.addEventListener("click", () => { restartForUpdate().catch((e) => reportUiError("update", e)); });
  const a = $("updAuto");
  if (a) a.addEventListener("change", async () => {
    const res = await api("/api/update/settings", { enabled: a.checked });
    if (res && res.ok) toast(a.checked ? "已开启启动检查更新" : "已关闭启动检查更新", "ok");
    else { a.checked = !a.checked; toast("保存失败", "warn"); }
  });
}

// ---- 界面主题：青瓷月白 / 昔涟粉紫 ----
//
// 两套皮肤可以同时挂着：青瓷那套是「有门」的（每条规则都挂在
// html.theme-celadon 下），所以换主题 = 往 <html> 上加/去一个 class。
// 选择存 localStorage；index.html 的 <head> 里会先读一次再加载样式表，
// 这样刷新时不会先闪一下另一套颜色。
const THEME_KEY = "dshTheme";

function applyTheme(name, save = true) {
  const celadon = name !== "cyrene";
  document.documentElement.classList.toggle("theme-celadon", celadon);
  if (save) {
    try { localStorage.setItem(THEME_KEY, celadon ? "celadon" : "cyrene"); } catch (e) { /* 忽略 */ }
  }
  document.querySelectorAll('#themePicker input[name="theme"]').forEach((el) => {
    el.checked = (el.value === (celadon ? "celadon" : "cyrene"));
  });
}

function initTheme() {
  let name = "celadon";
  try { name = localStorage.getItem(THEME_KEY) === "cyrene" ? "cyrene" : "celadon"; } catch (e) { /* 忽略 */ }
  applyTheme(name, false);
  document.querySelectorAll('#themePicker input[name="theme"]').forEach((el) => {
    el.addEventListener("change", () => { if (el.checked) applyTheme(el.value); });
  });
}

(async () => {
  // 开屏兜底：8 秒内一定让它退场（正常路径几百毫秒就走完，这里只是保险）
  setTimeout(() => { try { api("/api/ready", {}); } catch (e) { /* ignore */ } }, 8000);

  // ★ 第一件事：告诉服务端"新页面来了"。
  //   如果上一次 pagehide 预约过退出（选「完全退出」时按 F5 就会），
  //   这一下会把它取消掉。**必须放在最前面** —— 放到后面万一加载慢，
  //   15 秒宽限期一过程序就自己退了。
  try {
    await _withTimeout(api("/api/hello", {}), 3000, null);
  } catch (e) { /* 老版本服务端没有这个接口也不该卡住 */ }
  bindQuitButton();
  initTheme();

  connect();
  try {
    await _withTimeout(loadConfig(), 4000, null);
  } catch (e) { /* 配置读不到也要继续，界面不能停在半路 */ }
  try {
    const st = await _withTimeout(fetch("/api/state").then((r) => r.json()), 4000, null);
    if (st) {
      setRunning(!!st.running);
      if (st.running) setStatus("运行中", "run");
      setPrepUI(st.prep || { running: false });
    }
  } catch { /* 忽略 */ }
  refreshShot();
  refreshShotDir();
  bindUpdateUI();
  refreshUpdate(true);
  // 启动后的静默检查要约 4 秒 + 网络时间，晚点再拉一次结果
  setTimeout(() => refreshUpdate(true), 8000);

  // 首次使用引导：没配 Key 就直接把人带到设置页，省得对着空白发愣
  if (!keyAlreadySet) {
    addLog("warn", "还没有配置 API Key —— 已经帮你打开「设置」页，填好 Key 再回来开始。");
    document.querySelector('.nav-item[data-view="settings"]').click();
    $("dsKey").focus();
    toast("请先填写 DeepSeek API Key", "warn", 8000);
  } else {
    addLog("info", "界面已就绪。作业网站需要登录的话，先点「① 打开浏览器登录」。");
  }

  // ★ 告诉服务端"界面画好了" → 原生开屏窗口淡出。
  //   放在最后（配置读完了、页面也铺好了），这样开屏淡出时后面已经是完整的界面，
  //   而不是空壳。放在最前面的话会露出一段没铺好的页面。
  try {
    await api("/api/ready", {});
  } catch (e) { /* 失败也没关系：开屏窗口自己有超时兜底 */ }

  // 准备阶段的浏览器是独立进程，用户可能自己把它关掉 —— 定期同步一下状态，
  // 免得界面一直显示"已打开"却其实早就没了。
  setInterval(refreshPrep, 5000);
})();
