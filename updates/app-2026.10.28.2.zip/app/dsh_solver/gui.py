"""Tkinter 图形界面。

线程模型（重要，踩过的坑都在这里）：
  - Tk 只能在主线程里碰；
  - Playwright sync API 不能跑在 Tk 主线程（会和 Tk 的事件循环/信号打架），也不能跨线程共享；
  - pyautogui 的截图在 Tk 初始化之后调用才稳定。
所以：主线程 = Tk + 轮询队列；工作线程 = Playwright / pyautogui。
两边只通过 queue.Queue 和一个 threading.Event（人工确认）通信。
"""
from __future__ import annotations

import queue
import threading
import traceback
from datetime import datetime
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, X, BooleanVar, IntVar, StringVar, Tk, messagebox
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText

from . import config
from .agent import SessionResult, SolverAgent
from .lms import LMError, LMStudioClient

APP_TITLE = "LM Studio 网页答题助手"


class App:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.q: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.agent: SolverAgent | None = None
        self.confirm = threading.Event()
        self.confirm_answer = False
        self.client: LMStudioClient | None = None
        self._last_shot_path: Path | None = None
        self._photo = None

        root.title(APP_TITLE)
        root.geometry("1180x780")
        root.minsize(980, 640)

        self._build_vars()
        self._build_ui()
        self._poll()
        self.root.after(300, self.refresh_lm_status)

    # ------------------------------------------------------------ 变量
    def _build_vars(self) -> None:
        self.v_url = StringVar(value="")
        self.v_task = StringVar(value="")
        self.v_headless = BooleanVar(value=config.HEADLESS)
        self.v_auto_submit = BooleanVar(value=config.AUTO_SUBMIT)
        self.v_dry_run = BooleanVar(value=config.DRY_RUN)
        self.v_pause_login = BooleanVar(value=True)
        self.v_auto_next = BooleanVar(value=config.AUTO_NEXT)
        self.v_batch = IntVar(value=config.BATCH_SIZE)
        self.v_rounds = IntVar(value=config.MAX_ROUNDS)
        self.v_pages = IntVar(value=config.MAX_PAGES)
        self.v_steps = IntVar(value=config.PC_AGENT_MAX_STEPS)
        self.v_model = StringVar(value=config.LM_MODEL or "(自动)")
        self.v_base = StringVar(value=config.LM_BASE_URL)
        self.v_status = StringVar(value="就绪")
        self.v_lm = StringVar(value="LM Studio：未检测")

    # ------------------------------------------------------------ 界面
    def _build_ui(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except Exception:
            pass

        nb = ttk.Notebook(self.root)
        self.nb = nb
        nb.pack(fill=BOTH, expand=True, padx=8, pady=(8, 0))
        self.tab_web = ttk.Frame(nb)
        self.tab_pc = ttk.Frame(nb)
        self.tab_set = ttk.Frame(nb)
        nb.add(self.tab_web, text="  网页答题  ")
        nb.add(self.tab_pc, text="  键鼠代理(PC)  ")
        nb.add(self.tab_set, text="  设置/自检  ")
        self._build_web_tab()
        self._build_pc_tab()
        self._build_set_tab()

        bar = ttk.Frame(self.root)
        bar.pack(fill=X, padx=8, pady=6)
        self.lbl_status = ttk.Label(bar, textvariable=self.v_status, anchor="w")
        self.lbl_status.pack(side=LEFT, fill=X, expand=True)
        self.btn_stop = ttk.Button(bar, text="停止", command=self.on_stop, state="disabled", width=10)
        self.btn_stop.pack(side=RIGHT)
        self.btn_start = ttk.Button(bar, text="开始 (F5)", command=self.on_start, width=14)
        self.btn_start.pack(side=RIGHT, padx=(0, 6))

        self.root.bind("<F5>", lambda e: self.on_start())
        self.root.bind("<Escape>", lambda e: self.on_stop())

    # -------------------------------------------------- 网页答题页
    def _build_web_tab(self) -> None:
        f = self.tab_web
        top = ttk.LabelFrame(f, text="目标网页")
        top.pack(fill=X, padx=4, pady=4)
        ttk.Label(top, text="网址").grid(row=0, column=0, padx=(8, 4), pady=6, sticky="w")
        e = ttk.Entry(top, textvariable=self.v_url)
        e.grid(row=0, column=1, padx=4, pady=6, sticky="ew")
        top.columnconfigure(1, weight=1)
        ttk.Button(top, text="打开浏览器", command=self.on_open_browser, width=12).grid(row=0, column=2, padx=4)
        ttk.Label(
            top,
            text="提示：默认会尝试接管你已经开着的 Chrome（需带 --remote-debugging-port=9222），"
                 "连不上就另起一个独立浏览器。登录类页面会暂停等你手动登录。",
            foreground="#666",
        ).grid(row=1, column=0, columnspan=3, padx=8, pady=(0, 6), sticky="w")

        mid = ttk.Frame(f)
        mid.pack(fill=X, padx=4)
        opt = ttk.LabelFrame(mid, text="作答选项")
        opt.pack(side=LEFT, fill=X, expand=True, padx=(4, 2), pady=4)
        ttk.Checkbutton(opt, text="自动提交（⚠ 谨慎）", variable=self.v_auto_submit).grid(row=0, column=0, sticky="w", padx=8, pady=3)
        ttk.Checkbutton(opt, text="演练模式（只推理不落笔）", variable=self.v_dry_run).grid(row=0, column=1, sticky="w", padx=8, pady=3)
        ttk.Checkbutton(opt, text="遇到登录页暂停等我", variable=self.v_pause_login).grid(row=1, column=0, sticky="w", padx=8, pady=3)
        ttk.Checkbutton(opt, text="无头模式（不显示浏览器窗口）", variable=self.v_headless).grid(row=1, column=1, sticky="w", padx=8, pady=3)
        ttk.Checkbutton(opt, text="自动点「下一题」（逐题分页的作业必开）",
                        variable=self.v_auto_next).grid(row=2, column=0, columnspan=2, sticky="w", padx=8, pady=3)
        ttk.Label(opt, text="每批题数").grid(row=3, column=0, sticky="w", padx=8, pady=3)
        ttk.Spinbox(opt, from_=1, to=10, width=5, textvariable=self.v_batch).grid(row=3, column=0, sticky="e", padx=8)
        ttk.Label(opt, text="最多轮数").grid(row=3, column=1, sticky="w", padx=8, pady=3)
        ttk.Spinbox(opt, from_=1, to=200, width=5, textvariable=self.v_rounds).grid(row=3, column=1, sticky="e", padx=8)
        ttk.Label(opt, text="最多翻页").grid(row=3, column=2, sticky="w", padx=8, pady=3)
        ttk.Spinbox(opt, from_=1, to=300, width=5, textvariable=self.v_pages).grid(row=3, column=2, sticky="e", padx=8)

        panes = ttk.Panedwindow(f, orient="horizontal")
        panes.pack(fill=BOTH, expand=True, padx=4, pady=4)

        left = ttk.LabelFrame(panes, text="运行日志")
        self.txt = ScrolledText(left, wrap="word", height=20, font=("Consolas", 9))
        self.txt.pack(fill=BOTH, expand=True, padx=4, pady=4)
        panes.add(left, weight=3)

        right = ttk.LabelFrame(panes, text="页面截图")
        self.lbl_shot = ttk.Label(right, text="(开始后这里会实时显示截图)", anchor="center")
        self.lbl_shot.pack(fill=BOTH, expand=True, padx=4, pady=4)
        panes.add(right, weight=2)

    # -------------------------------------------------- PC 模式页
    def _build_pc_tab(self) -> None:
        f = self.tab_pc
        top = ttk.LabelFrame(f, text="任务描述（用自然语言说清楚要干什么）")
        top.pack(fill=X, padx=4, pady=4)
        self.txt_task = ScrolledText(top, wrap="word", height=4, font=("Microsoft YaHei UI", 9))
        self.txt_task.pack(fill=X, padx=6, pady=6)
        self.txt_task.insert(
            "1.0",
            "示例：屏幕上有一个在线答题网页，请阅读题目，选中正确答案的单选按钮，然后点击「提交」。"
            "遇到需要输入中文的填空题，先点击输入框再输入。",
        )
        row = ttk.Frame(top)
        row.pack(fill=X, padx=6, pady=(0, 6))
        ttk.Label(row, text="最多步数").pack(side=LEFT)
        ttk.Spinbox(row, from_=1, to=200, width=5, textvariable=self.v_steps).pack(side=LEFT, padx=6)
        ttk.Label(
            row, text="（每一步都要问一次视觉模型，9B 模型点上，慢但通用）", foreground="#666"
        ).pack(side=LEFT, padx=6)

        warn = ttk.LabelFrame(f, text="注意")
        warn.pack(fill=X, padx=4, pady=4)
        ttk.Label(
            warn,
            text="此模式会真实移动你的鼠标、真实敲键盘。运行期间请不要动鼠标键盘；"
                 "把鼠标快速甩到屏幕左上角可触发 pyautogui 之外的紧急停止（本工具已关闭该保护，"
                 "请用「停止」按钮）。建议先在不重要的页面上试一次。",
            wraplength=1050, justify=LEFT, foreground="#a33",
        ).pack(fill=X, padx=8, pady=8)

        panes = ttk.Panedwindow(f, orient="horizontal")
        panes.pack(fill=BOTH, expand=True, padx=4, pady=4)
        left = ttk.LabelFrame(panes, text="行动日志")
        self.txt_pc = ScrolledText(left, wrap="word", height=20, font=("Consolas", 9))
        self.txt_pc.pack(fill=BOTH, expand=True, padx=4, pady=4)
        panes.add(left, weight=3)
        right = ttk.LabelFrame(panes, text="屏幕快照")
        self.lbl_shot_pc = ttk.Label(right, text="(运行后这里显示每一步的屏幕)", anchor="center")
        self.lbl_shot_pc.pack(fill=BOTH, expand=True, padx=4, pady=4)
        panes.add(right, weight=2)

    # -------------------------------------------------- 设置/自检页
    def _build_set_tab(self) -> None:
        f = self.tab_set
        lm = ttk.LabelFrame(f, text="LM Studio 连接")
        lm.pack(fill=X, padx=4, pady=6)
        ttk.Label(lm, text="Base URL").grid(row=0, column=0, padx=8, pady=6, sticky="w")
        ttk.Entry(lm, textvariable=self.v_base, width=42).grid(row=0, column=1, padx=4, sticky="w")
        ttk.Label(lm, text="模型").grid(row=1, column=0, padx=8, pady=6, sticky="w")
        self.cmb_model = ttk.Combobox(lm, textvariable=self.v_model, width=40, state="readonly")
        self.cmb_model.grid(row=1, column=1, padx=4, sticky="w")
        ttk.Button(lm, text="刷新/自检", command=self.refresh_lm_status, width=14).grid(row=0, column=2, padx=8)
        ttk.Button(lm, text="用这个模型", command=self.apply_model, width=14).grid(row=1, column=2, padx=8)
        self.txt_lm = ScrolledText(lm, height=8, font=("Consolas", 9))
        self.txt_lm.grid(row=2, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
        lm.columnconfigure(1, weight=1)

        paths = ttk.LabelFrame(f, text="输出位置")
        paths.pack(fill=X, padx=4, pady=6)
        ttk.Label(paths, text=f"截图：{config.SHOT_DIR}").pack(anchor="w", padx=8, pady=2)
        ttk.Label(paths, text=f"运行记录：{config.RUNS_DIR}").pack(anchor="w", padx=8, pady=2)
        ttk.Label(paths, text=f"浏览器档案：{config.PROFILE_DIR}").pack(anchor="w", padx=8, pady=2)
        brow = ttk.Frame(paths)
        brow.pack(fill=X, padx=8, pady=6)
        ttk.Button(brow, text="打开输出目录", command=lambda: self._open(config.OUT_DIR)).pack(side=LEFT)
        ttk.Button(brow, text="打开浏览器档案目录", command=lambda: self._open(config.PROFILE_DIR)).pack(side=LEFT, padx=6)

        helpf = ttk.LabelFrame(f, text="给 Chrome 开调试端口（这样能复用你的登录状态）")
        helpf.pack(fill=BOTH, expand=True, padx=4, pady=6)
        ttk.Label(
            helpf,
            justify=LEFT, wraplength=1050,
            text=(
                "先完全关掉 Chrome，然后在 PowerShell / CMD 里执行：\n\n"
                '  & "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" '
                "--remote-debugging-port=9222 --user-data-dir=\"%USERPROFILE%\\.chrome-debug\"\n\n"
                "在这个窗口里登录你的作业网站并打开作业页面，回到本工具点「开始」，"
                f"程序会通过 CDP 接管这个浏览器（默认地址 {config.CDP_URL}）。\n\n"
                "不用这种方式也行：直接点「开始」，程序会用项目自带的独立浏览器档案启动 Chrome，"
                "你在那个窗口里登录一次，之后再启动就还是登录状态。"
            ),
        ).pack(fill=BOTH, padx=8, pady=8)

    @staticmethod
    def _open(p: Path) -> None:
        import os
        try:
            os.startfile(str(p))  # type: ignore[attr-defined]
        except Exception:
            pass

    # ------------------------------------------------------------ 队列通信
    def _poll(self) -> None:
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self._append_log(payload)
                elif kind == "log_pc":
                    self._append_log(payload, pc=True)
                elif kind == "status":
                    self.v_status.set(payload)
                elif kind == "shot":
                    self._show_shot(payload)
                elif kind == "confirm":
                    question, ev = payload
                    ok = messagebox.askyesno(APP_TITLE, question)
                    self.confirm_answer = ok
                    ev.set()
                elif kind == "done":
                    self._on_done(payload)
                elif kind == "lm":
                    self._fill_lm(payload)
        except queue.Empty:
            pass
        self.root.after(120, self._poll)

    def _append_log(self, text: str, pc: bool = False) -> None:
        w = self.txt_pc if pc else self.txt
        w.insert(END, text + "\n")
        w.see(END)

    def _show_shot(self, path: Path) -> None:
        lbl = self.lbl_shot_pc if self._pc_mode else self.lbl_shot
        try:
            from PIL import Image, ImageTk
            img = Image.open(path)
            maxw = max(320, lbl.winfo_width() - 12)
            maxh = max(240, lbl.winfo_height() - 12)
            r = min(maxw / img.width, maxh / img.height, 1.0)
            if r < 1.0:
                img = img.resize((max(1, int(img.width * r)), max(1, int(img.height * r))))
            self._photo = ImageTk.PhotoImage(img)
            lbl.configure(image=self._photo, text="")
            self._last_shot_path = path
        except Exception:
            lbl.configure(text=f"截图：{path.name}")

    # ------------------------------------------------------------ 动作
    def on_open_browser(self) -> None:
        """只开浏览器、不答题，方便用户先登录。"""
        url = self.v_url.get().strip()
        self.v_status.set("正在打开浏览器…")
        self._append_log("— 正在打开浏览器（不自动答题）—")

        def work() -> None:
            from .browser import BrowserDriver
            d = None
            try:
                d = BrowserDriver(headless=False)
                d.open(url or None)
                d.wait_for_load()
                self.log(f"浏览器已就绪，标题：{d.page.title()}")
                self.log("请在这个窗口里登录 / 进入作业页面，然后直接点「开始」。程序会继续用同一个浏览器。")
                self.queue_shot(d.screenshot(tag="manual_open"))
                self.queue_status("浏览器已打开，等你登录后点「开始」")
                # 保持浏览器存活：把它挂在 self 上，不让它被 GC
                self._keep_driver = d
            except Exception as e:
                self.log(f"✘ 打开浏览器失败：{e}")
                try:
                    d and d.close()
                except Exception:
                    pass

        threading.Thread(target=work, daemon=True).start()

    def on_start(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_TITLE, "正在运行中，请先停止。")
            return
        self._pc_mode = self._is_pc_tab()
        if self._pc_mode:
            self._start_pc()
        else:
            self._start_web()

    def _is_pc_tab(self) -> bool:
        try:
            return self.nb.index(self.nb.select()) == 1
        except Exception:
            return False

    def _new_client(self) -> LMStudioClient:
        base = self.v_base.get().strip() or config.LM_BASE_URL
        model = self.v_model.get().strip()
        if model in ("(自动)", ""):
            model = config.LM_MODEL
        return LMStudioClient(base_url=base, model=model or None)

    def _start_web(self) -> None:
        url = self.v_url.get().strip()
        if not url:
            messagebox.showwarning(APP_TITLE, "请先填写作业网页的网址。")
            return
        self._clear_log()
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")

        try:
            client = self._new_client()
        except Exception as e:
            self._append_log(f"✘ 初始化 LM Studio 客户端失败：{e}")
            self._reset_buttons()
            return

        agent = SolverAgent(
            client,
            log=self.log,
            status=self.queue_status,
            on_shot=self.queue_shot,
            ask_user=self.ask_user,
            auto_submit=self.v_auto_submit.get(),
            dry_run=self.v_dry_run.get(),
            batch_size=self.v_batch.get(),
            max_rounds=self.v_rounds.get(),
            auto_next=self.v_auto_next.get(),
            max_pages=self.v_pages.get(),
        )
        self.agent = agent

        def work() -> None:
            try:
                res = agent.run_web(
                    url,
                    headless=self.v_headless.get(),
                    pause_for_login=self.v_pause_login.get(),
                )
                self.q.put(("done", ("web", res)))
            except Exception:
                self.log("✘ 未捕获异常：\n" + traceback.format_exc())
                self.q.put(("done", ("web", SessionResult(error="内部错误，见日志"))))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()
        self.log(f"模型：{client.model}   视觉：{'支持' if client.is_vision_capable() else '不支持'}")

    def _start_pc(self) -> None:
        task = self.txt_task.get("1.0", END).strip()
        if not task:
            messagebox.showwarning(APP_TITLE, "请先描述要完成的任务。")
            return
        if not messagebox.askyesno(APP_TITLE, "PC 模式会真实操控你的鼠标和键盘。\n\n运行期间请不要动鼠标键盘。是否继续？"):
            return
        self._clear_log()
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        try:
            client = self._new_client()
        except Exception as e:
            self._append_log(f"✘ 初始化失败：{e}", pc=True)
            self._reset_buttons()
            return
        agent = SolverAgent(
            client,
            log=lambda s: self.q.put(("log_pc", s)),
            status=self.queue_status,
            on_shot=self.queue_shot,
            ask_user=self.ask_user,
        )
        self.agent = agent

        def work() -> None:
            # Tk 已初始化，此刻 pyautogui 截图才稳定
            try:
                res = agent.run_pc(task, max_steps=self.v_steps.get())
                self.q.put(("done", ("pc", res)))
            except Exception:
                self.q.put(("log_pc", "✘ 未捕获异常：\n" + traceback.format_exc()))
                self.q.put(("done", ("pc", SessionResult(error="内部错误，见日志"))))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def on_stop(self) -> None:
        if self.agent:
            self.agent.stop_now()
            self.v_status.set("正在停止…")
        self.confirm.set()

    def _on_done(self, payload) -> None:
        mode, res = payload
        self._reset_buttons()
        w = self.txt_pc if mode == "pc" else self.txt
        w.insert(END, "\n" + "=" * 60 + "\n")
        w.insert(END, f"结束：成功 {len(res.answered)} 题 / 需复核 {len(res.failed)} 题 / 用时 {res.seconds:.0f}s\n")
        if res.error:
            w.insert(END, f"错误/提示：{res.error}\n")
        w.see(END)
        self.v_status.set(f"完成（成功 {len(res.answered)}，待复核 {len(res.failed)}）")
        if getattr(self, "_keep_driver", None) is not None:
            # 网页模式的浏览器保持打开，方便用户复核提交
            pass

    def _reset_buttons(self) -> None:
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")

    def _clear_log(self) -> None:
        w = self.txt_pc if getattr(self, "_pc_mode", False) else self.txt
        w.delete("1.0", END)

    # ------------------------------------------------------------ 回调（工作线程里调）
    def log(self, s: str) -> None:
        self.q.put(("log", f"[{datetime.now().strftime('%H:%M:%S')}] {s}"))

    def queue_status(self, s: str) -> None:
        self.q.put(("status", s))

    def queue_shot(self, p: Path) -> None:
        self.q.put(("shot", Path(p)))

    def ask_user(self, question: str) -> bool:
        ev = threading.Event()
        self.q.put(("confirm", (question, ev)))
        ev.wait(timeout=1800)
        return self.confirm_answer

    # ------------------------------------------------------------ LM 自检
    def refresh_lm_status(self) -> None:
        base = self.v_base.get().strip() or config.LM_BASE_URL

        def work() -> None:
            info = {"base": base, "ok": False, "lines": [], "models": []}
            try:
                c = LMStudioClient(base_url=base, model="__probe__")
                native = c.native_models()
                info["ok"] = True
                info["lines"].append(f"连接成功：{base}")
                if native:
                    info["lines"].append(f"{'id':44s} {'type':10s} state")
                    for m in native:
                        info["lines"].append(f"{m.get('id',''):44s} {str(m.get('type')):10s} {m.get('state')}")
                        if m.get("type") in ("vlm", "llm"):
                            info["models"].append(m.get("id", ""))
                else:
                    for m in c.list_models():
                        info["lines"].append(f"  {m.get('id')}")
                        info["models"].append(m.get("id", ""))
                info["lines"].append("")
                info["lines"].append("视觉模型（type=vlm）= 能看截图；type=llm 只能读文字。")
            except LMError as e:
                info["lines"].append(f"✘ 连接失败：{e}")
            except Exception as e:
                info["lines"].append(f"✘ 自检异常：{type(e).__name__}: {e}")
            self.q.put(("lm", info))

        threading.Thread(target=work, daemon=True).start()

    def _fill_lm(self, info: dict) -> None:
        self.txt_lm.delete("1.0", END)
        self.txt_lm.insert(END, "\n".join(info["lines"]) + "\n")
        if info["models"]:
            self.cmb_model.configure(values=info["models"])
            if self.v_model.get() in ("(自动)", "", "__probe__"):
                self.v_model.set(info["models"][0])
        self.v_lm.set(("LM Studio：在线" if info["ok"] else "LM Studio：离线 ⚠"))
        self.log(f"LM 自检：{'在线' if info['ok'] else '离线'}（{info['base']}）")

    def apply_model(self) -> None:
        m = self.v_model.get()
        if not m or m.startswith("("):
            messagebox.showinfo(APP_TITLE, "请先点「刷新/自检」选一个模型。")
            return
        self.log(f"已选用模型：{m}")


def main() -> None:
    root = Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
