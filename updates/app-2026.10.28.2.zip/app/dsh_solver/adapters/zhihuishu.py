# -*- coding: utf-8 -*-
"""智慧树适配器。

覆盖智慧树**并存的五套系统**（DOM 结构互不兼容，这一点开源项目 Autovisor
也明确记着）：
    · AI 版课程   ai-smart-course-student-pro.zhihuishu.com  ← 资源卡片式
    · 老版课程    studyh5.zhihuishu.com                      ← 播放器式
    · 翻转课      hike.zhihuishu.com
    · 融合课      fusioncourseh5.zhihuishu.com
    · 考试        examloop.zhihuishu.com

实现状态
--------
**当前是「桥接实现」**：接口方法复用 `dsh_solver.course.CourseRunner` 里
已经验证过的逻辑，而不是把这些逻辑复制一份。

这么做的理由（重要）：
  · 那些逻辑是真机上踩了很多坑才调对的（展开判据、卡片选取顺序、
    进度以平台为准、弹题暂停计时…），复制一份就有两份会各自腐烂；
  · 桥接能让适配器接口**立刻可用**，被真实代码检验，
    而不是先设计一套"看起来对"的接口再发现不合用；
  · 搬家可以增量做（P2），每一步都能跑智慧树回归确认没坏。

所以这个文件现在**不含 DOM 选择器**，选择器仍在 `course.py` 里；
等搬家完成，它们会整体迁进本文件。
"""
from __future__ import annotations

from ..core.adapter import PlatformAdapter, register
from ..core.models import (Chapter, Course, ExamPage, PlatformProgress,
                           VideoState)

# 域名 → 匹配分。分数越高越优先；0 表示不匹配。
# 顺序即优先级（同一 URL 命中多个时取最高分）。
_HOSTS: list[tuple[str, int]] = [
    # AI 版课程（资源卡片式）—— 专用引擎支持得最完整，给最高分
    ("ai-smart-course", 90),
    ("ai-smart-course-student-pro", 95),
    # 考试系统
    ("examloop.zhihuishu", 80),
    # 老版 / 翻转 / 融合：播放器式
    ("studyh5.zhihuishu", 70),
    ("hike.zhihuishu", 70),
    ("fusioncourseh5.zhihuishu", 70),
    # 其它 zhihuishu 子域（如 passport 登录页）—— 低分，只作兜底识别
    ("zhihuishu.com", 30),
]


@register
class ZhihuishuAdapter(PlatformAdapter):
    platform_name = "智慧树"
    key = "zhihuishu"

    # ------------------------------------------------------------------
    # 页面版本（本平台内部有**六套学习页 + 十套作业页**，DOM 互不兼容）
    # ------------------------------------------------------------------
    # 路由表来自开源调研（OCS 的 ZHSProject 把这套东西列得最全）。
    # 这里只列出**我们实际会走**的几类；其余先归到 legacy/unknown，
    # 等真遇到再加 —— 宁可少列，也不要把没验证过的当已知。
    _PAGE_TYPES: list[tuple[str, str]] = [
        # AI 版 / 新形态课程 —— 资源卡片式，我们有专用引擎
        ("ai-smart-course-student-pro", "ai-smart"),
        ("smartcoursestudent", "ai-smart"),
        ("smartcourseexam", "ai-smart-exam"),
        ("fusioncourseh5", "fusion"),
        # 共用课（旧 / 新）
        ("studyvideoh5", "legacy"),
        ("studyplush5", "plus"),
        # 2025 之后的新智慧系列
        ("studywisdomh5", "wisdom"),
        ("wisdom-mooc", "wisdom"),
        # 翻转课 / 校内课
        ("hike.zhihuishu", "hike"),
        ("aidedteaching", "hike"),
        # AI 教学空间（另一个域名）
        ("polymas.com", "hike-v2"),
        # 考试
        ("examloop", "exam"),
        ("stuExamWeb", "exam-legacy"),
        ("studentexamcomh5", "exam-new"),
    ]

    def page_type(self, url: str = "") -> str:
        u = (url or "").lower()
        for pat, name in self._PAGE_TYPES:
            if pat.lower() in u:
                return name
        return "unknown"

    # ------------------------------------------------------------------
    # 识别
    # ------------------------------------------------------------------
    def match(self, url: str) -> int:
        u = (url or "").lower()
        if not u:
            return 0
        best = 0
        for host, score in _HOSTS:
            if host in u:
                best = max(best, score)
        return best
    # ------------------------------------------------------------------
    # 课程与章节
    # ------------------------------------------------------------------
    def get_courses(self, page=None) -> list[Course]:
        """课程页直开时只有一门课 —— 用页面标题当名字。"""
        name = ""
        try:
            name = self.driver.page.title() if self.driver else ""
        except Exception:
            pass
        return [Course(id="current", name=name or "当前课程")]

    def get_chapters(self, page=None, course: Course | None = None
                     ) -> list[Chapter]:
        """把引擎读到的知识点/章节统一转成 Chapter。

        AI 版课程：知识点（带「必学 n/n」进度）
        老版课程：目录项
        两种都用平台自己的进度数字，取不到就留 -1。
        """
        eng = self._bridge()
        out: list[Chapter] = []

        # ① 资源卡片式（AI 版）：知识点带进度文字
        try:
            st = eng._ai_scan()
            if st.get("isAI"):
                for i, t in enumerate(st.get("topics") or []):
                    prog = str(t.get("progress") or "")
                    done, total = _parse_progress(prog)
                    out.append(Chapter(
                        id=str(t.get("name") or i),
                        name=str(t.get("name") or ""),
                        done=(total >= 0 and done >= total),
                        finished=done, total=total, index=i,
                        raw={"active": bool(t.get("active")), "progress": prog}))
                return out
        except Exception:
            pass

        # ② 播放器式（老版）：平台目录
        try:
            cat = eng._catalog()
            for i, it in enumerate(cat.get("items") or []):
                out.append(Chapter(
                    id=str(it.get("title") or i),
                    name=str(it.get("title") or ""),
                    done=bool(it.get("finish")),
                    index=i, raw=dict(it)))
        except Exception:
            pass
        return out

    def open_chapter(self, page=None, chapter: Chapter | None = None) -> bool:
        """进入一节。

        AI 版：点知识点（引擎里已处理"展开式累加"的坑）
        老版：点目录项
        """
        if chapter is None:
            return False
        eng = self._bridge()
        try:
            st = eng._ai_scan()
            if st.get("isAI"):
                return bool(eng._ai_select_topic(chapter.name))
        except Exception:
            pass
        try:
            return bool(eng._click_next({"text": chapter.name}))
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 播放
    # ------------------------------------------------------------------
    def get_video(self, page=None) -> VideoState:
        """当前播放器状态。播放器可能在 iframe 里，交给引擎的通用探测。"""
        eng = self._bridge()
        try:
            v = eng._any_video()
        except Exception:
            return VideoState()
        if not v.get("found"):
            return VideoState()
        return VideoState(
            found=True,
            current=float(v.get("currentTime") or 0),
            duration=float(v.get("duration") or 0),
            ended=bool(v.get("ended")),
            paused=bool(v.get("paused")),
            rate=float(v.get("rate") or 1),
            src=str(v.get("src") or ""),
            frame=v.get("_frame"))

    def max_rate(self) -> float:
        """智慧树 AI 版实测上限 1.5×（用户真机验证）。

        ⚠ 这里读的是配置值，改配置即可调整，不用改代码。
        """
        from .. import config
        return float(config.COURSE_MAX_SPEED)

    def set_rate(self, page=None, rate: float = 1.0) -> float:
        """走引擎的实现 —— 它会**在播放器所在的框架里**执行设置。

        ⚠ 这个细节很关键：直接对顶层页面 evaluate 的话，
          播放器在 iframe 里时那行 JS 等于什么都没做
          （实测表现：日志说设好了、实际仍是 1×）。
        """
        return self._bridge()._set_video_rate(rate)

    def quiz_visible(self, page=None) -> bool:
        """课中弹题（答完才能继续播）。判据来自 Autovisor。"""
        try:
            return bool(self._bridge()._ai_quiz_visible())
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 平台进度 —— ★ 这就是 `_catalog()` 的正确接线方式
    #
    # 背景：`_catalog()` + `ZHIHUISHU_CATALOGS`（四套目录结构，约 120 行）
    #   一直存在于 course.py 里，但**从未被任何地方调用过** ——
    #   实际生效的完成判据是 `cur / dur >= 0.98`（靠播放位置猜）。
    #   真机后果见过：视频播到结尾、平台一条都没记，程序反复重刷同一节。
    #
    # 现在把它接到适配器接口上，让"平台进度为准"这条铁律真正生效。
    # `_catalog()` 返回的结构正好够用：
    #   { matched, name, total, finished, progress(百分比), done, title }
    # ------------------------------------------------------------------
    def progress(self, page=None, chapter=None) -> PlatformProgress:
        eng = self._bridge()

        # ① 资源卡片式（AI 版）：平台在知识点上写「必学 n/n」
        #    这是最可靠的一路，优先用。
        try:
            st = eng._ai_scan()
            if st.get("isAI"):
                for t in (st.get("topics") or []):
                    if chapter is not None and (t.get("name") or "") != chapter.name:
                        # 不是目标知识点就跳过，但记住"当前高亮"那个
                        if not t.get("active"):
                            continue
                    txt = str(t.get("progress") or "")
                    done, total = _parse_progress(txt)
                    if total >= 0:
                        return PlatformProgress(
                            found=True, finished=done, total=total,
                            done=(done >= total),
                            text=txt, source="知识点进度")
        except Exception:
            pass

        # ② 播放器式（老版 / 融合 / 翻转）：走平台自己的目录结构
        #    `_catalog()` 会逐个尝试四套选择器，命中哪套由页面决定。
        try:
            cat = eng._catalog()
        except Exception:
            cat = {}
        if cat.get("matched"):
            pct = cat.get("progress")
            fin = int(cat.get("finished") or -1)
            tot = int(cat.get("total") or -1)
            return PlatformProgress(
                found=True,
                percent=float(pct) if pct is not None else -1.0,
                finished=fin, total=tot,
                done=bool(cat.get("done")) or (tot > 0 and fin >= tot),
                text=str(cat.get("name") or "") + (
                    f" {fin}/{tot}" if tot > 0 else
                    (f" {pct:.0f}%" if pct is not None else "")),
                source="平台目录")

        # ③ 都没有 → 交给通用的语义扫描（它可能认得别的写法）
        return super().progress(page, chapter)

    def close_player(self, page=None) -> None:
        try:
            self._bridge()._ai_close_player()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 答题
    # ------------------------------------------------------------------
    def get_exam(self, page=None) -> ExamPage:
        """智慧树的答题页没有额外结构要求，交给通用扫描即可。"""
        return ExamPage(is_exam=True, title="智慧树答题页")

    def submit_exam(self, page=None) -> bool:
        """提交按钮的文案差异已由通用词表覆盖（submit/交卷/完成作答…）。"""
        return False

    # ------------------------------------------------------------------
    # 账号
    # ------------------------------------------------------------------
    def get_user_info(self, page=None) -> dict:
        """用户名。登录态由浏览器档案保存，这里只在页面上顺带读一下。"""
        try:
            name = self.driver.page.evaluate(
                """() => {
                    for (const s of ['.user-name', '.nameBox', '.userInfo .name',
                                     '.personal-name', '.head-name']) {
                        const e = document.querySelector(s);
                        if (e && (e.innerText || '').trim())
                            return (e.innerText || '').trim().slice(0, 30);
                    }
                    return '';
                }""") if self.driver else ""
            return {"name": name or ""}
        except Exception:
            return {}


def _parse_progress(text: str) -> tuple[int, int]:
    """从「必学 4/5」里解析出 (4, 5)。解析不出来返回 (-1, -1)。"""
    import re
    m = re.search(r"(\d+)\s*/\s*(\d+)", text or "")
    if not m:
        return -1, -1
    return int(m.group(1)), int(m.group(2))
