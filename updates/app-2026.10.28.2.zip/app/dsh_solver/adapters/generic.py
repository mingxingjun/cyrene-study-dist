# -*- coding: utf-8 -*-
"""通用兜底适配器 —— **必须最后注册**。

它匹配任何 http(s)/file 页面，但分数很低（10），所以只有在没有任何
专用适配器命中时才会被选中。

负责的形态：**播放器式课程页**
    页面上直接有可播的 <video>，学完一节点「下一节」推进。
    典型代表：自建网课平台、老版各类网校、以及我们还不知道的平台。

这样设计的好处：以后遇到没适配过的平台，只要它结构是"有视频 + 下一节"，
**不写任何代码就能跑**。
"""
from __future__ import annotations

from ..core.adapter import PlatformAdapter, register
from ..core.models import Chapter, Course, ExamPage, VideoState

# 「下一节」这类按钮的文案（跨平台词表，与 browser.py 里那份保持一致）
_NEXT_WORDS = ("下一节", "下一课", "下一章", "下一个", "下一讲", "下一题",
               "继续学习", "继续播放", "next", "continue")


@register
class GenericAdapter(PlatformAdapter):
    platform_name = "通用"
    key = "generic"

    def match(self, url: str) -> int:
        """任何页面都给一个很低的分数 —— 只在没人认领时才轮到我。"""
        u = (url or "").strip().lower()
        if u.startswith(("http://", "https://", "file://")):
            return 10
        return 0
    # ------------------------------------------------------------------
    # 课程与章节
    # ------------------------------------------------------------------
    def get_courses(self, page=None) -> list[Course]:
        name = ""
        try:
            name = self.driver.page.title() if self.driver else ""
        except Exception:
            pass
        return [Course(id="current", name=name or "当前课程")]

    def get_chapters(self, page=None, course: Course | None = None
                     ) -> list[Chapter]:
        """通用页面读不到章节树 —— 用"点下一节"的方式逐条推进。

        这里返回一个**占位章节**表示"还能继续学"，
        真正的推进交给 `open_chapter()`。
        取不到按钮时 `open_chapter` 返回 False，引擎会累计失败次数，
        连续 3 次就停下 —— 所以**不会死循环**。

        ⚠ 已知限制（调研结论）：这个兜底**不适合所有平台**。
          有的平台（SPA + 服务端并发限流）必须用 Playwright 的**可信点击**，
          而且需要处理"答题速度过快"的限流弹窗；光靠通用兜底会一直推不动。
          遇到那种平台，应当**为它单独写一个适配器**，而不是让兜底硬撑。
        """
        return [Chapter(id="next", name="下一节", index=0,
                        total=1, finished=0)]

    def open_chapter(self, page=None, chapter: Chapter | None = None) -> bool:
        """点「下一节」按钮。逐个文案尝试，点中就走。"""
        eng = self._bridge()
        try:
            cands = eng._find_next()
        except Exception:
            cands = []
        for c in cands:
            t = str(c.get("text") or "").strip()
            if any(w in t for w in _NEXT_WORDS):
                try:
                    if eng._click_next(c):
                        return True
                except Exception:
                    continue
        # 没找到明确文案的按钮时，试第一个候选（有些平台按钮只有图标）
        if cands:
            try:
                return bool(eng._click_next(cands[0]))
            except Exception:
                pass
        return False

    # ------------------------------------------------------------------
    # 播放
    # ------------------------------------------------------------------
    def get_video(self, page=None) -> VideoState:
        eng = self._bridge()
        try:
            v = eng._any_video()
        except Exception:
            return VideoState()
        if not v.get("found"):
            return VideoState()
        return VideoState(
            found=True,
            current=float(v.get("currentTime") or 0),
            duration=float(v.get("duration") or 0),
            ended=bool(v.get("ended")),
            paused=bool(v.get("paused")),
            rate=float(v.get("rate") or 1),
            src=str(v.get("src") or ""),
            frame=v.get("_frame"))

    def max_rate(self) -> float:
        from .. import config
        return float(config.COURSE_MAX_SPEED)

    def set_rate(self, page=None, rate: float = 1.0) -> float:
        """通用平台先试"平台自己的倍速菜单"，没有再直接改 playbackRate。

        顺序很重要：走平台自己的菜单更"正"，不容易被内核改回去。
        """
        eng = self._bridge()
        try:
            info = eng._find_speed()
            if info and info.get("found"):
                got, _how = eng._apply_speed(rate, info, self.get_video().frame)
                if got:
                    return float(got)
        except Exception:
            pass
        return eng._set_video_rate(rate)

    def quiz_visible(self, page=None) -> bool:
        try:
            return bool(self._bridge()._ai_quiz_visible())
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 答题
    # ------------------------------------------------------------------
    def get_exam(self, page=None) -> ExamPage:
        """通用扫描本来就覆盖各类原生控件与类名式选项，
        所以不挑页面 —— 能扫出题就答，扫不出就不答。"""
        return ExamPage(is_exam=True, title="通用答题页")

    def get_user_info(self, page=None) -> dict:
        return {}
