# -*- coding: utf-8 -*-
"""平台适配器集合。

注册顺序有讲究：**具体平台在前，通用兜底在后**。
`pick_adapter` 在分数相同时按注册顺序取第一个，
所以通用兜底必须最后，否则它会抢走具体平台的页面。

加一个新平台的步骤：
  1. 在本目录新建 `xxx.py`
  2. 写一个 `@register` 装饰的 `PlatformAdapter` 子类
  3. 在这里 import 它
"""
from . import zhihuishu          # noqa: F401   智慧树（含 AI 版 / 老版 / 考试）
from . import xuexitong          # noqa: F401   超星·学习通
from . import icve               # noqa: F401   职教云 / 智慧职教
from . import generic            # noqa: F401   通用兜底（务必最后）

__all__ = ["zhihuishu", "xuexitong", "icve", "generic"]
