# -*- coding: utf-8 -*-
"""超星 · 学习通适配器。

覆盖：
    · 课程页   mooc1.chaoxing.com/mycourse/studentstudy   ← 章节任务点式
    · 考试页   exam-ans / mooc1 的作业与考试
    · 新版     mooc2=1

结构要点（来自开源项目 OCS(ocsjs) 的 chaoxing 适配，已在两层 iframe
自测页上逐条验证）：
    顶层
      ├─ 左侧章节树    .chapter_item
      ├─ 未完成任务点  document.getElementsByClassName('jobCount')
      ├─ 任务点标签    .tabtags span（视频 / 章节测验）
      └─ #iframe ← 第 1 层
           └─ .ans-attach-ct（一个任务点）
                └─ iframe ← 第 2 层：<video> 在这里

两个关键坑（OCS 源码里明确记着，我们也踩过）：
  ① 「必须用原生 JS 点击」—— jobCount 的父级 <a> 用 jQuery/真实鼠标点击
     **界面不会跳转**。所以走 DOM 原生 click()。
  ② 跳转要点 `jobCount.parentNode` 里的那个 <a>，不是 jobCount 自己。

实现状态：与智慧树适配器相同，**当前是桥接实现** ——
接口方法复用 `dsh_solver.course.CourseRunner` 里已实现的 `_cx_*` 逻辑。
"""
from __future__ import annotations

from ..core.adapter import PlatformAdapter, register
from ..core.models import (Chapter, Course, ExamPage, PlatformProgress,
                           VideoState)

_HOSTS: list[tuple[str, int]] = [
    ("mooc1.chaoxing.com", 90),
    ("mooc2-ans.chaoxing.com", 90),
    ("mooc1-1.chaoxing.com", 85),
    ("mooc1-2.chaoxing.com", 85),
    ("exam-ans.chaoxing.com", 85),
    ("chaoxing.com", 50),
    ("edu.cn", 0),          # 占位：不匹配
]


@register
class XuexitongAdapter(PlatformAdapter):
    platform_name = "学习通"
    key = "xuexitong"

    # ------------------------------------------------------------------
    # 页面版本（学习通同样分很多种页面，路由细节留在这里）
    # ------------------------------------------------------------------
    _PAGE_TYPES: list[tuple[str, str]] = [
        # 新版学习页（卡片式，会自动补 mooc2=1）
        ("mooc2-ans/mycourse", "study-v2"),
        ("mycourse/studentstudy", "study"),
        # 任务点内容 iframe / 各类模块
        ("/knowledge/cards", "card"),
        ("/ananas/modules/video", "media-video"),
        ("/ananas/modules/audio", "media-audio"),
        ("/readsvr/book", "read"),
        ("ztnodedetailcontroller", "read-node"),
        # 作业
        ("mooc2/work/dowork", "work"),
        ("work/doHomeWorkNew", "work-legacy"),
        ("/work/selectWorkQuestion", "work-select"),
        # 考试
        ("/mooc2/exam", "exam"),
        ("exam/test/reVersionTestStartNew", "exam-legacy"),
        ("exam-ans/exam", "exam-ans"),
        # 个人信息
        ("chaoxing.com/space/index", "space"),
        ("chaoxing.com/base", "space-v2"),
    ]

    def page_type(self, url: str = "") -> str:
        u = (url or "").lower()
        for pat, name in self._PAGE_TYPES:
            if pat.lower() in u:
                return name
        return "unknown"

    def match(self, url: str) -> int:
        u = (url or "").lower()
        if not u:
            return 0
        best = 0
        for host, score in _HOSTS:
            if score and host in u:
                best = max(best, score)
        return best
    # ------------------------------------------------------------------
    # 课程与章节
    # ------------------------------------------------------------------
    def get_courses(self, page=None) -> list[Course]:
        name = ""
        try:
            name = self.driver.page.title() if self.driver else ""
        except Exception:
            pass
        return [Course(id="current", name=name or "当前课程")]

    def get_chapters(self, page=None, course: Course | None = None
                     ) -> list[Chapter]:
        """一「节」= 一个未完成任务点（.jobCount）。

        学习通左侧是章节树，但**真正决定"学完没有"的是任务点角标**：
        角标消失 = 这一章的任务点做完了。
        """
        eng = self._bridge()
        try:
            n = eng._cx_job_count()
        except Exception:
            return []
        out: list[Chapter] = []
        for i in range(n):
            title = ""
            try:
                title = eng._cx_job_title(i)
            except Exception:
                pass
            out.append(Chapter(id=str(i), name=title or f"任务点{i + 1}",
                               index=i, total=1, finished=0))
        return out

    def open_chapter(self, page=None, chapter: Chapter | None = None) -> bool:
        """点进任务点 —— **必须走原生 DOM click**（见文件头 ①）。"""
        if chapter is None:
            return False
        return bool(self._bridge()._cx_click_job(int(chapter.index or 0)))

    # ------------------------------------------------------------------
    # 播放
    # ------------------------------------------------------------------
    def get_video(self, page=None) -> VideoState:
        """播放器在第 2 层 iframe 里，交给引擎的通用探测（它会遍历所有框架）。"""
        eng = self._bridge()
        try:
            v = eng._any_video()
        except Exception:
            return VideoState()
        if not v.get("found"):
            return VideoState()
        return VideoState(
            found=True,
            current=float(v.get("currentTime") or 0),
            duration=float(v.get("duration") or 0),
            ended=bool(v.get("ended")),
            paused=bool(v.get("paused")),
            rate=float(v.get("rate") or 1),
            src=str(v.get("src") or ""),
            frame=v.get("_frame"))

    def max_rate(self) -> float:
        """学习通不强制限速，沿用配置里的上限。"""
        from .. import config
        return float(config.COURSE_MAX_SPEED)

    def set_rate(self, page=None, rate: float = 1.0) -> float:
        """同样走引擎 —— 关键是**在播放器所在的那个框架里**执行。"""
        return self._bridge()._set_video_rate(rate)

    def quiz_visible(self, page=None) -> bool:
        """超星的**视频内弹题**（答完才让继续播）。

        调研给出的判据：`.ans-videoquiz-opt` / `.ans-videoquiz-box`
        （提交按钮是 `#videoquiz-submit`）。通用检测已覆盖这些选择器，
        所以这里直接复用引擎的实现。

        ⚠ 关键在于**它必须遍历所有 iframe**：超星的弹题在播放器那层
          iframe 里，而 `page.evaluate()` 只在顶层文档执行 ——
          这正是原来"课中弹题"功能对超星**完全失效**的原因。
        """
        try:
            return bool(self._bridge()._ai_quiz_visible())
        except Exception:
            return super().quiz_visible(page)

    def close_player(self, page=None) -> None:
        try:
            self._bridge()._ai_close_player()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 平台进度
    #
    # 学习通有两套"学完没有"的信号，调研里都明确写了：
    #   ① **未完成任务点角标 `.jobCount`** —— 数量归零 = 这一章做完了
    #      （这是最可靠的：我们自己的推进循环也是靠它判断有没有前进）
    #   ② 任务点上的 **`.icon_Completed`** —— 单个任务点已完成的标记
    #   另有 `.jobUnfinishCount`（章节内的未完成数）可作补充。
    # ------------------------------------------------------------------
    def progress(self, page=None, chapter=None) -> PlatformProgress:
        # ① 目录式页面（mooc2=1）：**本章**还剩几个任务点
        #
        # 2026-10-23 的真机 dump 里，整门课的剩余数写在 #_studystate 的
        # unfinishCount（97），而本章剩余数写在当前高亮目录项的
        # input.jobUnfinishCount（3）上。拿整门课的数字回答"这一节学完没有"
        # 正是那次"2 秒就已播完"的根因，所以这里优先读**本章**的。
        try:
            fn = getattr(self._bridge(), "_cx_chapter_progress", None)
            chp = fn() if fn is not None else {}
        except Exception:
            chp = {}
        if isinstance(chp, dict) and chp.get("found"):
            left = int(chp.get("unfin") or 0)
            return PlatformProgress(
                found=True,
                done=(left == 0),
                text=(f"本章还剩 {left} 个任务点" if left
                      else "本章任务点已全部完成"),
                source="本章目录角标")

        # ② 老版：未完成任务点 `.jobCount`，这是本平台最权威的进度信号
        #
        # ⚠ 2026-10-23 真机教训：**「读不到」和「读到 0」必须分开**。
        #   新版学习页一个 `.jobCount` 都不渲染，`_cx_job_count()` 会返回 0，
        #   而 0 在语义上是「全都做完了」—— 于是这里一路报
        #   「任务点已全部完成」，刷课每节 2 秒就判完，「下一节」永远点不动。
        #   所以先用 `_cx_job_probe()` 问一句"这一页到底有没有任务点 UI"，
        #   没有就当成**未知**，交回通用语义扫描（读不到 → found=False →
        #   上层退回播放位置判据，行为与改动前一致）。
        probe: dict = {}
        try:
            fn = getattr(self._bridge(), "_cx_job_probe", None)
            if fn is not None:
                probe = fn() or {}
        except Exception:
            probe = {}

        if isinstance(probe, dict) and "found" in probe:
            if probe.get("found"):
                left = int(probe.get("jobs") or 0)
                return PlatformProgress(
                    found=True,
                    done=(left == 0),
                    text=(f"还剩 {left} 个任务点" if left else "任务点已全部完成"),
                    source="未完成任务点")
            # 页面上没有任务点角标 —— 读不到，别猜
            return super().progress(page, chapter)

        try:
            left = int(self._bridge()._cx_job_count() or 0)
        except Exception:
            left = -1
        if left >= 0:
            # ⚠ 这里**不能**把 left 硬塞进 finished/total ——
            #   `finished=0, total=left` 会显示成「0/3」，含义正好反了。
            #   平台的语义是"还剩几个"，所以只给 done 和 text，
            #   让 PlatformProgress.complete 走 `done` 这一路。
            return PlatformProgress(
                found=True,
                done=(left == 0),
                text=(f"还剩 {left} 个任务点" if left else "任务点已全部完成"),
                source="未完成任务点")

        # ② 退回通用语义扫描（它会找 .icon_Completed 之类的完成标记）
        return super().progress(page, chapter)

    # ------------------------------------------------------------------
    # 答题
    # ------------------------------------------------------------------
    def get_exam(self, page=None) -> ExamPage:
        """学习通测验页的选项是 `<div class="opt">` + 圆形字母圈，
        选中加 `.sel` 类 —— 通用扫描已经覆盖（词表里补过 opt / sel）。"""
        return ExamPage(is_exam=True, title="学习通答题页")

    def get_user_info(self, page=None) -> dict:
        try:
            name = self.driver.page.evaluate(
                """() => {
                    for (const s of ['.personal-name', '.userName', '.name',
                                     '#userName', '.head-name']) {
                        const e = document.querySelector(s);
                        if (e && (e.innerText || '').trim())
                            return (e.innerText || '').trim().slice(0, 30);
                    }
                    return '';
                }""") if self.driver else ""
            return {"name": name or ""}
        except Exception:
            return {}
