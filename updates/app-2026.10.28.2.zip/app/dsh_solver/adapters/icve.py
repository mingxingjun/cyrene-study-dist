# -*- coding: utf-8 -*-
"""职教云 / 智慧职教适配器。

覆盖（调研结论，来自 OCS 的 ZJY / IcveMooc 两个 Project）：
    · 职教云旧版   zjy2.icve.com.cn/study/...      ← 表格结构，非 iframe 章节树
    · 职教云新版   zjy2.icve.com.cn/study/v2/...   ← Vue 路由，脚本一般强跳回旧版
    · 资源库       zyk.icve.com.cn/icve-study/...
    · 智慧职教     icve.com.cn/study/directory/...  ← 章节树在 #mainContent iframe 里
    · MOOC 学院    /learnspace/learn/learn/...      ← 任务点在 .s_point[itemtype]
    · AI 课程      ai.icve.com.cn/app/...           ← iView 框架

这个平台为什么对**接口设计**特别有价值
--------------------------------------
① **大章节之间没有"下一节"按钮** ——
   必须先把整门课的章节数据读进内存，算出下一个目标，
   然后**直接改 URL 跳转**（旧版 `?id=`，在线课堂 `?activityId=`）。
   → 这正好检验 `get_all_chapters()` + `open_chapter()` 这套抽象够不够用。

② **读 Vue 实例而不是 DOM** ——
   新版页面没有可点的 DOM 树，课程数据藏在
   `.coursePreviewIndex.__vue__.list` 里。
   → 检验适配器是否**允许用完全不同的技术手段**拿到同样的 Chapter。

③ **播放器是 JW Player，不是 Video.js** ——
   全局 `jwplayer()`，媒体元素 `.jw-media.jw-reset`，完成判定用 `onComplete`。
   → 检验 `get_video()` / `set_rate()` 的抽象是否与播放器实现无关。

④ **平台明确不适合高倍速** ——
   三个独立来源都提示"职教云无法使用倍速 / 最好别超过 1.5 倍速 /
   最多二倍否则判定无效"。
   → 所以这里 `max_rate()` 直接给 1.5，不跟随全局配置。

实现状态：**桥接实现**，真实 DOM 逻辑待迁移。
当前方法给出的是"按调研结论应有的行为"，选择器先不写死 ——
没在真机上验证过的选择器写进来只会变成假的确定性。
"""
from __future__ import annotations

from ..core.adapter import PlatformAdapter, register
from ..core.models import (Chapter, Course, ExamPage, PlatformProgress,
                           VideoState)

_HOSTS: list[tuple[str, int]] = [
    # 职教云
    ("zjy2.icve.com.cn", 90),
    ("zyk.icve.com.cn", 85),
    # 智慧职教 / MOOC 学院 / AI 课程
    ("ai.icve.com.cn", 85),
    ("course.icve.com.cn", 85),
    ("icve.com.cn", 70),
    # 套壳域（有的学校用自己的域名承载同一套页面）
    ("courshare.cn", 60),
    ("webtrn.cn", 60),
]


@register
class IcveAdapter(PlatformAdapter):
    platform_name = "职教云"
    key = "icve"

    # ------------------------------------------------------------------
    # 页面版本
    # ------------------------------------------------------------------
    _PAGE_TYPES: list[tuple[str, str]] = [
        # 职教云新版（Vue 路由）—— 必须放在旧版前面，否则
        # "/study" 会先命中旧版规则
        ("zjy2.icve.com.cn/study/v2/", "study-v2"),
        ("zjy2.icve.com.cn/study/coursePreview", "study-vue"),
        ("zjy2.icve.com.cn/study/process", "study-legacy"),
        ("zjy2.icve.com.cn/common/directory", "directory"),
        ("zjy2.icve.com.cn/study/studentFast", "classroom"),
        ("zyk.icve.com.cn/icve-study", "zyk"),
        # 智慧职教
        ("icve.com.cn/study/directory/dir_course", "dir-course"),
        ("icve.com.cn/study/directory/directory_list", "dir-list"),
        ("/learnspace/learn/learn/", "mooc"),
        ("ai.icve.com.cn", "ai-course"),
        ("ai.icve.com.cn/preview-exam", "ai-exam"),
        # 作业 / 考试（两个子平台各有一套）
        ("spockeepTest", "test"),
        ("spocjobTest", "test"),
        ("spoctest", "test"),
        ("courseteaching/test", "test"),
        ("icve-study/coursePreview/jobTes", "test"),
        ("icve-study/coursePreview/test", "test"),
        ("icve-study/test", "test"),
        ("icve-study/coursePreview/keepTest", "test"),
        ("/platformwebapi/student/exam", "exam"),
        ("/student/exam/", "exam"),
    ]

    def page_type(self, url: str = "") -> str:
        u = (url or "").lower()
        for pat, name in self._PAGE_TYPES:
            if pat.lower() in u:
                return name
        return "unknown"

    # ------------------------------------------------------------------
    # 识别
    # ------------------------------------------------------------------
    def match(self, url: str) -> int:
        u = (url or "").lower()
        if not u:
            return 0
        best = 0
        for host, score in _HOSTS:
            if host in u:
                best = max(best, score)
        return best

    # ------------------------------------------------------------------
    # 倍速：这个平台**明确不适合加速**
    #
    # 调研里三个独立来源的提示：
    #   · "职教云无法使用倍速"
    #   · "最好别超过 1.5 倍速"
    #   · "视频倍速最多二倍，否则会判定无效"
    # 所以这里硬性给 1.5，**不跟随全局配置** ——
    # 用户把全局倍速调到 2× 是为了别的平台，但在这个平台上那是白费（不计进度）。
    # ------------------------------------------------------------------
    def max_rate(self) -> float:
        return 1.5

    # 职教云没有"下一节"按钮，推进靠改 URL。
    # 置 False 是让上层知道"不要去找下一节按钮"。
    can_advance: bool = False
    def get_courses(self, page=None) -> list[Course]:
        name = ""
        try:
            name = self.driver.page.title() if self.driver else ""
        except Exception:
            pass
        return [Course(id="current", name=name or "当前课程")]

    def get_chapters(self, page=None, course: Course | None = None
                     ) -> list[Chapter]:
        """读这一层能看到的章节。

        ⚠ 职教云旧版是**表格结构**（不是 iframe 章节树），而且：
          · 模块进度读 `moduleList[i].getElementsByTagName('div')[2]` 的文本
          · 章节 `tr` 列表**前 3 个是无效行、有效章节在奇数索引**
          · 单条内容的完成标记是它下面 `span[0].title === "100%"`
        这些选择器来自调研（OCS 的 zjy.ts），**但我还没在真机上验证过**，
        所以先不写死 —— 宁可返回空让上层跳过，也不要给出假的确定性。
        """
        return []

    def get_all_chapters(self, page=None, course: Course | None = None
                         ) -> list[Chapter]:
        """整门课的章节表。

        ⚠ 这是本平台**必须**的能力：大章节之间没有"下一节"按钮，
          脚本得自己算出下一个目标再跳 URL。
          调研里的做法是递归展开所有模块、把整棵树读进内存
          （`getCourseData()` → `courseList`），然后：
            · 若"下一节"就在同一模块内 → 调页面自带的 `vue.preNext(...)`
            · 否则直接改 URL：`?id=` / 在线课堂 `?activityId=`
          待真实页面结构确认后实现。
        """
        return []

    def open_chapter(self, page=None, chapter: Chapter | None = None) -> bool:
        """进入一节。

        ⚠ 本平台的进法和别家完全不同：**没有按钮可点**，要改 URL。
          这正是适配器接口该存在的原因 ——
          上层只需要"进入这一节"，怎么进入是平台自己的事。
        """
        if chapter is None:
            return False
        url = chapter.url or str(chapter.raw.get("url") or "")
        if not url:
            return False
        try:
            self.driver.page.goto(url, wait_until="domcontentloaded",
                                  timeout=30000)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 播放：JW Player（不是 Video.js）
    # ------------------------------------------------------------------
    def get_video(self, page=None) -> VideoState:
        """本平台用 JW Player，媒体元素是 `.jw-media.jw-reset`，
        但**底层同样是原生 <video>**，所以通用探测照样能用。

        ⚠ 不要为"抹平 Video.js / JW Player"写两套代码 ——
          两者最终都落到 HTML5 <video> 上，通用探测已经够用。
          这是调研给我的一个重要澄清。
        """
        eng = self._bridge()
        try:
            v = eng._any_video()
        except Exception:
            return VideoState()
        if not v.get("found"):
            return VideoState()
        return VideoState(
            found=True,
            current=float(v.get("currentTime") or 0),
            duration=float(v.get("duration") or 0),
            ended=bool(v.get("ended")),
            paused=bool(v.get("paused")),
            rate=float(v.get("rate") or 1),
            src=str(v.get("src") or ""),
            frame=v.get("_frame"))

    def set_rate(self, page=None, rate: float = 1.0) -> float:
        """JW Player 没有倍速菜单，只能直接改 playbackRate。

        仍然走引擎的实现 —— 关键是**在播放器所在的框架里**执行。
        """
        return self._bridge()._set_video_rate(rate)

    def close_player(self, page=None) -> None:
        try:
            self._bridge()._ai_close_player()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 平台进度
    #
    # 调研给出了本平台的进度读法（OCS 的 zjy.ts）：
    #   · 模块进度在 `moduleList[i].getElementsByTagName('div')[2]` 的文本里，
    #     形如 " 100% "，到 100%（脚本也放过 99%）才算完成
    #   · 单条内容的完成标记是它下面 `span[0].title === "100%"`
    #
    # ⚠ 我**没有真机验证过**这些下标（下标式的读法尤其脆），
    #   所以这里不写死 —— 交给通用语义扫描去按"百分比/完成文案"找。
    #   它能覆盖 aria-valuenow、`xx%` 文案、进度条宽度这三种常见表达。
    #   等有真实页面结构时，再把这个方法改成精确读法。
    # ------------------------------------------------------------------
    def progress(self, page=None, chapter=None) -> PlatformProgress:
        return super().progress(page, chapter)

    # ------------------------------------------------------------------
    # 答题
    # ------------------------------------------------------------------
    def get_exam(self, page=None) -> ExamPage:
        """本平台的选项**内部是原生 input**，但点击要落在 `label` 上
        （`option.querySelector('label').click()`）——
        通用落笔策略已经覆盖"点可见容器"这一条。
        填空赋值后需要派发 input 事件（Vue 双绑），通用 fill() 也已处理。
        """
        return ExamPage(is_exam=True, title="职教云答题页")

    def get_user_info(self, page=None) -> dict:
        try:
            name = self.driver.page.evaluate(
                """() => {
                    for (const s of ['.userName', '.name', '.personal-name',
                                     '.user-info .name']) {
                        const e = document.querySelector(s);
                        if (e && (e.innerText || '').trim())
                            return (e.innerText || '').trim().slice(0, 30);
                    }
                    return '';
                }""") if self.driver else ""
            return {"name": name or ""}
        except Exception:
            return {}
