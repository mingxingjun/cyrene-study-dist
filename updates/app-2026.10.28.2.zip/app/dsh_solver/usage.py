"""用量统计：token 累计、费用估算、余额查询。

为什么需要这个模块（实测结论，别凭记忆改）：
  · DeepSeek **有**余额接口：GET /user/balance → 直接给 CNY 余额。
  · DeepSeek **没有**用量接口：/user/usage、/dashboard/billing/* 全部 404。
  · 对话返回里带 usage：
        {"prompt_tokens":7,"completion_tokens":1,"total_tokens":8,
         "prompt_cache_hit_tokens":0,"prompt_cache_miss_tokens":7}
  · /models **不含价格字段**，所以单价只能自己维护（见下）。

因此：
  · **token 用量** —— 本地累计每次调用返回的 usage，存盘持久化。
  · **余额** —— 实时查官方接口。
  · **花费** —— 两条路一起给：
        ① 按单价估算（快，但单价是我们维护的常量，可能过时）
        ② 余额差额（准确，但需要用户点"记录基线"后才有基准）
    并且明确标注哪个是估算、哪个是实测，不让人误读。
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# 单价（人民币 / 每百万 token）
#
# ⚠ 这是**我们自己维护的常量**，官方 /models 接口不提供价格。
#   价格调整后需要手动改这里。界面上会标注"按内置单价估算"，
#   所以即使过时也不会误导成官方数字。
#   设成 0 就等于不估算费用，只看 token 数和余额差额。
#
# deepseek-flash 参考价（元/百万 token）：
#   输入（缓存未命中） 0.5 / 输入（缓存命中） 0.05 / 输出 2.0
# deepseek-v4-pro 参考价：
#   输入（缓存未命中） 4.0 / 输入（缓存命中） 0.4  / 输出 12.0
# ---------------------------------------------------------------------------
PRICES: dict[str, dict[str, float]] = {
    "deepseek-flash": {"in_miss": 0.5, "in_hit": 0.05, "out": 2.0},
    "deepseek-v4-pro": {"in_miss": 4.0, "in_hit": 0.4, "out": 12.0},
}
DEFAULT_PRICE = {"in_miss": 0.5, "in_hit": 0.05, "out": 2.0}

PRICE_NOTE = "按内置单价估算，非官方账单"


def price_for(model: str) -> dict[str, float]:
    m = (model or "").strip().lower()
    if m in PRICES:
        return PRICES[m]
    for k, v in PRICES.items():
        if k in m or m in k:
            return v
    return DEFAULT_PRICE


# ---------------------------------------------------------------------------
@dataclass
class ModelUsage:
    calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    first_ts: float = 0.0
    last_ts: float = 0.0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def cost(self, model: str) -> float:
        """按单价估算花费（元）。命中缓存的输入按更便宜的价算。"""
        p = price_for(model)
        miss = max(0, self.prompt_tokens - self.cached_tokens)
        return (miss * p["in_miss"]
                + self.cached_tokens * p["in_hit"]
                + self.completion_tokens * p["out"]) / 1_000_000.0


@dataclass
class UsageStore:
    """累计用量。按模型分开记，另外记一份总计。"""
    models: dict[str, ModelUsage] = field(default_factory=dict)
    baseline_balance: float | None = None      # 用户记录的余额基线
    baseline_ts: float = 0.0
    last_balance: float | None = None
    last_balance_ts: float = 0.0
    balance_currency: str = "CNY"
    first_ts: float = 0.0                      # 第一次产生用量（或记录基线）的时间
    updated_ts: float = 0.0

    # ---- 累计 ----
    def add(self, model: str, usage: dict | None) -> None:
        if not usage:
            return
        u = self.models.get(model)
        if u is None:
            u = ModelUsage()
            self.models[model] = u
        try:
            pt = int(usage.get("prompt_tokens") or 0)
            ct = int(usage.get("completion_tokens") or 0)
            # 缓存命中数：不同版本字段名不同，逐一兼容
            hit = usage.get("prompt_cache_hit_tokens")
            if hit is None:
                det = usage.get("prompt_tokens_details") or {}
                hit = det.get("cached_tokens")
            hit = int(hit or 0)
        except (TypeError, ValueError):
            return
        now = time.time()
        u.calls += 1
        u.prompt_tokens += pt
        u.completion_tokens += ct
        u.cached_tokens += min(hit, pt)
        u.first_ts = u.first_ts or now
        u.last_ts = now
        self.first_ts = self.first_ts or now
        self.updated_ts = now

    # ---- 汇总 ----
    def totals(self) -> dict:
        calls = pt = ct = hit = 0
        cost = 0.0
        for m, u in self.models.items():
            calls += u.calls
            pt += u.prompt_tokens
            ct += u.completion_tokens
            hit += u.cached_tokens
            cost += u.cost(m)
        return {
            "calls": calls,
            "prompt_tokens": pt,
            "completion_tokens": ct,
            "total_tokens": pt + ct,
            "cached_tokens": hit,
            "cost_est": round(cost, 6),
        }

    def snapshot(self) -> dict:
        t = self.totals()
        spent_by_balance = None
        if self.baseline_balance is not None and self.last_balance is not None:
            spent_by_balance = round(self.baseline_balance - self.last_balance, 4)
        return {
            "totals": t,
            "per_model": {
                m: {**asdict(u), "total_tokens": u.total_tokens,
                    "cost_est": round(u.cost(m), 6)}
                for m, u in self.models.items()
            },
            "balance": {
                "last": self.last_balance,
                "currency": self.balance_currency,
                "ts": self.last_balance_ts,
                "baseline": self.baseline_balance,
                "baseline_ts": self.baseline_ts,
                "spent_by_balance": spent_by_balance,
            },
            "first_ts": self.first_ts,
            "updated_ts": self.updated_ts,
            "prices": PRICES,
            "price_note": PRICE_NOTE,
        }


# ---------------------------------------------------------------------------
class UsageMeter:
    """线程安全的用量累计器，带落盘。

    单例式用途：整个进程共享一个计数器（任务在后台线程跑，服务在主线程读）。
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock = threading.RLock()
        self.store = UsageStore()
        self._load()

    # ---- 持久化 ----
    def _load(self) -> None:
        try:
            if not self.path.exists():
                return
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            st = UsageStore()
            # ⚠ 键名必须和 snapshot() 写出去的一致。
            # 踩过的坑：snapshot 写的是 "per_model"，这里却读 "models"，
            # 结果文件里明明有数据，载入却永远是 0（token 一重启就清零）。
            per = raw.get("per_model")
            if per is None:
                per = raw.get("models") or {}
            for m, d in (per or {}).items():
                st.models[m] = ModelUsage(
                    calls=int(d.get("calls") or 0),
                    prompt_tokens=int(d.get("prompt_tokens") or 0),
                    completion_tokens=int(d.get("completion_tokens") or 0),
                    cached_tokens=int(d.get("cached_tokens") or 0),
                    first_ts=float(d.get("first_ts") or 0),
                    last_ts=float(d.get("last_ts") or 0),
                )
            b = raw.get("balance") or {}
            st.baseline_balance = b.get("baseline")
            st.baseline_ts = float(b.get("baseline_ts") or 0)
            st.last_balance = b.get("last")
            st.last_balance_ts = float(b.get("ts") or 0)
            st.balance_currency = b.get("currency") or "CNY"
            st.first_ts = float(raw.get("first_ts") or 0)
            st.updated_ts = float(raw.get("updated_ts") or 0)
            self.store = st
        except Exception:
            self.store = UsageStore()

    def save(self) -> None:
        try:
            with self._lock:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(self.store.snapshot(), ensure_ascii=False, indent=1),
                               encoding="utf-8")
                tmp.replace(self.path)
        except Exception:
            pass

    # ---- 记录 ----
    def add(self, model: str, usage: dict | None) -> None:
        with self._lock:
            self.store.add(model, usage)
        # 每次都落盘太费；用量变动不大，交给调用方或退出时保存。
        # 但为了避免进程被杀丢数据，这里做轻量节流保存。
        now = time.time()
        if now - getattr(self, "_last_save", 0) > 5:
            self._last_save = now
            self.save()

    def reset(self) -> None:
        with self._lock:
            self.store = UsageStore()
        self.save()

    def __del__(self) -> None:
        # 兜底：进程退出/对象回收时把未落盘的用量写下去，
        # 否则被强杀时会丢掉最后几秒的统计。
        #
        # ⚠ 审计 C-8：**不能无条件 save()**。
        #   `meter()` 单例原来没加锁：两个线程同时首次调用会各自构造一个
        #   `UsageMeter`，被淘汰的那个**根本不在全局 `_METER` 里**
        #   （`_METER = UsageMeter(...)` 要等构造完成才赋值）。
        #   它被 GC 时如果照旧 `save()`，就会把自己那份**旧内存快照**
        #   原子替换掉磁盘上刚写好的新统计 —— 用户少掉一段用量，且毫无提示。
        #
        #   所以：**只有仍然持有全局单例引用时**才有资格落盘。
        #   用模块级函数读 `_METER` 而不用 `lms._METER`，是为了避免
        #   解释器退出阶段 `lms` 已被置 None 导致 AttributeError。
        try:
            from . import lms as _lms
            if getattr(_lms, "_METER", None) is not self:
                return
        except Exception:
            # 解释器正在退出、模块已拆 → 保守起见不写，避免覆盖新数据
            return
        try:
            self.save()
        except Exception:
            pass

    def snapshot(self) -> dict:
        with self._lock:
            return self.store.snapshot()

    # ---- 余额 ----
    def update_balance(self, info: dict) -> None:
        """写入一次余额查询结果。"""
        with self._lock:
            try:
                self.store.last_balance = float(info.get("total_balance"))
            except (TypeError, ValueError):
                return
            self.store.last_balance_ts = float(info.get("ts") or time.time())
            self.store.balance_currency = info.get("currency") or "CNY"
        self.save()

    def set_baseline(self) -> float | None:
        """把"当前余额"记为基线，之后就能用差额算实际消耗。"""
        with self._lock:
            if self.store.last_balance is None:
                return None
            self.store.baseline_balance = self.store.last_balance
            self.store.baseline_ts = time.time()
            if not self.store.first_ts:
                self.store.first_ts = self.store.baseline_ts
            val = self.store.baseline_balance
        self.save()
        return val


# ---------------------------------------------------------------------------
def fetch_balance(api_key: str, base_url: str = "https://api.deepseek.com",
                  timeout: int = 20) -> dict:
    """查 DeepSeek 账户余额。

    实测：GET /user/balance 可用（需 Authorization: Bearer <key>），
    返回 {"is_available":true,"balance_infos":[{"currency":"CNY",
          "total_balance":"21.88","granted_balance":"0.00","topped_up_balance":"21.88"}]}

    注意：**这个接口只对账户所有者开放**。如果用的是中转/共享 Key，
    会返回 401 —— 这不是 bug，界面上会如实说明。
    """
    key = (api_key or "").strip()
    if not key:
        return {"ok": False, "error": "还没填 API Key"}

    url = base_url.rstrip("/") + "/user/balance"
    req = urllib.request.Request(url)
    req.add_header("Authorization", "Bearer " + key)
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        if e.code in (401, 403):
            return {"ok": False, "code": e.code,
                    "error": "这个 Key 查不了余额（DeepSeek 只允许账户所有者查询，"
                             "中转 / 共享 Key 会返回 401）"}
        return {"ok": False, "code": e.code, "error": f"HTTP {e.code} {body}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {str(e)[:160]}"}

    infos = data.get("balance_infos") or []
    if not infos:
        return {"ok": False, "error": "接口没返回余额信息", "raw": data}

    # 优先人民币；没有就取第一条
    pick = next((x for x in infos if (x.get("currency") or "").upper() == "CNY"), infos[0])
    return {
        "ok": True,
        "is_available": bool(data.get("is_available")),
        "currency": pick.get("currency") or "CNY",
        "total_balance": pick.get("total_balance"),
        "granted_balance": pick.get("granted_balance"),
        "topped_up_balance": pick.get("topped_up_balance"),
        "all": infos,
        "ts": time.time(),
    }
