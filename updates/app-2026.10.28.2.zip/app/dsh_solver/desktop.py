"""桌面层：真实键鼠模拟 + 全屏截图 + 视觉定位。

两种后端，自动选择：
  1. NativeBackend —— 纯 ctypes 调 Win32（默认，零第三方依赖）
  2. PyAutoGUIBackend —— 装了 pyautogui 就用它（生态成熟，行为一致）

为什么要写 ctypes 后端：pyautogui 在 PyPI 上只有源码包，没有 wheel，
在部分网络/安全软件环境下根本装不上；而它真正用到的能力（截图、移动鼠标、
点击、按键、剪贴板）Win32 原生全都有，用 ctypes 直接调反而更稳、更少依赖。
它自带的若干依赖（pyscreeze/pygetwindow/pytweening/mouseinfo）也随之省掉。

重要前提：GUI 初始化之后再调用截图才稳定（Windows 上 Tk 未就绪时截图可能全黑）。
"""
from __future__ import annotations

import ctypes
import importlib.util
import io
import time
from ctypes import wintypes
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from . import config


# ---------------------------------------------------------------------------
def _pil():
    try:
        from PIL import Image  # noqa: PLC0415
        return Image
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            "Pillow 未安装（截图/裁图必需）。修复：\n"
            "  .venv\\Scripts\\python.exe -m pip install --no-index --find-links .wheels pillow"
        ) from e


@dataclass
class Hit:
    x: int
    y: int
    label: str = ""


# ---------------------------------------------------------------------------
# Win32 常量与结构
# ---------------------------------------------------------------------------
_INPUT_MOUSE, _INPUT_KEYBOARD = 0, 1
_MOUSEEVENTF_MOVE = 0x0001
_MOUSEEVENTF_LEFTDOWN, _MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
_MOUSEEVENTF_RIGHTDOWN, _MOUSEEVENTF_RIGHTUP = 0x0008, 0x0010
_MOUSEEVENTF_MIDDLEDOWN, _MOUSEEVENTF_MIDDLEUP = 0x0020, 0x0040
_MOUSEEVENTF_WHEEL = 0x0800
_MOUSEEVENTF_ABSOLUTE = 0x8000
_KEYEVENTF_KEYUP = 0x0002
_CF_UNICODETEXT, _GMEM_MOVEABLE = 13, 0x0002

# 字符 → 虚拟键码（以 US 布局为基准，Layout-independent 地打字）
_VK: dict[str, int] = {}
for _c in "abcdefghijklmnopqrstuvwxyz":
    _VK[_c] = ord(_c.upper())
for _c in "0123456789":
    _VK[_c] = ord(_c)
_SHIFT_CHARS = {
    "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6", "&": "7", "*": "8",
    "(": "9", ")": "0", "_": "-", "+": "=", "{": "[", "}": "]", "|": "\\",
    ":": ";", '"': "'", "<": ",", ">": ".", "?": "/", "~": "`",
}
for _c in " -=[]\\;',./`":
    _VK[_c] = ctypes.windll.user32.VkKeyScanW(_c) & 0xFF
for _ch, _base in _SHIFT_CHARS.items():
    _VK[_ch] = _VK[_base]

_KEY_ALIASES = {
    "enter": 0x0D, "return": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B,
    "space": 0x20, "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "insert": 0x2D,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10,
    "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
    "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
}
for _i in range(10):
    _KEY_ALIASES[f"numpad{_i}"] = 0x60 + _i


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_void_p)]


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_void_p)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", _MOUSEINPUT), ("ki", _KEYBDINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


# ---------------------------------------------------------------------------
# DPI 感知（审计 C-13）
#
# ⚠ 这里原来有个**静默失效**的回落分支：
#     try:    shcore.SetProcessDpiAwareness(2)      # 返回 HRESULT
#     except: user32.SetProcessDPIAware()           # ← 永远跑不到
#   因为 `SetProcessDpiAwareness` **不抛异常**，它返回 HRESULT：
#     0 = S_OK，E_ACCESSDENIED(0x80070005) = "已经设过了"，其它非 0 = 真失败。
#   所以 125%/150% 缩放下这个调用真失败时，坐标会被系统二次缩放 → "点偏了"，
#   而代码看起来"有兜底"，排查时极容易漏掉。
#
# 另外还要注意：**已经设过**之后再调用会返回 E_ACCESSDENIED，
#   这是成功状态的正常表现，不能因此去跑回落、也不能报错。
#   所以按"最精确 → 最古老"逐个试，并且每个都检查返回值。
_DPI_DONE = False


def _ensure_dpi_aware() -> str:
    """把进程设成 DPI 感知，返回一句结果说明（供日志）。只做一次。"""
    global _DPI_DONE
    if _DPI_DONE:
        return "已设置（跳过重复调用）"
    _DPI_DONE = True

    try:
        u32 = ctypes.windll.user32
        shcore = getattr(ctypes.windll, "shcore", None)
    except Exception as e:
        return f"取不到 user32/shcore：{type(e).__name__}"

    # ① Windows 10 1703+：per-monitor v2，最准
    try:
        f = getattr(u32, "SetProcessDpiAwarenessContext", None)
        if f is not None:
            f.argtypes = [ctypes.c_void_p]
            f.restype = wintypes.BOOL
            # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (HANDLE)-4
            if f(ctypes.c_void_p(-4)):
                return "PerMonitorV2"
            if f(ctypes.c_void_p(-3)):        # v1 回落
                return "PerMonitorV1"
    except Exception:
        pass

    # ② Windows 8.1+：SetProcessDpiAwareness（返回 HRESULT，**不抛异常**）
    try:
        if shcore is not None:
            f = getattr(shcore, "SetProcessDpiAwareness", None)
            if f is not None:
                f.argtypes = [ctypes.c_int]
                f.restype = ctypes.c_long
                hr = int(f(2))                 # PROCESS_PER_MONITOR_DPI_AWARE
                if hr == 0:
                    return "PerMonitor(HRESULT=S_OK)"
                # E_ACCESSDENIED = 0x80070005 → 已经设过，属正常
                if (hr & 0xFFFFFFFF) == 0x80070005:
                    return "已是 DPI 感知（E_ACCESSDENIED=已设置过）"
                # 其它非 0 才是**真失败** → 继续往下回落
    except Exception:
        pass

    # ③ 老系统兜底：SetProcessDPIAware（返回 BOOL）
    try:
        f = getattr(u32, "SetProcessDPIAware", None)
        if f is not None:
            f.restype = wintypes.BOOL
            if f():
                return "SystemDPI(老接口)"
            return "系统拒绝设置 DPI 感知（坐标可能在高缩放下偏移）"
    except Exception as e:
        return f"设置失败：{type(e).__name__}"

    return "没有可用的 DPI 接口（坐标可能偏移）"


# ---------------------------------------------------------------------------
class NativeBackend:
    """纯 ctypes 的 Win32 输入/截图后端。"""

    name = "native(ctypes)"

    def __init__(self) -> None:
        if not hasattr(ctypes, "windll"):  # pragma: no cover
            raise RuntimeError("NativeBackend 仅支持 Windows")
        self.u32 = ctypes.windll.user32
        self.k32 = ctypes.windll.kernel32
        _ensure_dpi_aware()
        self.u32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        self.u32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(_INPUT), ctypes.c_int]
        self.u32.SendInput.restype = wintypes.UINT

    # ---------------------------------------------------------- 查询
    def size(self) -> tuple[int, int]:
        return (self.u32.GetSystemMetrics(0), self.u32.GetSystemMetrics(1))

    def position(self) -> tuple[int, int]:
        pt = wintypes.POINT()
        self.u32.GetCursorPos(ctypes.byref(pt))
        return (pt.x, pt.y)

    # ---------------------------------------------------------- 鼠标
    def _send_mouse(self, flags: int, dx: int = 0, dy: int = 0, data: int = 0) -> None:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(dx, dy, data, flags, 0, None)
        self.u32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))

    def move_to(self, x: int, y: int) -> None:
        self.u32.SetCursorPos(int(x), int(y))

    def click(self, x: int, y: int, button: str = "left", clicks: int = 1) -> None:
        down, up = {
            "left": (_MOUSEEVENTF_LEFTDOWN, _MOUSEEVENTF_LEFTUP),
            "right": (_MOUSEEVENTF_RIGHTDOWN, _MOUSEEVENTF_RIGHTUP),
            "middle": (_MOUSEEVENTF_MIDDLEDOWN, _MOUSEEVENTF_MIDDLEUP),
        }.get(button, (_MOUSEEVENTF_LEFTDOWN, _MOUSEEVENTF_LEFTUP))
        self.move_to(x, y)
        time.sleep(0.02)
        for i in range(max(1, clicks)):
            self._send_mouse(down)
            time.sleep(0.02)
            self._send_mouse(up)
            if i + 1 < clicks:
                time.sleep(0.06)

    def scroll(self, amount: int) -> None:
        # Windows 滚轮一格 = 120，正数向上
        notches = int(amount / 120) if abs(amount) >= 120 else (1 if amount > 0 else -1)
        for _ in range(abs(notches)):
            self._send_mouse(_MOUSEEVENTF_WHEEL, data=120 if notches > 0 else -120)
            time.sleep(0.03)

    # ---------------------------------------------------------- 键盘
    def _key(self, vk: int, up: bool = False) -> None:
        inp = _INPUT(type=_INPUT_KEYBOARD)
        inp.u.ki = _KEYBDINPUT(wVk=vk, wScan=0,
                               dwFlags=_KEYEVENTF_KEYUP if up else 0, time=0, dwExtraInfo=None)
        self.u32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))

    def key_down(self, key: str) -> None:
        self._key(self._vk(key), up=False)

    def key_up(self, key: str) -> None:
        self._key(self._vk(key), up=True)

    def press(self, key: str) -> None:
        vk = self._vk(key)
        self._key(vk, up=False)
        time.sleep(0.02)
        self._key(vk, up=True)

    def hotkey(self, *keys: str) -> None:
        mods, last = keys[:-1], keys[-1]
        for m in mods:
            self.key_down(m)
            time.sleep(0.02)
        self.press(last)
        for m in reversed(mods):
            self.key_up(m)
            time.sleep(0.02)

    def _vk(self, key: str) -> int:
        k = str(key).lower().strip()
        if k in _KEY_ALIASES:
            return _KEY_ALIASES[k]
        if len(k) == 1 and k in _VK:
            return _VK[k]
        raise ValueError(f"不认识的按键：{key!r}")

    def type_text(self, text: str, interval: float = 0.012) -> None:
        """逐字符用 VK 打字。非 ASCII（中文等）走剪贴板粘贴。"""
        if not text:
            return
        if not all(ord(c) < 128 for c in text):
            self.paste(text)
            return
        shift_needed = set(_SHIFT_CHARS)
        for ch in text:
            if ch == "\n":
                self.press("enter")
                continue
            if ch == "\t":
                self.press("tab")
                continue
            vk = _VK.get(ch.lower() if ch.isalpha() else ch)
            if vk is None:
                self.paste(ch)
                continue
            need_shift = ch.isupper() or ch in shift_needed
            if need_shift:
                self.key_down("shift")
            self._key(vk, up=False)
            time.sleep(interval)
            self._key(vk, up=True)
            if need_shift:
                self.key_up("shift")
            time.sleep(interval)

    # ---------------------------------------------------------- 剪贴板
    def paste(self, text: str) -> None:
        self._set_clipboard(text)
        time.sleep(0.08)
        self.hotkey("ctrl", "v")
        time.sleep(0.12)

    def _set_clipboard(self, text: str) -> None:
        """用 ctypes 写剪贴板（比 tkinter 稳，比 win32clipboard 少一个依赖）。"""
        CF_UNICODETEXT = _CF_UNICODETEXT
        GMEM_MOVEABLE = _GMEM_MOVEABLE
        data = ctypes.create_unicode_buffer(text)
        size = ctypes.sizeof(data)

        for _ in range(12):          # 剪贴板可能被别的进程占着，重试
            if self.u32.OpenClipboard(None):
                break
            time.sleep(0.08)
        else:
            raise RuntimeError("打不开剪贴板（被其他程序占用）")
        try:
            self.u32.EmptyClipboard()
            handle = self.k32.GlobalAlloc(GMEM_MOVEABLE, size)
            if not handle:
                raise RuntimeError("GlobalAlloc 失败")
            ptr = self.k32.GlobalLock(handle)
            ctypes.memmove(ptr, data, size)
            self.k32.GlobalUnlock(handle)
            # 所有权移交系统，之后不能自己 GlobalFree
            if not self.u32.SetClipboardData(CF_UNICODETEXT, handle):
                self.k32.GlobalFree(handle)
                raise RuntimeError("SetClipboardData 失败")
        finally:
            self.u32.CloseClipboard()


# ---------------------------------------------------------------------------
class PyAutoGUIBackend:
    """装了 pyautogui 就用它。接口与 NativeBackend 一致。"""

    name = "pyautogui"

    def __init__(self) -> None:
        import pyautogui  # noqa: PLC0415
        pyautogui.FAILSAFE = False      # 别让鼠标甩角落变成急停
        pyautogui.PAUSE = 0.05
        self.pg = pyautogui
        # 探测 win32clipboard 是否可用（真正的剪贴板写入在 paste() 里 import）。
        # 用 find_spec 而不是 import，避免"导入了却不用"的静态告警。
        try:
            self._has_win32clip = importlib.util.find_spec("win32clipboard") is not None
        except Exception:
            self._has_win32clip = False
        self._native = NativeBackend()   # 剪贴板兜底

    def size(self):
        s = self.pg.size()
        return (s.width, s.height)

    def position(self):
        p = self.pg.position()
        return (p.x, p.y)

    def move_to(self, x, y):
        self.pg.moveTo(int(x), int(y), duration=0.12)

    def click(self, x, y, button="left", clicks=1):
        self.pg.click(int(x), int(y), button=button, clicks=clicks, interval=0.08)

    def scroll(self, amount):
        self.pg.scroll(int(amount / 120) if abs(amount) >= 120 else (1 if amount > 0 else -1))

    def press(self, key):
        self.pg.press(key)

    def hotkey(self, *keys):
        self.pg.hotkey(*keys)

    def key_down(self, key):
        self.pg.keyDown(key)

    def key_up(self, key):
        self.pg.keyUp(key)

    def type_text(self, text, interval=0.02):
        if all(ord(c) < 128 for c in text):
            self.pg.write(text, interval=interval)
        else:
            self.paste(text)

    def paste(self, text):
        if self._has_win32clip:
            import win32clipboard  # noqa: PLC0415
            for _ in range(10):
                try:
                    win32clipboard.OpenClipboard()
                    break
                except Exception:
                    time.sleep(0.08)
            try:
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardText(text, win32clipboard.CF_UNICODETEXT)
            finally:
                win32clipboard.CloseClipboard()
            self.pg.hotkey("ctrl", "v")
        else:
            self._native.paste(text)


def make_backend(prefer_pyautogui: bool = True, logger=print):
    """优先 pyautogui，装不上就用原生 ctypes。"""
    if prefer_pyautogui:
        try:
            b = PyAutoGUIBackend()
            logger(f"[desktop] 后端：{b.name}")
            return b
        except Exception as e:
            logger(f"[desktop] pyautogui 不可用（{type(e).__name__}），改用原生 ctypes 后端")
    b = NativeBackend()
    logger(f"[desktop] 后端：{b.name}")
    return b


# ---------------------------------------------------------------------------
class Desktop:
    """真实键鼠操作。对外 API 与本项目其他模块解耦。"""

    def __init__(self, prefer_pyautogui: bool = True, logger=print) -> None:
        self.backend = make_backend(prefer_pyautogui, logger)
        self.Image = _pil()
        self._shot_seq = 0

    # ------------------------------------------------------------ 截图
    def _grab(self):
        from PIL import ImageGrab  # noqa: PLC0415
        return ImageGrab.grab(all_screens=False)

    def screenshot(self, *, save: bool = False, tag: str = "desktop"):
        img = self._grab()
        if save:
            self.save(img, tag)
        return img

    def save(self, img, tag: str = "desktop") -> Path:
        self._shot_seq += 1
        p = config.SHOT_DIR / f"{datetime.now().strftime('%H%M%S')}_{self._shot_seq:03d}_{tag}.png"
        img.save(p)
        return p

    def png_bytes(self, img) -> bytes:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def jpeg_bytes(self, img, quality: int = 82) -> bytes:
        """转成 JPEG 字节（给模型看用）。

        ⚠ 为什么给它用 JPEG 而不是 PNG：
          整屏截图是**照片类内容**（照片、渐变、抗锯齿文字混在一起），
          这类内容 JPEG 比 PNG 小一个数量级；而题目文字在 q=82 下依然清楚。
          实测同一张 2560x1600 桌面：
              PNG  原图 2.31 MB(dataURI) → 缩到 1600 长边仍有 1.39 MB
              JPEG 缩到 1600 再压     → 约 0.2 MB 量级
          PC 模式**每一步**都要发一张，这个差别直接决定它能不能实用。

          ⚠ 存盘仍然用 PNG 原图（`save`），因为那是给人看的、要保真。
        """
        try:
            img2 = img
            if img2.mode not in ("RGB", "L"):
                img2 = img2.convert("RGB")     # JPEG 不支持 RGBA
            buf = io.BytesIO()
            img2.save(buf, format="JPEG", quality=int(quality), optimize=True)
            return buf.getvalue()
        except Exception:
            return self.png_bytes(img)          # 退路：至少还能用

    def shrink(self, img, max_edge: int | None = None):
        """把截图按长边降到 `max_edge` 以内（保持比例）。返回新图。

        为什么要这一步：实测 2560x1600 的整屏截图 → PNG 1.7 MB →
        base64 后的 data URI **2.3 MB**。PC 模式**每一步**都要发一张给模型，
        又慢又贵；而且模型对超大图也不见得更准（反而容易忽略细节）。
        降到 1600 长边后体积降到约 1/2.5，定位精度实测够用。

        ⚠ 返回的是**新图**，原图不动 —— 因为调用方还要拿原图存盘
          （存盘保留原始分辨率，方便事后人工核对"当时屏幕上到底是什么"）。
        """
        if max_edge is None:
            max_edge = getattr(config, "PC_SHOT_MAX_EDGE", 1600)
        try:
            w, h = img.size
            long_edge = max(w, h)
            if max_edge <= 0 or long_edge <= max_edge:
                return img
            r = max_edge / float(long_edge)
            new_size = (max(1, int(round(w * r))), max(1, int(round(h * r))))
            Image = _pil()                   # 本模块统一走懒加载
            resample = getattr(Image, "LANCZOS", None) or getattr(
                Image, "ANTIALIAS", None)
            if resample is None:
                return img
            return img.resize(new_size, resample)
        except Exception:
            # 降采样失败就将就用原图 —— 绝不因此中断 PC 模式
            return img

    @property
    def size(self) -> tuple[int, int]:
        return self.backend.size()

    # ------------------------------------------------------------ 鼠标
    def move(self, x: int, y: int) -> None:
        self.backend.move_to(x, y)

    def click(self, x: int, y: int, *, button: str = "left", clicks: int = 1, jitter: int = 0) -> None:
        import random
        if jitter:
            x += random.randint(-jitter, jitter)
            y += random.randint(-jitter, jitter)
        self.backend.click(x, y, button=button, clicks=clicks)

    def click_hit(self, hit: Hit, **kw) -> None:
        self.click(hit.x, hit.y, **kw)

    def scroll(self, amount: int, x: int | None = None, y: int | None = None) -> None:
        if x is not None and y is not None:
            self.move(x, y)
            time.sleep(0.05)
        self.backend.scroll(amount)

    # ------------------------------------------------------------ 键盘
    def type_text(self, text: str, *, interval: float = 0.012) -> None:
        self.backend.type_text(text, interval)

    def paste(self, text: str) -> None:
        self.backend.paste(text)

    def key(self, *keys: str) -> None:
        if len(keys) == 1:
            self.backend.press(keys[0])
        else:
            self.backend.hotkey(*keys)

    def clear_field(self) -> None:
        self.backend.hotkey("ctrl", "a")
        time.sleep(0.08)
        self.backend.press("delete")
        time.sleep(0.08)

    # ------------------------------------------------------------ 视觉定位
    def locate(self, client, description: str, *, extra_hint: str = "") -> Hit | None:
        """让视觉模型在整屏截图里找到目标，返回屏幕坐标。找不到返回 None（不要瞎点）。"""
        img = self.screenshot()
        w, h = img.size
        p = self.save(img, "locate")
        prompt = f"""你在帮一个自动化程序定位屏幕上的元素，以便移动鼠标点击它。

【要找的目标】{description}
{extra_hint}

【屏幕截图】尺寸 {w}x{h} 像素（左上角为原点，x 向右，y 向下）。

请只输出 JSON：
{{"found": true/false, "x": 元素中心点的x像素, "y": 元素中心点的y像素,
  "confidence": 0~1, "note": "你看到了什么"}}

要求：
- 坐标必须落在目标元素的正中心，不要给边框或旁边的元素。
- 如果目标不存在或看不清，found=false，x/y 给 0。
- 不要解释，只给 JSON。"""
        try:
            data = client.ask_json(prompt, images=[p], max_tokens=768, timeout=config.LM_VISION_TIMEOUT)
        except Exception:
            return None
        if not isinstance(data, dict) or not data.get("found"):
            return None
        try:
            x, y = float(data.get("x", 0)), float(data.get("y", 0))
        except (TypeError, ValueError):
            return None
        if not (0 <= x <= w and 0 <= y <= h):
            return None
        if float(data.get("confidence", 0) or 0) < 0.35:
            return None
        return Hit(int(x), int(y), label=str(data.get("note", "")))

    def drag_select(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """按住左键从 (x1,y1) 拖到 (x2,y2)。"""
        b = self.backend
        b.move_to(x1, y1)
        time.sleep(0.1)
        if isinstance(b, NativeBackend):
            b._send_mouse(_MOUSEEVENTF_LEFTDOWN)
            steps = 12
            for i in range(1, steps + 1):
                b.move_to(int(x1 + (x2 - x1) * i / steps), int(y1 + (y2 - y1) * i / steps))
                time.sleep(0.02)
            b._send_mouse(_MOUSEEVENTF_LEFTUP)
        else:  # pyautogui
            b.pg.dragTo(x2, y2, duration=0.4, button="left")


# ---------------------------------------------------------------------------
if __name__ == "__main__":   # 自检：python -m dsh_solver.desktop
    d = Desktop()
    print(f"后端     : {d.backend.name}")
    print(f"屏幕尺寸 : {d.size}")
    img = d.screenshot(save=True, tag="desktop_selfcheck")
    print(f"截图     : {img.size} -> {config.SHOT_DIR}")
    print(f"鼠标位置 : {d.backend.position()}")
