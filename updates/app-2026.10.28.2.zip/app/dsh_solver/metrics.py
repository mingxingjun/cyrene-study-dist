# -*- coding: utf-8 -*-
"""DOM 盲区埋点 —— 用数据决定"要不要投视觉"。

## 为什么先做这个，而不是先写视觉代码

视觉兜底是一条很贵的路（工期以周计，还要引入 OCR/模板依赖）。
在投入之前必须先回答一个问题：**DOM 到底有多大概率扫不出来？**

如果答案是"几乎不会"（占比 < 5%），那整条视觉路线就不该做 ——
把钱和风险花在一个基本不触发的分支上，是典型的投入产出倒挂。

所以这里只做一件事：**把"DOM 扫不出来"这件事记下来**。
数据够了再决定，而不是先写代码再找理由。

## 记什么

三类事件（都是"DOM 主力路径失效"的信号）：
  · `scan_empty`  —— 扫描出来一道题都没有（页面可能根本不是表单页）
  · `choose_fail` —— 找到了选项但**一个都没点中**（落笔失败）
  · `fill_fail`   —— 找到了填空框但**填不进去**

按"域名 + 事件类型"聚合计数，顺带存原始样本（含页面 URL 与耗时），
这样既能算占比，也能回看"到底是哪个站、哪种页面"。

## 存哪

`out/metrics/dom_blind_spots.json`

结构：
    {
      "version": 1,
      "updated": "2026-10-15T12:00:00",
      "events": {                       # 聚合计数
        "example.edu|scan_empty": 3,
        ...
      },
      "samples": [                      # 最近 N 条原始样本（便于排查）
        {"t": "...", "site": "...", "kind": "scan_empty",
         "url": "...", "detail": "...", "ms": 123},
        ...
      ]
    }

⚠ 样本里会带 URL。**URL 可能含 token/学号**，所以这里会：
  · 只保留 `scheme://host/path`，**丢掉 query 和 fragment**
  · 落盘前再过一遍敏感字段过滤
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

_LOCK = threading.Lock()
_MAX_SAMPLES = 500          # 只留最近这些条原始样本，防止文件无限长大

# 事件类型
SCAN_EMPTY = "scan_empty"
CHOOSE_FAIL = "choose_fail"
FILL_FAIL = "fill_fail"
KINDS = (SCAN_EMPTY, CHOOSE_FAIL, FILL_FAIL)


def _metrics_path() -> Path:
    from . import config
    return Path(config.OUT_DIR) / "metrics" / "dom_blind_spots.json"


def _safe_url(url: str) -> str:
    """只留 scheme://host/path —— 丢掉 query/fragment。

    ⚠ 这一条很重要：很多学习平台的 URL 里带 `?token=`、`?studentId=`、
      `?classId=`。埋点文件是要拿来看的，把凭据写进去就是自己泄自己。
    """
    try:
        u = urlparse(str(url or ""))
        host = u.netloc
        path = u.path
        # 路径里也可能塞了 id，但保留它才能看出"是哪个页面"，
        # 所以只做长度截断，不去猜哪个数字是敏感字段
        if len(path) > 120:
            path = path[:120] + "…"
        return f"{u.scheme}://{host}{path}"
    except Exception:
        return "(无法解析)"


def _site_of(url: str) -> str:
    """取域名作为聚合键。拿不到就归到 (未知)。"""
    try:
        host = urlparse(str(url or "")).netloc.lower()
        # 去掉端口
        host = host.split(":")[0]
        # 去掉 www. 前缀（www.x.com 与 x.com 视作同一个站）
        if host.startswith("www."):
            host = host[4:]
        return host or "(未知)"
    except Exception:
        return "(未知)"


def record(kind: str, *, url: str = "", detail: str = "",
           ms: float = 0.0, extra: dict | None = None) -> None:
    """记一次"DOM 主力路径失效"。

    **绝不能因为埋点本身出错而影响主流程** —— 所有异常都吞掉。
    """
    try:
        _record(kind, url=url, detail=detail, ms=ms, extra=extra)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# "成功扫描"的耗时统计（用于观察 DOM 路径本身是否越来越慢）
# ---------------------------------------------------------------------------
_OK_LOCK = threading.Lock()
_ok_stats = {"n": 0, "sum_ms": 0.0, "max_ms": 0.0}


def note_scan_ok(seconds: float) -> None:
    """记一次成功的扫描耗时（内存里累计，退出时落盘）。"""
    try:
        ms = float(seconds) * 1000.0
        with _OK_LOCK:
            _ok_stats["n"] += 1
            _ok_stats["sum_ms"] += ms
            if ms > _ok_stats["max_ms"]:
                _ok_stats["max_ms"] = ms
    except Exception:
        pass


def scan_ok_stats() -> dict:
    with _OK_LOCK:
        n = _ok_stats["n"]
        return {"count": n,
                "avg_ms": round(_ok_stats["sum_ms"] / n, 1) if n else 0.0,
                "max_ms": round(_ok_stats["max_ms"], 1)}


def _record(kind: str, *, url: str, detail: str, ms: float,
            extra: dict | None) -> None:
    if kind not in KINDS:
        kind = "other"
    site = _site_of(url)
    path = _metrics_path()
    with _LOCK:
        data = _load(path)
        key = f"{site}|{kind}"
        data["events"][key] = int(data["events"].get(key, 0)) + 1
        data["samples"].append({
            "t": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "site": site,
            "kind": kind,
            "url": _safe_url(url),
            "detail": str(detail or "")[:200],
            "ms": round(float(ms or 0), 1),
            **(extra or {}),
        })
        # 只留最近的一批
        if len(data["samples"]) > _MAX_SAMPLES:
            data["samples"] = data["samples"][-_MAX_SAMPLES:]
        data["updated"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                           encoding="utf-8")
            tmp.replace(path)          # 原子替换，断电不会留半截
        except OSError:
            pass


def _load(path: Path) -> dict:
    try:
        if path.exists():
            d = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                d.setdefault("version", 1)
                d.setdefault("events", {})
                d.setdefault("samples", [])
                return d
    except Exception:
        pass
    return {"version": 1, "updated": "", "events": {}, "samples": []}


def load() -> dict:
    """读回埋点数据（给界面/诊断脚本用）。"""
    return _load(_metrics_path())


def summary() -> dict:
    """算出盲区占比，供 G1 闸门判定。

    返回：
        {
          "total_pages": 扫描过的总页数（需要外部喂进来，见 note）
          "events": {kind: 次数},
          "sites": {域名: {kind: 次数}},
          "samples": N,
          "path": "埋点文件路径"
        }

    ⚠ **占比怎么算**：严格说需要"扫描总次数"作分母，而那个数只有
      调用方知道。所以这里同时给出：
        · `events` 绝对次数（可直接看量级）
        · `note` 提醒调用方用 `metrics.total()` 自己维护分母
      不在这里编一个假的分母 —— 那是自欺欺人。
    """
    d = load()
    by_kind: dict[str, int] = {}
    by_site: dict[str, dict[str, int]] = {}
    for key, n in (d.get("events") or {}).items():
        site, _, kind = str(key).partition("|")
        by_kind[kind] = by_kind.get(kind, 0) + int(n)
        by_site.setdefault(site, {})
        by_site[site][kind] = by_site[site].get(kind, 0) + int(n)
    return {
        "events": by_kind,
        "sites": by_site,
        "samples": len(d.get("samples") or []),
        "path": str(_metrics_path()),
    }


def blind_ratio(total_scans: int) -> dict:
    """按"盲区事件数 / 总扫描次数"算占比，用于 G1 判定。

    `total_scans` 由调用方提供（它就是"扫过多少次"）。
    若它没被维护（=0），这里**如实返回 unknown**，而不是编一个数。
    """
    s = summary()
    total_events = sum(s["events"].values())
    if total_scans <= 0:
        return {"ratio": None, "events": total_events, "total_scans": 0,
                "note": "没有总扫描次数，无法算占比（请让调用方维护分母）"}
    return {"ratio": total_events / float(total_scans),
            "events": total_events, "total_scans": total_scans,
            "note": ""}


# ---------------------------------------------------------------------------
# 总扫描次数（分母）
# ---------------------------------------------------------------------------
# 单独存一个小文件：它每个页面都会 +1，写在同一个大 JSON 里会太频繁。
_COUNT_LOCK = threading.Lock()
_count_cache = {"n": -1, "t": 0.0}


def _count_path() -> Path:
    from . import config
    return Path(config.OUT_DIR) / "metrics" / "scan_total.txt"


def bump_total(n: int = 1) -> None:
    """总扫描次数 +1。每次 `scan()` 调一次。

    用"内存缓存 + 定期落盘"的方式，避免每个页面都写磁盘。
    """
    try:
        with _COUNT_LOCK:
            if _count_cache["n"] < 0:
                _count_cache["n"] = _read_total()
            _count_cache["n"] += n
            now = time.time()
            # 每 10 秒才真的写一次盘
            if now - _count_cache["t"] < 10.0:
                return
            _count_cache["t"] = now
            p = _count_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(str(_count_cache["n"]), encoding="utf-8")
    except Exception:
        pass


def _read_total() -> int:
    try:
        p = _count_path()
        if p.exists():
            return int(p.read_text(encoding="utf-8").strip() or 0)
    except Exception:
        pass
    return 0


def total_scans() -> int:
    """读总扫描次数（优先用内存里的值，它更新）。"""
    with _COUNT_LOCK:
        if _count_cache["n"] >= 0:
            return int(_count_cache["n"])
    return _read_total()


def flush() -> None:
    """把总扫描次数落盘（退出时调一次）。"""
    try:
        p = _count_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(str(total_scans()), encoding="utf-8")
    except Exception:
        pass


def reset() -> None:
    """清空埋点（调试用）。"""
    global _count_cache
    try:
        for p in (_metrics_path(), _count_path()):
            if p.exists():
                p.unlink()
        with _COUNT_LOCK:
            _count_cache = {"n": 0, "t": 0.0}
    except Exception:
        pass


# 供日志用的标记（文档要求：日志里打一条明确标记，便于人工抽查）
def log_marker(kind: str, detail: str = "") -> str:
    return f"[blind] {kind}" + (f" {detail}" if detail else "")
