"""浏览器驱动：Playwright 负责"看结构 + 精准落笔"。

设计要点（和纯视觉点坐标的本质区别）：
  1. 先用 JS 把页面上的表单控件扫成结构化数据（题型 / 题干 / 选项 / 输入框）；
  2. 模型只做"选哪个"，不做"像素在哪"——9B 模型的强项；
  3. 落笔用 Playwright 的 locator（真点 DOM 元素），不依赖截图坐标；
  4. 只有 DOM 扫不出东西时，才回退到截图 + 视觉定位（Desktop.locate）。

扫描时会给每个控件打上 data-dsh-qid / data-dsh-oid 标记，落笔时就能稳定定位，
不受页面选择器变化影响。
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from . import config
from . import metrics

# 单题落笔的总时间预算（毫秒）。
#
# 为什么需要：真实考试页上四条落笔策略全失败时，每条要等满 1.2 秒点击超时，
#   再加两三次状态回读，实测**一道题要 6 秒**；日志里还看到同一道题
#   连着失败 28 次、白跑 3 分钟。
# 依据：本地实测成功路径只要 56~830 毫秒，所以 3.5 秒预算对正常页面绰绰有余。
# 超预算就放弃这题、继续下一题，避免拖慢整卷。
# （只限制总时长，不改任何一条策略的顺序和判据，快页面完全不受影响。）
BUDGET_MS = 3500

# ---------------------------------------------------------------------------
# 浏览器启动参数（运行内存 + 储存双重优化）
#
# 实测：软件冷启动后，自己开的 Edge 占 **913MB / 16 个进程**，
#   而启动器只有 35MB、Python 引擎只有 47MB —— **内存几乎全在浏览器上**。
#   那 16 个进程里很大一部分是后台服务（组件更新、遥测、同步、推荐…），
#   它们同时也是 out\ 涨到 900MB 的元凶（Edge 自己下的模型/组件缓存）。
#
# 下面关掉的全是**上网无关**的后台功能，不影响打开网页、登录、看视频、答题：
#   · 组件更新 —— 就是它下了 168MB 的 ProvenanceData 模型
#   · 遥测 / 指标上报 / 崩溃上报 —— 纯后台
#   · 账号同步 / 后台网络 —— 我们不需要
#   · 各类推荐、翻译、优化指南、媒体路由 —— 用不上
# 保留：GPU/渲染/编解码/登录相关，一个都不动。
BROWSER_ARGS = [
    "--disable-blink-features=AutomationControlled",   # 别让站点一眼看出是自动化的
    "--start-maximized",
    "--disable-component-update",        # ★ 关组件更新（省磁盘也省进程）
    "--disable-background-networking",
    "--disable-sync",                    # 不同步账号
    "--disable-breakpad",                # 不传崩溃报告
    "--disable-crash-reporter",
    "--no-service-autorun",
    "--disable-features=OptimizationGuideModelDownloading,"
    "OptimizationHints,MediaRouter,Translate,HeavyAdPrivacyMitigations,"
    "InterestFeedContentSuggestions,CalculateNativeWinOcclusion,"
    "BackForwardCache,AcceptCHFrame",
    "--disable-domain-reliability",      # 不传域名可靠性数据
    "--metrics-recording-only",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
]

# ---------------------------------------------------------------------------
# 页面内扫描脚本。故意写得保守（不用可选链之类的语法糖），兼容老页面。
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 「选项被选中了吗」的判定词表 —— **全工程唯一一份**
#
# ⚠ 为什么提成模块常量：这个判据在页面里必须出现两次
#   （扫描用的 SCAN_JS 一份、落笔回读用的 _FIND_JS 一份），
#   而 _FIND_JS 是**独立注入的片段**，访问不到 SCAN_JS 里的函数，
#   所以没法简单地"共用同一个函数"。
#   原来的做法是各写一份正则 —— 结果改了一处忘另一处，
#   实测学习通（超星）点选加的是 `.sel`，只补了扫描那份，
#   于是"页面自报 answered=2，程序却报未选中"。
#   现在词表在这里定义一次，两处都嵌入这一段，物理上不可能再跑偏。
#
# 覆盖主流平台的常见写法（不针对某一家）：
#   选中态类名 sel / selected / select / checked / active / on / cur /
#   current / is-* 等；另有背景色从白变色的样式判据。
# ---------------------------------------------------------------------------
_SEL_RE_SRC = (r"(^|[\s_-])(sel|selected|seled|select|checked|active|on|cur|"
               r"current|is-checked|is-selected|is-active|is-current|is-on|"
               r"is-sel)([\s_-]|$)")

# ---------------------------------------------------------------------------
# "这个 URL 像不像课程页"（2026-10-23 客户日志倒逼出来的）
#
# 客户 30 次运行里有 21 次：没填课程网址 → 程序抓了**最后一个标签页**
# （百度 / 学习通个人空间 / 登录页）→ 2 秒后只报一句
# 「页面上找不到可播放的视频（当前页面：翻译）」。
# 客户根本看不出"是自己没停在课程页上"。
#
# 用途只有两个，都不改变既有行为：
#   ① 空网址接管时，**优先挑**已经是课程页的那个标签页；
#   ② 判断不出来时，给一句人能看懂的话。
# ---------------------------------------------------------------------------
_COURSE_URL_RE = re.compile(
    r"(mycourse/studentstudy|mycourse/studentcourse|mooc-ans/knowledge/cards|"
    r"mooc2-ans\.chaoxing\.com|chaoxing\.com/course|/knowledge/cards|"
    r"/ananas/modules/video|zhihuishu\.com|studyvideoh5|icve\.com\.cn)", re.I)

# ---------------------------------------------------------------------------
# 题干是不是「页面源码」（而不是题目）—— 纯逻辑，可脱浏览器单测。
#
# 2026-10-23 真机：一页 4 道填空题，题干全变成了同一段
# `function greenlight() { Ext.fly(window.frameElement)… }` 的**脚本源码**，
# 于是模型把源码当题目解释了一遍（"该段代码用于在视频任务点完成后……"），
# 又因为 4 道题干完全相同 → 同一个缓存键 → **4 个空格写进同一段话**。
#
# 为什么不能只靠 JS 侧摘 <script>：
#   有些平台把源码塞进 <pre>/<textarea>/注释里，innerText 能取到；
#   这一层是**最后一道闸**，判据故意从严（宁可判"题干未识别"，
#   也不要让模型对着源码编答案）。
# ---------------------------------------------------------------------------
_SRC_STEM_HINTS = (
    "function(", "function (", "=>", "querySelector", "getElementById",
    "addEventListener", "window.frameElement", "Ext.fly", "Ext.Function",
    "console.log", "document.body", "document.querySelector",
    "ans-job-finished", "ed_complete", "aria-label", "try {", "catch (",
    "var ", "let ", "const ",
)


def stem_looks_like_source(text: str) -> bool:
    r"""这段"题干"是不是页面源码／脚本说明，而不是一道题。

    判据（两条同时成立才算）：
      ① 至少命中 2 个源码特征词（`function(` / `Ext.fly` / `querySelector` …）；
      ② 代码符号 `{ } ( ) ; = < >` 出现 >= 6 次。

    为什么两条都要：中文题干里正常会出现"函数""变量"这类词，
    单看关键词必然误伤；而**符号密度**是自然语言题干不具备的特征。
    长度 < 40 字的直接放过 —— 短题干不可能是一段脚本。
    """
    s = str(text or "")
    if len(s) < 40:
        return False
    hits = sum(1 for h in _SRC_STEM_HINTS if h in s)
    if hits < 2:
        return False
    marks = sum(s.count(c) for c in "{}();=<>")
    return marks >= 6


# ===========================================================================
# 结构化识别（**叠加**）：学习通随堂练习 / answerQuestion2 这类
# 「.question-item + .option-list > li」的页面。
#
# 为什么不改 SCAN_JS：那套逻辑服务着学习通作业、智慧树、问卷星等一大票页面，
# 动它有把别处改坏的风险。这段**只在结构匹配时接管**，不匹配就返回 ok:false，
# 调用方原样走 SCAN_JS。
#
# 关键：标记 `data-dsh-cqid` / `data-dsh-coid` 打在 **<li>** 上 ——
#   `choose()` 就是按这两个属性找元素的，所以下游完全不用改。
#   编号是**帧内**编号，和 SCAN_JS 的约定一致（合并到 Python 侧再加偏移）。
# ===========================================================================
_STRUCTURED_SCAN_JS = r"""
() => {
  function txt(e) {
    // 同 SCAN_JS 的 textOf：不能把 <script>/<style> 的源码当文字
    // （真机踩到过题干变成平台注入脚本，见 SCAN_JS 里的说明）
    var v = e.innerText;
    if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
    try {
      var c = e.cloneNode(true);
      c.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
      return (c.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (x) {
      return '';
    }
  }
  function cls(e) {
    try {
      return String((e.className && e.className.baseVal !== undefined)
                     ? e.className.baseVal : (e.className || ''));
    } catch (x) { return ''; }
  }

  const items = [].slice.call(document.querySelectorAll('.question-item'));
  if (!items.length) return {ok: false, why: '没有 .question-item'};

  const qs = [];
  for (let qi = 0; qi < items.length; qi++) {
    const it = items[qi];
    let lis = [].slice.call(it.querySelectorAll('.option-list > li'));
    if (lis.length < 2) lis = [].slice.call(it.querySelectorAll('ul > li'));
    // 结构不符就**整体放弃** —— 宁可让原逻辑接手，也不要半对半错
    if (lis.length < 2) return {ok: false, why: '第 ' + (qi + 1) + ' 题没有 >=2 个 li'};

    const nameEl = it.querySelector('.question-name');
    // ⚠ 不能只取 .question-name 的 textContent。
    //
    //   真机 HTML 是 `<p class="question-name">1. <span>[单选题]</span>
    //   <span class="html-content-box"><p>题干</p></span></p>` —— **嵌套 <p>**。
    //   HTML5 解析器遇到内层 <p> 会先把外层 <p> 关掉，于是内层那个
    //   `<p>题干</p>` 被**提出去**、变成 .question-name 的兄弟节点。
    //   2026-10-22 实测：题干只剩 '1. [单选题]'，正文全丢。
    //
    //   所以：把 .question-name 后面、**直到选项列表之前**的兄弟节点文字也并进来。
    //   真机上如果内容没被提出去（下一个兄弟直接就是 .option-list），这段自然什么都不加。
    let _stemParts = [];
    if (nameEl) _stemParts.push(txt(nameEl));
    let _sib = nameEl ? nameEl.nextElementSibling : null;
    let _guard = 0;
    while (_sib && _guard++ < 8) {
      const _cl = cls(_sib);
      if (/option-list/.test(_cl)) break;
      let _inner = false;
      try { _inner = !!_sib.querySelector('.option-list'); } catch (x) {}
      if (_inner) break;
      const _t = txt(_sib);
      if (_t) _stemParts.push(_t);
      _sib = _sib.nextElementSibling;
    }
    const stem = (_stemParts.length ? _stemParts.join(' ') : txt(it)).slice(0, 500);

    const opts = [];
    for (let oi = 0; oi < lis.length; oi++) {
      const li = lis[oi];
      const le = li.querySelector('.option-letter');
      const letter = le ? txt(le) : '';
      // ⚠ 正文同理：`<p class="option-result"><span><p>正文</p></span></p>` 里的
      //   内层 <p> 会被解析器提出去，.option-result 变成空壳。
      //   直接用**整个 <li> 的文字减去字母**最稳（两种排版都对）。
      let body = txt(li);
      if (letter && body.indexOf(letter) === 0) {
        body = body.slice(letter.length).trim();
      }
      // ★ 标记打在 <li> 上
      try {
        li.setAttribute('data-dsh-cqid', String(qi));
        li.setAttribute('data-dsh-coid', String(oi));
      } catch (x) {}
      const lc = cls(li);
      opts.push({
        text: (letter ? letter + ' ' : '') + body,
        value: letter,
        key: letter,
        checked: /(^|\s)active(\s|$)/i.test(lc)
                 || /(^|\s)(checked|selected|cur)(\s|$)/i.test(lc)
                 || !!li.querySelector('input:checked'),
      });
    }

    const kind = /multiple-choice|multi-choice|checkbox|多选/.test(cls(it))
                   ? 'checkbox' : 'radio';
    const r = it.getBoundingClientRect();
    qs.push({
      qid: qi,
      kind: kind,
      stem: stem,
      options: opts,
      name: '',
      in_view: r.top < (window.innerHeight || 900) && r.bottom > 0,
      box: {x: Math.round(r.left), y: Math.round(r.top),
            w: Math.round(r.width), h: Math.round(r.height)},
    });
  }

  // 配图（题目/选项旁边的图）。没有就空数组，不影响文字题。
  const images = [];
  try {
    const ims = document.querySelectorAll('.attach-img-list img, .question-item img');
    for (let i = 0; i < ims.length; i++) {
      const im = ims[i];
      const r = im.getBoundingClientRect();
      if (r.width < 60 || r.height < 40) continue;
      images.push({
        src: im.currentSrc || im.src || '',
        box: {x: Math.round(r.left), y: Math.round(r.top),
              w: Math.round(r.width), h: Math.round(r.height)},
      });
    }
  } catch (x) {}

  return {
    ok: true,
    url: location.href,
    title: document.title,
    questions: qs,
    inputs: [],
    images: images,
    buttons: [],
    headings: [],
    viewport: {w: window.innerWidth, h: window.innerHeight},
    scrollY: window.scrollY,
    scrollH: document.documentElement.scrollHeight,
    deduped: 0,
    deduped_frag: 0,
  };
}
"""


# 把占位符换成上面那份词表。
# （用 replace 而不是 f-string：JS 里有几千个花括号，f-string 会把它们
#   全当成格式占位符；而且 rs""" 里也塞不进 Python 表达式。）
_SCAN_JS_RAW = r"""
() => {
  const vw = window.innerWidth, vh = window.innerHeight;
  const out = { url: location.href, title: document.title, viewport: {w: vw, h: vh},
                scrollY: window.scrollY, scrollH: document.documentElement.scrollHeight,
                questions: [], inputs: [], images: [], buttons: [], headings: [] };

  // ======================================================================
  // ★ 穿透 shadow DOM 的查询助手（P-1「零成本手段」之一）★
  //
  // 为什么需要它：`document.querySelectorAll()` **不穿透 shadow root**。
  //   用 Web Component 写的页面（越来越多见）题目全在影子树里，
  //   于是扫描结果直接是 **0 题** —— 实测确认：
  //       shadow_only.html → 我们用原生查询扫到 0 题
  //       Playwright 定位器 / 显式取 shadowRoot → 能拿到 3 个选项
  //
  // 关键点：**这是零成本的**。不需要 OCR、不需要截图、不需要模板，
  //   只是把"查询范围"从 document 扩展到"所有 open 的 shadow root"。
  //   所以按 P-1 的要求，这个必须先做，而不是绕过去写视觉代码。
  //
  // ⚠ 只对 **open** 模式有效。`attachShadow({mode:'closed'})` 外部
  //   拿不到 shadowRoot，那是**真盲区**（文档点名的三块之一），
  //   只能靠视觉。这里刻意不假装能处理它。
  //
  // 实现注意：
  //   · 用 set 去重 —— 同一元素可能被多轮收集到
  //   · 限制递归深度与 root 数量，防止病态页面把扫描拖死
  //   · 任何一步抛错都跳过，不影响常规查询
  // ======================================================================
  const DSH_MAX_ROOTS = 60;
  const DSH_MAX_DEPTH = 8;

  function dshShadowRoots() {
    const roots = [];
    let queue = [[document, 0]];
    while (queue.length && roots.length < DSH_MAX_ROOTS) {
      const cur = queue.shift();
      const node = cur[0], depth = cur[1];
      if (depth > DSH_MAX_DEPTH) continue;
      let all = [];
      try { all = node.querySelectorAll('*'); } catch (e) { continue; }
      for (let i = 0; i < all.length && roots.length < DSH_MAX_ROOTS; i++) {
        const sr = all[i].shadowRoot;
        if (sr) {
          roots.push(sr);
          queue.push([sr, depth + 1]);     // 影子树里还能再套影子树
        }
      }
    }
    return roots;
  }

  // 返回数组（不是 NodeList），调用方一律用 [].slice 的写法也能吃
  function dshQueryAll(sel) {
    const seen = [];
    const push = function (list) {
      for (let i = 0; i < list.length; i++) {
        const e = list[i];
        if (seen.indexOf(e) < 0) seen.push(e);
      }
    };
    // ⚠ 这里必须用 **document.querySelectorAll**，不能换成 dshQueryAll！
    //   上一版做批量替换时，脚本把这一行也换掉了 → 变成
    //   `push(dshQueryAll(sel))` 的**无限递归** → RangeError 被 catch 吞掉
    //   → 函数**永远返回空数组**，所有页面都扫不到题。
    //   而且因为它静默返回 []，现象只是"扫不到题"，极难定位。
    try { push(document.querySelectorAll(sel)); } catch (e) { /* 选择器不合法就只查影子树 */ }
    const roots = dshShadowRoots();
    for (let r = 0; r < roots.length; r++) {
      try { push(roots[r].querySelectorAll(sel)); } catch (e) { /* 忽略 */ }
    }
    return seen;
  }

  // 单个元素也一样要能穿透（closest 不跨影子边界）
  function dshQueryOne(sel) {
    const all = dshQueryAll(sel);
    return all.length ? all[0] : null;
  }

  // ======================================================================
  // 「这个选项被选中了吗」——**全页唯一的一份实现**
  //
  // ⚠ 为什么要单独抽出来：这份判据原来在页面里**存在两份**
  //   （扫描用的 customSelected、落笔回读用的 dshChecked），
  //   各自带一份正则。结果改了一份忘了另一份 ——
  //   实测学习通（超星）点选后加的是 `.sel`，只补了一处，
  //   于是"页面自报 answered=2，程序却报未选中"。
  //   现在只有这一份，两边都调它，从根上不让它们再跑偏。
  //
  // 词表按**主流学习/考试平台**的常见写法收集（不针对某一家）：
  //   选中态类名：selected / sel / select / checked / active / on / cur /
  //               current / is-* / J_* / *-active / *-on / *-checked
  //   还可看样式：背景色从白色变成别的颜色、或内联 background
  // ======================================================================
  const DSH_SEL_RE = /__DSH_SEL_RE__/i;
  // ⚠⚠ 这些是 **CSS 工具类**，不是"选中态"。匹配前必须剔掉。
  //
  //   2026-10-19 智慧树（examloop）实测：label 的 class 是
  //       flex items-center gap-4 **user-select** group
  //   而词表里有裸的 `select`，`-select ` 正好满足词边界
  //   → **每个 label 都被判成"已选中"** → choose() 不去点
  //   → 只翻页不落笔。
  //   同样中招的还有 Tailwind 的 select-none / select-text / select-all。
  const DSH_CLASS_NOISE = /(^|[\s_-])(user-select|select-none|select-text|select-all|select-auto)([\s_-]|$)/gi;
  // 原子类背景色（Tailwind 风格）与常见色名
  const DSH_BG_RE = /bg-(blue|green|red|primary|success|danger|indigo|violet|sky|cyan|teal|emerald|rose|amber|orange)/i;
  const DSH_BG_WHITE = /bg-\[#(fff|ffffff)\]|bg-white/i;

  function dshIsSelected(e) {
    if (!e) return false;
    if (e.tagName === 'INPUT') return !!e.checked;
    const aria = (e.getAttribute && e.getAttribute('aria-checked') || '').toLowerCase();
    if (aria === 'true') return true;
    if (aria === 'false') return false;
    // 原生属性（部分平台直接写 selected / checked 属性）
    if (e.hasAttribute && (e.hasAttribute('data-selected')
        || e.getAttribute('data-checked') === 'true')) return true;

    let nodes = [e];
    try {
      // 前 16 个后代就够 —— 选中态通常画在紧邻的那个圆圈上
      nodes = nodes.concat([].slice.call(e.querySelectorAll('*')).slice(0, 16));
    } catch (err) { /* 忽略 */ }

    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      let c = (typeof n.className === 'string') ? n.className : '';
      if (c) {
        // 先剔掉 CSS 工具类（user-select 之类），否则会被误判成已选中
        c = c.replace(DSH_CLASS_NOISE, ' ');
        if (DSH_SEL_RE.test(c)) return true;
        // ★ 2026-10-28 真机事故：这里原来还有「背景色=选中」的启发式。
        //   学习通新作业页的选项正文是粘进来的富文本，带
        //   `<span style="background-color: rgb(239,240,241)">`（代码块底色），
        //   于是**每个选项**都被判成已选中 → 单选/多选一次都不点。
        //   背景色不是选中态，删掉。
      }
    }
    return false;
  }

  function vis(e) {
    if (!e) return false;
    const s = window.getComputedStyle(e);
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    const r = e.getBoundingClientRect();

    // ---- 表单控件：优先看"有没有可见的可点击祖先" ----
    // 真实考试系统（问卷星、超星、各类在线考试）几乎都会把原生 radio 视觉隐藏，
    // 常用手法是 position:absolute + width/height:1px + opacity:0 + clip:rect(0 0 0 0)，
    // 自己画一个圆圈来代替。这种控件尺寸是 0，但**用户能通过它的 label 点到它**，
    // 必须能被作答。所以对表单控件先做这层判断，不能一看到尺寸小就 return false。
    const tag = e.tagName.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      const type = (e.getAttribute('type') || '').toLowerCase();
      const isChoice = (type === 'radio' || type === 'checkbox');
      const clickable =
        e.closest('label') ||
        (e.id && document.querySelector('label[for="' + CSS.escape(e.id) + '"]')) ||
        e.closest('[role=radio],[role=checkbox],.option,.opt,.choice,.answer,.item,.el-radio,.el-checkbox');
      if (clickable && vis(clickable)) {
        const cr = clickable.getBoundingClientRect();
        if (cr.width >= 8 && cr.height >= 8) return true;
      }
      // 选择控件即使本体不可见，只要有 aria-label / title 也要认（无障碍写法）
      if (isChoice && (e.getAttribute('aria-label') || e.getAttribute('title'))) {
        const pr = (e.parentElement || e).getBoundingClientRect();
        if (pr.width >= 8 && pr.height >= 8) return true;
      }
    }

    if (r.width < 1 || r.height < 1) return false;
    if (parseFloat(s.opacity || '1') <= 0.05) return false;
    return true;
  }
  function box(e) {
    const r = e.getBoundingClientRect();
    return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)};
  }
  function inView(e) {
    const r = e.getBoundingClientRect();
    return r.bottom > -40 && r.top < vh + 40 && r.right > -40 && r.left < vw + 40;
  }
  // 取元素的"可见文字"。**绝不把 <script>/<style> 的源码当成文字。**
  //
  // ⚠ 2026-10-23 真机（4 道填空题的题干全变成同一段源码）：
  //   题目区当时取不到 innerText（不是可见文字），于是退回 textContent ——
  //   而 textContent **包含 <script> 里的源码**。页面里有平台注入的
  //   greenlight / ed_complete 那段（给任务点打"已完成"标记的脚本），
  //   结果 4 道填空题的题干全成了这段源码 → 模型回"该段代码用于……"，
  //   又因为题干完全相同 → 同一个缓存键 → 4 个空格写进**同一段话**。
  //   所以：退回 textContent 时必须先把源码类节点摘掉。
  function textSansCode(e) {
    try {
      var c = e.cloneNode(true);
      c.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
      return (c.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (x) {
      return '';
    }
  }
  function textOf(e) {
    if (!e) return '';
    var v = e.innerText;
    if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
    return textSansCode(e);
  }
  // 找到某个控件的可读标签（点选型控件专用）
  function labelOf(inp) {
    // 1) 显式 <label for>
    if (inp.id) {
      const l = document.querySelector('label[for="' + CSS.escape(inp.id) + '"]');
      if (l && vis(l)) return textOf(l);
    }
    // 2) 包在 <label> 里
    const wrap = inp.closest('label');
    if (wrap && vis(wrap)) return textOf(wrap);
    // 3) aria-label / title / value / 相邻文本
    for (const a of ['aria-label', 'title']) {
      const v = inp.getAttribute(a);
      if (v) return v.trim();
    }
    if (inp.value && inp.type !== 'text') return String(inp.value);
    const li = inp.closest('li, .option, .choice, .answer, .item, td, dd');
    if (li && vis(li)) {
      const t = textOf(li);
      if (t.length < 300) return t;
    }
    return '';
  }
  // 判断一段文字是不是"代码"（CSS / HTML / JS）而不是题目文字。
  //
  // ⚠ 实测踩到：学习通作业页上有几个与题目无关的输入框，它们的"提示文字"
  //   取出来是 `.view` 这种 **CSS 选择器**；题干也取到了样式代码。
  //   结果每轮要白花好几次模型调用，模型只能回
  //   "题目内容缺失，仅含样式代码"、"confidence: 0.1"。
  //   这类文字对作答**零价值**，还不如不给。
  function looksLikeCode(t) {
    if (!t) return false;
    const s = String(t);
    // 纯选择器：以 . 或 # 开头、没有空格分隔的自然语言
    if (/^\s*[.#][A-Za-z][\w-]*\s*$/.test(s)) return true;
    // 选择器 + 声明块（.a{...} / #b{color:red}）
    if (/[.#]?[\w-]+\s*\{[^{}]*[:;][^{}]*\}/.test(s)) return true;
    // 大量 CSS 属性名
    const cssHits = (s.match(/[a-z-]+\s*:\s*[^;{}]{1,40};/g) || []).length;
    if (cssHits >= 3) return true;
    // HTML 标签片段
    if (/<\/?[a-z][\w-]*(\s[^<>]*)?>/i.test(s) && s.length < 400) return true;
    return false;
  }
  function fieldLabel(el) {
    const al = el.getAttribute('aria-label');
    if (al && !looksLikeCode(al)) return al.trim();
    const ph = el.getAttribute('placeholder');
    if (ph && ph.length < 120 && !looksLikeCode(ph)) return ph.trim();
    if (el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) {
        const t = textOf(l);
        if (!looksLikeCode(t)) return t;
      }
    }
    const w = el.closest('label');
    if (w) {
      const t = textOf(w);
      if (!looksLikeCode(t)) return t;
    }
    // 往上找最近的、能解释这个空格的文字块
    let p = el.parentElement, hops = 0;
    while (p && hops < 4) {
      const t = textOf(p);
      if (t.length > 6 && t.length < 400 && !looksLikeCode(t)) return t;
      p = p.parentElement; hops++;
    }
    const prev = el.previousElementSibling;
    if (prev) {
      const t = textOf(prev);
      if (!looksLikeCode(t)) return t;
    }
    return '';
  }
  // 找一个控件所属的"题块"。
  //
  // 选择题：从控件往上走，取**最浅的**满足下面两条的祖先 ——
  //   (a) stemFrom 能给出 >= 8 字符的题干（而不是一上来就是选项）
  //   (b) 且包含 2 个以上表单控件（多选/多个填空同属一题）
  // 判据是"能不能解析出题干"，不是"文本够不够长"。反例：纯选项容器
  // （<div class="opts">）文本很长、也满足长度条件，但里面没有题干，
  // 选中它就会把整串选项当题干交出去。
  //
  // 填空题（noOptions=true）：判据完全不同，走 lastControlRoot ——
  // 见下面那个函数里的注释（这里踩过一个很贵的坑）。
  function questionRoot(el, optTexts, letteredTexts, noOptions) {
    if (noOptions) {
      // 先按"填空题专属"的判据找，找不到再退回通用判据
      const r = lastControlRoot(el);
      if (r) return r;
    }
    let node = el, hops = 0, firstOk = null;
    while (node && node !== document.body && hops < 10) {
      let stem = '';
      try { stem = stemFrom(node, optTexts, letteredTexts); } catch (e) { stem = ''; }
      const ctrls = node.querySelectorAll ? node.querySelectorAll('input,textarea,select').length : 0;
      if (stem.length >= 8 && ctrls >= 2) {
        if (!firstOk) firstOk = node;
      } else if (firstOk) {
        break;   // 已经找到合格的祖先，再往上题干就不专属于这道题了
      }
      node = node.parentElement; hops++;
    }
    return firstOk ||
           el.closest('fieldset, li, form, .question, .item') ||
           el.parentElement || document.body;
  }

  // 填空题的题块：从输入框往上走，找第一个满足全部三条的祖先：
  //   ① 本层有控件，且 el 是本层最后一个控件（→ 题的右边界）
  //   ② 本层文本里有**实质内容**（不只是 "答案：" 这种标签）
  //   ③ 越靠上越好？不 —— 取**第一个**满足①②的，那才是最贴身的题块
  //
  // 为什么不能用选择题那套判据：填空题没有"选项文字"可以拿来算题干，
  // 一旦某个祖先解析不出题干就会一路退到 body —— 结果是所有填空题的题干
  // 都变成整页第一题的文字（实测 f0/f1/f2 全被当成"HTTP 端口"那道题），
  // 模型拿着错误题干只能瞎给 id。
  //
  // 为什么要加判据②：输入框常常被包在一个只写 "答案：" 的 <label> 里，
  // 那一层虽然满足"自己是最后一个控件"，但没有任何题干信息；
  // 真正的题干在它的父级（如 <div class="q">）。
  // 富文本编辑器工具栏上的文字 —— **不是题干**。
  //
  // ⚠ 实测（学习通问答题）：可编辑区和它的工具栏同在一个容器里，
  //   `textOf(容器)` 拿到的是 "段落格式 字体 字号" 这种工具栏文字，
  //   于是题干被解析成工具栏、或者因为"长度不足 8"被判定为找不到题干。
  //   日志表现：`(填空题，题干未识别)`，模型只能回"无法作答"。
  //
  // 判据刻意保守：把已知的工具栏词**全部剔除后还剩东西**，就不是工具栏。
  //   这样题干里正常出现"字体"两个字也不会被误判。
  function looksLikeEditorChrome(t) {
    const s = String(t || '').replace(/\s+/g, '');
    if (!s || s.length > 60) return false;
    const stripped = s.replace(
      /段落格式|字体|字号|加粗|斜体|下划线|删除线|文字颜色|背景色|颜色|左对齐|右对齐|居中对齐|居中|两端对齐|对齐|缩进|有序列表|无序列表|列表|插入图片|插入链接|插入表格|插入|图片|链接|表格|公式|上标|下标|撤销|重做|全屏|预览|代码块|引用|清除格式|格式刷|行距|首行缩进/g, '');
    return stripped.length === 0;
  }

  function lastControlRoot(el) {
    // ⚠ 必须包含 `[contenteditable=true]`。
    //   第一版只写 `input,textarea,select`，于是**富文本回答框**（学习通的问答题
    //   是 contenteditable div，那个 textarea 反而是隐藏的）在这里
    //   `order < 0` 直接 return null → 题干拿不到 → 全部退化成"题干未识别"。
    //   实测日志：6 个问答题全是 `(填空题，题干未识别)`，一道都答不了。
    //   这里和 SCAN_JS 的 SEL 用同一套选择器，避免两处再跑偏。
    const SEL_CTRL = 'input,textarea,select,[contenteditable=true]';
    // ⚠ "最后一个控件"必须**只看可见的**。
    //   学习通的富文本结构是：
    //       div.eidtDiv
    //         ├ div[contenteditable=true]   ← 真正的回答框
    //         └ textarea (display:none)     ← 隐藏的备用件，**排在后面**
    //   于是 `last` 永远是那个隐藏 textarea，`last === el` 永不成立，
    //   循环走完返回 null → 题干拿不到 → 退化成"题干未识别"。
    //   （我第一版就是这样，工具栏过滤加了也没用 —— 因为压根没走到那一步。
    //     这个坑说明：**"最后一个"这种判据一定要先排除不可见的干扰项**。）
    function visibleControls(node) {
      return [].slice.call(node.querySelectorAll(SEL_CTRL)).filter(function (c) {
        return vis(c);
      });
    }
    const all = visibleControls(document);
    const order = Array.prototype.indexOf.call(all, el);
    if (order < 0) return null;
    let node = el.parentElement, hops = 0, firstBoundary = null;
    while (node && node !== document.body && hops < 10) {
      const list = visibleControls(node);
      if (list.length) {
        const last = list[list.length - 1];
        if (last === el) {
          if (!firstBoundary) firstBoundary = node;     // 记住第一个边界，兜底用
          // 判据②：把"答案/作答"这类标签去掉后还剩多少实质文字
          const t = textOf(node)
            .replace(/[\s:：]*\s*(答案|作答|填写|答)\s*[:：]?\s*$/g, '')
            .trim();
          // 工具栏文字不算数（见 looksLikeEditorChrome 的说明）
          if (looksLikeEditorChrome(t)) {
            node = node.parentElement; hops++;
            continue;
          }
          if (t.length >= 8) return node;
        }
      }
      node = node.parentElement; hops++;
    }
    return firstBoundary;
  }

  // 题干 = 容器文本在"选项区开始"处截断。
  //
  // 踩过的坑与最终判据：
  //   ① 只用"第一个选项文字出现的位置"截断会翻车 —— 选项文字常常**就是题干的一部分**
  //      （题干 "十进制数 255 对应…"，选项文字恰是 "255"），一截只剩半句话；
  //   ② 所以真正的判据不是"某个选项出现了"，而是"选项区开始了"：
  //      必须有两个不同的选项**按先后顺序**在附近依次出现，才认定这里就是选项区；
  //   ③ 单个选项匹配一律忽略；一处都找不到时保留全文（宁可题干带噪声，
  //      也不能交半句话给模型）。
  function findOptionRegionStart(flat, optTexts) {
    const parts = optTexts
      .map(function (t) { return (t || '').replace(/\s+/g, ' ').trim(); })
      .filter(function (s) { return s.length >= 2; });
    if (parts.length < 2) return -1;

    // 匹配点前面必须是空白或标点（"）" "：" "。" 等）。
    // 这条很关键：有些页面把题干写在容器外面，容器里**只剩选项**，
    // 于是第一个选项在位置 0 就匹配上了 —— 不加边界判断会把整个容器
    // 误当成"题干里的巧合匹配"，最终交出满屏选项当题干。
    function boundaryOk(idx) {
      if (idx <= 0) return true;                 // 容器开头就是选项，合法
      const prev = flat.charAt(idx - 1);
      if (/\s/.test(prev)) return true;
      return /[）)】\]:：。.、,，;；!！?？]/.test(prev);
    }

    let searchFrom = 0;
    while (searchFrom < flat.length) {
      const i0 = flat.indexOf(parts[0], searchFrom);
      if (i0 < 0) return -1;
      // 硬约束：选项区必须出现在容器的靠前位置。
      // 如果第一个选项要跑到 200 字符之后才出现，那就不是"这个容器里的选项区"，
      // 而是别处的巧合匹配 —— 继续往后找只会把题干截成半句话。
      if (i0 > 200) return -1;
      if (boundaryOk(i0)) {
        const i1 = flat.indexOf(parts[1], i0 + parts[0].length);
        if (i1 > i0 && i1 <= i0 + parts[0].length + parts[1].length + 120) {
          return i0;
        }
      }
      searchFrom = i0 + 1;
    }
    return -1;
  }

  function stemFrom(root, optTexts, letteredTexts) {
    const full = textOf(root);
    if (!full) return '';
    const flat = full.replace(/\s+/g, ' ');

    // ① 选项区起点（两个选项连续出现）
    const regionStart = findOptionRegionStart(flat, optTexts);

    // ② 带标号的文本 "A. xxx"：真正的选项题里最可靠，直接用
    let letteredStart = -1;
    (letteredTexts || []).forEach(function (t) {
      const s = (t || '').replace(/\s+/g, ' ').trim();
      if (s.length < 2) return;
      const idx = flat.indexOf(s);
      if (idx > 0 && (letteredStart < 0 || idx < letteredStart)) letteredStart = idx;
    });

    let cut = flat.length;                       // 默认：整段都当题干
    if (letteredStart >= 0) cut = Math.min(cut, letteredStart);
    if (regionStart >= 0) cut = Math.min(cut, regionStart);

    let stem = flat.slice(0, cut);
    stem = stem.replace(/[\s,，、;；:：\-—|]+$/, '').trim();
    return stem;
  }

  const SEL = 'input[type=radio],input[type=checkbox],input[type=text],input[type=search],' +
              'input[type=number],input[type=email],input[type=tel],input[type=url],' +
              'input:not([type]),textarea,select,[contenteditable=true]';
  const all = [].slice.call(dshQueryAll(SEL));

  // ------------------------------------------------------------------
  // 自定义选项组件：**页面里可能一个原生 input 都没有**
  //
  // 无障碍规范（WAI-ARIA）要求自定义单选/多选写成 role=radio / role=checkbox
  // 并带 aria-checked；国内自研考试系统也大量使用 div + click 事件，
  // 常用类名带 option / choice / answer / radio。
  //
  // 早期版本只认原生控件，遇到这种页面会「扫到 0 道题」→ 不落笔只翻页。
  // 这里在扫描不到原生控件时补一层识别。
  // ------------------------------------------------------------------
  function customChoiceEls() {
    const seen = [], out = [];
    function push(e, kind) {
      if (!e || seen.indexOf(e) >= 0) return;
      seen.push(e);
      out.push({el: e, kind: kind});
    }
    [].slice.call(dshQueryAll('[role=radio],[role=checkbox]')).forEach(function (e) {
      push(e, e.getAttribute('role') === 'checkbox' ? 'checkbox' : 'radio');
    });
    // aria-checked 是自定义选项最可靠的信号
    [].slice.call(dshQueryAll('[aria-checked]')).forEach(function (e) {
      const r = (e.getAttribute('role') || '').toLowerCase();
      if (r === 'radio' || r === 'checkbox') return;      // 上面已收
      push(e, e.getAttribute('aria-checked') === 'mixed' ? 'checkbox' : 'radio');
    });
    // ------------------------------------------------------------------
    // C. **靠类名标识的选项**（国内平台最常见的一类）
    //
    // 参考多个开源刷课/答题脚本的选择器集合后补上这一层：
    //   智慧树课中弹题  .topic-item
    //   超星学习通      .answer-item / .option-item
    //   职教云/智慧职教  .choice-item / .radio-item
    //   Element UI     .el-radio / .el-checkbox        （部分版本行内无 input）
    //   Ant Design     .ant-radio-wrapper / .ant-checkbox-wrapper
    //
    // 判据刻意保守，避免把题干、容器误当成选项：
    //   · 必须**成组**出现（同类名 ≥2 个），单个的多半是装饰
    //   · 排除标题类（*title / *head / *label-）和题号容器
    //   · 文字不能太长（≤160），太长的多半是整块题区
    // ------------------------------------------------------------------
    // 注意：JS 正则**不能换行写**（和 Python 的 re.X 不一样），所以这里是一整行。
    //
    // ★ 补 `opt` / `optionItem` 等：**学习通（超星）章节测验的选项就是
    //   `<div class="opt">` 加一个圆形字母圈，没有 input、没有 role、
    //   没有 aria-checked**，全靠 JS 加 `.sel` 类表示选中。
    //   实测（自测页 tests/site/chaoxing_quiz.html）：
    //     补之前 → 识别到 0 道题；补之后 → 正常认出。
    const OPTION_CLS = /(^|[\s_-])(opt|opts|option|options|option-item|optionItem|option_item|answer-item|answerItem|choice-item|choiceItem|topic-item|radio-item|checkbox-item|select-item|original-option|each-option|el-radio|el-checkbox|el-radio__label|ant-radio-wrapper|ant-checkbox-wrapper|van-radio|van-checkbox|exam-item|subject-item|ques-item|question-item|choice|answer)([\s_-]|$)/i;
    // 排除项：题干、标题、工具条、容器、以及"全选/清空"这类**操作按钮**
    // （它们文字短、又常和选项同处一块，最容易混进来）。
    const NOT_OPTION_CLS = /(^|[\s_-])(title|head|header|tip|hint|desc|label-|toolbar|footer|nav|menu|wrap|container|answer-title|option-title|all|clear|reset|btn|button|submit|checkbox-all)([\s_-]|$)/i;
    try {
      const byClass = {};
      [].slice.call(dshQueryAll('div,li,span,a,p,label')).forEach(
        function (e) {
          const c = (typeof e.className === 'string') ? e.className : '';
          if (!c) return;
          if (!OPTION_CLS.test(c)) return;
          if (NOT_OPTION_CLS.test(c)) return;
          // 已经有原生控件 / role / aria 的，前面收过了
          if (e.querySelector('input[type=radio],input[type=checkbox]')) return;
          const t = textOf(e);
          if (!t || t.length > 160) return;
          const r = e.getBoundingClientRect();
          if (r.width < 24 || r.height < 12) return;
          // 用类名做"族"的键：**必须剥掉状态类**，否则"已选中的那一个"会因为
          // 多了个状态类而被单独分到另一组、长度不足 2 被丢弃 ——
          // 实测学习通：`.opt` 与 `.opt.sel` 被拆成两组，回读时已选项直接消失。
          // 这里要与 dshChecked 的 SEL 词表保持一致（都认 sel 家族）。
          const key = c.split(/\s+/)
            .filter(function (x) {
              return x && !/^(is-|active|checked|selected|select|sel|seled|cur|current|on$|disabled|hover)/i.test(x);
            })
            .sort()                                  // 排序，消除书写顺序差异
            .join(' ');
          if (!byClass[key]) byClass[key] = [];
          byClass[key].push(e);
        });
      Object.keys(byClass).forEach(function (k) {
        const arr = byClass[k];
        if (arr.length < 2) return;                 // 必须成组
        arr.forEach(function (e) {
          push(e, /checkbox|多选/.test(k) ? 'checkbox' : 'radio');
        });
      });
    } catch (err) { /* 忽略：这一层只是补充，失败不影响前面 */ }
    return out;
  }

  // 找自定义选项所属的"题块"。
  //
  // 不能简单取"第一个包含 ≥2 个选项的祖先"——那种祖先往往就是**选项容器本身**
  // （<div class="opts"> 里只有选项），用它算出的题干会变成选项列表。
  // 真正的题干在更上一层。所以要往上走到"除了选项还有别的文字"的那一层。
  function groupRoot(el, allEls) {
    let n = el.parentElement, hops = 0, fallback = null;
    while (n && n !== document.body && hops < 8) {
      // ⚠ 必须用"包含"而不是"直接子元素"来判断。
      // 曾经写成 n.children 过滤，结果 skip 掉了真正含题干的祖先：
      //   #opts  直接子元素 = 4 个选项（但没有题干）
      //   .main  直接子元素 = 0 个选项（选项在孙辈），题干却在这里
      const contained = [].slice.call(n.querySelectorAll('*')).filter(function (c) {
        return allEls.indexOf(c) >= 0;
      });
      if (contained.length >= 2) {
        if (!fallback) fallback = n;
        // 这一层的文字去掉所有选项文字后，还剩多少？剩得多说明题干在这里
        let rest = textOf(n);
        contained.forEach(function (c) { rest = rest.replace(textOf(c), ' '); });
        rest = rest.replace(/\s+/g, ' ').trim();
        // 去掉"单选题/（4分）/答题卡/进度"这类标签后再判断
        const cleaned = rest.replace(/[（(]?\s*\d+\s*分\s*[)）]?/g, ' ')
                              .replace(/单选题|多选题|判断题|填空题|答题卡|进度|已用时|剩余时间/g, ' ')
                              .replace(/[\s:：·、,，。.\-—|]/g, '');
        if (cleaned.length >= 6) return n;
      }
      n = n.parentElement; hops++;
    }
    return fallback || el.parentElement || document.body;
  }

  // 自定义选项的可读文字：取自身文字，去掉太长的（可能是整块题区）
  function customText(el) {
    let t = textOf(el);
    if (t.length > 200) t = '';                 // 多半抓到了容器
    if (!t) {
      const al = el.getAttribute('aria-label');
      if (al) t = al.trim();
    }
    return t;
  }

  // 判定"这个自定义选项当前是否被选中"。
  //
  // ⚠ 实测踩坑（智慧树）：label 自己的 class **永远不变**，
  //   一直是 "flex items-center gap-4 user-select group"；
  //   选中时改的是**内部那个圆圈 div** 的类：
  //       未选: ... bg-white text-[#86909c] border-[#e5e6eb] ...
  //       选中: 变成蓝色（bg-[#<色号>]）
  //   所以只看 label 自己永远读不到选中状态 —— 必须连**后代**一起看。
  //   这也是"点了但其实选上了、却被判成没选上"的根源。
  function customSelected(e) {
    // 统一走 dshIsSelected（本文件顶部那份唯一实现）。
    // 这里以前自带一份正则，和落笔回读用的那份不一致 ——
    // 改了一处忘另一处，实测就因此把"已选中"判成"未选中"。
    return dshIsSelected(e);
  }

  // ------------------------------------------------------------------
  // 智慧树（examloop.zhihuishu.com）这类系统：**选项是 <label>，
  // 里面既没有 input，也没有 role/aria-checked，类名也不含 option/choice。**
  // 实测数据：
  //     input=0  radio=0  role=radio=0  aria-checked=0
  //     label=4  [class*=option]=0  [class*=choice]=0  [class*=radio]=0
  // 全靠 JS 给 label 绑 click 事件。
  // 之前所有识别策略都落空 → 扫到 0 道题 → 只翻页不落笔。
  // ------------------------------------------------------------------
  function looksLikeOptionLabel(lb) {
    if (!lb || lb.tagName !== 'LABEL') return false;
    if (lb.querySelector('input,textarea,select')) return false;  // 有原生控件走原路
    const r = lb.getBoundingClientRect();
    if (r.width < 40 || r.height < 14) return false;
    if (r.width > 1200 || r.height > 200) return false;          // 太大是容器
    const t = textOf(lb);
    if (t.length < 1 || t.length > 120) return false;
    return true;
  }
  function optionLabels() {
    return [].slice.call(dshQueryAll('label')).filter(looksLikeOptionLabel);
  }

  // ---------- 点选型：按 name 分组 ----------
  // ★ 候选题目先攒在这里，**去重之后再统一编号 + 打标记**（见文件末尾）。
  //   为什么不能边扫边打标记：qid 是去重后的编号，而标记是 DOM 上的持久属性。
  //   先按旧编号打、再去重重编号，就会出现"新 qid 指到一个已被丢弃的残片元素"，
  //   落笔（_mark_click_targets）与回读（_is_checked）都会照着错元素操作。
  let cand = [];
  const groups = {};
  const fillers = [];
  all.forEach(function (el) {
    const type = (el.getAttribute('type') || (el.tagName === 'TEXTAREA' ? 'textarea'
                 : el.tagName === 'SELECT' ? 'select' : 'text')).toLowerCase();
    if (!vis(el)) return;
    if (el.disabled || el.readOnly) return;
    if (el.getAttribute('contenteditable') === 'true') { fillers.push({el: el, kind: 'text'}); return; }
    if (type === 'radio' || type === 'checkbox') {
      const key = (el.name || '') || ('__nolegend_' + (el.closest('form') ? 'f' : 'p'));
      if (!groups[key]) groups[key] = {kind: type, name: el.name || '', els: []};
      groups[key].els.push(el);
    } else if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'file') {
      return;
    } else {
      fillers.push({el: el, kind: type});
    }
  });

  Object.keys(groups).forEach(function (k) {
    const g = groups[k];
    const first = g.els[0];
    const optTexts = [];
    const options = g.els.map(function (el, i) {
      const t = labelOf(el);
      optTexts.push(t);
      // 标记统一等去重之后再打（见文件末尾"落地"段）
      // 从选项文字里抠出"屏幕上显示的选项字母"（"A 专家系统" / "A. xxx" / "(A) xxx"）。
      // 上层要拿它核对：模型选的是字母 A，而我们把 DOM 里第 i 个当成了 A ——
      // 一旦页面 DOM 顺序与视觉顺序不一致，这两个就对不上，必须能发现。
      let key = '';
      const m = /^\s*[（(]?\s*([A-Za-z])\s*[)）.、:：]?\s+/.exec(t || '');
      if (m) key = m[1].toUpperCase();
      else if (/^[A-Za-z]$/.test((t || '').trim())) key = t.trim().toUpperCase();
      return {
        id: i,
        text: t || ('(选项' + i + ')'),
        key: key,
        checked: !!el.checked,
        box: box(el),
        in_view: inView(el),
        // 记录这个控件本体是否"视觉隐藏"（尺寸被压成 1x1 / opacity 0 等）。
        // 落笔时据此**直接走强制点击**，不要先试 check() —— Playwright 的
        // check() 会为不可见元素等满超时才失败，实测每页白等 6 秒。
        hidden: (function () {
          const rr = el.getBoundingClientRect();
          if (rr.width >= 4 && rr.height >= 4) {
            const ss = window.getComputedStyle(el);
            return parseFloat(ss.opacity || '1') <= 0.05;
          }
          return true;
        })(),
        value: el.value
      };
    });
    // 带标号的选项文本（"A. xxx"）：真实题目里选项多带标号，定位题干最可靠
    const lettered = options.map(function (o, i) {
      const L = 'ABCDEFGHIJ'[i] || String(i);
      return L + '. ' + o.text;
    });
    // 题块必须在拿到 optTexts 之后才能定 —— questionRoot 要用它来判断
    // "这个祖先里能不能解析出题干"
    const root = questionRoot(first, optTexts, lettered);
    let stem = stemFrom(root, optTexts, lettered);
    if (stem.length < 4) {
      // 实在解析不出题干 → 退回容器全文，宁可带点噪声也别交半句话
      const full = textOf(root);
      stem = full.length > 1200 ? full.slice(0, 1200) + '…' : full;
    }
    if (!stem) stem = '(题干未识别，请根据选项判断)';
    if (stem.length > 1200) stem = stem.slice(0, 1200) + '…';
    cand.push({
      kind: g.kind, name: g.name, stem: stem, options: options,
      box: box(root), in_view: inView(first), count: options.length,
      // ★ 元素句柄只在 JS 局部用，**绝不放进 out**（DOM 节点无法序列化）
      els: g.els, custom: false
    });
  });

  // ---------- 自定义选项组件（没有原生 input 的页面）----------
  // 只在"原生路径**一道选择题都没扫出来**"时才启用：避免和原生题重复计数。
  //
  // ⚠ 这里的判据原来写的是 `nativeCount === 0`（页面里一个 input 都没有），
  //   这是个**很隐蔽的过严条件**，实测在学习通作业页翻车：
  //     · 那一页有 6 个与题目无关的原生输入框（被当成"填空题"）
  //     · 于是 nativeCount = 6 ≠ 0 → 这条自定义路径**被整个跳过**
  //     · 而它真正的选项是自定义组件（不是原生 radio）→ 结果"识别到 0 道选择题"
  //   正确的判据是"原生**选择题**路径有没有产出"，而不是"页面有没有输入框"。
  //   只要原生一道题都没扫出来，就该给自定义路径一次机会。
  if (cand.length === 0) {
    // ---- A + B 合并成候选池 ----
    const cAll = customChoiceEls().filter(function (x) { return vis(x.el); });
    const cEls = cAll.map(function (x) { return x.el; });
    // B：把 label 也加进候选池
    const labAll = optionLabels();
    const labEls = labAll.slice();
    const pool = cEls.concat(labEls);

    const used = [];
    pool.forEach(function (item) {
      // 统一成 {el, kind}
      const obj = (item.el !== undefined) ? item : {el: item, kind: 'radio'};
      if (used.indexOf(obj.el) >= 0) return;

      // 找同一题的其他选项：优先"同一个父容器下的兄弟"
      const parent = obj.el.parentElement;
      if (!parent) return;
      const sibs = [].slice.call(parent.children).filter(function (c) {
        return c !== obj.el && pool.indexOf(c) >= 0 && used.indexOf(c) < 0;
      });
      const group = [{el: obj.el, kind: obj.kind}].concat(
        sibs.map(function (s) { return {el: s, kind: obj.kind}; })
      );
      if (group.length < 2) return;          // 至少两个选项才算题
      group.forEach(function (g) { used.push(g.el); });

      const optTexts = [];
      const options = group.map(function (g, i) {
        const t = customText(g.el);
        optTexts.push(t);
        // 标记统一等去重之后再打（见文件末尾"落地"段）
        let key = '';
        const m2 = /^\s*[（(]?\s*([A-Za-z])\s*[)）.、:：]?\s*/.exec(t || '');
        if (m2) key = m2[1].toUpperCase();
        return {
          id: i, text: t || ('(选项' + i + ')'), key: key,
          checked: customSelected(g.el),
          box: box(g.el), in_view: inView(g.el), hidden: false, value: '',
          custom: true
        };
      });

      const root = groupRoot(obj.el, pool);

      // 单选还是多选？**优先看题干文字**，不要只靠类名猜。
      // 实测：`<div class="topic-item">` 单选用、多选也用，类名分不出来；
      // 但题干里一定写着「多选」「不定项」之类。
      // （这一步只改 kind，不改任何其它逻辑 —— 认错类型的后果是
      //   多选只点一个选项，或者单选被当成多选清掉。）
      const stemForKind = textOf(root).replace(/\s+/g, ' ');
      if (/多\s*选|不定项|全部选|选出所有|可多选|至少选|多选型/.test(stemForKind)
          && !/单\s*选/.test(stemForKind)) {
        group.forEach(function (g) { g.kind = 'checkbox'; });
      } else if (/单\s*选/.test(stemForKind)) {
        group.forEach(function (g) { g.kind = 'radio'; });
      }

      // 从某个容器里解析题干。
      //
      // 原理：把容器全文里"第一个选项文字出现的位置"之前的部分当题干。
      //       题干在第一选项之前，所以它一定落在切点左边。
      function stemOfContainer(container) {
        const full = textOf(container).replace(/\s+/g, ' ');
        const parts = optTexts.map(function (t) {
          return (t || '').replace(/\s+/g, ' ').trim();
        }).filter(function (s) { return s.length >= 1; });
        let cut = full.length;
        if (parts.length >= 2) {
          const i0 = full.indexOf(parts[0]);
          // ⚠ 必须是 i0 > 0，不能是 >= 0：
          //   i0 === 0 意味着"这个容器从第一个选项开始"，即容器里**根本没有题干**
          //   （题干在更外层）。此时若照旧 cut=0，stem 会是空串，
          //   再被下面的兜底换成"容器全文=选项拼接" —— 模型就会收到
          //   "题干其实是那四个选项"，只能回"选项内容缺失/无法判断"。
          //   实测：学习通作业页题干取不到的那几题就是这么退化的。
          if (i0 > 0 && i0 <= 400) {
            const i1 = full.indexOf(parts[1], i0 + parts[0].length);
            if (i1 > i0 && i1 <= i0 + parts[0].length + parts[1].length + 120) cut = i0;
          }
        }
        let stem = full.slice(0, cut);
        stem = stem.replace(/[（(]?\s*\d+\s*分\s*[)）]?/g, ' ')
                   .replace(/^\s*\d+\s*[、.．]\s*/, ' ')
                   .replace(/[\s,，、;；:：\-—|]+$/, '').trim();
        return stem;
      }
      // 兜底：题干解析不出来时，往上找一层"含有真正题干"的容器再试。
      //
      // 为什么需要：选项容器（如学习通的 .stem_answer.qtDetail）里**可能只有选项**，
      //   题干在它的父级（.questionLi）里，或者干脆没有被渲染成文字。
      //   不往上找就会退化成"题干=选项拼接"，把模型带偏。
      const root2 = (function () {
        let stem = stemOfContainer(root);
        const p0 = (optTexts[0] || '').replace(/\s+/g, ' ').trim();
        // 判据：解析结果为空，或者**以第一个选项开头**（说明这个容器里没题干）
        const bad = (s) => !s || s.length < 4 || (p0 && s.indexOf(p0) === 0);
        if (bad(stem)) {
          let up = root.parentElement, hops = 0;
          while (up && up !== document.body && hops < 3) {
            const s = stemOfContainer(up);
            if (!bad(s)) { stem = s; break; }
            up = up.parentElement; hops++;
          }
        }
        // 实在找不到题干就**如实说**，不要拿选项拼接冒充题干。
        // 选项本来就会单独发给模型，当题干再发一遍只会互相干扰。
        if (bad(stem)) return '(题干未识别，请根据选项内容判断)';
        return stem.slice(0, 1200);
      })();

      cand.push({
        // ⚠ 用 group[0].kind（上面按题干文字修正过的），**不是** obj.kind。
        //   踩过的坑：只改了 group 里的 kind，输出却仍用最初的猜测值，
        //   于是"多选识别"看着生效了、实际上报的还全是单选。
        kind: group[0].kind, name: '', stem: root2, options: options,
        box: box(root), in_view: inView(obj.el), count: options.length,
        els: group.map(function (gg) { return gg.el; }), custom: true
      });
    });
  }

  // ---------- 填空型 ----------
  let lastFillerStem = null;      // 用于检测"多道填空题拿到同一段题干"的退化情况

  // ⚠ 「一眼就不是作答框」的排除表。
  //
  //  现场（真实智慧树课程页的采集）：章节目录的**搜索框**被当成填空题，
  //  题干取到了整份章节列表 —— 在课程页点「开始答题」就会往搜索框里填答案。
  //  原来只有 `!vis || disabled || readOnly` 一道闸门，而搜索框三条全不占。
  //
  //  ⚠ 验证码**必须**排除：那是平台的人机校验，
  //    自动填/自动解等于绕过反爬，与"不绕过人脸识别与活体检测"是同一条铁律。
  const NOT_ANSWER_WORD = /(搜索|查询|筛选|检索|search|filter|query|验证码|校验码|captcha|verify|密码|password|passwd|账号|账户|用户名|username|登录|login|注册|register|signin|signup)/i;
  const NOT_ANSWER_TYPE = ['search', 'password', 'email', 'url', 'tel',
                           'date', 'month', 'week', 'time', 'datetime-local',
                           'range', 'color', 'file', 'submit', 'button',
                           'reset', 'image', 'hidden'];
  function notAnswerField(el) {
    if (el.tagName === 'SELECT') return false;   // 下拉框是正经题型
    if (el.getAttribute('contenteditable') === 'true') return false;  // 富文本作答区
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (NOT_ANSWER_TYPE.indexOf(t) >= 0) return true;
    const hay = [el.getAttribute('placeholder'), el.getAttribute('aria-label'),
                 el.getAttribute('title'), el.getAttribute('name'),
                 el.id, (typeof el.className === 'string' ? el.className : '')
                ].join(' ');
    if (NOT_ANSWER_WORD.test(hay)) return true;
    // ★ 自己身上没线索时，看**周围那块**的文字。
    //
    //   为什么必须补：真实智慧树的验证码框是 `<input class="zc_input32">`，
    //   placeholder 是空的、类名也看不出含义 —— **属性词表认不出它**。
    //   它当时没被选中只是因为 `display:none`，**那是碰巧不是设计**。
    //   而它周围那块写着"请输入验证码： 看不清 确定"。
    //
    //   ⚠ 只上溯 3 层，且把整块文字**截断到 120 字**再匹配 ——
    //     再往上就会命中整页文字，于是什么都排除掉了。
    let up = el.parentElement, hops = 0;
    while (up && up !== document.body && hops < 3) {
      const t = (up.innerText || up.textContent || '').slice(0, 120);
      if (NOT_ANSWER_WORD.test(t)) return true;
      up = up.parentElement; hops++;
    }
    return false;
  }

  fillers.forEach(function (f) {
    const el = f.el;
    if (!vis(el) || el.disabled || el.readOnly) return;
    if (notAnswerField(el)) return;
    // 填空题没有"选项文字"可用，用输入框自己的可读标签当锚点。
    // noOptions=true → questionRoot 走 lastControlRoot 那套判据，
    // 避免退到 body 导致题干变成整页第一题。
    const near = fieldLabel(el);
    const root = questionRoot(el, [], [], true);
    let stem = textOf(root);
    // 去掉尾部粘连的输入框标签（placeholder / label 内容），它们会以
    // "…子命令。 答案：" 这种形式糊在题干后面，干扰模型理解空格在哪。
    if (near) {
      const n = near.replace(/\s+/g, ' ').trim();
      if (n.length >= 2 && n.length < 120) {
        const flat = stem.replace(/\s+/g, ' ');
        const idx = flat.lastIndexOf(n);
        if (idx > 0) stem = flat.slice(0, idx);
      }
    }
    stem = stem.replace(/[\s,，、;；:：\-—|]+$/, '').trim();
    // 页面上"答案：/答："这类前缀标签会糊在题干尾部，去掉它
    stem = stem.replace(/[\s:：]*\s*(答案|作答|填写|答)\s*[:：]?\s*$/, '').trim();
    // 兜底自检：如果拿到的题干和别的填空题一模一样，说明又退到公共祖先了。
    // 这时宁可用"标签 + 附近文字"，也不要给模型一段张冠李戴的题干。
    if (!stem || stem === lastFillerStem) {
      const nearTxt = (near || '').trim();
      stem = nearTxt ? '(填空题，输入框提示：' + nearTxt + ')' : '(填空题，题干未识别)';
    }
    lastFillerStem = stem;
    if (stem.length > 600) stem = stem.slice(0, 600) + '…';
    // ★ 简答/论述：作答形态与"填空"完全不同（要写几段话），必须单列一种题型。
    //   判据刻意宽松：多行作答区 + 题块文字里出现"简答/论述/问答/请简述…"。
    //   漏判的代价只是退化成填空（也就是现在的行为），不会更糟。
    const rootTxt = textOf(root).replace(/\s+/g, ' ');
    const isRich = (el.getAttribute('contenteditable') === 'true'
                    || el.tagName === 'TEXTAREA');
    const isEssay = isRich && /简答|论述|问答|名词解释|请简述|请说明|试述|谈一谈|结合实际|不少于\s*\d+\s*字/.test(rootTxt);
    const qno = (function () {          // 题号：日志与缓存都用得上
      const m = /(?:^|\s)(\d{1,3})\s*[.、．]/.exec(rootTxt);
      return m ? m[1] : '';
    })();
    const item = {
      fid: out.inputs.length,
      kind: isEssay ? 'essay'
            : el.tagName === 'SELECT' ? 'select'
            : (el.tagName === 'TEXTAREA' ? 'textarea'
            : (el.getAttribute('contenteditable') === 'true' ? 'contenteditable' : 'text')),
      stem: stem,
      label: near,
      qno: qno,
      essay: isEssay,
      value: (el.value !== undefined ? String(el.value) : ''),
      box: box(el),
      in_view: inView(el),
      multiline: el.tagName === 'TEXTAREA'
    };
    if (el.tagName === 'SELECT') {
      item.options = [].slice.call(el.options).map(function (o, i) {
        return {id: i, text: (o.textContent || '').trim(), value: o.value, selected: !!o.selected};
      });
    }
    el.setAttribute('data-dsh-fid', String(item.fid));
    out.inputs.push(item);
  });

  // ---------- 图片（题干配图的可能性大，交给上层裁切后送视觉模型）----------
  // 注意：这里不按"是否在首屏"过滤。懒加载的图在滚动前根本没有尺寸，
  // 而首屏外的图（比如第 5 题的柱状图）恰恰是最需要看的。既然
  // Document.images 在长页面上也就几十个，多留一些、让上层按需裁切更划算。
  [].slice.call(document.images).forEach(function (im) {
    if (!vis(im)) return;
    const r = im.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) return;      // 过滤图标
    const idx = out.images.length;
    // 打标记：上层可以用 Playwright 的 locator.screenshot() 直接截这个元素，
    // 这样即使它在首屏之外也能拿到完整图片（用视口截图 + 文档坐标裁剪会错位）。
    im.setAttribute('data-dsh-img', String(idx));
    out.images.push({
      src: (im.currentSrc || im.src || '').slice(0, 300),
      alt: (im.alt || '').slice(0, 200),
      box: box(im),
      in_view: inView(im),
      idx: idx
    });
  });

  // ---------- 按钮 ----------
  [].slice.call(dshQueryAll('button,input[type=submit],input[type=button],a[role=button],.btn')).forEach(function (b) {
    if (!vis(b)) return;
    const t = textOf(b) || b.value || '';
    if (!t && !b.getAttribute('aria-label')) return;
    out.buttons.push({text: t.slice(0, 60), box: box(b), in_view: inView(b),
                      disabled: !!b.disabled, tag: b.tagName.toLowerCase()});
  });

  [].slice.call(dshQueryAll('h1,h2,h3')).forEach(function (h) {
    if (!vis(h)) return;
    const t = textOf(h);
    if (t) out.headings.push(t.slice(0, 120));
  });

  // ---------- 去重 ----------
  //
  // ⚠ 为什么需要：真实作业页会把同一道题渲染**不止一份**（隐藏模板、预渲染副本、
  //   答题卡缩略、翻页缓存……），扫描会把同一道题收进来好几次。实测用户那份作业
  //   扫出 69 道，实际题量远小于此。直接后果有两个：
  //     ① 模型调用按倍数增加（用户反馈"答题前要等很久"）；
  //     ② 后面那些副本点不准，会把已经选好的答案又点一遍 → **取消作答**。
  //
  // ⚠ 判据不能用原始文字（第一版就是这么写的，实测漏掉一大半）：
  //   同一道题的两份渲染，一份选项是 "A Agent 只能调用联网…"（字母和文字在同一个
  //   元素里），另一份被拆成 "A" + "Agent 只能调用联网…"两个元素 → 原文不同 →
  //   认不出是同一道题。日志里 q0（完整）和 q17（拆开）就是这样。
  //
  // ⚠⚠ 第二版（2026-10-16 17:10 那版）又踩了一个坑，别再犯：
  //   它用 `s.length >= 3` 当"是不是有效选项内容"的阈值。可是**判断题的选项内容
  //   就是 '对'/'错'（1 个字）**，被阈值一并滤掉之后，残片 `['对','A']` 的
  //   有效内容变成空数组 → 残片判定整条失效 → 判断题残片 100% 存活
  //   （实测：17:07 那次 33 道题里 q17–q26 全是这种，仍然连续 10 道点不中）。
  //   正确做法：**只把"字母圈"排除掉**，长度不作为内容的判据。
  //   但"同题合并的签名"仍只认 ≥3 字的内容 —— 否则整页判断题（对/错）会算出
  //   同一个签名被合并成一道题（回归脚本场景 C 钉的就是这个）。
  (function () {
    // ① 归一化：剥掉"字母 + 分隔符"前缀，再去空白。
    //    ⚠ 顺序不能反：先"去空白再剥首字母"会把 'Agent' 的 A 吃掉（Agent → gent），
    //      于是"完整版"和"拆分版"归一化后差一个字母，去重整轮失效。
    function normOpt(t) {
      let s = String(t || '').trim();
      s = s.replace(/^[（(]\s*[A-Ja-j]\s*[)）]\s*/, '');        // (A) / （A）
      s = s.replace(/^[A-Ja-j]\s*[.、:：)）]\s*/, '');          // A. / A、/ A: / A)
      s = s.replace(/^[A-Ja-j]\s+/, '');                        // A + 空白
      return s.replace(/\s+/g, '').slice(0, 60);
    }
    // ② 只由一个选项字母构成的"内容" = 字母圈，永远不是选项文字。
    function isLetterOnly(s) {
      return /^[（(]?[A-Ja-j][)）.、:：]?$/.test(String(s || ''));
    }
    // ③ 有效选项**内容**：
    //      ['A', 'Agent 只能…'] → ['Agent只能…']
    //      ['对', 'A']          → ['对']            ← 旧版这里是 []
    //      ['A 对', 'B 错']     → ['对', '错']
    function partsContent(q) {
      return (q.options || []).map(function (o) { return normOpt(o && o.text); })
        .filter(function (s) { return s.length >= 1 && !isLetterOnly(s); });
    }
    // ④ 参与"同题合并"的部分：仍然只认 ≥3 字。
    //    判断题的 对/错/正确/错误（1~2 字）不参与签名 → 不会被合并成一道题。
    function sigParts(parts) {
      return parts.filter(function (s) { return s.length >= 3; });
    }
    // ⑤ 质量分：字母碎片重罚；选项数越少越好（拆分会把 4 个撑成 8 个）。
    function quality(q) {
      const opts = q.options || [];
      let bare = 0;
      opts.forEach(function (o) {
        const t = String((o && o.text) || '').replace(/\s+/g, '').trim();
        if (/^[（(]?[A-Ja-j][)）.、:：]?$/.test(t)) bare++;
      });
      return -bare * 100 - opts.length;
    }

    const seen = {};          // 签名 → 已保留的那道题
    const kept = [];
    let frag = 0;             // 被判为残片而丢弃的题目数

    // ⑥ ★ 两遍处理：先按"有效选项内容个数"降序，**选项多的先判残片**。
    //    旧版按池内顺序处理，等于假设"完整题永远排在残片前面" —— 这个假设
    //    当时只是因为 customChoiceEls() 把 [role=radio] 排在了 [aria-checked]/
    //    类名块之前才成立，没有任何保护。改成两遍之后与顺序无关。
    const order = cand.map(function (q, i) { return i; })
      .sort(function (a, b) {
        const da = partsContent(cand[a]).length;
        const db = partsContent(cand[b]).length;
        return (db - da) || (a - b);      // 同数量时保持 DOM 顺序（稳定）
      });

    order.forEach(function (idx) {
      const q = cand[idx];
      const parts = partsContent(q);
      // ---- 残片：有效内容**全是**某道已保留题的选项，且本组更少 ----
      //      安全性：一道正常的选择题不会是另一道题的选项子集。
      if (parts.length) {
        for (let ki = 0; ki < kept.length; ki++) {
          const other = kept[ki];
          if (!other.__parts || other.__parts.length <= parts.length) continue;
          let allIn = true;
          for (let pi = 0; pi < parts.length; pi++) {
            if (other.__parts.indexOf(parts[pi]) < 0) { allIn = false; break; }
          }
          if (allIn) { frag++; return; }
        }
      }
      // ---- 同题合并（真·重复渲染）----
      const sp = sigParts(parts);
      if (sp.length >= 2) {
        const sig = sp.slice().sort().join('\u0001');
        if (seen[sig] !== undefined) {
          const old = seen[sig];
          if (quality(q) > quality(old)) {          // 谁更完整留谁
            q.__sig = sig; q.__parts = parts; q.__i = idx;
            kept[kept.indexOf(old)] = q;
            seen[sig] = q;
          }
          return;                                    // 其余重复渲染丢弃
        }
        q.__sig = sig;
        seen[sig] = q;
      }
      q.__parts = parts;
      q.__i = idx;
      kept.push(q);
    });

    // ⑦ ★ 恢复 DOM 顺序：两遍处理打乱了顺序，而 kept 的顺序**就是 qid**
    //    （上层用 q0/q1… 引用题目）。不恢复的话题号会跟页面顺序对不上。
    kept.sort(function (a, b) { return a.__i - b.__i; });

    if (frag) out.deduped_frag = frag;
    // 这里**不再重新编号**：编号与打标记统一在下面的"落地"段做，
    // 保证 qid 与 DOM 标记永远一致。
    if (kept.length !== cand.length) {
      out.deduped = cand.length - kept.length;
    }
    cand = kept;
  })();

  // ---------- 落地：编号 + 打标记（★ 必须在去重之后）----------
  //
  // ⚠ 为什么不能边扫边打标记：qid 是**去重之后**的编号，而标记是 DOM 上的持久属性。
  //   先按旧编号打、再去重重编号，就会出现"新 qid 指到一个已被丢弃的残片元素"，
  //   落笔（_mark_click_targets）和回读（_is_checked）都会照着错元素操作。
  //   统一挪到这里之后，"标记与 qid 永远一致"，也就不必再依赖
  //   dshCustomGroup() 的"按文字找回"兜底了（那只是补救，不是正路）。
  //
  // ⚠ `c.els` 只在这个局部循环里用，绝不写进 out.questions ——
  //   DOM 节点无法被 Playwright 序列化回 Python。
  out.questions = cand.map(function (c, i) {
    (c.els || []).forEach(function (el, oi) {
      if (c.custom) {
        el.setAttribute('data-dsh-cqid', String(i));
        el.setAttribute('data-dsh-coid', String(oi));
      } else {
        el.setAttribute('data-dsh-qid', String(i));
        el.setAttribute('data-dsh-oid', String(oi));
      }
    });
    return {
      qid: i, kind: c.kind, name: c.name || '', stem: c.stem,
      options: c.options, box: c.box, in_view: c.in_view,
      count: (c.options || []).length
    };
  });

  return out;
}
"""

# 生成真正使用的 SCAN_JS：把词表占位符换成 _SEL_RE_SRC
SCAN_JS = _SCAN_JS_RAW.replace("__DSH_SEL_RE__", _SEL_RE_SRC)

# 可输入控件选择器 —— **必须与 SCAN_JS 里的 SEL 同源**。
# 用途：标记失效时按"帧内第 N 个"定位（fill 的快检兜底）。
# ⚠ 两处一旦跑偏就会出现"扫描说 3 个、按这个选择器只找到 2 个"，
#   兜底会取到错的元素 —— 那正是最危险的"写错格子"。
_FIELD_SEL = ('input[type=text],input:not([type]),textarea,select,'
              '[contenteditable=true]')
del _SCAN_JS_RAW


def _js_with_sel(src: str) -> str:
    """把 JS 片段里的词表占位符换成 _SEL_RE_SRC。

    这样「选中判定」的词表在工程里只有一份 —— SCAN_JS 和 _FIND_JS
    各嵌这一段，改词表只需改上面那一处，物理上不会再出现
    "改了一份忘了另一份"（那正是学习通 `.sel` 被判成未选中的原因）。
    """
    return src.replace("__DSH_SEL_RE__", _SEL_RE_SRC)


# ---------------------------------------------------------------------------
@dataclass
class Question:
    qid: int
    kind: Literal["radio", "checkbox"]
    stem: str
    options: list[dict]
    name: str = ""
    in_view: bool = True
    box: dict = field(default_factory=dict)
    # ⚠ 这道题在哪个框架里（None = 主文档）。
    #   审计 C-25：扫描会把 iframe 里的题**合并进同一个 state**，
    #   但落笔时全用 `self.page.evaluate / self.page.locator` ——
    #   那**只在主文档生效**，不穿透 iframe。
    #   后果：iframe 里的题"能扫到、永远点不中"，
    #   而且选完后回读也读不到 → 报"未生效" → 记进 attempts → 
    #   表现是"翻页正常、一题都没落笔"。
    frame: Any = None
    # ★ 在**它所在 frame** 里是第几个控件（0 起）。
    #   标记失效时靠它做位置兜底（见 fill 的快检 + nth）。
    in_frame_idx: int = -1

    def render(self) -> str:
        letters = "ABCDEFGHIJ"
        lines = [f"[q{self.qid}] ({'单选' if self.kind == 'radio' else '多选'}) {self.stem}"]
        for i, o in enumerate(self.options):
            mark = " ←已选" if o.get("checked") else ""
            lines.append(f"    {letters[i] if i < len(letters) else i}. {o['text']}{mark}")
        return "\n".join(lines)

    def letter(self, idx: int) -> str:
        letters = "ABCDEFGHIJ"
        return letters[idx] if 0 <= idx < len(letters) else str(idx)


@dataclass
class Field:
    fid: int
    kind: str
    stem: str
    label: str = ""
    value: str = ""
    options: list[dict] = field(default_factory=list)
    in_view: bool = True
    multiline: bool = False
    frame: Any = None        # 同 Question.frame（iframe 里的填空也要能填）
    # ★ 简答/论述（T4）：作答形态与填空完全不同，必须单列
    qno: str = ""            # 题号（"18" 这种），日志与缓存都用得上
    essay: bool = False      # 是不是简答/论述（要写几段话，而不是一个词）
    # ★ 在**它所在 frame** 里是第几个控件（0 起）。
    #   标记失效时靠它做位置兜底（见 fill 的 count 快检 + nth）。
    in_frame_idx: int = -1

    def render(self) -> str:
        tag = "简答/论述" if (self.kind == "essay" or self.essay) else "填空"
        head = f"[f{self.fid}] ({tag})"
        if self.qno:
            head += f" 第{self.qno}题"
        s = f"{head} {self.stem or self.label}"
        if self.kind == "essay" or self.essay:
            s += "　← 请给出 80~300 字的完整作答（按要点分段）"
        else:
            s += "　← 填空题：只输出这一空要填的词/短语（≤15 字），不要解释"
            _d_tot = int(getattr(self, "_dsh_dup_total", 0) or 0)
            _d_idx = int(getattr(self, "_dsh_dup_index", 0) or 0)
            if _d_tot > 1:
                s += (f"；本题共 {_d_tot} 个空，这是第 {_d_idx + 1} 空，"
                      f"只输出这一个空的答案，不要用分号把其他空拼进来")
        if self.label and self.label not in s:
            s += f" | 提示: {self.label}"
        if self.kind == "select":
            opts = " / ".join(o["text"] for o in self.options)
            s += f" | 下拉选项: {opts}"
        if self.value:
            s += f" | 当前值: {self.value!r}"
        return s


@dataclass
class PageState:
    url: str = ""
    title: str = ""
    questions: list[Question] = field(default_factory=list)
    fields: list[Field] = field(default_factory=list)
    images: list[dict] = field(default_factory=list)
    buttons: list[dict] = field(default_factory=list)
    headings: list[str] = field(default_factory=list)
    viewport: dict = field(default_factory=dict)
    scroll_y: int = 0
    scroll_h: int = 0
    # 扫描去重统计（T3：让用户一眼看出"这一页的选项结构是不是被识别错了"）
    deduped: int = 0          # 被合并掉的重复渲染数
    deduped_frag: int = 0     # 被判为残片丢弃的题数（选项被拆开的假题）

    @property
    def empty(self) -> bool:
        return not self.questions and not self.fields

    def render(self, limit: int | None = None) -> str:
        parts: list[str] = []
        if self.headings:
            parts.append("【页面标题】" + " / ".join(self.headings[:3]))
        qs = [q for q in self.questions]
        fs = [f for f in self.fields]
        if limit:
            qs, fs = qs[:limit], fs[:limit]
        if qs:
            parts.append("【选择题】")
            parts.extend(q.render() for q in qs)
        if fs:
            parts.append("【填空/下拉题】")
            parts.extend(f.render() for f in fs)
        if not parts:
            parts.append("(页面上没有识别到任何可作答控件)")
        return "\n".join(parts)

    # ---- 按钮分类 ----
    # 必须分开：很多 quiz 每页一题，"下一题"是最常见的推进方式，
    # 而"提交/交卷"是终点。混在一起会导致点到"提交"就提前交卷。
    # 提交/交卷类按钮。
    #
    # ⚠ 关键词之间要允许**空白**：按钮文字经常被排版成「提 交 答 卷」这种
    #   字间加空格的样式（浏览器取 innerText 时保留空格），
    #   直接写 `提交|交卷` 会匹配不上 —— 实测就因此没能自动交卷。
    #   所以这里把关键词拆成单字、允许字间有空白。
    # 扩充词表：参考国内常见平台（超星 / 智慧树 / 职教云 / 问卷星 / 考试云）
    # 以及 Element / Ant Design 的默认文案。
    # 只加词、不改判断逻辑，所以不会影响原来能认出来的按钮。
    _SUBMIT_KEY = re.compile(
        r"提\s*交|交\s*卷|完\s*成\s*作\s*答|保\s*存\s*并\s*提\s*交|"
        r"提交答案|提交试卷|提交作业|确认提交|确认交卷|"
        r"结束答题|结束考试|完成答题|完成测验|完成练习|完成考试|"
        r"保存答案|保存并关闭|我要交卷|交卷并查看成绩|查看成绩|"
        r"submit|finish|hand\s*in|turn\s*in|submit\s*answer",
        re.I,
    )
    # 翻页 / 推进（每页一题时最常用）
    _NEXT_KEY = re.compile(
        r"下一题|下一頁|下一页|下一个|下一节|下一步|下一部分|下页|"
        r"继续|继续答题|继续做题|继续学习|"
        r"next|continue|›|»|→|»",
        re.I,
    )
    _SUBMIT_EXCLUDE = re.compile(r"下一|next|继续|上一步|上一", re.I)

    def submit_candidates(self) -> list[dict]:
        return [
            b for b in self.buttons
            if not b.get("disabled")
            and self._SUBMIT_KEY.search(b.get("text", ""))
            and not self._SUBMIT_EXCLUDE.search(b.get("text", ""))
        ]

    def next_candidates(self) -> list[dict]:
        """推进到下一题的按钮，按"越像下一题越靠前"排序。"""
        out = []
        for b in self.buttons:
            if b.get("disabled"):
                continue
            t = (b.get("text") or "").strip()
            if not t:
                continue
            if self._NEXT_KEY.search(t):
                out.append(b)
        # "下一题" 优先于泛泛的 "继续"
        out.sort(key=lambda b: 0 if re.search(r"下一", b.get("text", "")) else 1)
        return out

    def progress_hint(self) -> str:
        """从标题/按钮里抠出"3/20"、"第3题"这类进度，判断是不是最后一题。

        headings 只有 h1/h2/h3，很多站点把进度写在别的元素里，所以
        BrowserDriver.progress_hint() 还会去扫页面上的小字。
        """
        for h in self.headings + [b.get("text", "") for b in self.buttons]:
            m = re.search(r"(\d{1,3})\s*/\s*(\d{1,3})", h or "")
            if m:
                return f"{m.group(1)}/{m.group(2)}"
            m = re.search(r"第\s*(\d{1,3})\s*题\s*(?:/\s*共?\s*(\d{1,3})\s*题)?", h or "")
            if m:
                return f"{m.group(1)}/{m.group(2) or '?'}"
        return ""


# ---------------------------------------------------------------------------
class BrowserDriver:
    """一个薄封装：负责活着、能扫、能点。"""

    def __init__(self, *, headless: bool | None = None, cdp_url: str | None = None,
                 log=None):
        from playwright.sync_api import sync_playwright  # noqa: PLC0415

        self._pw = sync_playwright().start()
        self.headless = config.HEADLESS if headless is None else headless
        self.cdp_url = cdp_url
        self.context = None
        self.page = None
        self._shot_seq = 0
        # 日志回调（可选）。用来打 `[blind] ...` 这类标记 ——
        # 埋点数据是给人算占比用的，而日志是给人**当场看**的，两者都要。
        self.log = log if callable(log) else None
        # 落笔失败的现场快照只记一次，避免刷屏
        self._fail_dumped = False
        # 填空/论述的元信息（fid → {essay, qno}），供 fill() 选写入通道
        self._field_meta: dict[int, dict] = {}
        # 扫描到的"题号 → 选项信息"快照。落笔时可以拿它当依据重建定位 ——
        # 因为组件重渲染会把我们打在 DOM 上的 data-dsh-* 标记冲掉。
        self._options_snapshot: dict[int, dict] = {}
        # 题号/填空号 → 它所在的框架（None = 主文档）。
        # 见 `_frame_for` 的说明：iframe 里的题必须用对应 frame 才能操作。
        self._frames_by_qid: dict[int, Any] = {}
        self._frames_by_fid: dict[int, Any] = {}
        # 最近一次扫描的图片列表（含每张图的 `_frame`），见 `_frame_for_image`
        self._last_images: list[Any] = []
        # ⚠ 这个 context / browser **是不是我们自己创建的**？
        #   audit C-38：`_open_cdp()` 接管的是**用户自己已经开着的**浏览器
        #   （用户在「打开浏览器登录」里登完，我们连上去用他的登录态）。
        #   那种情况下 `close()` 去关它的 context，等于**关掉用户的浏览器**，
        #   下次还得重新登录。所以只有自己创建的才允许关。
        self._owns_context = True
        self._owns_browser = True
        # 临时标签页的"返回地址栈"：`open_new_tab()` 把当前页压进来，
        # `close_current_tab()` 关掉临时页后还原。见这两个方法的说明。
        self._tab_stack: list[Any] = []

    # ------------------------------------------------------------ 生命周期
    def open(self, url: str | None = None) -> None:
        """优先连已开的真实 Chrome/Edge（能带登录态），否则用持久化档案启一个。

        启动是分级的：正常档案 → 干净档案 → 换一个档案目录。因为上一次运行被强杀
        会在档案里留下锁/半写状态，表现为"启动即崩"，这时只有换干净档案才救得回来。
        """
        errors: list[str] = []

        if self.cdp_url is None and config.CDP_URL:
            self.cdp_url = config.CDP_URL
        if self.cdp_url:
            self._note(f"尝试接管你已打开的浏览器（调试端口 {self.cdp_url}）")
            try:
                target = self.to_file_url(url) if url else None
                self._open_cdp(self.cdp_url, target)
                if target and not self._same_url(self.page.url, target):
                    self.page.goto(target, wait_until="domcontentloaded", timeout=config.NAV_TIMEOUT_MS)
                    try:
                        self.page.wait_for_load_state("networkidle", timeout=5000)
                    except Exception:
                        pass
                if getattr(self, "log_note", ""):
                    self._note(self.log_note)
                # 目标页 vs 实际落点：被弹回登录页是最常见的"没登录成功"
                if target and not self._same_url(self.page.url, target):
                    self._note(f"⚠ 请求 {target} 后落到了 {self.page.url}"
                               f"（可能是未登录被重定向，或该页面会自动跳转）")
                return
            except Exception as e:
                errors.append(f"CDP({self.cdp_url}): {type(e).__name__}: {str(e).splitlines()[0][:120]}")
                # ⚠ 接管失败要说出来并给出下一步：否则用户以为"用的是我登录的那个"，
                #   实际下面会新开一个**未登录**的浏览器，必然撞上登录页。
                self._note(f"⚠ 没能接管已打开的浏览器（{str(e).splitlines()[0][:70]}）；"
                           f"接下来会新开一个浏览器 —— 那个**没有登录态**，"
                           f"如果被弹到登录页，请改用界面上的「打开浏览器登录」先登录。")

        self._note("正在新开一个浏览器（该窗口默认没有登录态；"
                   "如果你之前点过「打开浏览器登录」，请检查那一步是否成功）")
        for attempt, profile in enumerate(self._profile_candidates(), start=1):
            try:
                self._open_persistent(profile)
                if url:
                    self.page.goto(url, wait_until="domcontentloaded", timeout=config.NAV_TIMEOUT_MS)
                if not self.is_alive():
                    raise RuntimeError("启动后页面立即失效")
                if attempt > 1:
                    self._note(f"浏览器第 {attempt} 次尝试成功（档案：{profile.name}）")
                return
            except Exception as e:
                errors.append(f"{profile.name}: {type(e).__name__}: {str(e).splitlines()[0][:120]}")
                try:
                    self.close_context()
                except Exception:
                    pass

        raise RuntimeError(
            "浏览器启动失败，已尝试以下方式：\n  " + "\n  ".join(errors) +
            "\n\n处置建议：\n"
            "  1) 关掉所有 Edge / Chrome 窗口（任务管理器里确认没有残留）\n"
            f"  2) 删除档案目录：{config.PROFILE_DIR}\n"
            "  3) 重跑。若浏览器内核缺失："
            "\n     .venv\\Scripts\\python.exe -m playwright install chromium"
        )

    def wait_for_content(self, *, min_chars: int = 120,
                         timeout: float = 10.0, log=None) -> tuple[bool, int]:
        r"""等页面**真的渲染出内容**再开始扫描。

        返回 `(是否等到, 最后量到的字符数)`。

        ⚠ 为什么必须有这一步（实测踩到）：
          `wait_for_load()` 只等 `networkidle` + 1.2 秒，对**服务端渲染**的页面够用；
          但学习通的「作业作答」页是 **JS 异步填内容**的 —— 打开后先是一个白壳，
          几秒后题目才被写进去。

          实测现象（用户报"点开始答题后页面变纯白"）：
            15:21:29  页面标题：作业作答        ← 地址和标题都对
            15:21:30  识别到 0 道选择题、6 个填空/下拉框
            截图      2549x1352 全白（13KB）
            模型回传  'reason': '题目内容缺失，仅含样式代码'
          也就是说：**程序扫的是一个还没渲染完的白页**，
          于是把页面上的样式层当成了"填空题"，模型自然答不出来。

        做法：轮询"所有框架里的可见文字总长度"，够了才开始扫。
        同时看**所有 iframe** —— 题目常常渲染在子框架里，只看主文档会误判成空页。
        """
        deadline = time.time() + max(0.5, timeout)
        last_n = 0
        while time.time() < deadline:
            last_n = self._content_chars()
            if last_n >= min_chars:
                return True, last_n
            time.sleep(0.4)
        return False, last_n

    def _content_chars(self) -> int:
        """所有框架里可见文字的总长度（用来看"页面到底有没有内容"）。

        ⚠ 用 `self.page.frames` 而不是 `_frames()` —— 后者是 CourseRunner 的方法，
          BrowserDriver 上没有（我第一版写错了，一调用就 AttributeError）。
        """
        js = r"""() => {
            try {
                const b = document.body;
                if (!b) return 0;
                // innerText 只算可见文字；空白页会返回接近 0
                return ((b.innerText || b.textContent || '')
                        .replace(/\s+/g, ' ').trim()).length;
            } catch (e) { return 0; }
        }"""
        total = 0
        try:
            frames = list(self.page.frames)
        except Exception:
            frames = []
        for fr in frames:
            try:
                total += int(fr.evaluate(js) or 0)
            except Exception:
                continue
        return total

    def looks_blank(self) -> bool:
        """页面是不是"基本没内容"（白页 / 壳页）。

        给上层做两件事：① 决定要不要再等一等；② 给出**说得清原因**的提示，
        而不是含糊的"识别到 0 道题"。
        """
        try:
            return self._content_chars() < 60
        except Exception:
            return False

    def _profile_candidates(self) -> list[Path]:
        """依次尝试的档案目录：原档案 → 干净副本 → 带时间戳的全新档案。"""
        base = config.PROFILE_DIR
        cands = [base / "msedge", base / "chrome", base / "chromium"]
        # 只保留可能被渠道用到的；第一个"原档案"若启动失败，后续由 retry 换新目录
        fresh = base / f"fresh-{int(time.time())}"
        return cands + [fresh]

    # ---------------------------------------------------------------- 字体加密
    @staticmethod
    def looks_obfuscated(text: str) -> bool:
        """文字看着像不像被学习通「字体加密」过的乱码。

        ## 原理

        学习通在 `<style>` 里塞 `@font-face { font-family: font-cxsecret;
        src: url(data:font/ttf;base64,...) }`，把题目渲染成
        **码位是假的、字形是真的** 的汉字。眼睛看着是正常中文，
        `innerText` 取出来是 `悝悚悞悘` 这种。

        ## 判据

        汉字 ≥6 个，且其中 **≥45% 不在 GB2312 一级字库**里。

        ⚠ 为什么不用 3755 字表：`char.encode("gb2312")` 的**首字节**
          落在 `0xB0~0xD7` 就是一级字库（最常用那 3755 字），
          一个字节比较就够了，不用往仓库里塞几千字的常量。

        ⚠ 为什么阈值是 45% 而不是 60%：实测 2026-10-17 那句
          「GAN悴彻悹悰决悮悳坍悱问悷」生僻率只有 **50%** ——
          有些假字恰好也是常用字。卡 60% 会漏掉它。
          代价是可能误伤生僻文言，**所以这只是兜底**，
          主判据是 `page_font_obfuscated()`（页面里有没有 font-cxsecret）。
        """
        s = str(text or "")
        cjk = [c for c in s if "\u4e00" <= c <= "\u9fff"]
        if len(cjk) < 6:
            return False
        common = 0
        for c in cjk:
            try:
                b = c.encode("gb2312")
            except Exception:
                continue                     # GB2312 都编不出 → 肯定生僻
            if len(b) == 2 and 0xB0 <= b[0] <= 0xD7:
                common += 1
        rare = (len(cjk) - common) / len(cjk)
        return rare >= 0.45

    def page_font_obfuscated(self) -> bool:
        """当前页面（含各 frame）有没有用学习通的加密字体。

        这是**确定**判据：`font-cxsecret` 是学习通专用的 family 名，
        正常页面不会叫这个。
        """
        if self.page is None:
            return False
        js = r"""() => {
          try {
            const styles = document.querySelectorAll('style');
            for (const s of styles) {
              const t = s.textContent || '';
              if (/font-cxsecret/i.test(t)) return 'cxsecret';
            }
            // 兜底：内嵌 base64 字体 + 名字里带 secret / cx
            for (const s of styles) {
              const t = s.textContent || '';
              if (/@font-face/.test(t) && /data:font/i.test(t)
                  && /secret|cxsecret/i.test(t)) return 'inline';
            }
          } catch (e) {}
          return '';
        }"""
        try:
            frames = list(self.page.frames)
        except Exception:
            return False
        for fr in frames:
            try:
                if fr.evaluate(js):
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    def to_file_url(s: str) -> str:
        """把本地路径（绝对或相对）转成合法的 file:// URL。

        用户（或调用方）经常直接给一个路径，比如 E:\\x\\homework.html 甚至 tests\\a.html。
        这种字符串既不能直接 goto（浏览器报 Cannot navigate to invalid URL），
        也没法和页面实际 URL 比较，结果是"页面明明是对的却判定为不一致"，
        还会误报成"被重定向到登录页"。
        """
        t = (s or "").strip()
        if not t:
            return t
        if re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", t):
            return t                      # 已经是 http:// file:// 之类
        # 绝对路径（含 UNC）和相对路径都走 resolve + as_uri
        try:
            p = Path(t)
            if p.exists() or p.is_absolute():
                return p.resolve().as_uri()
        except Exception:
            pass
        return t

    @classmethod
    def _same_url(cls, a: str, b: str) -> bool:
        """宽松比较两个 URL（忽略末尾斜杠与锚点，并容忍本地路径写法）。"""
        def norm(s: str) -> str:
            s = cls.to_file_url(s).split("#", 1)[0]
            return s.rstrip("/")
        return norm(a) == norm(b)

    @staticmethod
    def looks_like_course_url(u: str) -> bool:
        """这个 URL 看起来像不像"课程页"（只用于挑标签页 / 给可读提示）。"""
        return bool(_COURSE_URL_RE.search(str(u or "")))

    @classmethod
    def pick_page_index(cls, urls: list[str]) -> int:
        """从一组标签页 URL 里挑"该接管哪一个"，返回下标；空列表返回 -1。

        优先级：**最后一个课程页**（用户刚打开的往往就是它）→ 否则保持原样
        用最后一个标签页。抽成纯函数是为了能脱离浏览器做回归。
        """
        if not urls:
            return -1
        for i in range(len(urls) - 1, -1, -1):
            if cls.looks_like_course_url(urls[i]):
                return i
        return len(urls) - 1

    def _open_cdp(self, cdp_url: str, url: str | None = None) -> None:
        """接管一个已经开着的浏览器（带登录态）。

        关键点：不能"抓到哪个标签页就用哪个"。用户可能在里面开着别的页面
        （甚至另一个作业），直接用就会答错页面。所以按优先级挑：
          1) URL 已经就是目标网址的标签页 —— 直接用它，页面状态原样保留
          2) 否则用当前标签页导航过去
          3) 都没有就新开一个标签页
        """
        browser = self._pw.chromium.connect_over_cdp(cdp_url)
        if not browser.contexts:
            raise RuntimeError("CDP 已连接但没有可用的 context")
        self.context = browser.contexts[0]
        # ⚠ 这不是我们创建的！用户自己开着的浏览器，我们只是接管。
        #   收尾时**绝不能 close 它**，否则会连带关掉用户刚登录好的窗口
        #   （下次还得重登）。只断开连接即可。见 close()。
        self._owns_context = False
        self._owns_browser = False
        self._cdp_browser = browser
        pages = [p for p in self.context.pages if not p.is_closed()]

        target = (url or "").strip()
        if target:
            want = target.rstrip("/")
            for p in pages:
                try:
                    if (p.url or "").rstrip("/") == want:
                        self.page = p
                        self.log_note = f"复用已打开的目标标签页（{p.title()[:30]}）"
                        return
                except Exception:
                    continue
            # 没有现成的目标页 → 用当前标签页导航过去（保留 cookie，但换掉页面）
            if pages:
                self.page = pages[-1]
                self.log_note = "在已登录的浏览器里打开目标网址"
                return
            self.page = self.context.new_page()
            self.log_note = "新开标签页打开目标网址"
            return

        # ★ 没填网址：**先按 URL 挑课程页**，再退回最后一个标签页。
        #
        #   原来的 `pages[-1]` 是"最后新建的那个"，跟用户眼前看的那页都不一定
        #   是同一页，更不判断它是不是课程页。客户日志里 21/30 次就是这么
        #   抓到百度/个人空间、2 秒就报"找不到可播放的视频"的。
        #   客户通常**已经**在另一个标签页开着课程，只是当前页是百度。
        urls: list[str] = []
        for p in pages:
            try:
                urls.append(str(p.url or ""))
            except Exception:
                urls.append("")
        idx = self.pick_page_index(urls)
        if idx >= 0 and self.looks_like_course_url(urls[idx]):
            self.page = pages[idx]
            self.log_note = f"自动挑中课程标签页（{urls[idx][:60]}）"
            return

        self.page = pages[-1] if pages else self.context.new_page()
        self.log_note = "接管当前标签页"

    def _open_persistent(self, profile_dir: Path | None = None) -> None:
        profile_dir = profile_dir or (config.PROFILE_DIR / "msedge")
        profile_dir.mkdir(parents=True, exist_ok=True)
        channels = [c.strip() for c in str(config.CHROME_CHANNEL or "").split(",") if c.strip()]
        errors: list[str] = []
        # 依次尝试：系统 Edge → 系统 Chrome → Playwright 内置 chromium
        for chan in channels + [None]:
            kw: dict[str, Any] = dict(
                user_data_dir=str(profile_dir),
                headless=self.headless,
                viewport={"width": config.VIEWPORT_W, "height": config.VIEWPORT_H},
                locale="zh-CN",
                args=list(BROWSER_ARGS),
                ignore_default_args=["--enable-automation"],
            )
            if chan:
                kw["channel"] = chan
            try:
                self.context = self._pw.chromium.launch_persistent_context(**kw)
                self.log_channel = chan or "chromium(bundled)"
                self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
                self.page.set_default_timeout(config.NAV_TIMEOUT_MS)
                return
            except Exception as e:
                first = str(e).splitlines()[0][:150]
                errors.append(f"{chan or 'chromium(bundled)'}: {first}")
                try:
                    self.context and self.context.close()
                except Exception:
                    pass
                self.context = None
        raise RuntimeError("；".join(errors))

    def close_context(self) -> None:
        """只关掉当前 context（用于启动重试），保留 playwright 本身。"""
        try:
            if self.context is not None:
                self.context.close()
        except Exception:
            pass
        self.context = None
        self.page = None

    def cleanup_profile(self) -> None:
        """删除整个档案目录。会丢失登录态，只在启动反复失败时用。"""
        try:
            self.close_context()
        except Exception:
            pass
        try:
            import shutil
            shutil.rmtree(config.PROFILE_DIR, ignore_errors=True)
        except Exception:
            pass

    @property
    def channel_used(self) -> str:
        return getattr(self, "log_channel", "?")

    def open_new_tab(self, url: str | None = None) -> bool:
        """在**同一个 context** 里开一个新标签页，并把 `self.page` 切过去。

        成功返回 True。

        ## 为什么需要它

        「章节测验」要打开一个**别的页面**去作答，但课程页本身不能丢
        （还指着它继续刷课）。用 `self.page.goto()` 会把课程页导航走；
        另建一个 `BrowserDriver` 又会**留下关不掉的标签页** ——
        因为 `close()` 对 CDP 接管的情况只断开、不关页面（audit C-38）。

        所以：同一个 driver、同一个浏览器 context，开一个临时标签页，
        用完 `close_current_tab()` 关掉，`self.page` 自动还原。

        ⚠ 只有在 `context` 已经建立后才有意义。`open()` 之前调用会返回 False。
        """
        if self.context is None or self.page is None:
            self._note("⚠ 开临时标签页失败：浏览器还没连上"
                       "（context/page 为空）")
            return False
        try:
            prev = self.page
            pg = self.context.new_page()
            self._tab_stack.append(prev)
            self.page = pg
            if url:
                target = self.to_file_url(url)
                pg.goto(target, wait_until="domcontentloaded",
                        timeout=config.NAV_TIMEOUT_MS)
                try:
                    pg.wait_for_load_state("networkidle", timeout=5000)
                except Exception:
                    pass
            return True
        except Exception as _e:
            # ⚠ 把原因写出来 —— 只说"开不出"没法定位。
            #   2026-10-17 用户日志里就只留了「⚠ 开不出测验标签页」，
            #   完全看不出是地址的问题还是浏览器的状态问题。
            self._note(f"⚠ 开临时标签页失败（{type(_e).__name__}: "
                       f"{str(_e).splitlines()[0][:120]}）")
            # ⚠ 回滚时**必须把刚建的 page 关掉** ——
            #   只还原 self.page 的话，那个空标签会一直挂在 context.pages 里。
            #   自测里就是这么发现的：标签数 1 → 2 之后回不到 1。
            try:
                pg.close()
            except Exception:
                pass
            try:
                if self._tab_stack:
                    self.page = self._tab_stack.pop()
            except Exception:
                pass
            return False

    def close_current_tab(self) -> bool:
        """关掉 `open_new_tab()` 开的那个标签页，`self.page` 还原成上一页。

        没有临时标签页可关时返回 False（无害）。
        """
        if not self._tab_stack:
            return False
        try:
            cur = self.page
            prev = self._tab_stack.pop()
            try:
                if cur is not None and not cur.is_closed():
                    cur.close()
            except Exception:
                pass
            self.page = prev
            return True
        except Exception:
            return False

    def close(self) -> None:
        """收尾。

        ⚠ audit C-38：**必须区分"自己启动的浏览器"和"CDP 接管的用户浏览器"。**
          浏览器是用户在「打开浏览器登录」里自己开的，我们只是连上去用他的登录态
          （`_owns_context=False`）。这种情况下如果照旧 `context.close()`：
            · 轻则断开连接、用户下次还得重登；
            · 重则**连带关掉用户刚登录好的窗口**（行为随 Playwright 版本而异）。
          所以：只关自己创建的；接管的只断开。

        ⚠ audit C-23：网页答题路径原来**根本不调 close()**，
          每答一次就多留一个 node.exe + 一个浏览器进程。
          现在 `run_web()` 的 finally 里会调它（见 agent.py）。
        """
        try:
            if self.context is not None:
                if self._owns_context:
                    self.context.close()
                else:
                    # 不是我们的 → 只断开与它 / 浏览器的连接
                    try:
                        br = getattr(self, "_cdp_browser", None)
                        if br is not None:
                            br.close()          # 对 CDP 连接而言 = 断开
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            self._pw.stop()
        except Exception:
            pass
        self.context = None
        self.page = None
        self._cdp_browser = None

    def is_alive(self) -> bool:
        """浏览器/页面是否还活着。崩了还继续点会刷出一堆同样的错误。"""
        try:
            if self.page is None or self.page.is_closed():
                return False
            self.page.evaluate("1")
            return True
        except Exception:
            return False

    # ---- 复用 PageState 上的按钮/横幅判定，避免两处逻辑各写一遍 ----
    # 只需要按钮和标题，不必跑整个 SCAN_JS（那个要遍历所有控件 + 算题干，几毫秒起步）。
    _BUTTONS_JS = r"""
    () => {
      const vh = window.innerHeight;
      function vis(e) {
        if (!e) return false;
        const r = e.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) return false;
        const s = window.getComputedStyle(e);
        return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0.05;
      }
      function box(e) {
        const r = e.getBoundingClientRect();
        return {x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height)};
      }
      function textOf(e) { return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim(); }
      const buttons = [], headings = [];
      document.querySelectorAll('button,input[type=submit],input[type=button],a[role=button],.btn').forEach(b => {
        if (!vis(b)) return;
        const t = textOf(b) || b.value || b.getAttribute('aria-label') || '';
        if (!t) return;
        const r = b.getBoundingClientRect();
        buttons.push({text: t.slice(0, 60), box: box(b), disabled: !!b.disabled,
                      tag: b.tagName.toLowerCase(),
                      in_view: r.bottom > -40 && r.top < vh + 40});
      });
      document.querySelectorAll('h1,h2,h3').forEach(h => {
        if (!vis(h)) return;
        const t = textOf(h);
        if (t) headings.push(t.slice(0, 120));
      });
      // 进度提示经常写在 div/span 里（"第 3 题 / 共 5 题"、"3/20"），
      // 只扫 h1/h2/h3 会漏掉。这里单独捞一小段含进度特征的文本。
      const progRe = /(\d{1,3}\s*\/\s*\d{1,3})|(第\s*\d{1,3}\s*题)/;
      let progress = '';
      for (const el of document.querySelectorAll('div,span,p,small,strong,em,li')) {
        const t = textOf(el);
        if (t.length > 0 && t.length < 40 && progRe.test(t)) { progress = t; break; }
      }
      return {buttons, headings, progress};
    }
    """

    def _button_state(self) -> PageState:
        try:
            raw = self.page.evaluate(self._BUTTONS_JS)
        except Exception:
            return PageState()
        st = PageState(buttons=raw.get("buttons", []), headings=raw.get("headings", []))
        self.page_progress = str(raw.get("progress") or "")
        return st

    def progress_hint(self) -> str:
        st = self._button_state()
        hint = st.progress_hint()
        if hint:
            return hint
        # 页面小字里捞到的进度优先于按钮文字
        p = getattr(self, "page_progress", "")
        if p:
            return p
        return ""

    def next_candidates(self) -> list[dict]:
        return self._button_state().next_candidates()

    def submit_candidates(self) -> list[dict]:
        return self._button_state().submit_candidates()

    def page_signature(self, state: PageState | None = None) -> str:
        """当前"题页"的指纹。变了 = 翻页了；没变 = 还卡在同一题。

        ⚠ 只用**结构化、稳定**的数据（题干、选项文字、name、勾选状态）。

        绝对不要从 body.innerText 里取内容（哪怕是开头/结尾一段）：
        真实考试页面顶部常有倒计时、右侧有用时/进度，它们每秒都在变，
        会把指纹搞成"每轮都不一样"。这个坑的完整后果链是：

            指纹乱变 → 程序以为翻页了 → attempts.clear() 反复执行
            → 每题都被当成"待答"反复重答 → 落笔记录被覆盖
            → 最终报告「落笔 0 题」（表现就是"只翻页不落笔"）

        state 是已经解析好的 PageState。传了就用它算（最稳）；
        没传则退回一段保守的 JS，只取**题干类元素**的文本，同样不碰 body 文本。
        """
        if state is not None:
            try:
                parts = [
                    state.url.split("#")[0],
                    str(len(state.questions)),
                    str(len(state.fields)),
                ]
                for q in state.questions:
                    # ⚠ 不要把 checked（已勾选状态）算进指纹：作答本身会改变它，
                    # 于是"答完一题"也会被当成"翻页了"，导致 attempts 被清空、
                    # 同一题被反复重答（历史里出现重复的 q0）。
                    # 题目身份靠 stem + 选项文字已经足够区分。
                    opts = "|".join(str(o.get("text", ""))[:40] for o in q.options)
                    parts.append(f"{q.name}#{q.stem[:180]}#{opts}")
                for f in state.fields:
                    parts.append(f"{f.kind}#{(f.stem or f.label)[:120]}#{f.value}")
                return "~".join(parts)[:1200]
            except Exception:
                pass

        # 退路：只取题干类元素，绝不碰 body.innerText
        try:
            sig = self.page.evaluate(
                """() => {
                    const qs = [];
                    document.querySelectorAll('input[type=radio],input[type=checkbox]').forEach(e => {
                        if (e.name) qs.push(e.name);
                    });
                    const stems = [];
                    document.querySelectorAll('h1,h2,h3,h4,.stem,.question,.qtitle,p,label').forEach(e => {
                        const t = (e.textContent || '').replace(/\\s+/g, ' ').trim();
                        if (t && t.length > 4 && t.length < 200) stems.push(t);
                    });
                    const inputs = document.querySelectorAll(
                        'input[type=text],textarea,select').length;
                    // 同样不含 checked：作答会改它，不能当"翻页"信号
                    return location.pathname + location.hash + '|' +
                           qs.sort().join(',') + '|' + inputs + '|' +
                           stems.slice(0, 6).join('~');
                }"""
            )
            return str(sig)[:1200]
        except Exception:
            return ""

    def assert_alive(self) -> None:
        if not self.is_alive():
            raise RuntimeError(
                "浏览器已关闭或崩溃。多半是上一个实例的残留进程还在占用同一个用户档案目录：\n"
                "  1) 先关掉所有 Edge/Chrome 窗口\n"
                f"  2) 删掉档案目录：{config.PROFILE_DIR}\n"
                "  3) 重新运行\n"
                "（本工具正常退出时会自动关闭浏览器；若上次是强杀，就会留下残留进程。）"
            )

    # ------------------------------------------------------------ 扫 & 点
    def _scan_raw(self, frame) -> dict:
        """跑一次扫描：**先试结构化识别，不匹配再走原来的 SCAN_JS**。

        这是叠加式改动：原来的 `SCAN_JS` 一字未改，
        只是在前面多了一次“能不能用更准的那套”的尝试。
        结构不符时 `_STRUCTURED_SCAN_JS` 返回 ok=False，原样回退。
        """
        try:
            r = frame.evaluate(_STRUCTURED_SCAN_JS) or {}
            if r.get("ok") and r.get("questions"):
                return r
        except Exception:
            pass                      # 结构化识别自身出错绝不能影响主流程
        return frame.evaluate(SCAN_JS)

    def scan(self, *, frames: bool = True) -> PageState:
        """扫描主框架（默认也扫 iframe，很多在线作业把题嵌在 iframe 里）。

        ⚠ 这里是**埋点**位置之一（`dsh_solver/metrics.py`）：
          每次扫描 +1 计入分母；扫出空页时记一次 `scan_empty`。
          埋点的用途是量出"DOM 到底多大概率扫不出来"，
          数据不够就不该去写视觉代码（详见 P-1 阶段的闸门 G1）。
          埋点自身出错**绝不影响主流程** —— metrics 里全部吞异常。
        """
        t0 = time.time()
        raw = self._scan_raw(self.page)
        state = self._to_state(raw)
        self._remember_options(state)
        if frames:
            for fr in self.page.frames:
                if fr == self.page.main_frame:
                    continue
                try:
                    r = self._scan_raw(fr)
                except Exception:
                    continue
                if r and (r.get("questions") or r.get("inputs")):
                    sub = self._to_state(r)
                    # ★ 先记下"帧内旧编号" —— 重贴标记要靠它做 old→new 映射。
                    #   必须在 +base / 重新赋 fid **之前**取，否则映射就丢了。
                    #   背景：SCAN_JS 是在每个 frame 里各跑一遍的，编号**每帧从 0 开始**，
                    #   合并到 Python 侧才加偏移 → 帧内 DOM 标记 ≠ Python 编号。
                    old_qids = [q.qid for q in sub.questions]
                    old_fids = [f.fid for f in sub.fields]
                    base = len(state.questions)
                    for i, q in enumerate(sub.questions):
                        q.qid += base
                        # ★ 记下"这道题在哪个框架里" —— 落笔要按它定位。
                        #   不记的话，后面所有点击都会打到主文档上（审计 C-25）。
                        q.frame = fr
                        # ★ 帧内位置：标记失效时靠它做位置兜底（见 fill 的快检）
                        q.in_frame_idx = old_qids[i]
                        state.questions.append(q)
                    for i, f in enumerate(sub.fields):
                        f.fid = len(state.fields)
                        f.frame = fr
                        f.in_frame_idx = old_fids[i]
                        state.fields.append(f)
                    # ★★ 一帧一次、按映射整体重贴。
                    #    ⚠ 绝不能"逐个 item 调一次、每次改整帧" ——
                    #      那会让标记互相覆盖（3 个字段变 [2,1,2]、
                    #      整帧题目全被贴成最后一题的 qid），
                    #      正是"填空错位/串题"的根因。
                    #
                    #    ⚠⚠ 映射的 key **必须是字符串**：
                    #      Playwright 序列化参数时，JS 对象的 key 只能是字符串，
                    #      传 `{0: 1}` 会直接报
                    #        "arg.value…o[0].k: expected string, got number"
                    #      我第一版就是整数 key，而外层的 `except: pass` 把它吞了 ——
                    #      表现只是"重贴从没生效"、标记停在帧内编号，极难查。
                    self._restamp_frame_markers(
                        fr,
                        {str(old): q.qid for old, q in zip(old_qids, sub.questions)},
                        {str(old): f.fid for old, f in zip(old_fids, sub.fields)},
                    )
                    for im in sub.images:
                        # ★ 图片也要记框架：audit C-37 —— 扫描会把 iframe 里的
                        #   图片合并进来，但取图原来只在主文档，于是
                        #   "图在 iframe 里"的题**永远拿不到配图**，视觉模型只能猜。
                        if isinstance(im, dict):
                            im["_frame"] = fr
                        state.images.append(im)
                    state.buttons.extend(sub.buttons)
                    if not state.headings:
                        state.headings = sub.headings
        # 标记重贴已经在每个子 frame 合并时**就地**做完（见上面
        # `_restamp_frame_markers`）—— 那时才拿得到"帧内旧编号→全局新编号"
        # 的映射；等到这里再统一做，映射早就丢了。
        # ★ 跨文档补题干（论述/简答）：作答区在编辑器**自己的**文档/iframe 里，
        #   那个文档里只有工具栏文字（"段落格式 字体 字号"），题干在**父文档**的题目块。
        #   从作答区往上找永远找不到题干 —— 这就是 6 道简答全是
        #   "(填空题，题干未识别)" 的原因（证据见 out\quiz_dom.txt 【C】段：
        #   主文档里一个 [contenteditable=true] 都查不到）。
        #   必须放在**所有 frame 都合并完之后**（字段的 f.frame 此时才记好）。
        self.enrich_essay_stems(state)
        # ★ 题干兜底闸：源码不能当题干（见 _drop_source_stems 的说明）
        self._drop_source_stems(state)
        self._remember_options(state)
        # ★ 错位自检：不通过就写日志，别等用户发现"答案写进别的格子"
        self._verify_markers(state)
        # 记下这次扫描的图片列表（含每张图的 `_frame`），
        # 供 `shoot_images()` 知道"这张图在哪个框架里"（audit C-37）。
        self._last_images = list(getattr(state, "images", []) or [])

        # ---- 埋点：分母 + 空页事件 ----
        try:
            metrics.bump_total(1)
            if state.questions or state.fields:
                # 这一页确实有题目/填空 → 顺便记一次"成功扫描"的耗时
                metrics.note_scan_ok(time.time() - t0)
            else:
                metrics.record(
                    metrics.SCAN_EMPTY,
                    url=getattr(self.page, "url", ""),
                    detail=(f"题 0 / 填空 0 / 按钮 {len(state.buttons)} "
                            f"/ 标题 {(state.headings or [''])[0][:30]}"),
                    ms=(time.time() - t0) * 1000,
                )
                # 日志里也打一条明确标记，便于人工抽查（文档要求）
                if self.log:
                    try:
                        self.log("  " + metrics.log_marker(
                            metrics.SCAN_EMPTY,
                            f"题0 填空0 按钮{len(state.buttons)}"))
                    except Exception:
                        pass
        except Exception:
            pass
        return state

    def enrich_essay_stems(self, state: PageState) -> None:
        r"""给"题干未识别"的填空/论述题补题干（跨文档）。

        ## 为什么必须跨文档

        学习通（超星）的问答题是**富文本编辑器**：真正的可编辑区在编辑器
        **自己的文档/iframe 里**，那个文档里只有工具栏文字（"段落格式 字体 字号"），
        而题干在**父文档**的题目块（`.questionLi` 那一层）。
        从作答区往上找永远找不到题干 —— 这就是日志里 6 道简答/论述全是
        `(填空题，题干未识别)` 的原因。

        证据：`out\quiz_dom.txt` 的【C】段，以及"主文档里一个
        `[contenteditable=true]` 都查不到"这条硬证据。

        ## 三条路（① 失败就走 ②，再失败走 ③）

          ① 字段在子框架里 → 用 `frame_element()` 回到父文档，从 iframe 元素往上找
          ② 字段就在主文档里 → 用同文档 JS 上溯（与 `_dump_field_dom` 同一套写法）
          ③ 主文档里找"装着编辑器 iframe 的题目块" → 按序号对应到第几个论述题

        ⚠ 每条路的结果都写进日志。这一块**猜错过太多次**（"作答区在子文档、
          题干在父文档"是我从采集数据推的，但实测 `enrich_essay_stems` 根本没取到），
          所以宁可多打一行，也不要再让作者靠想象定位。
        """
        # 先收集"待补题干"的字段，路径③要按序号对应
        pending = [f for f in (getattr(state, "fields", []) or [])
                   if "题干未识别" in str(getattr(f, "stem", "") or "")]
        if not pending:
            return
        # 路径③需要的"父文档里的论述题块"（只查一次）
        parent_blocks: list[str] | None = None

        for idx_in_pending, f in enumerate(pending):
            fr = getattr(f, "frame", None)
            is_sub = fr is not None and fr != self.page.main_frame
            txt = ""
            dbg: list[str] = []
            # ① 字段在子框架里 → 回到父文档，从 iframe 元素往上找题目块
            if is_sub:
                try:
                    # ★ 沿**字段自己的 frame 链**往上找，而不是只看直接父文档。
                    #
                    # ⚠ 这是"填写错位"的根治点。
                    #   实测：①（只看直接父文档）拿到 0 字，于是退回③
                    #   "主文档里第 N 个题块"——**那是纯按序号猜的**。
                    #   字段顺序（按 page.frames 枚举）与题块 DOM 顺序一旦不一致，
                    #   题干就会张冠李戴：模型答的是第 18 题，字却写进第 19 题框里。
                    #
                    #   真实结构是**嵌套**的：编辑器 iframe 装在另一层 iframe 里，
                    #   从编辑器 iframe 往上只看得到工具栏（"段落格式 字体 字号"）；
                    #   再往外一层才到主文档、才看得到题干。
                    #   所以要一层层 `frame_element()` + `parent_frame` 往上走。
                    txt = self._stem_via_frame_chain(fr) or ""
                    dbg.append(f"①frame链={len(txt)}字")
                except Exception as e:
                    dbg.append(f"①失败({type(e).__name__})")
            else:
                dbg.append("①跳过(字段在主文档)")
            # ② 字段就在主文档里 → 同文档上溯
            if not txt:
                try:
                    txt = self._field_stem_from_dom(f.fid) or ""
                    dbg.append(f"②同文档={len(txt)}字")
                except Exception as e:
                    dbg.append(f"②失败({type(e).__name__})")
            # ③ 兜底：主文档里那些"装着编辑器 iframe / 隐藏 textarea 的题目块"
            #
            # ⚠ 这条路**按序号对应**，只在①②都失败时用，并且会把"用的是第几个"
            #   写进日志 —— 序号对应一旦错位就是"答案写进别的题"，
            #   属于比"填不进去"严重得多的错误，必须能从日志上看出来。
            if not txt:
                try:
                    if parent_blocks is None:
                        parent_blocks = self._essay_blocks_in_main_doc()
                    dbg.append(f"③按序号兜底(共{len(parent_blocks)}个)")
                    if idx_in_pending < len(parent_blocks):
                        cand = parent_blocks[idx_in_pending]
                        dbg.append(f"③取第{idx_in_pending}个={len(cand)}字⚠序号对应")
                        txt = cand
                except Exception as e:
                    dbg.append(f"③失败({type(e).__name__})")
            try:
                self.log(f"   [补题干] f{f.fid} frame={'子' if is_sub else '主'} "
                         + " ".join(dbg))
            except Exception:
                pass
            if txt and "题干未识别" not in txt:
                f.stem = txt
                # ★ 题干里**明写**了题型时，以题型为准 —— 别把填空题当论述题。
                #
                #   2026-10-23 真机：41~44 是【填空题】（答案就是"人工智能之父"
                #   "达特茅斯"这种一个词），但作答区是富文本编辑器，于是被这里
                #   无条件标成 essay=True。`Field.render()` 对 essay 的要求是
                #   "80~300 字的完整作答" → 模型给每道填空写了一整段话
                #   （日记里 f0~f9 全是 277~391 字）。
                #   判据用页面自己写的题型标记，只有"没写题型"时才保留老行为。
                # ★ 2026-10-28 真机：学习通这套卷子的题型是**半角** `(填空题)`，
                #   旧正则只认全角 `【填空题】` → 填空被当成论述题 → 写 300 字小作文。
                _fill_like = bool(re.search(
                    r"[【(（]\s*(填空题|单选题|多选题|判断题)\s*[】)）]", txt))
                f.essay = not _fill_like
                # ⚠ 顺带把 kind 也改成 essay。
                #   扫描时判据看的是**题块文字**，而那时题干还没补上
                #   （只有工具栏文字"段落格式 字体 字号"）→ 命不中"简答/论述"，
                #   于是 kind 停在 'contenteditable'。现在题干拿到了，
                #   依据就充分了 —— 不统一的话 render()/日志里两种叫法混着出现。
                if f.essay and f.kind == "contenteditable":
                    f.kind = "essay"
                try:
                    self.log(f"· f{f.fid} 补到题干：{txt[:40]}…")
                except Exception:
                    pass

    def _drop_source_stems(self, state: PageState) -> None:
        r"""把"题干其实是页面源码"的字段打回 `题干未识别`（**叠加**，只做减法）。

        为什么必须在 `scan()` 的最后再做一次：
          JS 侧已经不再把 `<script>/<style>` 拼进文字了，但平台还有别的藏法
          （`<pre>`、注释、隐藏 textarea 里的代码）；而且 `enrich_essay_stems`
          会**跨文档**取题干，取到的也可能是父文档里的脚本块。

        打回 `题干未识别` 之后有三条既有护栏自动生效：
          · `_cache_key()` 对这种题干返回 None → 不读也不写缓存（不会互相抄答案）；
          · 日志里能直接看到"题干未识别"，而不是一段看起来像题的文字；
          · 用户侧"没把握就不落笔"的原则不变。
        """
        try:
            for f in (getattr(state, "fields", []) or []):
                stem = str(getattr(f, "stem", "") or "")
                if not stem or "题干未识别" in stem:
                    continue
                if not stem_looks_like_source(stem):
                    continue
                f.stem = "(填空题，题干未识别)"
                try:
                    if self.log:
                        self.log(f"⚠ f{f.fid} 的题干是页面源码（不是题目），已丢弃："
                                 f"{stem[:36]!r}… —— 否则模型会把源码当题目解释，"
                                 f"多道题还会因此共用同一个答案")
                except Exception:
                    pass
        except Exception:
            pass

    # 沿祖先找题干时用的"取文字"函数。
    #
    # ⚠ 退回 textContent 时**必须摘掉 <script>/<style>**：
    #   2026-10-23 真机踩到 —— 题目区不可见时 innerText 为空，`|| textContent`
    #   把平台注入的 greenlight 脚本源码当成了题干（4 道填空题全同一段），
    #   模型于是回"该段代码用于……"，4 个空格被写进同一段话。
    _STEM_TEXT_JS = r"""
        function stemText(n) {
          var v = n.innerText;
          if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
          try {
            var c = n.cloneNode(true);
            c.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
            return (c.textContent || '').replace(/\s+/g, ' ').trim();
          } catch (x) { return ''; }
        }
    """

    _WALK_UP_STEM_JS = r"""(e) => {
        function stemText(n) {
          var v = n.innerText;
          if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
          try {
            var c = n.cloneNode(true);
            c.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
            return (c.textContent || '').replace(/\s+/g, ' ').trim();
          } catch (x) { return ''; }
        }
        // 「这像不像一道题」—— 用来越过工具栏/源码层，继续往上找。
        //
        // 2026-10-23 真机（学习通作业 41~44 填空题）：从作答区 iframe 往上走，
        // 第一个 ≥12 字的祖先是**编辑器工具栏**（"点击上传 段落格式 字体"），
        // 老写法在这里就停了 → 题干 = 工具栏（或它上面那层藏着的脚本源码）。
        // 真正的题干在再往上一层的 `.questionLi` 里（"41【填空题】1950年…"）。
        // 所以：先一路扫完，**优先返回像题目的那一层**；都没有才退回老行为。
        function looksLikeQuestion(t) {
          if (!t) return false;
          if (/【(单选|多选|判断|填空|简答|论述|名词解释)题】/.test(t)) return true;
          if (/^\s*\d{1,3}\s*[.、．]\s*\S/.test(t)) return true;
          if (t.length <= 400 && /(_{2,}|（\s*）|\(\s*\))/.test(t)) return true;
          return false;
        }
        function looksLikeChrome(t) {
          var s = String(t || '').replace(/\s+/g, '');
          if (!s || s.length > 40) return false;
          return /^(点击上传|段落格式|字体|字号|加粗|斜体|下划线|插入|全屏|预览)/.test(s);
        }
        // 找到题目那层后，把尾巴上的编辑器工具栏削掉（"…机器能否思考”。 点击上传 段落格式 字体 字号"）。
        // cut > 8 是为了不把"从第 1 个字就是工具栏词"的题干整条削没。
        function trimChrome(t) {
          var m = t.search(/点击上传|段落格式|字体\s*字号|字号\s*字体/);
          return (m > 8 ? t.slice(0, m) : t).trim();
        }
        let n = e, hops = 0, first = '';
        while (n && hops < 10) {
          const t = stemText(n);
          if (t.length >= 12) {
            if (!first) first = t;          // 老行为的"第一层够长的祖先"，兜底用
            if (looksLikeQuestion(t)) return trimChrome(t).slice(0, 600);
          }
          n = n.parentElement; hops++;
        }
        return first.slice(0, 600);
    }"""

    def _verify_markers(self, state: PageState) -> None:
        r"""检查"编号 == DOM 标记"在每个 frame 里是否成立。

        ## 为什么要有

        错位类 bug 的特点是**静默** —— 答案写进了别的空格、
        或者点到别的题上，日志里却全是 ✔。等用户发现时已经交卷了。

        这里每个 frame 只发一次 JS（毫秒级），却能在**下一次运行**时就暴露问题。

        ⚠ 判据要"精确等于"，不是"大于 0"：
          `f.fid` 必须恰好命中 1 个元素；`q.qid` 必须恰好命中
          **本题选项数** 个元素。数量不对就说明标记串了。
        """
        bad: list[str] = []
        for f in getattr(state, "fields", []) or []:
            fr = getattr(f, "frame", None)
            try:
                n = self._ev(fr, """(fid) => document.querySelectorAll(
                    '[data-dsh-fid="' + fid + '"]').length""", str(f.fid))
            except Exception:
                n = -1
            if n != 1:
                bad.append(f"f{f.fid}:标记{n}个")
        for q in getattr(state, "questions", []) or []:
            fr = getattr(q, "frame", None)
            try:
                n = self._ev(fr, """(a) => document.querySelectorAll(
                    '[data-dsh-qid="' + a[0] + '"],[data-dsh-cqid="' + a[0] + '"]'
                    ).length""", [str(q.qid)])
            except Exception:
                n = -1
            if n != len(q.options):
                bad.append(f"q{q.qid}:标记{n}个/选项{len(q.options)}个")
        if not bad:
            return
        try:
            self.log("⚠ 编号与 DOM 标记不一致（落笔可能错位，请把这份日志发给作者）："
                     + "、".join(bad[:8]))
        except Exception:
            pass
        try:
            metrics.record(metrics.CHOOSE_FAIL,
                           url=getattr(self.page, "url", ""),
                           detail="marker_mismatch " + " ".join(bad[:8]))
        except Exception:
            pass

    def _restamp_frame_markers(self, fr, qmap: dict, fmap: dict) -> None:
        r"""把一个**子 frame** 里的 data-dsh-* 从"帧内编号"重贴成"全局编号"。

        ## 为什么必须一帧一次、按映射整体改

        SCAN_JS 是在每个 frame 里各跑一遍的，编号**每帧都从 0 开始**，
        合并到 Python 侧才加上偏移。所以搬进 DOM 的必须是 old→new 的**映射**，
        而不是"把第 N 个元素改成 N"。

        ⚠ 上一版（_restamp_markers）是**按 item 逐个调用**、每次 querySelector
          只找**第一个**元素改 —— 一个 frame 里有 3 个输入框时，标记会变成
          [2, 1, 2]（实测），于是 ill(f0) 找不到元素、
          ill(f2) 把答案写进**第 1 格** —— 这就是用户说的"填空错位"。

          题目那边更糟：每次调用都把**整帧**元素贴成当前这道的 qid，
          循环走完整帧只剩**最后一题**的 qid（实测 8 个元素全是 qid=1）→
          自定义组件题直接**点到别的题上**（串题）。

        ## 为什么 oid / coid 不用改

        它们本来就是"本题内第几个选项"（落地段里的 oi），
        全局编号变化不影响它。

        ## 为什么一次遍历就安全

        每个元素只被**读一次、写一次**，而且读取发生在它自己被改写之前 ——
        不会出现"读到别的元素刚写进去的新值"。
        """
        try:
            fr.evaluate(
                r"""([qmap, fmap]) => {
                    function reAttr(attr, map) {
                        document.querySelectorAll('[' + attr + ']').forEach(function (e) {
                            const old = e.getAttribute(attr);
                            if (map[old] === undefined) return;
                            e.setAttribute(attr, String(map[old]));
                        });
                    }
                    // 原生与自定义分开改，避免两类互相踩
                    reAttr('data-dsh-qid', qmap);
                    reAttr('data-dsh-cqid', qmap);
                    reAttr('data-dsh-fid', fmap);
                    return {
                        q: document.querySelectorAll(
                            '[data-dsh-qid],[data-dsh-cqid]').length,
                        f: document.querySelectorAll('[data-dsh-fid]').length
                    };
                }""",
                [qmap, fmap],
            )
        except Exception as e:
            # ⚠ 失败**不能完全静默**：第一版这里就是 `except: pass`，
            #   于是一整类错误（比如参数字典的 key 必须是字符串）被吞掉，
            #   表现只是"重贴没生效"、标记停在帧内编号 —— 查了很久。
            #   现在记一次埋点 + 打一条日志（不抛，扫描还要继续）。
            try:
                metrics.record(metrics.CHOOSE_FAIL,
                               url=getattr(self.page, "url", ""),
                               detail=f"restamp_frame_fail {type(e).__name__}: "
                                      f"{str(e)[:80]}")
            except Exception:
                pass
            try:
                if not getattr(self, "_restamp_failed_logged", False):
                    self._restamp_failed_logged = True
                    self.log(f"⚠ 跨 frame 标记重贴失败（{type(e).__name__}）——"
                             f"落笔将退到「帧内位置」兜底，请把日志发给作者")
            except Exception:
                pass

    def _stem_via_frame_chain(self, fr) -> str:
        r"""沿**字段自己的 frame 链**逐层往上找题干。

        ## 为什么不能只看直接父文档（这是"填写错位"的根治点）

        实测：字段的帧是子框架，但**只看直接父文档拿到 0 字** ——
        真实结构是**嵌套**的：

            主文档
              div.questionLi
                ├ 题干文字                      ← 要的是它（在第 2 层才看得到）
                └ iframe (外层)
                     └ 子文档
                          div.eidtDiv
                            ├ iframe (编辑器)   ← 字段就在这一层
                            └ textarea

        从编辑器 iframe 往上，在**它自己的父文档**里只看得到工具栏
        （"段落格式 字体 字号"，9 字，被 12 字阈值挡掉）→ 0 字。
        再往外一层（外层 iframe 的父文档 = 主文档）才看得到题干。

        所以要一层层地：
          `frame_element()`（拿到本层 iframe 元素）
          → 在它所在的父文档里往上走
          → 没有就 `parent_frame` 跳到再外一层，重复。

        ## 为什么必须用它而不是"按序号猜"

        兜底的"主文档里第 N 个题块"是**纯按序号**对应的：
        字段顺序按 `page.frames` 枚举，题块顺序按 DOM —— 两者不一致时，
        模型答的是第 18 题、字却写进第 19 题的框里，**比填不进去严重得多**。
        用 frame 链是"从这一次作答区自己出发"去找它的题干，天然对得上。
        """
        cur = fr
        for _ in range(4):
            if cur is None:
                break
            try:
                if cur == self.page.main_frame:
                    break
            except Exception:
                pass
            try:
                el = cur.frame_element()
                txt = el.evaluate(self._WALK_UP_STEM_JS) or ""
                if txt and len(str(txt)) >= 12:
                    return str(txt)
            except Exception:
                pass
            try:
                cur = cur.parent_frame
            except Exception:
                break
        return ""

    def _field_stem_from_dom(self, fid: int) -> str:
        """同文档兜底：从 `[data-dsh-fid]` 元素往上找最像题干的一层。

        ⚠ 这里有两类要分开处理：

          · 普通输入框 → 看祖先的文字（第一层"够长"的祖先通常就是题目块）
          · **可编辑区就是文档的 `<body>`**（学习通的编辑器是 designMode 的 body）
            → 它的祖先只有 `<html>`，再往上就出文档了，**在本文档里根本找不到题干**。
              实测快照：`fid=0 <body class='view' contenteditable='true'>`，
              上一层 `<html>` 文字为空。这种情况必须靠父文档（enrich 的路径①/③）。

        ⚠ 原写法 `while (n && n !== document.body ...)` 还有个副作用：
          当可编辑元素**就是** body 时，循环从 `<html>` 开始、
          `html !== document.body` 成立，于是查 `<html>`（没文字）后就到顶了 ——
          逻辑上没错，但结果必然是空。这里额外把"元素自己是不是 body"
          判出来，便于日志区分"真没有"和"找错地方"。
        """
        fr = self._frame_for(fid, field=True)
        try:
            return self._ev(fr, r"""(fid) => {
                function stemText(n) {
                    var v = n.innerText;
                    if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
                    try {
                        var c = n.cloneNode(true);
                        c.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
                        return (c.textContent || '').replace(/\s+/g, ' ').trim();
                    } catch (x) { return ''; }
                }
                const e = document.querySelector('[data-dsh-fid="' + fid + '"]');
                if (!e) return '';
                // 可编辑区就是 body → 本文档里没有题干可找
                if (e === document.body) return '';
                // 同 _WALK_UP_STEM_JS：优先返回"像题目"的那一层，
                // 不被工具栏/源码层挡住（真机 4 道填空题就是被工具栏挡住的）。
                function looksLikeQuestion(t) {
                    if (!t) return false;
                    if (/【(单选|多选|判断|填空|简答|论述|名词解释)题】/.test(t)) return true;
                    if (/^\s*\d{1,3}\s*[.、．]\s*\S/.test(t)) return true;
                    return false;
                }
                function trimChrome(t) {
                    var m = t.search(/点击上传|段落格式|字体\s*字号|字号\s*字体/);
                    return (m > 8 ? t.slice(0, m) : t).trim();
                }
                let n = e.parentElement, hops = 0, first = '';
                while (n && n !== document.body && hops < 10) {
                    const t = stemText(n);
                    if (t.length >= 12) {
                        if (!first) first = t;
                        if (looksLikeQuestion(t)) return trimChrome(t).slice(0, 600);
                    }
                    n = n.parentElement; hops++;
                }
                return first.slice(0, 600);
            }""", str(fid)) or ""
        except Exception:
            return ""

    def _essay_blocks_in_main_doc(self) -> list[str]:
        r"""在主文档里找出"装着编辑器 iframe / 隐藏 textarea 的题目块"的文字。

        ## 为什么需要这条路

        学习通问答题的真实结构（来自 `out\quiz_dom.txt` 的实测）：

            主文档:  div.questionLi
                       ├ 题干文字                        ← ★ 要的就是它
                       └ div.eidtDiv
                            ├ iframe  ← 真正可编辑的 body 在**这个子文档**里
                            └ textarea(display:none)

        也就是说：**题干在主文档，作答区在子文档**。
        从子文档往上找永远出不去；而主文档里那个 `iframe` 元素本身没有文字，
        所以"从 iframe 往上找"（路径①）也可能一路只看到工具栏。

        这条路换个方向：**直接在主文档里，把"含有 iframe 或隐藏 textarea 的
        题目块"收集起来**，按 DOM 顺序对应到第几个论述题。
        取到的文字里可能带一点工具栏词（"段落格式 字体 字号"），
        但那是给模型看的上下文，比"题干未识别"有用得多。

        返回值：按 DOM 顺序排列的题目块文字列表。
        """
        try:
            return self._ev(self.page.main_frame, r"""() => {
                function stemText(n) {
                    var v = n.innerText;
                    if (v && v.trim()) return v.replace(/\s+/g, ' ').trim();
                    try {
                        var c2 = n.cloneNode(true);
                        c2.querySelectorAll('script,style,noscript,template').forEach(function (x) { x.remove(); });
                        return (c2.textContent || '').replace(/\s+/g, ' ').trim();
                    } catch (x) { return ''; }
                }
                const out = [];
                // ★ 必须用**一条**选择器查询，才能得到 DOM 顺序。
                //   ⚠ 原来是 `querySelectorAll('iframe')` 和
                //     `querySelectorAll('textarea')` 分两次查再拼接 ——
                //     那样得到的是"先所有 iframe、再所有 textarea"，
                //     **不是 DOM 顺序**，按序号对应时会整体错位。
                document.querySelectorAll('iframe, textarea').forEach(function (c) {
                    // textarea 只收"隐藏的"（富文本编辑器的提交备用件）；
                    // 可见的 textarea 是普通填空题，不该占论述题的位子
                    if (c.tagName === 'TEXTAREA') {
                        const r = c.getBoundingClientRect();
                        const st = getComputedStyle(c);
                        const hidden = (r.width < 2 && r.height < 2)
                            || st.display === 'none' || st.visibility === 'hidden';
                        if (!hidden) return;
                    }
                    // 往上找"题目块"：第一层能给出 >=12 字文字的祖先
                    let n = c.parentElement, hops = 0;
                    while (n && n !== document.body && hops < 8) {
                        const t = stemText(n);
                        if (t.length >= 12) {
                            if (out.indexOf(t) < 0) out.push(t.slice(0, 600));
                            break;
                        }
                        n = n.parentElement; hops++;
                    }
                });
                return out;
            }""") or []
        except Exception:
            return []

    def _remember_options(self, state: PageState) -> None:
        """记下每道题的选项信息，供落笔时重建定位用。

        ⚠ 必须记 name：真实站点（Element UI / Vue / React）勾选后会重建整个题块，
        我们打在元素上的 data-dsh-* 标记会**全部消失**（实测 4 个 → 0 个）。
        那时唯一还能重新找回这道题的办法，就是靠 radio 的 name 分组，
        或者靠选项文字去匹配。

        ⚠ 也要记 **frame**：iframe 里的题只能用那个 frame 的
        `evaluate / locator` 去操作（`page.*` 不穿透 iframe）。见 `_frame_for`。
        """
        try:
            for q in state.questions:
                self._options_snapshot[q.qid] = {
                    "ids": [o.get("id", i) for i, o in enumerate(q.options)],
                    "texts": [str(o.get("text", ""))[:80] for o in q.options],
                    "values": [o.get("value") for o in q.options],
                    "n": len(q.options),
                    "name": getattr(q, "name", "") or "",
                    "kind": q.kind,
                }
                self._frames_by_qid[q.qid] = getattr(q, "frame", None)
            for f in getattr(state, "fields", []) or []:
                self._frames_by_fid[f.fid] = getattr(f, "frame", None)
                # 给 fill() 用的轻量登记表：这张表只活在 Python 侧，
                # 决定"这个字段要不要走富文本写入通道"
                self._field_meta[f.fid] = {
                    "essay": bool(getattr(f, "essay", False)
                                  or getattr(f, "kind", "") == "essay"),
                    "qno": getattr(f, "qno", "") or "",
                    # ★ 帧内位置：标记失效时靠它定位（见 fill 的 count 快检）
                    "idx": int(getattr(f, "in_frame_idx", -1)),
                }
        except Exception:
            pass

    def _frame_for(self, item_id: int, *, field: bool = False):
        """取"这个题目/填空所在的框架"。主文档返回 None。

        ⚠ 这是审计 C-25 的核心修复点。
          `page.evaluate()` 与 `page.locator()` **只在主文档生效**，不穿透 iframe。
          而 `scan()` 会把 iframe 里的题合并进同一个 state ——
          于是那些题"扫得到、点不着、也回读不到"，
          表现是"翻页正常、一题都没落笔"（还很难查，因为日志说没生效）。

        拿到 frame 之后，落笔与回读统一走 `_ev(frame, ...)` / `_loc(frame, ...)`。
        """
        reg = self._frames_by_fid if field else self._frames_by_qid
        fr = reg.get(item_id)
        # 主文档（或没记录）→ 返回 None，调用方回退到 self.page
        if fr is None or fr == self.page.main_frame:
            return None
        return fr

    def _ev(self, frame, js: str, arg=None):
        """在指定框架（None=主文档）里执行 JS。"""
        return (frame or self.page).evaluate(js, arg)

    def _note(self, text: str) -> None:
        r"""把"浏览器是怎么开的"这类关键信息**同时**写进日志文件和界面。

        ⚠ 原来这几条提示用的是 `print()` —— 而交付版是 exe 启动的，
          **没有可见控制台**，那些字等于丢了。后果很具体：
          用户点了「打开浏览器登录」、也登录好了，但程序到底是用
          **他登录的那个浏览器**、还是**另外新开了一个未登录的**，
          日志里完全看不出来 —— 于是遇到登录页被拦时，
          用户根本无从判断是自己没登录、还是程序没用上他的登录态。

          这类"程序做了决定但不说"的信息，必须进日志。
        """
        msg = f"[浏览器] {text}"
        try:
            if self.log:
                self.log(msg)
        except Exception:
            pass
        # 顺带打到控制台：命令行/开发场景下能直接看到，不影响交付版
        try:
            print(f"[browser] {text}")
        except Exception:
            pass

    def _loc(self, frame, selector: str):
        """在指定框架（None=主文档）里取 locator。

        ⚠ 用 `frame.locator` 而不是 `page.frame_locator(...)`：
          后者返回的是"定位器工厂"，写法不同且更绕；
          而我们手上已经有 Frame 对象了，直接用最省事、语义也最清楚。
        """
        return (frame or self.page).locator(selector)

    def frame_origin(self, frame) -> tuple[float, float]:
        """框架（iframe）在**页面坐标系**里的左上角。

        审计 C-30：`getBoundingClientRect()` 在 iframe 内部是
        **相对该 iframe 视口**的，而 `page.mouse.click()` 用的是主页面视口坐标。
        只要 iframe 有偏移或内部滚动过，直接拿内层坐标去点就会点到别处
        （可能点到无关链接）。所以要加上这个原点偏移。

        主文档或取不到时返回 (0, 0)。
        """
        if frame is None or frame == self.page.main_frame:
            return (0.0, 0.0)
        try:
            el = frame.frame_element()
            box = el.bounding_box()
            if box:
                return (float(box["x"]), float(box["y"]))
        except Exception:
            pass
        return (0.0, 0.0)

    def click_in_frame(self, frame, x: float, y: float) -> tuple[float, float]:
        """在框架内用**真实鼠标**点击（自动换算到页面坐标）。

        返回实际点击的页面坐标，便于日志核对。
        """
        ox, oy = self.frame_origin(frame)
        px, py = float(x) + ox, float(y) + oy
        self.page.mouse.click(px, py)
        return px, py

    @staticmethod
    def _to_state(raw: dict) -> PageState:
        return PageState(
            url=raw.get("url", ""),
            title=raw.get("title", ""),
            questions=[
                Question(
                    qid=q["qid"], kind=q["kind"], stem=q["stem"], options=q["options"],
                    name=q.get("name", ""), in_view=q.get("in_view", True), box=q.get("box", {}),
                )
                for q in raw.get("questions", [])
            ],
            fields=[
                Field(
                    fid=f["fid"], kind=f["kind"], stem=f.get("stem", ""), label=f.get("label", ""),
                    value=f.get("value", ""), options=f.get("options", []),
                    in_view=f.get("in_view", True), multiline=f.get("multiline", False),
                    qno=f.get("qno", ""), essay=bool(f.get("essay", False)),
                )
                for f in raw.get("inputs", [])
            ],
            images=raw.get("images", []),
            buttons=raw.get("buttons", []),
            headings=raw.get("headings", []),
            viewport=raw.get("viewport", {}),
            scroll_y=raw.get("scrollY", 0),
            scroll_h=raw.get("scrollH", 0),
            deduped=raw.get("deduped", 0),
            deduped_frag=raw.get("deduped_frag", 0),
        )

    # ------------------------------------------------------------ 落笔
    #
    # 这一块踩过两个很贵的坑，都写在这里免得以后再犯：
    #
    #   坑①：只 click(force=True)，从不回读 checked。对"原生控件被藏起来、
    #        靠外层 label 响应"的站点，等于点了空气却报 ✔ —— 表现就是
    #        "翻页正常、一题都没落笔"。
    #
    #   坑②：用扫描时打的 data-dsh-qid/data-dsh-oid 去自查。组件（Vue/React）
    #        勾选后会重渲染，节点被重建，**这些标记随之消失**；之后的查询
    #        全部落空，Playwright 又按默认 30 秒超时干等，一次落笔能拖到
    #        120 秒以上，并且把已经勾上的判成"未生效"。
    #
    # 现在：自查一律**即时重解析 DOM**（不依赖会失效的标记），
    #      并且每个查询/点击都带显式超时，绝不等 30 秒。

    def _resolve_options(self, qid: int) -> dict | None:
        """取回第 qid 题的选项信息（跨重渲染容错）。

        优先用扫描时登记的 _options_snapshot；标记还在就直接用，
        标记没了也能靠 name / 选项文字把这道题重新找回来。
        """
        snap = self._options_snapshot.get(qid)
        if snap and self._dom_has_options(qid, snap):
            return snap
        if snap:
            # 标记被重渲染冲掉了，但快照本身仍然有效（题干、选项文字、name 都在）
            return snap
        return None

    def _dom_has_options(self, qid: int, snap: dict) -> bool:
        """我们打在 DOM 上的标记是否还在（组件重渲染后就会失效）。

        ⚠ 也要在**该题所在的框架**里查：iframe 里的标记在主文档里当然找不到，
          原来会因为这一点把"标记还在"误判成"标记没了"，
          然后走一遍多余的重建流程。
        """
        try:
            n = self._ev(self._frame_for(qid),
                         """(qid) => document.querySelectorAll('[data-dsh-qid="' + qid + '"]').length""",
                         qid)
            return int(n or 0) >= max(1, len(snap.get("ids", [])))
        except Exception:
            return False

    # 页面内通用的"第 qid 题第 oid 个选项"定位脚本片断。
    # 全部用即时重解析，绝不依赖可能已经失效的 data-dsh-* 标记。
    _FIND_JS = r"""
        function dshEscape(s) {
          return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s);
        }

        // ------------------------------------------------------------------
        // ★ 穿透 shadow DOM 的查询助手（落笔/回读侧）★
        //
        // 为什么落笔侧也要它：扫描侧已经能看见影子树里的题了，
        //   但**回读选中状态**原来用 `document.querySelector`，
        //   它同样不穿透 shadow root。实测出现的假失败：
        //       落笔报告  ✘未生效(④JS:状态仍未变)
        //       实际状态  [false, true, false]   ← 其实点中了
        //   于是程序白跑四套策略、还会把题目记成"落笔失败"。
        //
        // ⚠ 这段必须**自包含**：_FIND_JS 是独立注入的片断，
        //   拿不到 SCAN_JS 里的 dshQueryAll，所以这里再来一份。
        //   两处逻辑要保持一致（都是"document + 所有 open shadow root"）。
        // ------------------------------------------------------------------
        function dshDeepAll(sel) {
          var seen = [];
          function push(list) {
            for (var i = 0; i < list.length; i++) {
              if (seen.indexOf(list[i]) < 0) seen.push(list[i]);
            }
          }
          try { push(document.querySelectorAll(sel)); } catch (e) { /* 忽略 */ }
          try {
            var all = document.querySelectorAll('*');
            var roots = [];
            for (var i = 0; i < all.length && roots.length < 60; i++) {
              if (all[i].shadowRoot) roots.push(all[i].shadowRoot);
            }
            for (var r = 0; r < roots.length; r++) {
              try { push(roots[r].querySelectorAll(sel)); } catch (e2) { /* 忽略 */ }
            }
          } catch (e) { /* 忽略 */ }
          return seen;
        }
        function dshDeepOne(sel) {
          var a = dshDeepAll(sel);
          return a.length ? a[0] : null;
        }

        // 判定"自定义选项现在是不是选中状态"。
        //
        // ⚠ 必须看**后代**：很多平台选中时改的是内部那个圆圈 div 的类，
        //   外层 label 自己的 class 从头到尾不变。只看自己会永远判成"未选中"。
        // ⚠ 这段必须**自包含**：_FIND_JS 是独立注入的片断，
        //   访问不到 SCAN_JS 里的函数，所以不能直接调 dshIsSelected。
        //   词表用占位符嵌入 _SEL_RE_SRC，和扫描那份保持同一份来源。
        function dshChecked(e) {
          if (!e) return false;
          if (typeof e.checked === 'boolean' && e.tagName === 'INPUT') return e.checked;
          var aria = (e.getAttribute('aria-checked') || '').toLowerCase();
          if (aria === 'true') return true;
          if (aria === 'false') return false;
          if (e.hasAttribute && (e.hasAttribute('data-selected')
              || e.getAttribute('data-checked') === 'true')) return true;
          // Radix / shadcn 这类组件用 aria-pressed 或 data-state 表达选中。
          if ((e.getAttribute('aria-pressed') || '').toLowerCase() === 'true') return true;
          var dst = (e.getAttribute('data-state') || '').toLowerCase();
          if (dst === 'checked' || dst === 'on') return true;

          var SEL = /__DSH_SEL_RE__/i;
          // 同上：先剔掉 CSS 工具类（user-select 之类），否则误判成已选中
          var NOISE = /(^|[\s_-])(user-select|select-none|select-text|select-all|select-auto)([\s_-]|$)/gi;
          var nodes = [e];
          try {
            nodes = nodes.concat(Array.prototype.slice.call(e.querySelectorAll('*'), 0, 16));
          } catch (err) { /* 忽略 */ }

          for (var i = 0; i < nodes.length; i++) {
            var n = nodes[i];
            var c = (typeof n.className === 'string') ? n.className : '';
            if (c) {
              c = c.replace(NOISE, ' ');
              if (SEL.test(c)) return true;
              // ★ 2026-10-28 真机事故：这里原来还有两条「背景色 = 选中」的启发式。
              //   学习通新作业页的选项正文是从别处粘进来的富文本，里面带
              //   `<span style="background-color: rgb(239,240,241)">`（代码块底色），
              //   于是**每一个选项**都被判成「已选中」→ 程序一次都不点，
              //   单选/多选整片空白。背景色不是选中态，删掉这两条。
            }
            var nst = n.getAttribute && (n.getAttribute('data-state') || '').toLowerCase();
            if (nst === 'checked' || nst === 'on') return true;
          }
          return false;
        }
        // 找回"自定义选项组"：标记还在就用标记，否则按 role/aria-checked/成组 label 重新找
        function dshCustomGroup(snap, qid) {
          var marked = document.querySelectorAll('[data-dsh-cqid="' + qid + '"]');
          if (marked.length) return Array.prototype.slice.call(marked);
          var out = [], seen = [];
          function push(e) {
            if (!e || seen.indexOf(e) >= 0) return;
            seen.push(e); out.push(e);
          }
          // ------------------------------------------------------------------
          // ⚠ 这里**不许**无条件把整帧所有 role/aria 元素都收进来。
          //
          //   实测（体检用例 D）：一个 iframe 里有两道自定义组件题时，
          //   按标记找不到（标记串了）→ 落到这里 → 收进**整帧 8 个选项** →
          //   上层 `cg[oid]` 取到的是**第 2 题的选项** →
          //   “q0 的答案点到了 q2 上”（串题）。
          //
          //   原则（方案 §3-4）：**任何"按文字/按序号找回"的兜底都不许返回
          //   "整帧所有候选元素"**。宁可这一题不答，也不要答到别的题上。
          //
          //   做法：只有当收进来的候选数**恰好等于**本题选项数时才认；
          //        否则返回空数组，由上层如实记为"定位失败"。
          // ------------------------------------------------------------------
          var cand = [];
          document.querySelectorAll('[role=radio],[role=checkbox],[aria-checked]')
            .forEach(function (e) { cand.push(e); });
          var want = (snap && snap.texts) ? snap.texts.length : 0;
          if (want && cand.length === want) {
            cand.forEach(function (e) { push(e); });
          }
          // 智慧树这类：选项是 <label>，里面没有 input、没有 role/aria。
          // 只收"像选项的 label"（尺寸、文字长度都合理），避免把无关 label 收进来。
          if (out.length < 2) {
            document.querySelectorAll('label').forEach(function (e) {
              if (e.querySelector('input,textarea,select')) return;
              var r = e.getBoundingClientRect();
              if (r.width < 40 || r.height < 14) return;
              if (r.width > 1200 || r.height > 200) return;
              var t = (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
              if (t.length < 1 || t.length > 120) return;
              push(e);
            });
          }
          // ------------------------------------------------------------------
          // ★ 第三条兜底：**按选项文字把组找回来**。
          //
          // 为什么需要：学习通（超星）章节测验的选项是 `<div class="opt">`
          //   加一个圆形字母圈 —— 既不是 label、也没有 role/aria-checked，
          //   上面两条全都不匹配，于是 dshCustomGroup 返回空数组，
          //   `_is_checked` 拿不到元素 → **明明点上了却判成"未生效"**。
          //   （实测：页面自报 answered=2，程序却报"选项元素在 DOM 里找不到"）
          //
          // 做法：拿扫描时存下的选项文字，在 DOM 里逐条找回最像的那个元素。
          //   要求"文字以选项文字开头"并且排除掉包含其它选项的大容器，
          //   避免把整个题块当成选项。
          // ------------------------------------------------------------------
          if (out.length < 2 && snap && snap.texts && snap.texts.length) {
            var want = snap.texts;
            var found = [];
            var pool = document.querySelectorAll('div,li,span,a,p,label,td');
            for (var wi = 0; wi < want.length; wi++) {
              var wt = String(want[wi] || '').replace(/\s+/g, ' ').trim();
              if (wt.length < 1) { found.push(null); continue; }
              // 去掉开头的 "A " / "A." / "(A)" 这类字母前缀再比对
              var bare = wt.replace(/^\s*[（(]?\s*[A-Za-z]\s*[)）.、:：]?\s*/, '');
              var hit = null;
              for (var pi = 0; pi < pool.length; pi++) {
                var e = pool[pi];
                var t = (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
                if (!t) continue;
                if (t.length > (bare.length + 40)) continue;   // 太大：多半是容器
                if (t !== wt && t !== bare
                    && t.indexOf(bare) !== 0 && bare.indexOf(t) !== 0) continue;
                if (e.querySelector && e.querySelector('input,textarea,select')) continue;
                var rr = e.getBoundingClientRect();
                if (rr.width < 16 || rr.height < 10) continue;
                // 取**最内层**的那个：命中越深越可能是选项本身，
                // 而不是把它包进去的题目容器。
                if (!hit) { hit = e; }
                else if (hit.contains(e)) { hit = e; }        // e 是 hit 的后代 → 更内层
                // 反之（e 是 hit 的祖先）就保持 hit 不变
              }
              found.push(hit);
            }
            // 至少要凑齐一半，才认为这组认得靠谱
            var okCount = found.filter(function (x) { return !!x; }).length;
            if (okCount >= 2) {
              found.forEach(function (x) { if (x) push(x); });
            }
          }
          return out;
        }
        // 找回"选项控件组"：返回按 DOM 顺序排列的 input 数组
        function dshGroup(snap) {
          var sel = 'input[type=radio],input[type=checkbox]';
          // ① name 是最可靠的：同一题的 radio 共享 name
          if (snap && snap.name) {
            var byName = document.querySelectorAll(
              'input[name="' + dshEscape(snap.name) + '"]');
            if (byName.length) return Array.prototype.slice.call(byName);
          }
          // ② 标记还在
          var marked = document.querySelectorAll('[data-dsh-qid]');
          if (marked.length) {
            var out = [], seen = [];
            marked.forEach(function (m) {
              var nm = m.name || '';
              var g = nm ? document.querySelectorAll('input[name="' + dshEscape(nm) + '"]')
                         : [m];
              g.forEach(function (x) {
                if (seen.indexOf(x) < 0) { seen.push(x); out.push(x); }
              });
            });
            if (out.length) return out;
          }
          // ③ 按选项文字找：拿第一个选项的文字去匹配
          if (snap && snap.texts && snap.texts.length) {
            var probe = (snap.texts[0] || '').trim();
            if (probe.length >= 1) {
              var all = document.querySelectorAll(sel);
              for (var i = 0; i < all.length; i++) {
                var el = all[i];
                var lb = el.closest('label');
                var t = lb ? (lb.innerText || '') : '';
                if (!t && el.parentElement) t = el.parentElement.innerText || '';
                if (t.indexOf(probe) >= 0) {
                  // 以它所在的 name 组为准
                  var nm2 = el.name || '';
                  if (nm2) {
                    var g2 = document.querySelectorAll(
                      'input[name="' + dshEscape(nm2) + '"]');
                    if (g2.length) return Array.prototype.slice.call(g2);
                  }
                }
              }
            }
          }
          return [];
        }
    """

    def _is_checked(self, qid: int, oid: int, wait_ms: int = 700) -> bool:
        """第 qid 题第 oid 个选项当前是否被勾选。

        支持三种"选中"的表达方式：
          ① 原生 input 的 .checked
          ② 自定义组件的 aria-checked="true"
          ③ 自定义组件的类名（checked / selected / active / is-checked …）

        每次都**重新解析**当前 DOM，不依赖 data-dsh-* 是否还在
        —— 组件重渲染会把标记全部冲掉（实测 4 个 → 0 个）。
        用 page.evaluate 而不是 locator：evaluate 不做 auto-wait，
        找不到元素立刻返回，不会干等 30 秒默认超时。
        """
        import time as _t
        snap = self._resolve_options(qid) or {}
        end = _t.time() + max(0.05, wait_ms / 1000.0)
        js = ("(a) => {" + _js_with_sel(self._FIND_JS) + """
            var snap = a[0], oid = Number(a[1]), qid = String(a[2]), oidS = String(a[3]);
            // ⚠ 用 dshDeepOne 而不是 document.querySelector ——
            //   后者不穿透 shadow root，会把"其实点中了"误报成"未生效"。
            var marked = dshDeepOne(
                '[data-dsh-qid="' + qid + '"][data-dsh-oid="' + oidS + '"]');
            if (marked) return !!marked.checked;
            var g = dshGroup(snap);
            if (g.length > oid) return !!g[oid].checked;
            // 自定义组件
            var cu = dshDeepOne(
                '[data-dsh-cqid="' + qid + '"][data-dsh-coid="' + oidS + '"]');
            if (cu) return dshChecked(cu);
            var cg = dshCustomGroup(snap, qid);
            if (cg.length > oid) return dshChecked(cg[oid]);
            // ★ 学习通新版卷子：真实答案写在隐藏 input `#answer<qid>`（值如 "AC"），
            //   比猜 class 可靠。选项元素自带 qid 属性，题号就在里面。
            var cur = dshDeepOne('[data-dsh-cqid="' + qid + '"][data-dsh-coid="' + oidS + '"]');
            if (cur) {
              var pid = cur.getAttribute('qid');
              if (!pid && cur.closest) {
                var host = cur.closest('[qid]');
                pid = host ? host.getAttribute('qid') : '';
              }
              if (pid) {
                var ansEl = document.getElementById('answer' + pid);
                if (ansEl) {
                  var letterEl = cur.querySelector('[data]');
                  var letter = letterEl ? String(letterEl.getAttribute('data') || '') : '';
                  if (letter) return String(ansEl.value || '').indexOf(letter) >= 0;
                }
              }
            }
            return null;
        }""")
        # ★ 回读也要落到"这道题所在的框架"里。
        #   否则 iframe 里的题会出现**假失败**：点击其实生效了，
        #   但主文档里读不到状态 → 报"未生效" → 白跑四套策略（审计 C-25）。
        fr = self._frame_for(qid)
        while True:
            try:
                hit = self._ev(fr, js, [snap, oid, str(qid), str(oid)])
            except Exception:
                hit = None
            if hit is True:
                return True
            if _t.time() >= end:
                return False
            _t.sleep(0.06)

    def _mark_click_targets(self, qid: int, oid: int) -> int:
        """把"点它最可能生效"的可见容器打上 data-dsh-click="i"，返回数量。

        返回下标而不是元素句柄：句柄（evaluate_handle）在某些 Playwright
        版本上取到的不是元素，容易静默失败；打标记后用 locator 点击最稳。

        候选优先级：
          ① 与 input 关联的 <label>（原生控件最标准，浏览器自动转发点击）
          ② 附近"本选项专属"的可见外壳（.el-radio / [role=radio] / li / td…）
          ③ input 自身（有的站点其实能直接点到）
        跳过 0 尺寸的隐藏 input —— 点它没意义还白等超时。
        """
        snap = self._resolve_options(qid) or {}
        js = ("(a) => {" + _js_with_sel(self._FIND_JS) + """
            var snap = a[0], qid = String(a[1]), oid = Number(a[2]);
            // ⚠ 这里一律用 dshDeepAll（穿透 shadow DOM），不要用 document.querySelector：
            //   ① shadow root 里的元素，普通查询找不到；
            //   ② 打标记与后面点击必须落在**同一个根**里，否则点不到。
            var e = dshDeepOne(
                '[data-dsh-qid="' + qid + '"][data-dsh-oid="' + oid + '"]');
            // ---- 自定义选项组件（页面上没有原生 input）----
            var custom = null;
            if (!e) {
                custom = dshDeepOne(
                    '[data-dsh-cqid="' + qid + '"][data-dsh-coid="' + oid + '"]');
                if (!custom) {
                    var cg = dshCustomGroup(snap, qid);
                    if (cg.length > oid) {
                        custom = cg[oid];
                        cg.forEach(function (x, i) {
                            x.setAttribute('data-dsh-cqid', qid);
                            x.setAttribute('data-dsh-coid', String(i));
                        });
                    }
                }
            }
            if (!e) {
                if (!custom) return 0;
                // 自定义组件：直接点它自己（它自己就是可点区域）
                dshDeepAll('[data-dsh-click]').forEach(function (x) {
                    x.removeAttribute('data-dsh-click');
                });
                var r0 = custom.getBoundingClientRect();
                if (r0.width < 6 || r0.height < 6) return 0;
                custom.setAttribute('data-dsh-click', '0');
                return 1;
            }
            if (!e) return 0;

            dshDeepAll('[data-dsh-click]').forEach(function (x) {
                x.removeAttribute('data-dsh-click');
            });

            var seen = [], pick = [];
            function add(c) {
                if (!c || seen.indexOf(c) >= 0) return;
                seen.push(c);
                var r = c.getBoundingClientRect();
                var s = getComputedStyle(c);
                if (r.width < 6 || r.height < 6) return;
                if (s.display === 'none' || s.visibility === 'hidden') return;
                if (parseFloat(s.opacity || '1') <= 0.05) return;
                if (r.width > 460 && r.height > 300) return;   // 整块题区，别点
                pick.push(c);
            }
            var lb = null;
            if (e.id) {
                try { lb = dshDeepOne('label[for="' + dshEscape(e.id) + '"]'); }
                catch (err) { lb = null; }
            }
            if (!lb) lb = e.closest('label');
            add(lb);

            var nm = e.name || '';
            function mine(el) { return nm ? (el.name === nm) : true; }
            var n = e.parentElement, hops = 0;
            while (n && n !== document.body && hops < 5) {
                var others = n.querySelectorAll('input[type=radio],input[type=checkbox]');
                var hasOther = false;
                for (var i = 0; i < others.length; i++) {
                    if (others[i] !== e && !mine(others[i])) { hasOther = true; break; }
                }
                if (!hasOther) add(n);
                n = n.parentElement; hops++;
            }
            add(e);

            pick.forEach(function (c, i) { c.setAttribute('data-dsh-click', String(i)); });
            return pick.length;
        }""")
        try:
            # 打标记要落在"这道题所在的框架"里（iframe / shadow DOM 都靠它）
            return int(self._ev(self._frame_for(qid), js, [snap, qid, oid]) or 0)
        except Exception:
            return 0

    def _activate_in_page(self, qid: int, oid: int, snap: dict | None = None) -> str:
        r"""在页面内直接激活选项 —— 学浏览器插件的做法。

        为什么放在鼠标点击**之前**：
          插件是注入到页面里跑的，可以直接 `el.click()`，
          不存在"元素被遮住 / 滚出视口 / 被透明层挡住"的问题。
          Playwright 是在页面外模拟鼠标，必须命中坐标；真实作业页上
          经常有固定底栏、悬浮客服、加载遮罩，鼠标点两三次都没中，
          3.5 秒预算就耗尽了，最后那一步 JS 兜底根本轮不到。
          所以先走页面内激活（快、稳），失败再退回鼠标点击。

        只处理原生 input（有 .checked 这种可信回读）；自定义组件继续走
        原来的鼠标路径 —— 它们没有可信状态，点了又读不到会被当成失败，
        再点一次反而把选中取消。

        返回 "input-click" / "input-set" / ""。
        """
        snap = snap or {}
        js = ("(a) => {" + _js_with_sel(self._FIND_JS) + """
            var snap = a[0], oid = Number(a[1]), qid = String(a[2]);
            var e = dshDeepOne(
                '[data-dsh-qid="' + qid + '"][data-dsh-oid="' + oid + '"]');
            if (!e) {
                var g = dshGroup(snap);
                if (g.length > oid) e = g[oid];
            }
            if (e && e.tagName === 'INPUT') {
                if (e.disabled) return 'disabled';
                // 原生 click：浏览器自己切换 checked，同时触发框架的
                // click/change 监听（React 的 radio 就是靠 click 更新的）。
                try { e.click(); } catch (err) { /* 继续尝试 setter */ }
                if (e.checked) return 'input-click';
                // 少数受控组件会把 click 拦掉，用原型 setter 补一次。
                try {
                    var setter = Object.getOwnPropertyDescriptor(
                        window.HTMLInputElement.prototype, 'checked').set;
                    setter.call(e, true);
                    e.dispatchEvent(new Event('input', {bubbles: true}));
                    e.dispatchEvent(new Event('change', {bubbles: true}));
                } catch (err) { /* 交给鼠标兜底 */ }
                return e.checked ? 'input-set' : '';
            }
            // 自定义组件不在这里点：它们没有 .checked 这种可信回读，
            // 点了又读不到状态会被上层当成失败，再点一次反而把选中取消。
            // 这类页面继续走原来的鼠标路径。
            return '';
        }""")
        try:
            return str(self._ev(self._frame_for(qid), js, [snap, oid, str(qid)]) or "")
        except Exception:
            return ""

    def choose(self, qid: int, option_ids: list[int], hidden_hint: bool = False) -> list[str]:
        """点选项（单选/多选）。返回逐项的说明。

        通用策略：每一步点完都**回读 checked**，确认真的勾上才算成功。

          ① 点可见容器（label / 组件外壳）—— 原生控件与自定义组件都靠它
          ② Playwright check()
          ③ click(force=True) 穿透遮挡
          ④ JS 原生 setter + 派发 input/change（React 受控组件兜底）

        每一步都**重新解析定位**：真实组件勾选后会重建整个题块，
        data-dsh-* 标记会全部消失，靠旧标记去点第二次必然失败。

        hidden_hint 仅用于日志：旧版据它跳过 check() 以免白等 6 秒；
        现在所有超时都压到 1.2 秒内，且优先点容器，不会再白等。
        """
        done: list[str] = []
        snap = self._resolve_options(qid) or {}
        # ------------------------------------------------------------------
        # 单题总时间预算（做题速度优化）
        #
        # 背景：真实考试页上四条策略全失败时，每条要等满 1.2 秒点击超时，
        #   再加两三次状态回读，实测**一道题要 6 秒**，而且日志里看到
        #   同一道题连着失败 28 次、白跑 3 分钟。
        # 依据：本地实测**成功路径只要 56~830 毫秒**，
        #   所以 3.5 秒预算对正常页面绰绰有余；超了就说明这题确实点不动，
        #   继续耗下去只会拖慢整卷，不如早点放弃、交给下一题。
        # 注意：这里只**限制总时长**，不改任何一条策略的顺序和判据，
        #   也不删任何兜底 —— 慢页面只是少试最后一条，快页面完全不受影响。
        budget_end = time.time() + BUDGET_MS / 1000.0
        for oid in option_ids:
            sel = f'[data-dsh-qid="{qid}"][data-dsh-oid="{oid}"]'
            # ★ 这道题在哪个框架里？iframe 里的题只能用那个 frame 操作。
            fr = self._frame_for(qid)

            # ------------------------------------------------------------------
            # ★★ 安全护栏：这个选项**已经选中了**就绝对不能再点。
            #
            # 为什么必须有（用户实测的严重问题）：
            #   单选题点一下是"选中"，**再点一下就取消**。
            #   实测用户那份作业：同一道题被扫成好几份（q0 完整、q17 被拆开），
            #   程序先把 q0 答对了，随后处理 q17 时又点了一次同一个选项
            #   → **把已经答好的题取消掉了**。用户原话：
            #     "任务没有停止，反而是把每个已作答题目选项取消"。
            #
            #   这不是"点错了选项"，而是**把对的答案毁掉** —— 比不答更糟。
            #   所以这里先只读一次状态，已选中就直接算成功、不点。
            #   （只读，不改页面；`_is_checked` 内部本来就是轮询回读，这里给 0 秒）
            # ------------------------------------------------------------------
            try:
                if self._is_checked(qid, oid, 0):
                    done.append(f"{qid}→选项{oid} ✔(已是选中状态，未重复点击)")
                    continue
            except Exception:
                pass

            ok = False
            how = ""
            failed: list[str] = []
            if time.time() >= budget_end:
                failed.append("超时:单题预算用尽")

            # ⓪ 页面内直点（插件式，不走坐标）——先试最稳的一条
            if time.time() < budget_end:
                try:
                    mode = self._activate_in_page(qid, oid, snap)
                    if mode and self._is_checked(qid, oid, 300):
                        ok, how = True, f"页面内:{mode}"
                except Exception as e:
                    failed.append(f"⓪页面内:{type(e).__name__}")

            # 页面内直点失败才需要鼠标：先滚进视口
            if not ok:
                try:
                    self._loc(fr, sel).first.scroll_into_view_if_needed(timeout=800)
                except Exception:
                    pass

            # ① 点可见容器（页面内直点已经成功就不要再点 —— 多选会被点掉）
            if not ok:
                n = self._mark_click_targets(qid, oid)
                for i in range(n):
                    if time.time() >= budget_end:
                        failed.append("①容器:预算用尽")
                        break
                    try:
                        self._loc(fr, f'[data-dsh-click="{i}"]').click(
                            timeout=900, force=False)
                    except Exception as e:
                        # 标上来源：光看 "TimeoutError" 分不清是"点不中元件"
                        # 还是"回读状态超时"，而这两种的修法完全不同。
                        failed.append(f"①容器:{type(e).__name__}")
                        continue
                    # 回读窗口也收紧：勾选状态是**同步**生效的，
                    # 却给了 600~700ms 的轮询窗口 —— 失败时纯属白等。
                    # 快页面（63ms 一次回读）在 250ms 内早就拿到了结果。
                    if self._is_checked(qid, oid, 250):
                        ok, how = True, "容器"
                        break

            # ② Playwright 标准 check
            if not ok and time.time() < budget_end:
                try:
                    self._loc(fr, sel).first.check(timeout=900, force=False)
                    ok, how = self._is_checked(qid, oid, 250), "check"
                except Exception as e:
                    failed.append(f"②check:{type(e).__name__}")

            # ③ 强制点击（穿透遮挡）
            if not ok and time.time() < budget_end:
                try:
                    self._loc(fr, sel).first.click(timeout=900, force=True)
                    ok, how = self._is_checked(qid, oid, 250), "强制点击"
                except Exception as e:
                    failed.append(f"③强制:{type(e).__name__}")

            # ④ JS 置位 + 事件（受控组件兜底）
            #
            # 两种情形分开处理：
            #   原生 input——用原型上的 setter，而不是 `e.checked = true`：
            #     React 在 input 上装了 checked 的 tracker，直接赋值会被判定成
            #     "没变化"，onChange 不触发。
            #   自定义组件——没有 checked 属性，只能补一次完整的鼠标事件序列
            #     （mousedown/mouseup/click），让挂在它上面的监听器自己响应。
            if not ok:
                js = ("(a) => {" + _js_with_sel(self._FIND_JS) + """
                    var snap = a[0], oid = Number(a[1]), qid = String(a[2]);
                    var e = dshGroup(snap)[oid];
                    if (e) {
                        // 先点：原生 click 会切换 checked 并触发框架监听。
                        // ⚠ 不要点 label —— 那会把刚选中的又切回去（旧实现的坑）。
                        try { e.click(); } catch (err) { /* setter 兜底 */ }
                        if (!e.checked) {
                            var setter = Object.getOwnPropertyDescriptor(
                                window.HTMLInputElement.prototype, 'checked').set;
                            setter.call(e, true);
                            e.dispatchEvent(new Event('input', {bubbles: true}));
                            e.dispatchEvent(new Event('change', {bubbles: true}));
                        }
                        return true;
                    }
                    // 自定义组件：补完整鼠标事件序列
                    var cg = dshCustomGroup(snap, qid);
                    var cu = cg[oid];
                    if (!cu) return false;
                    ['mousedown', 'mouseup', 'click'].forEach(function (t) {
                        cu.dispatchEvent(new MouseEvent(t, {bubbles: true, cancelable: true}));
                    });
                    return true;
                }""")
                try:
                    self._ev(fr, js, [snap, oid, str(qid)])
                    # ④ 是最后的兜底，回读窗口给足一点（React 受控组件
                    #    要等一次 change 事件回流），但也别超过预算。
                    if self._is_checked(qid, oid, 500):
                        ok, how = True, "JS 置位"
                    else:
                        failed.append("④JS:状态仍未变")
                except Exception as e:
                    failed.append(f"④JS:{type(e).__name__}")

            if ok:
                done.append(f"q{qid}→选项{oid} ✔{('(' + how + ')') if how else ''}")
            else:
                why = "、".join(dict.fromkeys(failed)) or "点完状态没变"
                # 全部策略都失败时，补一条**现场诊断**。
                # 光有 "①容器:TimeoutError" 还是不知道是"元件找不到"、
                # "被遮挡"、还是"点了但状态读不出来"——这三种修法完全不同。
                diag = self._diag_click_failure(qid, oid)
                done.append(f"q{qid}→选项{oid} ✘未生效({why})"
                            + (f"　[诊断] {diag}" if diag else ""))
                # ★ 第一次点失败时，把这道题的 DOM 现场**完整**记一次日志。
                #
                # 为什么：诊断串只说"选项文字是 ['对','A']"，看不出为什么被拆成
                # 两个元素、父元素是谁。而这类问题靠猜只会来回改错
                # （我已经因此改坏过两次）。一次性把结构摊开，
                # 用户只要照常跑一次，作者就能拿到定位所需的全部信息。
                if not self._fail_dumped:
                    self._fail_dumped = True
                    try:
                        self.log("—— 首次落笔失败的现场快照（只记一次）——")
                        for line in self._dump_fail_dom(qid):
                            self.log("   " + line)
                    except Exception as e:
                        self.log(f"   (快照失败：{type(e).__name__})")
                # ---- 埋点：找到了选项但一个都没点中 = DOM 落笔失效 ----
                try:
                    metrics.record(
                        metrics.CHOOSE_FAIL,
                        url=getattr(self.page, "url", ""),
                        detail=f"q{qid}→o{oid} {why}"
                               + (f" | {diag}" if diag else ""),
                    )
                except Exception:
                    pass
        return done

    def _dump_field_dom(self, fid: int) -> list[str]:
        """把"题干识别不出来"的填空/论述题的 DOM 现场摊开。

        为什么专门为它做一份：论述/简答题的题干取不到时，日志只有一句
        `(填空题，题干未识别)` —— 完全看不出题干在 DOM 的哪一层、
        为什么没取到。而这类题恰恰是**用户最希望自动完成**的（手写几段话最费时间）。
        与其反复猜结构，不如把现场摊开一次。
        """
        fr = self._frame_for(fid, field=True)
        js = r"""(a) => {
            var fid = String(a[0]);
            var e = document.querySelector('[data-dsh-fid="' + fid + '"]');
            if (!e) {
                var all = [].slice.call(document.querySelectorAll(
                    'input,textarea,select,[contenteditable=true]'))
                    .filter(function (x) {
                        var r = x.getBoundingClientRect();
                        return r.width > 0 && r.height > 0;
                    });
                e = all[Number(fid)] || null;
            }
            if (!e) return { found: false };
            var out = { found: true, tag: e.tagName.toLowerCase(),
                        cls: String(e.className || '').slice(0, 40),
                        ce: e.getAttribute('contenteditable') || '',
                        chain: [], hops: [] };
            var n = e, i = 0;
            while (n && i < 7) {
                var c = (typeof n.className === 'string' ? n.className : '')
                    .trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
                var txt = ((n.innerText || n.textContent || '')
                           .replace(/\s+/g, ' ').trim()).slice(0, 60);
                var r2 = n.getBoundingClientRect();
                out.chain.push(n.tagName.toLowerCase() + (c ? '.' + c : '')
                               + ' 〔可见 ' + (r2.width > 0 && r2.height > 0)
                               + ' ' + Math.round(r2.width) + 'x'
                               + Math.round(r2.height) + '〕');
                out.hops.push('     上' + (i + 1) + '层: ' + JSON.stringify(txt));
                n = n.parentElement; i++;
            }
            return out;
        }"""
        try:
            info = self._ev(fr, js, [str(fid)]) or {}
        except Exception as e:
            return [f"(读不到：{type(e).__name__})"]
        if not info.get("found"):
            return ["(找不到该填空对应的控件)"]
        lines = [f"fid={fid} <{info.get('tag')} class={info.get('cls')!r} "
                 f"contenteditable={info.get('ce')!r}>"]
        for c in (info.get("chain") or []):
            lines.append(f"   {c}")
        for h in (info.get("hops") or []):
            lines.append(h)
        return lines

    def _dump_fail_dom(self, qid: int) -> list[str]:
        """把"点不中的那道题"的 DOM 现场摊开，供作者定位。

        输出内容（都在**这道题所在的框架**里查）：
          · 该题被标记的元素（data-dsh-cqid / data-dsh-qid）逐个列出：
            标签、class、role、文字、尺寸、在父元素里的下标
          · 它们各自的父元素是谁、父元素有几个孩子
          · 快照里记下的选项文字
        这样"为什么被拆成两个""父元素是不是同一个"一目了然。
        """
        fr = self._frame_for(qid)
        snap = self._resolve_options(qid) or {}
        js = r"""(a) => {
            var qid = String(a[0]);
            var out = { items: [], parents: [] };
            var els = [].slice.call(document.querySelectorAll(
                '[data-dsh-cqid="' + qid + '"],[data-dsh-qid="' + qid + '"]'));
            out.markedN = document.querySelectorAll(
                '[data-dsh-cqid],[data-dsh-qid]').length;
            els.forEach(function (e) {
                var r = e.getBoundingClientRect();
                var p = e.parentElement;
                out.items.push({
                    tag: e.tagName.toLowerCase(),
                    cls: String(e.className || '').slice(0, 40),
                    role: e.getAttribute('role') || '',
                    text: ((e.innerText || e.textContent || '')
                           .replace(/\s+/g, ' ').trim()).slice(0, 30),
                    vis: r.width > 0 && r.height > 0,
                    size: Math.round(r.width) + 'x' + Math.round(r.height),
                    idx: p ? Array.prototype.indexOf.call(p.children, e) : -1,
                    chain: (function () {
                        var out2 = [], n = e, i = 0;
                        while (n && i < 3) {
                            var c = (typeof n.className === 'string' ? n.className : '')
                                .trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
                            out2.push(n.tagName.toLowerCase() + (c ? '.' + c : ''));
                            n = n.parentElement; i++;
                        }
                        return out2.join(' < ');
                    })(),
                });
                if (p) {
                    var pc = (typeof p.className === 'string' ? p.className : '')
                        .trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
                    var tag = p.tagName.toLowerCase() + (pc ? '.' + pc : '');
                    if (out.parents.indexOf(tag + ' 〔孩子 ' + p.children.length + '〕') < 0) {
                        out.parents.push(tag + ' 〔孩子 ' + p.children.length + '〕');
                    }
                }
            });
            return out;
        }"""
        try:
            info = self._ev(fr, js, [str(qid)]) or {}
        except Exception as e:
            return [f"(读不到：{type(e).__name__})"]
        lines = [f"qid={qid}　本帧标记总数={info.get('markedN')}　"
                 f"本题标记={len(info.get('items') or [])} 个"]
        lines.append(f"快照选项文字={[str(t)[:20] for t in (snap.get('texts') or [])]}")
        lines.append(f"快照 n={snap.get('n')}  name={snap.get('name')!r}")
        for p in (info.get("parents") or []):
            lines.append(f"父元素：{p}")
        for i, it in enumerate(info.get("items") or []):
            lines.append(f"  [{i}] <{it['tag']} class={it['cls']!r} "
                         f"role={it['role']!r}> 孩子下标={it['idx']} "
                         f"可见={it['vis']} {it['size']} 文字={it['text']!r}")
            lines.append(f"      链：{it['chain']}")
        return lines

    def _diag_click_failure(self, qid: int, oid: int) -> str:
        """点不中时的现场快照：元件是否存在、是否可见、是否被遮挡。

        ⚠ 这个诊断之所以越写越长，是因为失败的**原因差别极大**，
          而光看 "②check:TimeoutError" 完全分不出来：
            · 标记没打上（扫描时元素被判定不可见 → 整个跳过）
            · 分组抓错了（所有题共用一个 name → 拿到全页的输入框）
            · 选项文字读错了层（读成 value 的字母 "A" → 模型说"内容缺失"）
            · 元素不可见 / 被遮挡（自定义样式把它藏起来了）
          这几种的修法完全不同，所以这里一次性把线索都带出来。
        """
        snap = self._resolve_options(qid)
        if not snap:
            return "拿不到这道题的选项快照（题干可能变了）"
        try:
            # 诊断也要在正确的框架里做，否则会给出误导性的
            # "选项元素在 DOM 里找不到（可能被重渲染重建了）"（审计 C-25）
            info = self._ev(self._frame_for(qid),
                "(a) => {" + _js_with_sel(self._FIND_JS) + """
                    var snap = a[0], oid = Number(a[1]), qid = String(a[2]);
                    var out = {};
                    var g = dshGroup(snap);
                    out.groupN = g ? g.length : 0;
                    // ⚠ 必须**两种标记都数**：原生控件打的是 data-dsh-qid，
                    //   自定义组件打的是 data-dsh-cqid。第一版只数前者，
                    //   于是自定义题一律显示"本帧一个标记都没有"，
                    //   把"选项被拆错"误报成"控件不可见被跳过" —— 带偏了排查方向。
                    out.markedN = document.querySelectorAll(
                        '[data-dsh-qid],[data-dsh-cqid]').length;
                    out.thisMarked = document.querySelectorAll(
                        '[data-dsh-qid="' + qid + '"],[data-dsh-cqid="' + qid + '"]'
                        ).length;
                    out.customN = document.querySelectorAll(
                        '[data-dsh-cqid]').length;
                    out.inputsN = document.querySelectorAll(
                        'input[type=radio],input[type=checkbox]').length;
                    // 同名的有多少个 —— 判断"分组是否抓成了全页"
                    if (snap && snap.name) {
                        try {
                            out.sameNameN = document.querySelectorAll(
                                'input[name="' + dshEscape(snap.name) + '"]').length;
                        } catch (err) { out.sameNameN = -1; }
                    } else {
                        out.sameNameN = 0;
                    }
                    out.snapN = (snap && snap.ids) ? snap.ids.length : 0;
                    out.snapName = (snap && snap.name) || '';
                    out.snapTexts = (snap && snap.texts)
                        ? snap.texts.slice(0, 4) : [];

                    var e = g ? g[oid] : null;
                    out.found = !!e;
                    if (e) {
                        out.tag = e.tagName.toLowerCase();
                        out.type = e.getAttribute('type') || '';
                        out.cls = String(e.className || '').slice(0, 60);
                        out.name = e.name || '';
                        out.val = String(e.value || '').slice(0, 20);
                        var r = e.getBoundingClientRect();
                        out.rect = Math.round(r.width) + 'x' + Math.round(r.height);
                        out.disabled = !!e.disabled;
                        var st = getComputedStyle(e);
                        out.display = st.display;
                        out.vis = st.visibility;
                        out.opacity = st.opacity;
                        // 中心点上最顶层的元素是谁 —— 判断有没有被遮挡
                        var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
                        if (r.width > 0 && r.height > 0) {
                            var top = document.elementFromPoint(cx, cy);
                            out.topEl = top ? (top.tagName.toLowerCase() + '.' +
                                String(top.className || '').slice(0, 40)) : '(null)';
                            out.covered = !(top === e || (top && e.contains(top))
                                            || (top && top.contains(e)));
                        }
                    }
                    return out;
                }""", [snap, oid, str(qid)])
            if not info:
                return ""
            parts: list[str] = []
            # ---- 先给"结构性线索"，这些比单个元素的属性更有诊断价值 ----
            parts.append(f"分组{info.get('groupN')}个"
                         f"/本帧标记{info.get('markedN')}"
                         f"(本题{info.get('thisMarked')}，自定义{info.get('customN')})"
                         f"/本帧选项控件{info.get('inputsN')}")
            if info.get("snapName"):
                parts.append(f"同名{info.get('sameNameN')}个")
            # 选项文字是否为空 —— 这是"模型说选项内容缺失"的直接原因
            texts = info.get("snapTexts") or []
            empty = sum(1 for t in texts if not str(t or "").strip())
            if texts:
                shown = "/".join(str(t)[:12] for t in texts[:3])
                parts.append(f"选项文字[{shown}]"
                             + (f"★{empty}个为空" if empty else ""))
            if not info.get("found"):
                # 标记数量能直接区分两种完全不同的原因
                if not info.get("markedN"):
                    parts.append("★本帧**一个标记都没有**"
                                 "（扫描时这些控件被判定不可见而跳过了）")
                elif not info.get("thisMarked"):
                    parts.append("★本帧有标记、但**没有本题的**"
                                 "（页面重渲染把标记冲掉了，且按文字也找不回）")
                else:
                    parts.append("★标记在、但这个下标取不到元素"
                                 "（分组抓错 / oid 越界）")
                return "，".join(parts)
            parts.append(f"<{info.get('tag')}"
                         + (f" type={info['type']}" if info.get("type") else "") + ">")
            parts.append(f"尺寸 {info.get('rect')}")
            if info.get("name") or info.get("val"):
                parts.append(f"name={info.get('name')!r} value={info.get('val')!r}")
            if info.get("disabled"):
                parts.append("★被禁用")
            if info.get("vis") == "hidden" or info.get("display") == "none":
                parts.append("★不可见")
            try:
                if float(info.get("opacity") or 1) <= 0.05:
                    parts.append("★透明度为 0")
            except Exception:
                pass
            if info.get("covered"):
                parts.append(f"★被遮挡(topEl={info.get('topEl')})")
            if info.get("cls"):
                parts.append(f"class={info['cls'][:34]}")
            return "，".join(parts)
        except Exception as e:
            return f"诊断失败({type(e).__name__})"

    def fill(self, fid: int, value: str) -> str:
        """往填空框里填值。**任何失败都返回说明字符串，绝不抛异常。**

        ⚠ 原来是两处坑一起踩（审计 C-24）：
          ① `loc.evaluate("e => e.tagName...")` **既不在 try 里、也没有 timeout**。
             而 `_open_persistent` 里设过 `page.set_default_timeout(60s)`，
             所以标记被组件重渲染冲掉时，这一行会**干等 60 秒**再抛
             `TimeoutError`；异常一路上抛到 `run_web` 的 except，
             **整场作答终止、剩余题目全丢**。
             （对比：同一模块的 `choose()` 有 try 保护 —— 两套标准。）
          ② 填不进去时**不留任何痕迹**，事后不知道是哪个字段、哪种失败。
        """
        t0 = time.time()
        sel = f'[data-dsh-fid="{fid}"]'
        # ★ 填空也要落到"这个字段所在的框架"里（iframe 里的输入框同理）
        fr = self._frame_for(fid, field=True)
        loc = self._loc(fr, sel).first
        # ------------------------------------------------------------------
        # ★ 存在性/唯一性**快检**：标记对不上就立刻改按"帧内第 N 个"定位。
        #
        # 为什么必须快检：定位失败时原流程会依次干等
        #   scroll(4s) + evaluate(1.5s) + click(4s) ≈ **9.5 秒/题**（实测），
        #   而且最后还是失败 —— 白等。`count()` 不走 auto-wait，毫秒级。
        #
        # ⚠ 判据是 `!= 1`（不是 `== 0`）：标记重复命中（同一个 fid 贴在多个
        #   元素上）比找不到更危险 —— 会写进**别的空格**。
        # ------------------------------------------------------------------
        try:
            if loc.count() != 1:
                idx = int((self._field_meta or {}).get(fid, {}).get("idx", -1))
                if idx >= 0:
                    loc = self._loc(fr, _FIELD_SEL).nth(idx)
                    self._note(f"f{fid} 标记解析不唯一，改按帧内第 {idx} 个定位")
                else:
                    self._blind(metrics.FILL_FAIL, fid, str(value)[:40],
                                f"定位失败(标记解析到 {loc.count()} 个元素)", t0)
                    return f"f{fid}→定位 ✘(标记解析不到元素)"
        except Exception:
            pass
        try:
            loc.scroll_into_view_if_needed(timeout=4000)
        except Exception:
            pass
        # ① 探测标签：给短超时 + try，失败就当成普通输入框继续走
        tag = ""
        try:
            tag = loc.evaluate("e => e.tagName.toLowerCase()", timeout=1500)
        except Exception:
            tag = ""
        try:
            if tag == "select":
                if self._select(loc, value):
                    return f"f{fid}→下拉 ✔"
                self._blind(metrics.FILL_FAIL, fid, value,
                            "下拉里没有匹配项", t0)
                return f"f{fid}→下拉 ✘(无匹配项 {value!r})"
            # ★ 简答/论述（富文本作答区）：不能只 loc.fill()。见 _fill_rich 的说明。
            if self._is_essay_field(fid):
                # ★ 把**已经解析好的 loc**传进去。
                #   原来 _fill_rich 内部又用 sel 取了一次 locator ——
                #   那样上面按"帧内第 N 个"做的兜底就白做了
                #   （它还是去找那个失效的标记）。
                return self._fill_rich(fr, fid, str(value), loc=loc)
            loc.fill(str(value), timeout=6000)
            return f"f{fid}→填入 {value!r} ✔"
        except Exception as e:
            try:
                loc.click(timeout=4000)
                loc.type(str(value), timeout=6000)
                return f"f{fid}→键入 {value!r} ✔(退路)"
            except Exception as e2:
                self._blind(metrics.FILL_FAIL, fid, value,
                            f"{type(e).__name__} / 退路 {type(e2).__name__}", t0)
                return f"f{fid}→填写 ✘({type(e).__name__}: {e})"

    def _is_essay_field(self, fid: int) -> bool:
        """这个字段是不是简答/论述（富文本作答区）。"""
        try:
            return bool((self._field_meta or {}).get(fid, {}).get("essay"))
        except Exception:
            return False

    def _fill_rich(self, fr, fid: int, value: str, loc=None) -> str:
        r"""往富文本作答区写答案：真实键入 → 回读校验 → 退路（置入 + 事件 + 同步）。

        ## 为什么不能只用 loc.fill()

          ① 可编辑区可能是编辑器 iframe 里的 `<body>`（designMode）。
             Playwright 的 `fill()` 只认 form 控件 / `[contenteditable]`；
             对 designMode 的 body 要么抛错、要么"写了但编辑器不认"
             （它靠 input 事件同步）。
          ② 平台提交时读的是**旁边那个 display:none 的 textarea**。
             光改 DOM 文字不触发编辑器同步 → 交上去还是空的。

        所以先试真实键盘输入（编辑器认的是真实事件流），
        不行再退到"置入 + 派发事件 + 同步隐藏 textarea"。

        ⚠ 无论如何都要**回读校验**：本项目最贵的一类 bug 就是"报了 ✔ 其实没写进去"。
        """
        t0 = time.time()
        sel = f'[data-dsh-fid="{fid}"]'
        if loc is None:
            loc = self._loc(fr, sel).first
        words = str(value)
        try:                                # ① 键盘输入（编辑器认的是真实事件流）
            # 成功路径实测 <1s，原来给 4s；失败时白等，收到 1.2s
            loc.click(timeout=1200)
            for i, line in enumerate(words.split("\n")):
                if i:
                    self.page.keyboard.press("Enter")
                if line:
                    self.page.keyboard.type(line, delay=0)
        except Exception:
            pass
        if self._rich_readback(fr, sel, words):
            # ⚠ 键盘输入成功也**必须**补一次"同步隐藏 textarea"。
            #
            #   为什么：平台提交时读的是旁边那个 display:none 的 textarea，
            #   而不是可编辑区本身。真实编辑器会在 input 事件里自己同步，
            #   但这**依赖站点实现**；实测我自己的复刻页就没同步上
            #   （键盘输入后 contenteditable 有字、textarea 还是空）。
            #   一旦没同步，用户看到界面有字、交上去却是空的 ——
            #   比"填不进去"更难发现，所以这里无条件补一次。
            #   （同步失败不影响结果：可编辑区里已经有字了。）
            self._rich_sync_hidden(fr, sel, words)
            return f"f{fid}→富文本键入 ✔（{len(words)} 字）"
        try:                                # ② 退路：置入 + 事件 + 同步隐藏 textarea
            self._ev(fr, r"""(a) => {
                const sel = a[0], val = a[1];
                const e = document.querySelector(sel);
                if (!e) return false;
                try { e.focus(); } catch (err) {}
                if (e.isContentEditable || e.tagName === 'BODY') {
                    e.innerHTML = String(val).split('\n').map(function (l) {
                        return '<div>' + String(l)
                            .replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</div>';
                    }).join('');
                } else {
                    e.value = val;
                }
                ['input', 'change', 'keyup', 'blur'].forEach(function (t) {
                    e.dispatchEvent(new Event(t, {bubbles: true}));
                });
                // 学习通/超星的富文本编辑器靠隐藏 textarea 提交 → 一并同步
                let p = e.parentElement, hops = 0;
                while (p && hops < 5) {
                    const ta = p.querySelector('textarea');
                    if (ta && ta !== e) {
                        ta.value = val;
                        ta.dispatchEvent(new Event('input', {bubbles: true}));
                        ta.dispatchEvent(new Event('change', {bubbles: true}));
                        break;
                    }
                    p = p.parentElement; hops++;
                }
                try { e.blur(); } catch (err) {}
                return true;
            }""", [sel, words])
        except Exception as e:
            self._blind(metrics.FILL_FAIL, fid, words,
                        f"富文本写入异常 {type(e).__name__}", t0)
            return f"f{fid}→富文本填写 ✘({type(e).__name__})"
        if self._rich_readback(fr, sel, words):
            return f"f{fid}→富文本置入 ✔(退路，{len(words)} 字)"
        self._blind(metrics.FILL_FAIL, fid, words, "回读为空", t0)
        return f"f{fid}→富文本填写 ✘(回读为空，需人工复核)"

    def _rich_sync_hidden(self, fr, sel: str, value: str) -> None:
        r"""把答案同步进"作答区容器里那个隐藏的 textarea"。

        ## 为什么单独做一件事

        学习通/超星这类富文本编辑器，**提交时读的是旁边的 `display:none` textarea**，
        而不是可编辑区本身。可编辑区只是给人看的，textarea 才是数据源。

        正常流程里编辑器自己会在 input 事件里同步，但这依赖站点实现：
        实测我自己的复刻页（iframe + 手动 input 监听）就没同步上 ——
        键盘输入后 contenteditable 有字、textarea 还是空。

        一旦没同步，症状是**用户看到界面有字、交上去却是空的**，
        比"完全没填"更难发现。所以这里无条件补一次。

        ## ⚠ 必须跨 frame 找，不能只在字段自己的文档里找

        真实结构里，那个隐藏 textarea 是**编辑器 iframe 的兄弟**、在**外层文档**：

            主文档 / 外层 iframe 的文档
              div.eidtDiv
                ├ iframe (编辑器)   ← 字段在这个子文档里
                └ textarea(display:none)   ← 数据源在这里

        所以从字段元素往上找（走到 `<html>` 就到顶了）永远找不到它。
        要沿 frame 链往上：`frame_element()` 拿到编辑器 iframe，
        再看它的父元素里有没有 textarea。

        ⚠ 全程吞异常：这只是一道保险，失败不该影响已经写进去的内容。
        """
        JS = r"""(a) => {
            const sel = a[0], val = a[1];
            const e = document.querySelector(sel);
            if (!e) return false;
            let p = e.parentElement, hops = 0;
            while (p && hops < 5) {
                const ta = p.querySelector('textarea');
                if (ta && ta !== e) {
                    ta.value = val;
                    ta.dispatchEvent(new Event('input', {bubbles: true}));
                    ta.dispatchEvent(new Event('change', {bubbles: true}));
                    return true;
                }
                p = p.parentElement; hops++;
            }
            return false;
        }"""
        # ① 先在字段自己的文档里找（普通站点：textarea 就在同一容器里）
        try:
            if self._ev(fr, JS, [sel, str(value)]):
                return
        except Exception:
            pass
        # ② 再沿 frame 链往上找（学习通：textarea 是编辑器 iframe 的兄弟，在外层文档）
        #
        #    在每一层：拿到"本层 iframe 元素"，然后在**它的父文档**里
        #    从 iframe 元素往上走，看哪一层的容器里有 textarea。
        cur = fr
        for _ in range(4):
            if cur is None:
                break
            try:
                if cur == self.page.main_frame:
                    break
            except Exception:
                pass
            try:
                el = cur.frame_element()
                # ⚠ `Locator.evaluate(expr, arg)` 的签名是
                #   `(element, arg) => ...` —— **元素是自动作为第一个参数传进来的**。
                #   我第一版写成 `el.evaluate(JS, [el, value])`，把 Locator 当参数传，
                #   而 Locator 不可序列化 → 整段静默失败（外层有 try 吞掉）。
                #   结果就是"可编辑区有字、隐藏 textarea 还是空"，
                #   症状和"根本没同步"一模一样，很难查。
                if el.evaluate(r"""(e, val) => {
                        let n = e, hops = 0;
                        while (n && hops < 6) {
                            const ta = n.querySelector
                                ? n.querySelector('textarea') : null;
                            if (ta && ta !== e && ta !== n) {
                                ta.value = val;
                                ta.dispatchEvent(new Event('input', {bubbles: true}));
                                ta.dispatchEvent(new Event('change', {bubbles: true}));
                                return true;
                            }
                            n = n.parentElement; hops++;
                        }
                        return false;
                    }""", str(value)):
                    return
            except Exception:
                pass
            try:
                cur = cur.parent_frame
            except Exception:
                break

    def _rich_readback(self, fr, sel: str, want: str) -> bool:
        """回读校验：作答区（或其容器里的 textarea）能看到答案开头就算成功。"""
        probe = re.sub(r"\s+", "", str(want))[:12]
        if not probe:
            return False
        try:
            got = self._ev(fr, r"""(a) => {
                const e = document.querySelector(a[0]);
                if (!e) return '';
                let p = e.parentElement, hops = 0;
                while (p && hops < 5) {
                    const ta = p.querySelector('textarea');
                    if (ta && ta.value) return ta.value;
                    p = p.parentElement; hops++;
                }
                return (e.innerText || e.textContent || e.value || '');
            }""", [sel]) or ""
        except Exception:
            return False
        return probe in re.sub(r"\s+", "", str(got))

    def _blind(self, kind: str, fid: int, value: str, why: str,
               t0: float) -> None:
        """填不进去时记一次埋点（**吞掉一切异常**，绝不影响主流程）。"""
        try:
            metrics.record(
                kind, url=getattr(self.page, "url", ""),
                detail=f"f{fid} 值={value!r} {why}".replace("\n", " ")[:180],
                ms=(time.time() - t0) * 1000,
            )
        except Exception:
            pass

    @staticmethod
    def _select(loc, value: str) -> bool:
        s = str(value).strip()
        for how, payload in (
            ("label", s),
            ("value", s),
        ):
            try:
                loc.select_option(**{how: payload}, timeout=4000)
                return True
            except Exception:
                pass
        # 退路：按包含关系挑最像的选项
        try:
            opts = loc.evaluate("e => [...e.options].map(o => ({t:o.textContent.trim(), v:o.value}))")
        except Exception:
            return False
        for o in opts or []:
            t = (o.get("t") or "").strip()
            if t and (t == s or s in t or t in s):
                try:
                    loc.select_option(value=o["v"], timeout=4000)
                    return True
                except Exception:
                    return False
        return False

    def click_button(self, text_hint: str | None = None, box: dict | None = None) -> bool:
        if box:
            try:
                self.page.mouse.click(box["x"] + box["w"] / 2, box["y"] + box["h"] / 2)
                return True
            except Exception:
                return False
        if text_hint:
            for role in ("button", "link"):
                try:
                    loc = self.page.get_by_role(role, name=re.compile(re.escape(text_hint), re.I)).first
                    loc.click(timeout=4000)
                    return True
                except Exception:
                    continue
            try:
                loc = self.page.get_by_text(text_hint, exact=False).first
                loc.click(timeout=4000)
                return True
            except Exception:
                return False
        return False

    def advance_next(self) -> str:
        """点击"下一题"并确认页面真的翻了。

        逐题分页的作业里这是主流程。要点：
          - 页面上可能同时有"下一题"和"提交"，只点 navigation 类的；
          - 有些站点会弹"还有未作答的题"二次确认，这里顺手点掉"确定/继续"；
          - 点完必须核对页面指纹是否变化，没变就不能当作成功（会死循环）。

        返回：'ok' 翻页成功 / 'no_button' 没有可用的下一题 / 'no_change' 点了但没翻页
        """
        # 用 scan() 解析出的 state 算指纹：只有结构化数据才稳定，
        # 单跑一段 JS 去捞页面文本会把倒计时也算进去（见 page_signature 的说明）。
        # scan 本身只要几毫秒，这点开销换指纹可靠是值得的。
        before = self.page_signature(self.scan())
        cands = self.next_candidates()
        if not cands:
            return "no_button"

        for cand in cands[:3]:
            text = cand.get("text", "")
            try:
                ok = self.click_button(text_hint=text, box=cand.get("box"))
            except Exception:
                ok = False
            if not ok:
                continue

            # 别一上来就固定等 900ms：先短等一下看页面变没变，没变再补等。
            # 本地页面/瞬时切换的站点能省掉大半等待，慢站点行为不变。
            self.wait_for_load(extra_ms=200)
            after = self.page_signature(self.scan())
            if not (after and after != before):
                self.wait_for_load(extra_ms=700)
                after = self.page_signature(self.scan())

            # 处理"还有未作答"之类的确认弹窗（原生 confirm 已被 Playwright 自动接受）
            for confirm_kw in ("确定", "继续", "确认", "是"):
                try:
                    loc = self.page.get_by_role("button", name=re.compile(f"^{confirm_kw}$")).first
                    if loc.is_visible(timeout=300):
                        loc.click(timeout=2000)
                        self.wait_for_load(extra_ms=500)
                except Exception:
                    pass

            # ⚠ 这里曾经混用了**两种格式不同**的页面指纹，导致"没翻页也报成功"：
            #
            #     before = self.page_signature(self.scan())   # 结构化：url~题数~...
            #     after  = self.page_signature()              # 无参 → JS 兜底分支
            #                                                 # 格式：pathname+hash+'|'+...
            #
            #   两者几乎**必定不相等**，于是"点了下一题但页面没动"被判成翻页成功。
            #   上层 `_web_loop` 收到 'ok' 就把 stagnant 归零、并在下一轮把题目
            #   当成"已作答"而不清空 attempts，结果是**反复点同一个按钮空转**
            #   直到 MAX_ROUNDS(60) 才退出 —— 日志表现就是"一直点下一题、什么也不做"。
            #
            #   修法：**同一函数里只用一种口径**（都用 scan 出来的 state）。
            #   注意确认弹窗点完、页面可能已经变了，所以要**重新取一次**再比。
            after = self.page_signature(self.scan())
            if after and after != before:
                return "ok"
        return "no_change"

    def scroll_by(self, dy: int) -> None:
        self.page.mouse.wheel(0, dy)

    def scroll_to_top(self) -> None:
        try:
            self.page.keyboard.press("Home")
        except Exception:
            pass

    # 截图保留上限：一次作业几十轮，每轮一张会堆出几十 MB。
    # 只保留最近几张供界面预览与排查，多余的自动删掉。
    _SHOT_KEEP = 8

    def screenshot(self, *, full_page: bool = False, tag: str = "page",
                   save: bool = True) -> Path:
        """截当前视口。**绝不抛异常** —— 截图失败不允许影响作答。

        ⚠ 这里踩过一个"整个任务崩掉"的坑（真机实测）：
            原来是
                try:
                    page.screenshot(path=...)          # 第一次
                except Exception:
                    body = page.screenshot(...)        # 退路 —— 没有 try！
            浏览器进入异常状态时（实测那次是用户预开的浏览器连接被断开、
            程序新开了一个，页面状态不稳），**两次都失败** →
            异常从退路抛出去 → 一路冒到 `_web_loop` →
            `result.error = "Page.screenshot: Protocol error ..."`，
            **整场作答在第 1 轮就结束了**，用户看到的就是"跑死了"。

            截图只是**事后核对用的旁支功能**，它失败绝不能终止作答。
            返回的路径在失败时可能指向一个不存在的文件 —— 调用方
            （`on_shot` / 界面预览）本来就按"可能读不到"处理。

        save=False 时**不落盘**（返回值只是占位路径，不要拿去读文件）。

        ⚠ 语义对齐：`DesktopDriver.screenshot(save=...)` 里的 save 就是"是否落盘"
          （`desktop.py`），而这里原来是"落盘 + 用 save 决定要不要清理旧图" ——
          同样一个参数名，两处意思不一样，很容易用错。
          现在统一成"是否落盘"。
          （实测：BrowserDriver 这条路上没有任何调用方传 save=False，
            改语义不影响现有行为。）
        """
        self._shot_seq += 1
        from datetime import datetime
        p = config.SHOT_DIR / f"{datetime.now().strftime('%H%M%S')}_{self._shot_seq:03d}_{tag}.png"
        ok = False
        try:
            if save:
                try:
                    self.page.screenshot(path=str(p), full_page=full_page,
                                         animations="disabled")
                except Exception:
                    # 退路：不带 path 拿字节、自己写盘（有些环境对 path 参数不友好）。
                    # ⚠ 这一层同样在 try 里 —— 它正是"崩掉整场"的那一行。
                    p.write_bytes(self.page.screenshot(full_page=full_page))
            else:
                # 只要图、不落盘（丢弃字节）
                self.page.screenshot(full_page=full_page)
            ok = True
        except Exception as e:
            # ⚠ 失败**绝不能抛**：整场作答不允许因为一张核对图而终止。
            try:
                if not getattr(self, "_shot_failed_logged", False):
                    self._shot_failed_logged = True
                    self._note(f"⚠ 截图失败（{type(e).__name__}）——"
                               f"不影响作答，继续。页面可能处于异常状态。")
            except Exception:
                pass
        if save and ok:
            self._trim_shots()
        return p

    # 我们自己生成的截图文件名形如 `170925_001_trimcheck.png`。
    # 只有长得像这个的文件才允许被清理。
    _SHOT_NAME_RE = re.compile(r"^\d{6}_\d{3}_.*\.png$", re.IGNORECASE)

    def _shots_dir_owned(self) -> bool:
        """这个截图目录是"我们自己的"吗？决定能不能删里面的文件。

        ⚠ 这是一个**会造成用户数据丢失**的地方，必须保守：
          `SHOT_DIR` 是用户可配置项，界面上可以把它指到任何目录
          （「图片」「桌面」都很自然）。而 `_trim_shots` 原来的逻辑是
          "目录里出现比当前截图旧的 *.png 就 unlink()" ——
          于是用户把它指向「图片」文件夹时，**我们会删掉他自己的照片**。
          `clear_shots(keep_latest=False)` 更狠，一次删光该目录**所有** PNG。

          有意思的是同一份约束在 `cleanup_stale_state` 里**是对的**
          （那边有一句 "用户可能把截图位置改成自己的图片文件夹……
          绝对不能动"），只是 `_trim_shots` 把这个前提丢了。
          这里把两边统一到同一个判断上。

        判定规则：
          · 默认截图目录（程序自己的「截图」文件夹）→ 可以清理
          · 其它目录 → **只清理文件名符合我们命名规则的那些**，
            用户自己的 `IMG_1234.png`、`照片.png` 一律不碰。
        """
        try:
            default_dir = (config.PROJECT_DIR / "截图").resolve()
            return config.SHOT_DIR.resolve() == default_dir
        except Exception:
            # 判断不了就当"不是我们的"，宁可不删
            return False

    def _trim_shots(self, keep: int | None = None) -> int:
        """只保留最近的 N 张**我们自己的**截图，返回删掉几张。

        N 由 DSHS_CLEAR_SHOTS_EACH_ROUND 决定：
          开启（默认）→ keep=1，即"每轮只留当前这张"。这样磁盘占用最小，
                        而界面预览仍然有图可看（它取的就是最新那张）。
          关闭         → keep=_SHOT_KEEP(8)，留最近几张方便事后排查。

        ⚠ 安全约束见 `_shots_dir_owned()`：**绝不能删用户自己的文件。**
          清理前会先筛掉名字不像我们生成的那些。
        """
        if keep is None:
            keep = 1 if config.CLEAR_SHOTS_EACH_ROUND else self._SHOT_KEEP
        deleted = 0
        owned_dir = self._shots_dir_owned()
        try:
            cands = sorted(config.SHOT_DIR.glob("*.png"),
                           key=lambda f: f.stat().st_mtime, reverse=True)
            # 不是我们自己的目录时，只认符合命名规则的文件
            if not owned_dir:
                cands = [f for f in cands if self._SHOT_NAME_RE.match(f.name)]
            for old in cands[keep:]:
                try:
                    old.unlink()
                    deleted += 1
                except Exception:
                    pass
        except Exception:
            pass
        return deleted

    def clear_shots(self, keep_latest: bool = True) -> int:
        """清空截图目录。keep_latest=True 时留下最新一张（供界面预览）。

        ⚠ 同 `_trim_shots`：只清我们自己生成的截图，不动用户其它文件。
        """
        return self._trim_shots(keep=1 if keep_latest else 0)

    def crop_regions(self, boxes: list[dict], tag: str = "crop") -> list[Path]:
        """按矩形从当前视口截图里裁图。

        注意：坐标必须是"视口坐标"（getBoundingClientRect 的结果），调用前元素得在视口里。
        首屏之外的配图请用 shoot_images()，它走浏览器原生元素截图，不会错位。
        """
        from PIL import Image  # noqa: PLC0415

        if not boxes:
            return []
        shot = self.screenshot(tag=tag + "_full")
        img = Image.open(shot)
        paths: list[Path] = []
        for i, b in enumerate(boxes):
            pad = 12
            x1 = max(0, int(b["x"]) - pad)
            y1 = max(0, int(b["y"]) - pad)
            x2 = min(img.width, int(b["x"] + b["w"]) + pad)
            y2 = min(img.height, int(b["y"] + b["h"]) + pad)
            if x2 - x1 < 8 or y2 - y1 < 8:
                continue
            p = shot.with_name(shot.stem.replace("_full", "") + f"_{tag}_{i}.png")
            img.crop((x1, y1, x2, y2)).save(p)
            paths.append(p)
        return paths

    def shoot_images(self, indexes: list[int], tag: str = "img") -> list[Path]:
        """用浏览器原生元素截图抓取页面上第 idx 张图片（自动滚动，不会错位）。

        这是配图裁剪的正道：Playwright 会把元素滚进视口再截，坐标由浏览器保证。

        ⚠ audit C-37：`scan()` 会把 **iframe 里的图片**也合并进 state，
          但这里原来只用 `self.page.locator(...)` —— 那**不穿透 iframe**，
          于是"图在 iframe 里"的题永远拿不到配图，视觉模型只能瞎猜。
          现在按图片自己记的 `_frame` 去对应的框架里取。
        """
        from datetime import datetime  # noqa: PLC0415

        out: list[Path] = []
        for idx in indexes:
            fr = self._frame_for_image(idx)
            loc = self._loc(fr, f'img[data-dsh-img="{idx}"]').first
            p = config.SHOT_DIR / f"{datetime.now().strftime('%H%M%S')}_{self._shot_seq:03d}_{tag}{idx}.png"
            self._shot_seq += 1
            try:
                loc.scroll_into_view_if_needed(timeout=5000)
                self.page.wait_for_timeout(150)
                loc.screenshot(path=str(p), timeout=8000)
                if p.exists() and p.stat().st_size > 0:
                    out.append(p)
            except Exception:
                # 退路：元素被遮挡/尺寸异常时，用当前视口 + 视口坐标裁
                try:
                    b = loc.bounding_box()
                    if b:
                        got = self.crop_regions([b], tag=f"{tag}{idx}_fb")
                        out.extend(got)
                except Exception:
                    pass
        return out

    def _frame_for_image(self, idx: int):
        """第 idx 张图片在哪个框架里（None = 主文档）。

        ⚠ `_frame_for(idx)` 那个用的是"题号"注册表，图片是另一回事
          （图片没有 qid/fid），所以单独按 index 找。
        """
        try:
            imgs = getattr(self, "_last_images", None) or []
            if 0 <= idx < len(imgs) and isinstance(imgs[idx], dict):
                fr = imgs[idx].get("_frame")
                if fr is not None and fr != self.page.main_frame:
                    return fr
        except Exception:
            pass
        return None

    def upscale_small(self, paths: list[Path], min_side: int = 480) -> list[Path]:
        """把过小的图放大后另存：9B 视觉模型对小图细节几乎看不见。"""
        from PIL import Image  # noqa: PLC0415

        out: list[Path] = []
        for p in paths:
            try:
                im = Image.open(p)
                if max(im.size) >= min_side:
                    out.append(p)
                    continue
                scale = min(3.0, min_side / max(1, max(im.size)))
                big = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))),
                                Image.LANCZOS)
                q = p.with_name(p.stem + f"_x{scale:.1f}.png")
                big.save(q)
                out.append(q)
            except Exception:
                out.append(p)
        return out

    # ------------------------------------------------------------ 杂项
    def wait_for_load(self, extra_ms: int = 1200) -> None:
        """等页面稳定。

        ⚠ 这里以前对每个页面都等一次 networkidle(最多 8 秒)。实测在本地 HTML 上
        它就是白白等到超时 —— 每页多花几百毫秒，几十页就是几十秒。
        file:// 页面根本没有网络活动，直接跳过；http(s) 才做一次短等待。
        """
        try:
            u = (self.page.url or "")
        except Exception:
            u = ""
        if u.startswith("file://"):
            # 本地文件：只等极短的一瞬让同步脚本跑完，不做 networkidle
            if extra_ms:
                self.page.wait_for_timeout(min(extra_ms, 150))
            return
        try:
            self.page.wait_for_load_state("networkidle", timeout=2500)
        except Exception:
            pass
        if extra_ms:
            self.page.wait_for_timeout(extra_ms)

    def login_signals(self, state: PageState) -> list[str]:
        """判断当前页面是不是登录页，返回命中的线索（空列表 = 不像登录页）。

        为什么要单独判断：登录页上的用户名/密码框也是 input，
        如果直接进答题流程，agent 会把它们当成"填空题"去作答 ——
        账号密码被乱填、登录流程被搅断，然后卡死。所以必须在答题之前拦住。

        ⚠ 判据必须**保守**。第一版写得太宽（页面文字含"登录/账号"且控件≤6 就算），
        结果把正常考试页也判成登录页 —— 侧边栏"答题卡"里的"答"字命中了关键词，
        加上一页一题本来就只有 5 个控件，直接导致整场考试在第 1 页就停住。
        宁可漏判（让它去答题，答不出自然会停），也不要误判。

        现在只认两种强信号：
          A. 页面上有 password 输入框（最强信号，作业页不该有）
          B. 同时满足：① 有 ≤3 个文本类输入框 ② 有"登录/登陆/sign in/log in"
             字样的可点击按钮或链接 ③ 没有题目（选项组）
        """
        reasons: list[str] = []

        # A. 密码框
        try:
            n_pwd = self.page.evaluate(
                "() => document.querySelectorAll('input[type=password]').length")
            if n_pwd:
                reasons.append(f"检测到 {n_pwd} 个密码输入框")
                return reasons          # 密码框一票通过，不必再看别的
        except Exception:
            pass

        # B. 登录表单形态（三个条件同时成立才算）
        n_choice = len(state.questions)
        if n_choice:
            return reasons              # 页面上已经有选项组 → 肯定是题目页，不是登录页
        n_text = sum(1 for f in state.fields if f.kind in ("text", "textarea", "contenteditable"))
        if n_text > 3:
            return reasons              # 输入框太多，更像问卷/表单而不是登录页

        login_word = re.compile(r"登录|登陆|sign\s*in|log\s*in|单点登录", re.I)
        btn_hit = next((b.get("text", "") for b in state.buttons if login_word.search(b.get("text", ""))), "")
        if btn_hit and n_text >= 1:
            reasons.append(f"页面上有登录按钮「{btn_hit}」和 {n_text} 个输入框，且没有任何题目")
        return reasons

    def looks_like_login(self, state: PageState) -> bool:
        return bool(self.login_signals(state))

    # 人机校验 / 验证码的关键词与选择器。
    #
    # ⚠ 这里**只用来检测**，绝不用来"解" —— 见 detect_challenge 的说明。
    _CHALLENGE_WORD = re.compile(
        r"验证码|校验码|人机验证|安全验证|滑块验证|拖动滑块|请完成验证|"
        r"captcha|recaptcha|geetest|verify\s*code|security\s*check",
        re.I)
    _CHALLENGE_SEL = (
        "img[src*='captcha' i]", "img[src*='yzm' i]", "img[src*='verify' i]",
        "[class*='captcha' i]", "[id*='captcha' i]",
        "[class*='yzm' i]", "[id*='yzm' i]",
        ".geetest_panel", ".geetest_holder", "[class*='geetest' i]",
        "[class*='slider' i]", "[class*='verify' i]",
    )

    _CHALLENGE_JS = r"""(args) => {
        const [sels, wordSrc] = args;
        const re = new RegExp(wordSrc, 'i');
        function visible(e) {
            if (!e) return false;
            const s = getComputedStyle(e);
            const r = e.getBoundingClientRect();
            return s.display !== 'none' && s.visibility !== 'hidden'
                && parseFloat(s.opacity || '1') > 0.05
                && r.width > 0 && r.height > 0;
        }
        // ① 选择器命中（可见才算）
        for (const sel of sels) {
            let list = [];
            try { list = document.querySelectorAll(sel); } catch (e) { continue; }
            for (const e of list) {
                if (visible(e)) return {found: true, how: sel};
            }
        }
        // ② 可见输入框**旁边**出现验证码字样
        //
        //    ⚠ 原来这里要求"页面上有 button 或 a"，实测**完全失效**：
        //      超星这类站点用的是 `<div class="btn2">` / `<span>`，
        //      页面上一个 <button> 都没有 → nBtn=0 → 判据永远不成立。
        //      2026-10-17 用户那份 quiz_dom.txt 里就有这个结构：
        //        <input class='Inp fl' placeholder='请输入验证码'>
        //        上三层文字：为保障您的账号安全，请输入验证码 … 继续学习
        //      当时 detect_challenge() 返回 found=False，
        //      于是交卷失败被误报成"没能确认提交成功"。
        //
        //    现在的判据：**一个可见的文本输入框，往上找 4 层，任一层含验证码字样**。
        //    不要求 button，也不数"全页面的输入框"（那样别的表单会误报）。
        const inputs = document.querySelectorAll(
            'input:not([type]), input[type=text], input[type=password]');
        for (const el of inputs) {
            if (!visible(el)) continue;
            let p = el, txt = '';
            for (let k = 0; k < 4 && p; k++, p = p.parentElement) {
                txt = (p.innerText || p.textContent || '');
                if (re.test(txt)) {
                    const m = re.exec(txt);
                    return {found: true,
                            how: '输入框旁:' + (m ? m[0] : ''),
                            hint: txt.replace(/\s+/g, ' ').slice(0, 90)};
                }
            }
        }
        return {found: false};
    }"""

    def detect_challenge(self) -> dict:
        r"""检测页面上是否出现了人机校验 / 验证码。

        返回 `{"found": bool, "how": str, "hint": str, "frame": str}`。

        ⚠ **本方法只做检测，绝不尝试识别或填写验证码。**
          验证码是平台的人机校验，自动解等于绕过反爬 ——
          这与本项目"不绕过人脸识别与活体检测"是同一条铁律。
          调用方应当在 `found` 时**停下并告知用户手动处理**。

        ⚠ 必须遍历**所有 frame**：这类弹层经常整块装在 iframe 里
          （实测智慧树/超星都会）。
        """
        frames = []
        try:
            frames = list(self.page.frames)
        except Exception:
            return {"found": False}
        for fr in frames:
            try:
                r = fr.evaluate(self._CHALLENGE_JS,
                                [list(self._CHALLENGE_SEL),
                                 self._CHALLENGE_WORD.pattern])
            except Exception:
                continue
            if r and r.get("found"):
                try:
                    furl = fr.url or ""
                except Exception:
                    furl = ""
                return {"found": True, "how": str(r.get("how") or ""),
                        "hint": str(r.get("hint") or "")[:80],
                        "frame": furl[:80]}
        return {"found": False}



# ---------------------------------------------------------------------------
def cleanup_stale_state(log=print) -> dict:
    """清理上一次运行残留的状态，回收磁盘。

    被强杀（任务管理器结束进程、断电、崩溃）时会留下垃圾：
      1. 浏览器档案里的 SingletonLock 等锁文件 —— 新实例可能因此起不来；
      2. Playwright 的临时目录 —— 每个几十 KB，久了两千个也不稀奇；
      3. 超出保留上限的截图；
      4. ★ **浏览器档案里的纯缓存** —— 这是磁盘真正的大头。

    服务启动时顺手清一遍，避免"越用越坏"。返回清理计数便于观察。

    ⚠ 关于第 4 项（储存优化）：实测连续用几次之后 out\\ 能涨到 **900MB**，
      几乎全是 Edge 自己下的东西：
        ProvenanceData           168MB（模型，每次重新下）
        component_crx_cache      155MB（组件缓存）
        Default\\Cache            20MB
        Edge Entity Extraction    8MB×2
      这些**删掉完全不影响功能**（Edge 下次要用会自己再下），
      但**登录态绝对不能碰** —— 那是用户要留着的东西。
      所以下面按"白名单删缓存 / 黑名单保登录"的边界来写。
    """
    import shutil

    freed = {"locks": 0, "tmp": 0, "shots": 0, "cache": 0}

    # 1) 浏览器档案锁文件
    for pat in ("SingletonLock", "SingletonSocket", "SingletonCookie", "lockfile"):
        try:
            for f in config.PROFILE_DIR.rglob(pat):
                try:
                    f.unlink()
                    freed["locks"] += 1
                except Exception:
                    pass
        except Exception:
            pass

    # 2) Playwright 临时目录
    try:
        for d in list(config.TMP_DIR.glob("**/playwright-artifacts-*")):
            try:
                shutil.rmtree(d, ignore_errors=True)
                freed["tmp"] += 1
            except Exception:
                pass
    except Exception:
        pass

    # 3) 截图超量
    #    ⚠ 只清"程序自己管的默认截图目录"。如果用户把截图位置改成了自己的
    #    图片文件夹（设置里可改），那里面可能有他的文件，绝对不能动。
    try:
        default_dir = (config.PROJECT_DIR / "截图").resolve()
        if config.SHOT_DIR.resolve() == default_dir:
            keep = 1 if config.CLEAR_SHOTS_EACH_ROUND else BrowserDriver._SHOT_KEEP
            shots = sorted(config.SHOT_DIR.glob("*.png"),
                           key=lambda f: f.stat().st_mtime, reverse=True)
            for old in shots[keep:]:
                try:
                    old.unlink()
                    freed["shots"] += 1
                except Exception:
                    pass
    except Exception:
        pass

    # 4) 浏览器档案里的纯缓存（占用大头）
    freed["cache"] = _trim_profile_caches(log)

    if any(freed.values()):
        log(f"[cleanup] 清理残留：锁 {freed['locks']} 个、临时目录 {freed['tmp']} 个、"
            f"旧截图 {freed['shots']} 张、档案缓存 {freed['cache']} 项")
    return freed


# 浏览器档案里**可以放心删**的目录/文件名（纯缓存，Edge 会自己重建）。
#
# 判定依据：删掉它们不会让用户重新登录，也不会丢设置 ——
#   它们要么是下载缓存，要么是每次启动重新拉取的模型/组件。
_PROFILE_JUNK = (
    "component_crx_cache",       # 组件缓存（实测 155MB）
    "ProvenanceData",            # 可视化模型（实测 168MB）
    "Edge Entity Extraction",    # 实体抽取模型（实测 8MB×2）
    "Cache", "Code Cache", "GPUCache", "ShaderCache", "DawnCache",
    "GrShaderCache", "GraphiteDawnCache",
    "Service Worker", "Application Cache", "Media Cache",
    "Crashpad", "BrowserMetrics", "OptimizationGuidePredictionModels",
    "Snapshots", "Safe Browsing", "SSLErrorAssistant",
    "OriginTrials", "Subresource Filter", "TrustTokenKeyCommitments",
    "ZxcvbnData", "WidevineCdm", "hyphen-data",
)

# **绝对不能删**的：删了就要重新登录 / 丢设置。
_PROFILE_KEEP = (
    "Cookies", "Cookies-journal", "Login Data", "Login Data-journal",
    "Web Data", "Web Data-journal", "Preferences", "Secure Preferences",
    "Local Storage", "Session Storage", "IndexedDB",
    "Extension State", "Local State", "Network",
)


def _trim_profile_caches(log=print) -> int:
    """删掉浏览器档案里的纯缓存目录，返回删掉的项数。

    ⚠ 只按**精确的目录名**匹配，且**跳过** _PROFILE_KEEP 里的名字 ——
      宁可少删一点，也绝不能把登录态删掉让用户重新登录。
    """
    import shutil

    n = 0
    # 两个档案都要清：
    #   PROFILE_DIR  —— 干活用的浏览器（登录态在这里，不能删）
    #   ui-profile   —— 软件自己的界面窗口（app_server 建的）
    ui_prof = config.OUT_DIR / "ui-profile"
    for prof in (config.PROFILE_DIR, ui_prof):
        try:
            if not prof or not prof.exists():
                continue
        except Exception:
            continue
        for name in _PROFILE_JUNK:
            if name in _PROFILE_KEEP:
                continue
            try:
                # 按名字在**任意层级**找（Edge 把这些放在 Default\ 下）
                for p in prof.rglob(name):
                    if not p.is_dir():
                        continue
                    # 保险：路径里出现受保护的名字就跳过
                    if any(k.lower() in str(p).lower()
                           for k in ("cookies", "login data")):
                        continue
                    shutil.rmtree(p, ignore_errors=True)
                    n += 1
            except Exception:
                pass
        # 顺带删掉体积大的散装缓存文件
        try:
            for pat in ("*.tmp", "*.log", "*-journal"):
                for f in prof.rglob(pat):
                    try:
                        if f.stat().st_size > 1024 * 1024:      # 只删 >1MB 的
                            f.unlink()
                            n += 1
                    except Exception:
                        pass
        except Exception:
            pass
    return n
