"""昔涟自习室（Cyrene Study）—— 网页作业 / 网课自动化引擎。

模块划分：
    config       配置（环境变量 DSHS_* 可覆盖；界面写的值存在 out/app_config.json）
    lms          OpenAI 兼容客户端（DeepSeek 官方 API / 本地 LM Studio 皆可）
    browser      Playwright 驱动（DOM 结构化扫描 + 精准落笔 + 翻页）
    desktop      纯 ctypes 键鼠 + 视觉定位（PC 模式兜底）
    agent        答题引擎（Web 模式 / PC 键鼠模式）
    app_server   图形界面用的本地服务（HTTP + SSE）
    gui          旧版 Tkinter 界面（保留，命令行场景可用）
"""

__version__ = "1.1.0"
__all__ = ["config", "lms", "browser", "desktop", "agent", "app_server", "gui"]
