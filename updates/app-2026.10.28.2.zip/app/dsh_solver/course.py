"""自动刷课：打开网课 → 设倍速 → 播完自动推进 → 直到学完。

**支持两种课程页形态，按页面结构自动分流（不绑域名）**：

  A. 「资源卡片式」课程页
     左侧目录（模块/章节） + 右侧资源卡片列表（视频/文档/PPT），
     完成判据以**平台自己记的进度**为准（如「必学 4/5」）。
     实测代表：智慧树 AI 版课程（ai-smart-course-student-pro.zhihuishu.com）。
     识别靠结构（找得到知识点+资源卡片），所以**别的平台只要是这套结构也能跑**。

  B. 「播放器式」课程页
     页面上直接有 <video>，学完一节点「下一节」推进。
     实测代表：老版智慧树 studyh5、超星/学习通 mooc1 学生页。
     识别靠"页面上有没有可播放的 <video>"，同样不绑域名。

  C. 「横向栏目式」课程页（学习通新版）
     顶部一行横向栏目（1 本章导读 / 2 目标与导学 / 3 学习视频 /
     4 小节测验 / 5 电子课件 / 6 扩展阅读），点哪条 #iframe 换成哪条的内容。
     视频在第 3 条里，**不点开那条页面上就没有 <video>**。
     识别靠几何位置（同一水平行 + X 方向连续的一串短文字），不绑类名。

实现思路（参考了开源同类工具的做法，如 cxmooc-tools / ocsjs / Autovisor）：
  1. 用已经登录好的浏览器打开课程页（复用答题那套 CDP 接管，登录态不用重来）
  2. 页面内找 <video>，设 playbackRate 与 muted，然后 play()
  3. 轮询 currentTime / duration / ended / paused
  4. 学完一节 → 找"下一节/下一个"按钮点掉 → 等视频换成新的一节 → 回到第 2 步
  5. 找不到下一节或没有视频了就结束

⚠ 现实提醒（不是免责套话，是真会遇到的）：
  · 主流网课平台（智慧树 / 超星学习通 / 职教云等）**普遍有防刷课机制**。
    常见后果是"进度不计入、需要重新学习"，账号被标记也时有发生。
  · 平台可能限制倍速（改了会被还原），也可能要求页面保持前台。
  · 因此这里会**如实报告**：只把"平台自己承认的进度"当作完成依据，
    不去伪造心跳或进度上报。改倍速、自动点下一节，仅此而已。
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass, field
from typing import Callable

from . import config
from .browser import BrowserDriver
from .keepalive import KeepAlive

# ---------------------------------------------------------------------------
# 智慧树「AI 版课程」 —— ai-smart-course-student-pro.zhihuishu.com
#
# 这是**独立的第五套系统**（考试 examloop / 老版 studyh5 / 翻转 hike /
# 融合 fusioncourseh5 / AI 版 ai-smart-course），DOM 结构互不兼容。
# 开源项目 Autovisor 明确写着未适配这一套。
#
# 结构实测（2026-10，用户真实页面采集）：
#   左侧  button.el-collapse-item__header              知识模块
#         .section-item-collapse-info[.active]          知识点
#         .progress-text                                "必学 5/5"
#   资源  .resources-detail-container 内的            ← 只取第一个（必学）
#           .resources-list > .basic-info-video-card-container
#             .video-info                              名称 + 时长
#             .finished-icon                           ★「已完成」角标
#             .page-num                                "69页"（PPT 才有）
#   播放器 Video.js：div#vjs_videoContStudy > video
#         ★ 实测带 vjs-controls-disabled —— **没有倍速菜单可点**，
#           只能直接设 video.playbackRate。这不算绕过平台：
#           平台菜单里根本没有倍速项，而且我们设的值在平台上限（1.8）之内。
# ---------------------------------------------------------------------------
AI_SELECTORS = {
    "module_head": "button.el-collapse-item__header",
    "module_active": ".el-collapse-item.is-active",
    "topic": ".section-item-collapse-info",
    "topic_active": ".section-item-collapse-info.active",
    "progress_text": ".progress-text",
    "detail_container": ".resources-detail-container",   # 第一个 = 必学资源
    "detail_title": ".resources-detail-title",
    "card": ".basic-info-video-card-container",
    "card_info": ".video-info",
    "card_done": ".finished-icon",
    "card_pages": ".page-num",
    "video": "video",
    "video_box": "#vjs_videoContStudy, #videoContStudy, .videoNameBox",
    "ppt_page": ".ppt-btn-container",
    "ppt_next": ".next-page-btn",
    "ppt_prev": ".prev-page-btn",
}

# 给 AI 版课程的 Video.js 播放器设倍速 + 静音 + 起播，并**同步界面显示**。
#
# 实测这个播放器带 `vjs-controls-disabled`（**控件被禁用**），
# 所以没有倍速菜单可点，只能直接改 playbackRate。
# 这不构成"绕过平台限制"：平台没提供倍速入口，而我们设的值在平台上限内。
#
# ⚠ 关键补充（参考开源项目 Autovisor 的做法）：
#   光改 playbackRate，**播放器上显示的倍速标签不会变** ——
#   用户看到界面上还写着 1×，会以为"没开倍速"，虽然实际已经加速了。
#   所以这里顺手把界面上的倍速文字也改掉（Autovisor 改的是 `.speedBox span`，
#   而 AI 版播放器控件被禁用、没有明显的倍速框，
#   于是这里**按文字内容找**：谁显示着 "1x"/"1.0×"/"倍速" 就改谁）。
_AI_VIDEO_JS = r"""
(arg) => {
  const rate = arg[0], mute = arg[1];
  const v = document.querySelector('video');
  if (!v) return { ok: false, why: 'no-video' };
  const out = {};
  try { if (mute) { v.muted = true; out.muted = v.muted; } } catch (e) {}
  try { v.playbackRate = rate; } catch (e) { out.rateErr = String(e); }
  // 有的内核把 playbackRate 包了一层，直接赋值不生效 → 走原生 setter
  try {
    const d = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(v), 'playbackRate');
    if (d && d.set && Math.abs(v.playbackRate - rate) > 1e-6) {
      d.set.call(v, rate);
    }
  } catch (e) { /* 忽略 */ }
  out.rate = v.playbackRate;
  try { const p = v.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  out.paused = v.paused;

  // ---- 同步界面上的倍速显示 ----
  const label = 'X ' + rate;
  const RATE_TXT = /^\s*(倍速|播放速度|速度)?\s*\d+(\.\d+)?\s*(x|X|×|倍)\s*$/;
  let updated = 0;
  try {
    // ① 经典选择器优先（老版课程就是 .speedBox span）
    document.querySelectorAll(
      '.speedBox span, .speed-box span, [class*=speed] span, [class*=rate] span'
    ).forEach(function (e) {
      const t = (e.innerText || e.textContent || '').trim();
      if (RATE_TXT.test(t) || /倍速|速度/.test(t)) {
        e.innerText = label; updated++;
      }
    });
    // ② 兜底：全页找"看着就是倍速"的短文字节点
    if (!updated) {
      document.querySelectorAll('span,div,p,b,i,em').forEach(function (e) {
        if (e.children.length > 0) return;
        const t = (e.innerText || e.textContent || '').trim();
        if (t.length > 8) return;
        if (!RATE_TXT.test(t)) return;
        e.innerText = label; updated++;
      });
    }
  } catch (e) { /* 忽略 */ }
  out.labelUpdated = updated;
  return out;
}
"""

# 资源列表 + 目录 + 播放器状态读取（只在 AI 版页面用）
_AI_SCAN_JS = r"""
(sel) => {
  function txt(e, n) {
    return (e && (e.innerText || e.textContent) || '')
      .replace(/\s+/g, ' ').trim().slice(0, n || 80);
  }
  function vis(e) {
    const r = e.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  function hasActive(e) {
    return /(^|\s)active(\s|$)/.test(typeof e.className === 'string' ? e.className : '');
  }

  const out = { url: location.href, isAI: false, topics: [], cards: [],
                activeTopics: 0, activeTopic: '', video: null, ppt: null };

  // 认页：既没有知识点也没有资源卡片，就不是 AI 版课程页
  if (!document.querySelector(sel.topic) && !document.querySelector(sel.card)) {
    return out;
  }
  out.isAI = true;

  // ---- 左侧知识点（带"必学 n/n"进度）----
  //
  // ★ 每个知识点还要记下"它属于哪个知识模块"。
  //
  // 为什么必须这样：真实页面的左侧目录是**累积展开**的 —— 点开一个新模块，
  // 旧模块的内容**不会消失**，新知识点只是**追加在后面**（叶子扇出）。
  // 实测日志：
  //   [1/16] 人工智能导论 → 5 个：人工智能概述、…发展历史、…流派、…
  //   [2/16] 机器学习    → 10 个：人工智能概述、…发展历史、…流派、…
  //                                机器学习和人工智能的关系、…      ← 新的追加在后
  // 所以"取列表里第一个没访问过的知识点"永远会落在**第一个模块**上 ——
  // 这正是用户说的"一直在同一个知识模块里反复选择"的根因。
  // 记下归属模块后，就能只处理当前模块自己的知识点。
  const moduleHeads = [...document.querySelectorAll(sel.module_head)];
  document.querySelectorAll(sel.topic).forEach(function (e) {
    const pt = e.querySelector(sel.progress_text);
    const name = txt(e, 40).replace(/必学\s*\d+\s*\/\s*\d+/, '').trim();
    const active = hasActive(e);
    // 往上找它所在的 .el-collapse-item，再拿这个 item 在折叠头列表里的下标
    let modIdx = -1;
    try {
      const item = e.closest('.el-collapse-item');
      if (item) {
        for (let i = 0; i < moduleHeads.length; i++) {
          if (moduleHeads[i].closest('.el-collapse-item') === item) { modIdx = i; break; }
        }
      }
    } catch (err) { modIdx = -1; }
    out.topics.push({
      name: name, progress: pt ? txt(pt, 12) : '', active: active,
      visible: vis(e), mod: modIdx,
    });
    if (active) { out.activeTopics += 1; out.activeTopic = name; }
  });
  // 每个模块各有几个知识点（用于日志和判断）
  out.modTopicCount = {};
  out.topics.forEach(function (t) {
    out.modTopicCount[t.mod] = (out.modTopicCount[t.mod] || 0) + 1;
  });

  // ---- 资源卡片：**只取标题是「必学资源」的那一块** ----
  //
  // ⚠ 走过两次弯路：
  //   ① 直接按卡片类名全页抓 → 把「选学资源」也刷了；
  //   ② 改成"取第一个 .resources-detail-container" → 真实页面的嵌套让
  //      "第一个"落到了选学上（实测去刷了「人工智能课程：1.2 …」
  //      「【余燕芳讲人工智能】…」这些选学内容，用户明确要求无视它们）。
  //
  //   所以现在**不按位置猜**：从每个「资源标题」节点出发，往上找
  //   真正装着卡片的那个祖先；关键是**优先选最近的**，并且一旦这个祖先
  //   里出现了别的资源标题（选学/AI推荐…），就说明爬过头了，退回上一层。
  function nearestBlock(titleEl, allTitles) {
    let n = titleEl.parentElement, hops = 0, fallback = null;
    while (n && hops < 6) {
      if (n.querySelector(sel.card)) {
        // 这个祖先里除了自己，还夹着别的资源标题 → 爬过头了
        let hasOther = false;
        for (const o of allTitles) {
          if (o === titleEl) continue;
          if (n.contains(o)) { hasOther = true; break; }
        }
        if (!hasOther) return n;
        if (!fallback) fallback = n;      // 记下来，实在找不到就用它
      }
      n = n.parentElement; hops++;
    }
    return fallback || titleEl.parentElement;
  }
  const titleEls = [...document.querySelectorAll(sel.detail_title)];
  let requiredBlock = null, requiredTitle = '';
  const others = [];
  for (const te of titleEls) {
    const name = txt(te, 12);
    if (!requiredBlock && /必学/.test(name)) {
      requiredBlock = nearestBlock(te, titleEls);
      requiredTitle = name;
    } else {
      others.push(te);
    }
  }
  out.detailTitle = requiredTitle;
  out.containerFound = !!requiredBlock;
  out.titleCount = titleEls.length;
  if (!requiredBlock && titleEls.length) {
    // 没有"必学"字样（页面文案可能不同）→ 退回第一个容器
    requiredBlock = document.querySelector(sel.detail_container);
    out.containerFound = !!requiredBlock;
    out.detailTitle = '(未找到「必学」字样，退回第一个容器)';
  }
  if (requiredBlock) {
    requiredBlock.querySelectorAll(sel.card).forEach(function (c, i) {
      // 被其它标题块（选学 / AI推荐…）包着的卡片，跳过
      for (const ot of others) {
        const ob = nearestBlock(ot, titleEls);
        if (ob && ob !== requiredBlock && ob.contains(c)) return;
      }
      const info = c.querySelector(sel.card_info);
      const full = txt(info || c, 80);
      const pagesEl = c.querySelector(sel.card_pages);
      const durM = /(\d{1,2}:\d{2}:\d{2})/.exec(full);
      const pctM = /(\d{1,3})\s*%/.exec(full);
      let name = full
        .replace(/\d{1,2}:\d{2}:\d{2}/g, '')
        .replace(/\d{1,3}\s*%/g, '')
        .replace(/已完成/g, '')
        .trim();
      // ★ 类型判定：先看时长，再看页数，最后看扩展名。
      //
      // ⚠ 踩过的坑：原来写成 `/\.pptx?|\.pdf/.test(full) || !!pagesEl`，
      //   结果**视频也被判成 PPT** —— 因为视频卡片上带时长（如 `00:04:25`），
      //   而 `.page-num` 选择器在某些卡片的祖先里也能命中。
      //   后果：视频走了"点开关闭"分支，根本不让它播，进度自然不动。
      //   实测日志：`· 打开PPT：机器学习基本框架（00:04:25）` ← 这明明是视频。
      //
      //   正确判据：**有时长的是视频；有页数的才是 PPT。**
      const isVideo = !!durM;
      const isDoc = !isVideo
        && (!!pagesEl || /\.pptx?$|\.pdf$/i.test((name || full).trim()));
      out.cards.push({
        idx: i, name: name, full: full,
        done: !!c.querySelector(sel.card_done),
        active: hasActive(c),
        duration: durM ? durM[1] : '',
        percent: pctM ? parseInt(pctM[1], 10) : null,
        pages: pagesEl ? txt(pagesEl, 10) : '',
        isPpt: isDoc, isVideo: isVideo,
        visible: vis(c),
        // 诊断：把「已完成」角标的原始信息带出来。
        // 疑惑点是"必学 4/5 但读到 5 条全完成" —— 怀疑这个角标元素一直存在、
        // 只是隐藏或文案不同，所以要看清它真实长什么样。
        iconCls: (function () {
          const ic = c.querySelector(sel.card_done);
          return ic ? String(ic.className || '') : '(无角标元素)';
        })(),
        iconVisible: (function () {
          const ic = c.querySelector(sel.card_done);
          if (!ic) return false;
          const r = ic.getBoundingClientRect();
          const s = getComputedStyle(ic);
          return r.width > 0 && r.height > 0
                 && s.display !== 'none' && s.visibility !== 'hidden'
                 && parseFloat(s.opacity || '1') > 0.05;
        })(),
      });
    });
  }

  // ---- 播放器状态 ----
  const v = document.querySelector(sel.video);
  if (v) {
    const box = v.closest(sel.video_box) || v.parentElement;
    const bc = box ? String(box.className || '') : '';
    out.video = {
      found: true,
      currentTime: Number(v.currentTime) || 0,
      duration: Number(v.duration) || 0,
      ended: !!v.ended, paused: !!v.paused, muted: !!v.muted,
      rate: Number(v.playbackRate) || 1,
      src: String(v.currentSrc || v.src || '').slice(0, 110),
      controlsDisabled: /vjs-controls-disabled/.test(bc),
    };
  }
  const ppt = document.querySelector(sel.ppt_page);
  if (ppt) {
    const t = txt(ppt, 20);
    out.ppt = { text: t, hasPages: /\d+\s*\/\s*\d+/.test(t) };
  }
  return out;
}
"""


# ---------------------------------------------------------------------------
# 智慧树（老版 studyh5）的真实结构 —— 取自开源项目 Autovisor 的源码。
#
# 它有**四套**并存的课程目录结构（新版/融合共享课/翻转课/旧版），得逐个尝试。
# 详情见 docs/智慧树刷课-现成方案调研.md
#
# 最重要的一条设计（照抄自 Autovisor，理由见下）：
#   **以「平台记录的进度」为完成判据，而不是 video.currentTime。**
#   因为平台只认真实播放时长 —— 把 currentTime 往前快进，平台不计数，
#   反而可能判为异常。所以不能靠快进"秒过"，只能按平台允许的倍速老实播。
# ---------------------------------------------------------------------------
ZHIHUISHU_CATALOGS: list[dict[str, str]] = [
    {   # 新版智慧课
        "name": "新版智慧课",
        "item": ".child-info.hasvideo",
        "active": ".child-info.hasvideo.current",
        "finish": ".child-check",
        "title": ".child-name",
        "progress": "[role='progressbar'][aria-valuenow]",
    },
    {   # 融合共享课
        "name": "融合共享课",
        "item": ".chapter-item",
        "active": ".chapter-content-second.current",
        "finish": ".finish-icon",
        "title": ".item-name",
        "progress": ".el-progress",
    },
    {   # 翻转课
        "name": "翻转课",
        "item": ".file-item",
        "active": ".file-item.active",
        "finish": ".icon-finish",
        "title": "",
        "progress": ".rate",
    },
    {   # 旧版
        "name": "旧版",
        "item": ".clearfix.video",
        "active": ".clearfix.video.current_play",
        "finish": ".time_icofinish",
        "title": "#lessonOrder",
        "progress": ".progress-num",
    },
]

# 页面内的"平台进度 + 目录"读取脚本。
# 把四套结构都试一遍，返回可用的一套与当前可见的进度。
_CATALOG_JS = r"""
(cats) => {
  function txt(e) {
    return (e && (e.innerText || e.textContent) || '').replace(/\s+/g, ' ').trim();
  }
  function styleOf(e) {
    return ((e && e.getAttribute && e.getAttribute('style')) || '');
  }
  function pctFromText(s) {
    const m = /(\d{1,3}(?:\.\d+)?)\s*%/.exec(s || '');
    return m ? Math.min(100, parseFloat(m[1])) : null;
  }
  function readProgress(el) {
    if (!el) return null;
    const av = el.getAttribute('aria-valuenow');
    if (av !== null && av !== '') {
      const n = parseFloat(av);
      if (isFinite(n)) return Math.min(100, n);
    }
    const t = pctFromText(txt(el));
    if (t !== null) return t;
    const m = /width\s*:\s*(\d{1,3}(?:\.\d+)?)%/.exec(styleOf(el));
    if (m) return parseFloat(m[1]);
    return null;
  }

  for (let i = 0; i < cats.length; i++) {
    const c = cats[i];
    let items = [];
    try { items = Array.prototype.slice.call(document.querySelectorAll(c.item)); }
    catch (e) { continue; }
    if (!items.length) continue;

    let act = null;
    try { act = document.querySelector(c.active); } catch (e) { act = null; }

    // 进度：优先取"当前项"里的，取不到再全页找
    let progress = null;
    let progressText = '';
    if (c.progress) {
      let el = null;
      try { if (act) el = act.querySelector(c.progress); } catch (e) { el = null; }
      if (!el) { try { el = document.querySelector(c.progress); } catch (e) { el = null; } }
      if (el) {
        progress = readProgress(el);
        progressText = (txt(el) || styleOf(el)).slice(0, 40);
      }
    }

    // 当前课时标题
    let title = '';
    if (act) {
      if (c.title) {
        try {
          const te = act.querySelector(c.title);
          if (te) title = txt(te);
        } catch (e) { /* 忽略 */ }
      }
      if (!title) title = txt(act);
      if (title.length > 60) title = title.slice(0, 60);
    }

    // 当前项是否已被标记完成
    let done = false;
    if (act && c.finish) {
      try { done = !!act.querySelector(c.finish); } catch (e) { done = false; }
    }

    // 整章的完成情况
    let finished = 0;
    if (c.finish) {
      items.forEach(function (it) {
        try { if (it.querySelector(c.finish)) finished++; } catch (e) { /* 忽略 */ }
      });
    }

    return {
      matched: true, name: c.name, total: items.length, finished: finished,
      index: act ? items.indexOf(act) : -1,
      progress: progress, progressText: progressText,
      title: title, done: done,
    };
  }
  return { matched: false };
}
"""

# 页面内脚本：找视频、发现平台提供的倍速、控制播放、读进度
# ---------------------------------------------------------------------------
_PROBE_JS = r"""
() => {
  function vis(e) {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 80 || r.height < 50) return false;
    const s = getComputedStyle(e);
    return s.display !== 'none' && s.visibility !== 'hidden'
           && parseFloat(s.opacity || '1') > 0.05;
  }
  // 取页面上"最大"的那个 video —— 课程播放器通常是最大的那个，
  // 小的往往是广告/预览片。
  const vids = Array.prototype.slice.call(document.querySelectorAll('video')).filter(vis);
  if (!vids.length) return { found: false };
  vids.sort(function (a, b) {
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    return (rb.width * rb.height) - (ra.width * ra.height);
  });
  const v = vids[0];
  v.setAttribute('data-dsh-video', '1');
  return {
    found: true,
    count: vids.length,
    currentTime: Number(v.currentTime) || 0,
    duration: Number(v.duration) || 0,
    ended: !!v.ended,
    paused: !!v.paused,
    muted: !!v.muted,
    rate: Number(v.playbackRate) || 1,
    readyState: v.readyState,
    src: String(v.currentSrc || v.src || '').slice(0, 120),
  };
}
"""

# ---------------------------------------------------------------------------
# 发现"平台自己提供的倍速选项"。
#
# 设计原则（用户明确要求）：**不去改代码里的 playbackRate 来绕开限制**，
# 而是点平台自己的倍速菜单，选一个它允许的值。
# 平台只给到 2× 就用 2×，给到 1.5× 就用 1.5× —— 尊重平台，不越界。
#
# 难点：各平台倍速控件的结构千差万别，所以这里做三件事：
#   ① 收集页面上所有"像倍速"的可点元素（文字形如 1.5x / 2.0倍 / 倍速）
#   ② 找出倍速菜单的开关（文字含"倍速"），以便需要时展开
#   ③ 返回候选清单，由 Python 侧决定点哪个
_SPEED_JS = r"""
(arg) => {
  const wantText = (arg && arg[0]) || '';
  function txt(e) {
    return (e.innerText || e.textContent || e.getAttribute('aria-label')
            || e.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
  }
  function vis(e) {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return false;
    const s = getComputedStyle(e);
    return s.display !== 'none' && s.visibility !== 'hidden'
           && parseFloat(s.opacity || '1') > 0.05;
  }
  const RATE = /(\d+(?:\.\d+)?)\s*(?:x|X|倍|×)/;
  const rates = [];        // {rate, x, y, text, active}
  const toggles = [];      // 倍速菜单开关

  const all = document.querySelectorAll('div,span,a,button,li,label,p');
  for (let i = 0; i < all.length; i++) {
    const e = all[i];
    if (!vis(e)) continue;
    const t = txt(e);
    if (!t || t.length > 16) continue;
    const m = RATE.exec(t);
    if (m) {
      // 形如 1.5x —— 收集为可选倍速
      const r = parseFloat(m[1]);
      if (r > 0 && r <= 16) {
        const rc = e.getBoundingClientRect();
        const cls = (typeof e.className === 'string' ? e.className : '');
        rates.push({
          rate: r, text: t,
          x: Math.round(rc.x), y: Math.round(rc.y),
          w: Math.round(rc.width), h: Math.round(rc.height),
          active: /active|current|selected|checked|on\b/i.test(cls),
          clickable: true,
        });
      }
      continue;
    }
    // 菜单开关：文字就是"倍速"，或者含"倍速"且很短
    if (/倍速|播放速度|速度/.test(t) && t.length <= 8) {
      const rc = e.getBoundingClientRect();
      toggles.push({ text: t, x: Math.round(rc.x), y: Math.round(rc.y),
                     w: Math.round(rc.width), h: Math.round(rc.height) });
    }
  }
  // 同一倍速去重（保留第一个）
  const seen = {}, uniq = [];
  rates.forEach(function (r) {
    const k = r.rate + '|' + r.text;
    if (seen[k]) return;
    seen[k] = 1; uniq.push(r);
  });
  uniq.sort(function (a, b) { return a.rate - b.rate; });
  return { rates: uniq, toggles: toggles.slice(0, 4),
           current: uniq.filter(function (r) { return r.active; })
                        .map(function (r) { return r.rate; })[0] || null };
}
"""

# 兜底：页面上找不到倍速菜单时，直接设播放器倍速。
# **只在平台上限之内使用**（调用方已钳到 COURSE_MAX_SPEED），
# 所以不构成"绕过平台限制"。
#
# 用原型上的 setter 而不是 `v.playbackRate = x`：有的播放器内核
# 在这个属性上装了拦截，直接赋值会被判定成"没变化"而不生效。
_FORCE_RATE_JS = r"""
(rate) => {
  const v = document.querySelector('video[data-dsh-video="1"]')
         || document.querySelector('video');
  if (!v) return { ok: false };
  try { v.playbackRate = rate; } catch (e) { /* 继续试 setter */ }
  try {
    const d = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(v), 'playbackRate');
    if (d && d.set && Math.abs(v.playbackRate - rate) > 1e-6) {
      d.set.call(v, rate);
    }
  } catch (e) { /* 忽略 */ }
  // 顺手把界面上的倍速标签也改掉（智慧树是 .speedBox span），
  // 免得画面显示的和实际不一致。
  try {
    document.querySelectorAll('.speedBox span').forEach(function (el) {
      el.innerText = 'X ' + rate;
    });
  } catch (e) { /* 忽略 */ }
  try { v.play(); } catch (e) { /* 忽略 */ }
  return { ok: true, rate: v.playbackRate };
}
"""

# 设静音 +（可选）播放。**不直接改 playbackRate** —— 倍速交给平台菜单。
_SETUP_JS = r"""(arg) => {
  const mute = arg[0];
  const v = document.querySelector('video[data-dsh-video="1"]')
         || document.querySelector('video');
  if (!v) return { ok: false, why: 'no-video' };
  const out = {};
  try { v.muted = !!mute; out.muted = v.muted; } catch (e) { out.mutedErr = String(e); }
  let p = null;
  try { p = v.play(); } catch (e) { out.playErr = String(e); }
  if (p && typeof p.catch === 'function') {
    p.catch(function (e) { window.__dshPlayErr = String(e); });
  }
  out.paused = v.paused;
  return out;
}
"""

# 找"下一节 / 下一个"按钮。返回候选的文字，供上层决定点哪个。
_NEXT_JS = r"""
() => {
  function vis(e) {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 20 || r.height < 12) return false;
    const s = getComputedStyle(e);
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    if (parseFloat(s.opacity || '1') <= 0.05) return false;
    if (e.disabled) return false;
    return true;
  }
  function txt(e) {
    return (e.innerText || e.textContent || e.getAttribute('aria-label') || '')
      .replace(/\s+/g, ' ').trim();
  }
  // 优先级：明确的"下一节"，再退到"下一个"
  const strong = /^\s*(下一节|下一讲|下一课|下一个视频|下一集)\s*$/;
  const weak = /(下一节|下一讲|下一课|下一集|下一个|next)/i;
  const bad = /(上一|返回|上一节|上一讲)/;
  const hits = [];
  document.querySelectorAll('a,button,div,span,li,i').forEach(function (e) {
    if (e.children.length > 2) return;         // 只要叶子/近叶子，避免点到整块
    if (!vis(e)) return;
    const t = txt(e);
    if (!t || t.length > 24) return;
    if (bad.test(t)) return;
    let score = 0;
    if (strong.test(t)) score = 100;
    else if (weak.test(t)) score = 50;
    else {
      // 图标型按钮：靠 title / aria-label / class 里带 next
      const meta = (e.getAttribute('title') || '') + ' ' +
                   (e.getAttribute('aria-label') || '') + ' ' +
                   (typeof e.className === 'string' ? e.className : '');
      if (/next/i.test(meta)) score = 30;
      else return;
    }
    const r = e.getBoundingClientRect();
    hits.push({ text: t, score: score, x: Math.round(r.x), y: Math.round(r.y),
                w: Math.round(r.width), h: Math.round(r.height) });
  });
  hits.sort(function (a, b) { return b.score - a.score; });
  return hits.slice(0, 8);
}
"""

# ---------------------------------------------------------------------------
# 「没有『下一节』按钮」时的兜底：从**右侧目录**点下一条
#
# 2026-10-23 用户：「无法切换下一节是因为他没有下一节按键，需要在侧栏手动选择」
# —— 智慧树这版就是这样：
#     li.clearfix.font_gray_inclined.chapter   ← 章标题（不可播）
#     li.clearfix.video.current_play           ← 当前这一节
#     li.clearfix.video                        ← 其它可播小节
#   点 li 的任意位置即可切换，切换后 <video> 的 src 会变。
# ---------------------------------------------------------------------------
_SIDEBAR_NEXT_JS = r"""
() => {
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 20 && r.height > 10;
    } catch (err) { return false; }
  }
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  }
  // ① 智慧树：能播的小节是 li.video（章标题是 li.chapter，分组是 li.clearfix）
  let items = Array.prototype.slice.call(document.querySelectorAll('li.video'))
      .filter(function (e) {
        // 还要求条目里有 .catalogue_title —— 免得在别的站点把随便一个
        // 「视频列表」当成课程目录乱点。
        return vis(e) && !!e.querySelector('.catalogue_title');
      });
  // ② 兜底：没有 .video 类时，用"带小节编号"的 li（.catalogue_title4）
  if (items.length < 2) {
    items = Array.prototype.slice.call(document.querySelectorAll('li'))
      .filter(function (e) {
        return vis(e) && !!e.querySelector('.catalogue_title4');
      });
  }
  if (items.length < 2) {
    return {ok: false, why: '目录里只找到 ' + items.length + ' 条可播小节'};
  }
  let idx = items.findIndex(function (e) {
    return /(^|[\s_-])(current_play|current|active)([\s_-]|$)/.test(String(e.className || ''));
  });
  if (idx < 0) {
    return {ok: false, why: '找不到"当前播放"的那一条'};
  }
  if (idx + 1 >= items.length) {
    return {ok: false, why: '已经是目录最后一条'};
  }
  const nxt = items[idx + 1];
  try { nxt.scrollIntoView({block: 'center'}); } catch (err) {}
  const r = nxt.getBoundingClientRect();
  return {
    ok: true,
    x: r.left + r.width / 2,
    y: r.top + r.height / 2,
    from: txt(items[idx]).slice(0, 30),
    to: txt(nxt).slice(0, 30),
    count: items.length,
  };
}
"""

# ---------------------------------------------------------------------------
# 「平台到底记了多少」：右侧目录的每一条上就写着百分比
#
# 2026-10-23 真机日志（智慧树 12:05）：
#     —— 第 1 节：00:13:51/00:13:51 ...   → 播放器 100%，2 秒就判「已播完」
#     侧栏却写着「0.1 引言 73%」          → 平台只认 73%
# 它把这节记成播完、直接切到 0.2.1 —— 就是用户说的「不刷完自动切下一个」。
# 这里只读**当前那一条**上的百分比；读不到返回 ok:false，上层原样退回老判据。
# ---------------------------------------------------------------------------
_SIDEBAR_PROGRESS_JS = r"""
() => {
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 20 && r.height > 10;
    } catch (err) { return false; }
  }
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  }
  let items = Array.prototype.slice.call(document.querySelectorAll('li.video'))
      .filter(function (e) { return vis(e) && !!e.querySelector('.catalogue_title'); });
  if (items.length < 2) {
    items = Array.prototype.slice.call(document.querySelectorAll('li'))
      .filter(function (e) { return vis(e) && !!e.querySelector('.catalogue_title4'); });
  }
  if (items.length < 2) return {ok: false, why: '目录里只找到 ' + items.length + ' 条'};
  const cur = items.find(function (e) {
    return /(^|[\s_-])(current_play|current|active)([\s_-]|$)/.test(String(e.className || ''));
  });
  if (!cur) return {ok: false, why: '找不到"当前播放"的那一条'};
  const t = txt(cur);
  const m = t.match(/(\d{1,3})\s*%/);
  if (!m) return {ok: false, why: '这一条上没有百分比', text: t.slice(0, 60)};
  return {ok: true, pct: Math.max(0, Math.min(100, parseInt(m[1], 10))),
          text: t.slice(0, 60)};
}
"""

# 把视频拨回「平台已经记到的位置」，好把没被记上的那一段补看完。
_SEEK_BY_PCT_JS = r"""
(pct) => {
  const v = document.querySelector('video[data-dsh-video="1"]')
         || document.querySelector('video');
  if (!v) return {ok: false};
  const d = Number(v.duration) || 0;
  if (!d) return {ok: false};
  // 往前退 2 秒再开始 —— 平台常按"最后几秒没看"不认账
  const t = Math.max(0, Math.min(d - 0.4, d * (Number(pct) || 0) / 100 - 2));
  try { v.currentTime = t; } catch (err) { return {ok: false}; }
  return {ok: true, t: t, d: d};
}
"""

# 平台百分比到多少才算「这一节真的学完了」。留 2% 余量：有的平台只记到
# 98/99%，按 100 卡会永远差一口气。
_PLATFORM_PCT_DONE = 98

# 播放器到头、平台却没记满时，最多拨回去补看几次。
_REWIND_TRIES = 3

# 点完「下一节」后等视频换源的秒数（测试里会临时改小）。
# 10 秒：原来一次固定等 20 秒；现在最多试几条路，单条就别再那么久了。
_ADVANCE_WAIT_SEC = 10.0


def _rect_contains(outer: dict, inner: dict) -> bool:
    """`outer` 的矩形是否**完整包住** `inner`（用来剔掉"包着按钮的容器"）。"""
    try:
        ox, oy = float(outer["x"]), float(outer["y"])
        ow, oh = float(outer["w"]), float(outer["h"])
        ix, iy = float(inner["x"]), float(inner["y"])
        iw, ih = float(inner["w"]), float(inner["h"])
    except (KeyError, TypeError, ValueError):
        return False
    return (ox <= ix + 1 and oy <= iy + 1
            and ox + ow >= ix + iw - 1 and oy + oh >= iy + ih - 1
            and ow * oh > iw * ih)

# 页面上的课程/章节标题，用于日志里显示"在学哪一节"
#
# ⚠ 别只取页面上第一个 h1/h2 —— 实测会抓到侧栏的「课程目录」这种标签。
#   优先从**视频元素附近**往上找标题，那才是当前这一节的名字。
_TITLE_JS = r"""
() => {
  function txt(e) {
    return (e && (e.innerText || e.textContent) || '').replace(/\s+/g, ' ').trim();
  }
  function ok(t) {
    if (!t || t.length < 2 || t.length > 60) return false;
    if (/^(课程目录|目录|章节|答题卡|播放列表|评论)$/.test(t)) return false;
    // 排除播放器 HUD / 状态条这类"看着像标题其实不是"的文字，例如
    //   "0.0s / 20s 倍速 1×  [播放中]"
    if (/^\d+(\.\d+)?\s*s\s*\/\s*\d/.test(t)) return false;
    if (/\[(播放中|暂停|已播完|完|停)\]/.test(t)) return false;
    if (/^[\d.\s/xX×倍速\[\]()（）]+$/.test(t)) return false;
    return true;
  }
  const found = [];
  const v = document.querySelector('video[data-dsh-video="1"]')
         || document.querySelector('video');
  if (v) {
    let n = v, hops = 0;
    while (n && n !== document.body && hops < 8) {
      // 本层里的标题类元素
      const cand = n.querySelectorAll(
        'h1,h2,h3,h4,.title,.name,.lesson-title,[class*=lessonName],[class*=chaptername]');
      for (let i = 0; i < cand.length; i++) {
        const t = txt(cand[i]);
        if (ok(t) && found.indexOf(t) < 0) found.push(t);
      }
      // 本层自身也可能就是标题容器
      const st = txt(n);
      if (ok(st) && st.length < 60 && found.indexOf(st) < 0) found.push(st);
      if (found.length >= 3) break;
      n = n.parentElement; hops++;
    }
  }
  if (!found.length) {
    // 兜底：整页找"像标题"的元素。
    // ⚠ 不能只扫 h1/h2/h3 —— 实测很多平台（含自测页）用
    //   <div class="lesson-title"> 之类的结构，扫标题标签会一无所获。
    document.querySelectorAll(
      'h1,h2,h3,h4,[class*=title],[class*=name],[class*=chapter],[class*=lesson]'
    ).forEach(function (e) {
      if (e.children.length > 3) return;              // 只要近叶子，避免大容器
      const cls = (typeof e.className === 'string' ? e.className : '');
      if (/card-head|nav|menu|list-|item-|breadcrumb|tab|hud|hint|tip|toast/i.test(cls)) return;
      const t = txt(e);
      if (ok(t) && found.indexOf(t) < 0) found.push(t);
    });
  }
  return found.slice(0, 4);
}
"""


# ===========================================================================
# 「横向栏目」识别与点击（学习通新版章节页）
# ===========================================================================
#
# 页面长这样（顶部一行横向栏目，点哪条 #iframe 就换成哪条的内容）：
#
#   计算机网络的概念与发展
#   ┌──────────────────────────────────────────────────────────────┐
#   │ 1 本章导读 │ 2 目标与导学 │ 3 学习视频 │ 4 小节测验 │ 5 电子课件 │ 6 扩展阅读 │
#   └──────────────────────────────────────────────────────────────┘
#   ┌── #iframe ───────────────────────────────────────────────────┐
#   │  当前栏目的内容（视频在第 3 条里，不点开根本不加载）              │
#   └──────────────────────────────────────────────────────────────┘
#
# ⚠ 为什么**不能用类名点**：
#   · 这一版的栏目项没有任何稳定类名/ID，不同学校、不同版本都不一样；
#   · 栏目项常常是 <ul><li><a><span>文字</span></a></li></ul> 这种
#     深层嵌套，每个文字节点的**父级都不同**，按父级分组一个也凑不齐。
#   所以这里改成**按几何位置认**：谁是"同一水平行 + X 方向连续 + 文字很短
#   的一串"，谁就是栏目条。栏目名只用来**打分挑出真正的那一条**，不用来定位。
# ===========================================================================
# 在场守卫（防「鼠标离开播放器 → 平台按暂停」）
#
# 证据：out\pause_trace.json（2026-10-17 13:54）里 6 次 pause-call 之前
#   0~3ms 全都有一个 mouseout，目标是 .vjs-control-bar / .sp_function /
#   播放器 iframe；visibilitychange / blur / pagehide 一次都没有。
#   调用栈是 videojs-ext → all-classes（混淆层的程序化调用），不是 DOM 直连。
# ===========================================================================
# 弹题答完后那个「继续学习」按钮。
#
# 用户 2026-10-17 14:16 的截图：答对之后弹出
#   「恭喜你，答对了！你的答题水准超过了 91% 的同学」 + [继续学习]
# 不点它，视频就一直停在那层下面，进度条不走。
#
# ⚠ 只认**短文字**（≤12 字）且是整串相等，避免点到"继续学习下面的说明文字"。
# 「下一节」点不动时，从**右侧章节目录**点下一条。
#
# 用户 2026-10-17 16:03：「这不是最后一节」——截图里 4.4 之后还有第五、六章，
# 但「下一节」点了页面没变化，于是整轮在 4.4 停住。
#
# ⚠ 不写死学习通的类名（`posCatalog_name` 之类会随版本变），
#   改用**文字形状 + 高亮状态**来找：
#     · 文字像目录项：以 "4.4 " / "5.1 " 这种编号开头
#     · "当前"：类名/属性里有 active / cur / select / on，或 aria-selected
_CX_CATALOG_NEXT_JS = r"""
() => {
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 8 && r.height > 8;
    } catch (err) { return false; }
  }
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  }
  function cls(e) {
    try {
      return String((e.className && e.className.baseVal !== undefined)
                     ? e.className.baseVal : (e.className || ''));
    } catch (err) { return ''; }
  }
  // 目录项：**必须带小数点**（4.4 / 5.1）。章标题「5 第六章 …」不算 ——
  // 2026-10-17 16:15 就是被章标题骗过，从 4.4 跳回了第一章。
  const ITEM = /^\d{1,2}(\.\d{1,2})+\s+\S/;
  function isCur(e) {
    try {
      if (e.getAttribute && e.getAttribute('aria-selected') === 'true') return true;
      let p = e;
      for (let k = 0; k < 3 && p; k++, p = p.parentElement) {
        // ⚠⚠ 只认明确的“当前”词。
        //
        //   2026-10-17 17:49 实测：原来的正则里有 `select` / `on` / `cur`，
        //   而学习通给**所有**目录项都挂了 `posCatalog_select`，
        //   于是 12 条全被判成"当前" → 选了第 1 条 → 点了第 2 条，
        //   跟实际章节完全无关。
        if (/(^|[\s_-])(active|current|curr|checked)([\s_-]|$)/i
              .test(cls(p))) return true;
      }
    } catch (err) {}
    return false;
  }

  // 收集目录项（最内层）
  let all = [];
  for (const e of document.querySelectorAll('a,li,span,div,p')) {
    if (!vis(e)) continue;
    const t = txt(e);
    if (!t || t.length > 80) continue;
    if (!ITEM.test(t)) continue;
    all.push({el: e, t: t});
  }
  all = all.filter(function (a) {
    return !all.some(function (b) { return b !== a && a.el.contains(b.el); });
  });
  // 只要"看得见一长串"的那个列表（右侧目录）
  if (all.length < 2) {
    return {ok: false, why: '目录里只找到 ' + all.length + ' 条', dump: []};
  }

  // 诊断用：把前 12 条的**真实结构**带回去
  const dump = all.slice(0, 12).map(function (a) {
    const e = a.el;
    return {
      t: a.t.slice(0, 26),
      tag: String(e.tagName || '').toLowerCase(),
      cls: cls(e).slice(0, 40),
      // 父级链的 class（往上 3 层）—— “当前”标记很可能在父级上
      pcls: (function () {
        const out = [];
        let p = e.parentElement, k = 0;
        while (p && k < 3) { out.push((p.tagName || '').toLowerCase()
                                + '.' + cls(p).slice(0, 28)); p = p.parentElement; k++; }
        return out.join(' < ');
      })(),
      href: (e.getAttribute && e.getAttribute('href')) || '',
      onclick: !!(e.getAttribute && e.getAttribute('onclick')),
      cur: isCur(e),
    };
  });

  let idx = -1;
  for (let i = 0; i < all.length; i++) { if (isCur(all[i].el)) { idx = i; break; } }
  if (idx < 0) return {ok: false, why: '找不到"当前高亮"的那一条', dump: dump};
  if (idx + 1 >= all.length) {
    return {ok: false, why: '当前已经是目录最后一条', dump: dump};
  }
  const cur = all[idx], nxt = all[idx + 1];
  // ★ 先滚到可见再取坐标。
  //
  //   2026-10-17 17:49 实测：目录是可滚动列表，目标项常常在视口下面，
  //   `getBoundingClientRect()` 给的 y 是 1500+ → 真实鼠标点到了别处
  //   → "chapterId 没变"。滚一下就好了。
  try { nxt.el.scrollIntoView({block: 'center', inline: 'nearest'}); } catch (err) {}
  const r = nxt.el.getBoundingClientRect();
  return {
    ok: true,
    from: cur.t.slice(0, 30),
    to: nxt.t.slice(0, 30),
    x: r.left + r.width / 2,
    y: r.top + r.height / 2,
    href: (nxt.el.getAttribute && nxt.el.getAttribute('href')) || '',
    tag: String(nxt.el.tagName || '').toLowerCase(),
    dump: dump,
  };
}
"""

# ---------------------------------------------------------------------------
# 「目录式」章节页（mooc2=1 的 studentstudy，2026-10-23 真机 dump 出来的）
#
# 结构（来自用户的一键检测报告）：
#   #coursetree
#     └─ .posCatalog_select[id="cur352290168"]         ← 一个**章节**（叶子）
#          ├─ span.posCatalog_name[onclick="getTeacherAjax(课程,班级,章节)"]
#          ├─ input.jobUnfinishCount[value="3"]       ← 本章还剩几个任务点
#          └─ span.icon_Completed                     ← 本章已完成
#   当前章 = .posCatalog_active
#   整门课：#_studystate value="{nextChapterId:…,unfinishCount:97}"
#   内容层：#iframe → knowledge/cards → .ans-attach-ct（视频/文档/作业…）
#
# ⚠ 这一版**没有** `.jobCount`、没有 `.tabtags`、也没有"横向栏目条"，
#   所以三条既有路径全都认不出它；而它的 `下一节` 按钮在**本章任务点没做完时
#   平台是拦着的** —— 只点「下一节」永远翻不了页。
# ---------------------------------------------------------------------------
_CX_CATALOG_TREE_JS = r"""
() => {
  const tree = document.querySelector('#coursetree');
  if (!tree) return {ok: false};
  function txt(e) {
    return (e && (e.innerText || e.textContent) || '')
      .replace(/\s+/g, ' ').trim();
  }
  const leaves = [];
  // ⚠ 2026-10-23：不再只认 `[id^="cur"]`。
  //   有的学校/版本叶子项的 id 没有 `cur` 前缀（数字 id 或纯 onclick），
  //   只认 cur 会整页判否、掉回通用逻辑（就是"每节 2 秒假播完"那个老问题）。
  //   真正的判据是**叶子上有 `.posCatalog_name`**（章标题用的是 `.posCatalog_title`）。
  tree.querySelectorAll('.posCatalog_select').forEach(function (el) {
    const name = el.querySelector('.posCatalog_name');
    if (!name) return;
    let id = String(el.id || '').replace(/^cur/, '');
    if (!id) {
      // 从 onclick="getTeacherAjax('课程','班级','章节')" 里取章节 id
      const oc = String(name.getAttribute('onclick') || '');
      const m = oc.match(/getTeacherAjax\([^)]*?['"](\d{4,})['"]\s*\)/);
      if (m) id = m[1];
    }
    if (!id) return;
    // 本章还剩几个任务点：优先读隐藏 input，再退到角标上的数字
    let unfin = -1;
    const inp = el.querySelector('input.jobUnfinishCount');
    if (inp) {
      const v = parseInt(String(inp.value || ''), 10);
      if (!isNaN(v)) unfin = v;
    }
    if (unfin < 0) {
      const o = el.querySelector('.orangeNew');
      if (o) {
        const v = parseInt(txt(o), 10);
        if (!isNaN(v)) unfin = v;
      }
    }
    leaves.push({
      id: id,
      title: ((name && (name.getAttribute('title') || txt(name))) || '')
             .replace(/\s+/g, ' ').trim().slice(0, 60),
      finished: !!el.querySelector('.icon_Completed'),
      active: el.classList.contains('posCatalog_active'),
      unfin: unfin,
      onclick: (name && name.getAttribute('onclick')) || '',
    });
  });
  const st = document.querySelector('#_studystate');
  return {ok: true, leaves: leaves, state: st ? String(st.value || '') : ''};
}
"""

_CX_CLICK_CATALOG_ITEM_JS = r"""
(cid) => {
  let el = document.getElementById('cur' + cid);
  if (!el) el = document.getElementById(cid);
  if (!el) {
    // 没有 cur 前缀的版本：按 onclick 里的章节 id 找
    const all = Array.prototype.slice.call(
      document.querySelectorAll('#coursetree .posCatalog_select'));
    el = all.find(function (x) {
      if (!x.querySelector('.posCatalog_name')) return false;
      const oc = String((x.querySelector('.posCatalog_name') || {}).getAttribute
                        ? x.querySelector('.posCatalog_name').getAttribute('onclick') : '') || '';
      return oc.indexOf("'" + cid + "'") >= 0 || oc.indexOf('"' + cid + '"') >= 0;
    }) || null;
  }
  if (!el) return {ok: false, why: '目录里没有这一条'};
  try { el.scrollIntoView({block: 'center', inline: 'nearest'}); } catch (e) {}
  const name = el.querySelector('.posCatalog_name') || el;
  const r = name.getBoundingClientRect();
  if (r.width < 5 || r.height < 5) return {ok: false, why: '目录项不可见'};
  return {ok: true, x: r.left + r.width / 2, y: r.top + r.height / 2};
}
"""

# 本章（knowledge/cards 那一层）里的任务点清单
_CX_CHAPTER_JOBS_JS = r"""
() => {
  const cts = document.querySelectorAll('.ans-attach-ct');
  if (!cts.length) return {ok: false};
  let total = 0, fin = 0, videoUnfin = 0, videoFin = 0;
  const types = [];
  cts.forEach(function (ct) {
    total++;
    const isFin = ct.classList.contains('ans-job-finished');
    if (isFin) fin++;
    const icon = ct.querySelector('.ans-job-icon');
    const cls = String((icon && icon.className) || '');
    let type = 'other';
    if (/(^|[\s_-])ans-job-video([\s_-]|$)/.test(cls)) type = 'video';
    else if (/ans-job-work/.test(cls)) type = 'work';
    else if (/ans-job-(pdf|doc|document|ppt)/.test(cls)) type = 'doc';
    types.push(type + (isFin ? ':done' : ':todo'));
    if (type === 'video') { if (isFin) videoFin++; else videoUnfin++; }
  });
  return {ok: true, total: total, fin: fin,
          videoUnfin: videoUnfin, videoFin: videoFin, types: types};
}
"""

# 只看「视频任务点」这一个是不是已完成（不是"本章有没有完成的任务点"）。
_CX_VIDEO_JOB_DONE_JS = r"""
() => {
  let seen = false, done = false;
  document.querySelectorAll('.ans-attach-ct').forEach(function (ct) {
    const isVideo = !!(ct.querySelector('.ans-job-video') ||
                       /(^|[\s_-])videoContainer([\s_-]|$)/.test(String(ct.className || '')));
    if (!isVideo) return;
    seen = true;
    if (ct.classList.contains('ans-job-finished')) done = true;
  });
  return {seen: seen, done: done};
}
"""

# 本章**所有**视频任务点（一个任务点里可能挂着好几个视频）。
_CX_VIDEO_POINT_LIST_JS = r"""
() => {
  window.__dshVpSeq = window.__dshVpSeq || 0;
  return Array.prototype.map.call(
    document.querySelectorAll('.ans-attach-ct'),
    function (ct, i) {
      const isVideo = !!(ct.querySelector('.ans-job-video') ||
                         /(^|[\s_-])videoContainer([\s_-]|$)/.test(String(ct.className || '')));
      if (!isVideo) return null;
      const f = ct.querySelector('iframe');
      // ⚠ 给每个任务点一个**贴在 DOM 上**的稳定编号：
      //   序号会随"平台把已完成的任务点从 DOM 里移除"而错位，
      //   标题又可能重名（两个都叫「视频任务点」）。
      //   data 属性跟着元素走，元素还在就还是同一个任务点。
      let vp = ct.getAttribute('data-dsh-vp');
      if (!vp) {
        vp = 'vp' + (++window.__dshVpSeq);
        try { ct.setAttribute('data-dsh-vp', vp); } catch (e) {}
      }
      return {
        i: i,
        vp: vp,
        fin: ct.classList.contains('ans-job-finished'),
        src: (f && (f.getAttribute('src') || f.src)) || '',
        title: (ct.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 60),
      };
    }
  ).filter(Boolean);
}
"""

# ---------------------------------------------------------------------------
# 「滚到底才算完成」的任务点（内嵌 PDF / PPT / 文档）
#
# 用户 2026-10-23 截图：「右边栏下划的，并且还有内嵌下划式ppt需要滑动完才算完成」。
# 学习通这些查看器是把**滚动位置**报给平台的 —— 不滚到底，任务点一直是待完成。
# ---------------------------------------------------------------------------
# 只对这些 URL 的框架做滚动：PDF / PPT / 文档查看器。
_DOC_FRAME_RE = re.compile(
    r"ananas/modules/(pdf|ppt|doc|document)|pan-yz|screen/v2|readsvr|"
    r"\.(pdf|pptx?)(\?|$)", re.I)

_SCROLL_PROBE_JS = r"""
() => {
  function delta(el) {
    try {
      const sh = Number(el.scrollHeight) || 0;
      const ch = Number(el.clientHeight) || 0;
      return sh - ch;
    } catch (e) { return 0; }
  }
  let best = null, bestD = 0;
  const cands = [document.scrollingElement, document.documentElement, document.body];
  try { cands.push.apply(cands, document.querySelectorAll('div,section,main,article')); }
  catch (e) {}
  cands.forEach(function (el) {
    if (!el || !el.getBoundingClientRect) return;
    const d = delta(el);
    if (d < 40 || d <= bestD) return;
    let oy = 'auto';
    try { oy = String(getComputedStyle(el).overflowY || 'visible'); } catch (e) {}
    const isRoot = (el === document.scrollingElement || el === document.documentElement
                    || el === document.body);
    if (!isRoot && !/(auto|scroll|overlay)/.test(oy)) return;
    best = el; bestD = d;
  });
  if (!best) return {ok: false};
  try { best.setAttribute('data-dsh-scroll', '1'); } catch (e) {}
  return {ok: true, top: Number(best.scrollTop) || 0,
          max: bestD, h: Number(best.clientHeight) || 0};
}
"""

# 本章任务点清单：每个 .ans-attach-ct 的**标题**和它内嵌的 iframe 地址。
# 「章节测验」就藏在这些 iframe 里（work/doHomeWorkNew）。
_CX_TASKPOINT_LIST_JS = r"""
() => Array.prototype.map.call(
  document.querySelectorAll('.ans-attach-ct'),
  function (ct) {
    let src = '';
    try {
      const f = ct.querySelector('iframe');
      src = (f && (f.getAttribute('src') || f.src)) || '';
    } catch (e) {}
    return {
      src: src,
      text: (ct.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 120),
      cls: String(ct.className || ''),
      fin: ct.classList.contains('ans-job-finished'),
    };
  })
"""

# 「章节测验」页的地址形状（学习通的测验/考试都走这些路由）
_QUIZ_URL_RE = re.compile(
    r"(work/doHomeWorkNew|work/dowork|work/selectWorkQuestion|selectWorkQuestion|"
    r"exam/test|/mooc2/exam|exam-ans/exam|/exam/)", re.I)
# ⚠ 2026-10-23 用户要求：「刷课时遇到的所有题目和任务一键自动完成」。
#   所以 **作业也做**（此前只做标题带「测验」的）。
#   但**考试不代做** —— 这条是产品级的承诺（界面上写着），也是风险最高的一项。
_EXAM_URL_RE = re.compile(r"(exam/test|/mooc2/exam|exam-ans/exam|/exam/)", re.I)
_EXAM_TITLE_RE = re.compile(r"考试|期末|期中|统考")
# 标题里有这些词的，日志里说成「测验」，其余说成「作业」（只是文案）
_QUIZ_TITLE_RE = re.compile(r"测验|测试|答题|自测")
# 用哪个参数区分"这是同一份卷子"
_QUIZ_KEY_RE = re.compile(r"[?&](workId|workAnswerId|jobid|examId)=([^&]+)", re.I)

# 一个章节里可能挂着**多个分节**（2026-10-26 用户真机截图）：
#   2.12 第二章章节测验 → 标签「1 第二章第一 / 2 第二章第二 / 3 第二章第三」
#   任一时刻页面上只挂着当前那一节的 iframe，所以只扫当前页只能答第一份。
# 实测结构（从用户的登录态页面扒下来的）：
#   <div class="prev_list"><ul class="prev_ul clearfix">
#     <li id="dct1" class="active"><div class="prev_white">
#       <span class="spanText">第二章第一…</span></div></li>
#     <li id="dct2" class="c2">…</li>
#     <li id="dct3" class="c3">…</li>
_CX_SECTION_TABS_JS = r"""
() => {
  const out = [];
  const lis = Array.prototype.slice.call(
    document.querySelectorAll(
      '.prev_list .prev_ul > li, .prev_list .prev_ul li, .prev_list li'));
  lis.forEach(function (li, i) {
    if (!li) return;
    const t = (li.innerText || '').replace(/\s+/g, ' ').trim();
    if (!t || t.length > 40) return;
    // 「上一节 / 下一节 / 返回」这类按钮不是分节标签，别混进来
    if (/^(上一|下一|返回|首页|更多)/.test(t)) return;
    const r = li.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return;
    out.push({i: i, id: String(li.id || ''), text: t.slice(0, 40),
              active: /(^|\s)active(\s|$)/.test(String(li.className || ''))});
  });
  return out;
}
"""

# target: 0 = 点内层 .spanText/div（绝大多数情况），1 = 直接点 li（兜底）
_CX_SECTION_TAB_CLICK_JS = r"""
(arg) => {
  const i = (arg && typeof arg === 'object') ? arg.i : arg;
  const target = (arg && typeof arg === 'object') ? arg.target : 0;
  const lis = Array.prototype.slice.call(
    document.querySelectorAll(
      '.prev_list .prev_ul > li, .prev_list .prev_ul li, .prev_list li'));
  const li = lis[i];
  if (!li) return false;
  const inner = li.querySelector('.spanText') || li.querySelector('div') || li;
  const el = target === 1 ? li : inner;
  try { el.click(); } catch (e) {
    try {
      el.dispatchEvent(new MouseEvent('click',
        {bubbles: true, cancelable: true, view: window}));
    } catch (e2) { return false; }
  }
  return true;
}
"""

# 讨论任务点：卡片 iframe 指向 ananas/modules/insertbbs/index.html，里面再套
#   mooc-ans/bbscircle/chapter?mtopicid=... → #topicMainDiv[data="groupweb.../replysList?..."]
# 真正的回复框在 groupweb 那个「话题详情」页里（textarea[placeholder=回复话题] + .addReply）。
_CX_DISCUSS_ATTACH_JS = r"""
() => Array.prototype.map.call(
  document.querySelectorAll('.ans-attach-ct'),
  function (ct) {
    const f = ct.querySelector('iframe');
    const src = (f && (f.getAttribute('src') || f.src)) || '';
    const text = (ct.innerText || '').replace(/\s+/g, ' ').trim();
    const isD = /insertbbs|bbscircle|topic|bbs/i.test(src) || /讨论|话题/.test(text);
    return isD ? {src: src, text: text.slice(0, 80),
                  fin: ct.classList.contains('ans-job-finished')} : null;
  }).filter(Boolean)
"""

_CX_TOPIC_CARD_JS = r"""
() => {
  const el = document.getElementById('topicMainDiv');
  if (!el) return null;
  const t = el.querySelector('.cardRightTit');
  const d = el.querySelector('.Booksspan');
  return {url: String(el.getAttribute('data') || ''),
          title: ((t && t.innerText) || '').trim().slice(0, 120),
          desc: ((d && d.innerText) || '').trim().slice(0, 600)};
}
"""

# 当前页本身是不是一份作业/试卷（学习通 work 页常见结构）
_CX_QUIZ_PAGE_JS = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect();
                     return r.width > 0 && r.height > 0; };
  const sels = ['.questionLi', '.TiMu', '.mark_item', '#answerCard',
                '.answerBg', '.subject_describe', '.stem_answer', '.q_content'];
  for (const s of sels) {
    for (const e of document.querySelectorAll(s)) {
      if (vis(e)) return true;
    }
  }
  return false;
}
"""




_SCROLL_STEP_JS = r"""
(dy) => {
  const el = document.querySelector('[data-dsh-scroll="1"]');
  if (!el) return {ok: false};
  const before = Number(el.scrollTop) || 0;
  try { el.scrollTop = before + dy; } catch (e) {}
  const after = Number(el.scrollTop) || 0;
  // 有些查看器只认 window 的滚动
  try {
    if (el === document.scrollingElement || el === document.documentElement
        || el === document.body) {
      window.scrollTo(0, after);
    }
  } catch (e) {}
  return {ok: true, before: before, after: after,
          max: (Number(el.scrollHeight) || 0) - (Number(el.clientHeight) || 0)};
}
"""

_CX_CONTINUE_JS = r"""
() => {
  const WORDS = ['继续学习', '继续观看', '继续播放', '继续听课',
                 '我知道了', '知道了', '好的', '继续'];
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, '').trim();
  }
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 0 && r.height > 0;
    } catch (err) { return false; }
  }
  const SEL = 'button,a,span,div,input[type=button],input[type=submit],[role=button]';
  let best = null;
  for (const e of document.querySelectorAll(SEL)) {
    if (!vis(e)) continue;
    const t = txt(e);
    if (!t || t.length > 12) continue;
    if (WORDS.indexOf(t) < 0) continue;
    // 只留最内层：外层容器也会匹配到同样的文字，点外层不一定触发
    if (best === null || (best.contains(e) && best !== e)) best = e;
  }
  if (!best) return '';
  const r = best.getBoundingClientRect();
  const opt = {
    bubbles: true, cancelable: true, view: window,
    clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
  };
  // 完整指针序列 —— 有些框架只监听其中一种
  ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (ty) {
    try { best.dispatchEvent(new MouseEvent(ty, opt)); } catch (e) {}
  });
  // ⚠ 不要再补 est.click()：上面那个派发的 click 事件
  //   本身就会触发监听器，再调一次 = **点两次**。
  //   自测实测：确认框的点击计数是 2（应为 1）。
  return txt(best);
}
"""

_QUIZ_CLOSE_JS = r"""
(sel) => {
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/[\s\u00a0]+/g, '').trim();
  }
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 2 && r.height > 2;
    } catch (err) { return false; }
  }
  const WORDS = ['关闭', '关闭弹窗', '关闭窗口', '我知道了', '知道了', '确定'];
  const SEL = 'button,a,span,div,[role=button]';
  const found = {best: null};
  function pick(scope) {
    for (const e of scope.querySelectorAll(SEL)) {
      if (!vis(e)) continue;
      const t = txt(e);
      if (WORDS.indexOf(t) < 0) continue;
      if (found.best === null || (found.best.contains(e) && found.best !== e)) {
        found.best = e;
      }
    }
  }

  // ① 老行为：从 sel（题面/容器）往上，逐层找「关闭」
  let node = null;
  try { node = sel ? document.querySelector(sel) : null; } catch (err) { node = null; }
  for (let up = 0; node && up < 8; up++, node = node.parentElement) {
    if (node === document.body) break;
    pick(node);
    if (found.best) break;
  }

  // ② ★ 答对之后，「关闭」常常**不在**题面容器里 —— 智慧树会另起一个结果层
  //    （「恭喜你，答对了！」+ 关闭），题面容器还留在原地。
  //    用户 2026-10-23：「答对了没有点击关闭」。这里把页面上**可见的弹层**
  //    逐个找一遍；范围仍是"弹层"而不是整页，免得误点别处的关闭。
  if (!found.best) {
    const DLG = '#playTopic-dialog,.el-dialog,.el-dialog__wrapper,'
      + '.el-message-box,.el-message,[role=dialog],[role=alertdialog],'
      + '.layui-layer,.ant-modal,.vjs-modal-dialog,'
      + '[class*=dialog],[class*=Dialog],[class*=modal],[class*=Modal],'
      + '[class*=popup],[class*=Popup],[class*=result],[class*=Result]';
    for (const d of document.querySelectorAll(DLG)) {
      if (!vis(d)) continue;
      pick(d);
      if (found.best) break;
    }
  }

  // ③ 最后兜底：整页只有**一个**可见的「关闭」时才敢点（多于一个就放弃，
  //    宁可交给人，也不能点错）。
  if (!found.best) {
    const all = [];
    for (const e of document.querySelectorAll(SEL)) {
      if (!vis(e)) continue;
      if (WORDS.indexOf(txt(e)) < 0) continue;
      all.push(e);
    }
    const inner = all.filter(function (e) {
      return !all.some(function (o) { return o !== e && e.contains(o); });
    });
    if (inner.length === 1) found.best = inner[0];
  }

  const best = found.best;
  if (!best) return '';
  const r = best.getBoundingClientRect();
  const opt = {
    bubbles: true, cancelable: true, view: window,
    clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
  };
  ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (ty) {
    try { best.dispatchEvent(new MouseEvent(ty, opt)); } catch (e) {}
  });
  return txt(best);
}
"""

# 弹题现在是不是已经「答对了」的样子（智慧树结果层：恭喜你，答对了！）。
#
# 为什么需要：答对后如果「关闭」没点上，弹层还在 → `is_done` 一直为假 →
# `answer_quiz` 会以为答错、**换 B/C/D 重试**，把正确答案改掉（真机日志
# 14:14 就是这样：A 已经选中了，还在换 B/C/D）。有了这条，就能在换选项前
# 认出来"已经答对，只是没关掉"，然后只补点关闭、不再改答案。
_QUIZ_CORRECT_JS = r"""
(sel) => {
  const WORDS = ['恭喜你答对了', '回答正确', '答对了', '回答对了', '太棒了',
                 '恭喜答对', '回答正确'];
  function norm(s) {
    return String(s || '').replace(/[\s\u00a0]+/g, '');
  }
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 2 && r.height > 2;
    } catch (err) { return false; }
  }
  function hit(e) {
    const t = norm(e.innerText || e.textContent || '');
    if (!t) return false;
    return WORDS.some(function (w) { return t.indexOf(w) >= 0; });
  }
  // ① 题面容器自己/往上 8 层
  let node = null;
  try { node = sel ? document.querySelector(sel) : null; } catch (err) { node = null; }
  for (let up = 0; node && up < 8; up++, node = node.parentElement) {
    if (node === document.body) break;
    if (hit(node)) return true;
  }
  // ② 页面上可见的弹层（结果层常常是**另一个**弹层）
  const DLG = '#playTopic-dialog,.el-dialog,.el-dialog__wrapper,'
    + '.el-message-box,.el-message,[role=dialog],[role=alertdialog],'
    + '.layui-layer,.ant-modal,[class*=dialog],[class*=Dialog],'
    + '[class*=message-box],[class*=result],[class*=Result]';
  for (const d of document.querySelectorAll(DLG)) {
    if (!vis(d)) continue;
    if (hit(d)) return true;
  }
  return false;
}
"""

# 诊断：把弹层里可见的按钮/短文字列出来（点不到「关闭」时打一行日志用）。
_QUIZ_BUTTONS_JS = r"""
(sel) => {
  function norm(s) {
    return String(s || '').replace(/[\s\u00a0]+/g, '');
  }
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 2 && r.height > 2;
    } catch (err) { return false; }
  }
  const out = [];
  const SEL = 'button,a,[role=button],.el-button,.btn,input[type=button],span';
  for (const e of document.querySelectorAll(SEL)) {
    if (!vis(e)) continue;
    const t = norm(e.innerText || e.value || e.textContent || '');
    if (!t || t.length > 12) continue;
    if (out.indexOf(t) < 0) out.push(t);
  }
  return out.slice(0, 12);
}
"""

_PRESENCE_GUARD_JS = r"""
() => {
  if (window.__dshPresence) return 'already';
  const st = { blocked: 0 };
  window.__dshPresence = st;

  function inPlayer(t) {
    if (!t || !t.tagName) return false;
    const tag = String(t.tagName).toUpperCase();
    if (tag === 'VIDEO') return true;
    if (tag === 'IFRAME') return true;            // 播放器 iframe 本身
    let cls = '';
    try {
      cls = (typeof t.className === 'string')
        ? t.className
        : String((t.className && t.className.baseVal) || '');
    } catch (e) { cls = ''; }
    // ⚠ 一条正则就够，别写成两段互相矛盾的（我第一版写歪过）
    if (/vjs-|sp_function|ans-videoquiz|video-js|posCatalog/.test(cls)) return true;
    try {
      return !!(t.closest && t.closest('.video-js, #video, .ans-attach-online'));
    } catch (e) { return false; }
  }

  ['mouseout', 'mouseleave', 'pointerout', 'pointerleave'].forEach(function (type) {
    window.addEventListener(type, function (e) {
      if (!inPlayer(e.target)) return;
      st.blocked++;
      try { e.stopImmediatePropagation(); } catch (err) {}
    }, true);
  });

  const pin = {
    hidden: false, webkitHidden: false,
    visibilityState: 'visible', webkitVisibilityState: 'visible',
  };
  const targets = [document];
  try { targets.push(Document.prototype); } catch (e) {}
  targets.forEach(function (t) {
    Object.keys(pin).forEach(function (k) {
      try {
        Object.defineProperty(t, k, {
          configurable: true,
          get: function () { return pin[k]; },
        });
      } catch (e) {}
    });
    try { t.hasFocus = function () { return true; }; } catch (e) {}
  });
  return 'installed';
}
"""

_PRESENCE_COUNT_JS = r"""
() => {
  try {
    return window.__dshPresence
      ? { blocked: window.__dshPresence.blocked,
          visible: document.visibilityState,
          focus: (typeof document.hasFocus === 'function'
                  ? document.hasFocus() : null) }
      : null;
  } catch (e) { return null; }
}
"""

# 恢复播放：**优先走 videojs 播放器**，再退回 <video>.play()
#
# 为什么要这条：pause 的栈是 videojs tech.pause ← videojs-ext ← all-classes，
# 平台走的是**包装器**。`element.play()` 绕过包装器，包装器内部还是"暂停"状态，
# 所以日志里「直接 play() 起播」之后马上又被按停。
_PLAYER_PLAY_JS = r"""
() => {
  function go(p) {
    try {
      if (p && typeof p.play === 'function') {
        if (!p.paused) return 'already';
        p.play();
        return 'player.play()';
      }
    } catch (e) {}
    return '';
  }
  try {
    if (window.player) {
      const r = go(window.player);
      if (r) return r;
    }
  } catch (e) {}
  try {
    const el = document.querySelector('.video-js, .vjs-tech');
    if (el && el.player) {
      const r = go(el.player);
      if (r) return r;
    }
  } catch (e) {}
  try {
    const v = document.querySelector('video');
    if (v) {
      if (!v.paused) return 'already';
      v.muted = true;
      v.play();
      return '<video>.play()';
    }
  } catch (e) {}
  return '';
}
"""

_CX_TABROW_JS = r"""
() => {
  function vis(e) {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return false;
    const s = getComputedStyle(e);
    if (!s) return false;
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    if (parseFloat(s.opacity || '1') <= 0.05) return false;
    return true;
  }
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  }
  // 栏目名打分：学习通这几条栏目名是固定的，命中就给分。
  // 打分只用于"在若干横向行里挑出真正的栏目条"，不用于定位元素。
  const KW = [
    [/学习视频|视频|录像|微课/, 100],
    [/小节测验|章节测验|测验|测试|作业|练习/, 80],
    [/电子课件|课件|讲义|PPT|教案/i, 80],
    [/扩展阅读|阅读|文献|资料/, 60],
    [/本章导读|导读|目标与导学|导学|学习目标/, 60],
    [/讨论|答疑|问答/, 30],
    [/知识点|任务|目录|首页|公告/, 15],
  ];
  function score(t) {
    let s = 0;
    for (let i = 0; i < KW.length; i++) if (KW[i][0].test(t)) s += KW[i][1];
    return s;
  }
  function isActive(e) {
    const c = (typeof e.className === 'string' ? e.className : '');
    if (/(^|[\s_-])(active|current|cur|on|selected|checked)([\s_-]|$)/i.test(c)) return true;
    if (e.getAttribute && e.getAttribute('aria-selected') === 'true') return true;
    return false;
  }

  // ---- 1. 收集"像栏目项的文字块" ----
  const cand = [];
  const all = document.querySelectorAll('a,li,span,div,button,p,label,em,i,dt,dd');
  for (let i = 0; i < all.length && cand.length < 4000; i++) {
    const e = all[i];
    if (e.children.length > 2) continue;      // 近叶子：栏目项不会是大的内容容器
    const t = txt(e);
    if (!t || t.length > 24) continue;        // 栏目名都很短
    if (!vis(e)) continue;
    cand.push({ el: e, t: t, r: e.getBoundingClientRect() });
  }

  // ---- 2. 按"同一水平行"分组（全局分组，不要求同一父级）----
  const rows = [];
  cand.forEach(function (it) {
    const cy = it.r.top + it.r.height / 2;
    let row = null;
    for (let i = 0; i < rows.length; i++) {
      const tol = Math.max(6, Math.min(it.r.height, rows[i].h) * 0.6);
      if (Math.abs(rows[i].cy - cy) <= tol) { row = rows[i]; break; }
    }
    if (!row) { row = { cy: cy, h: it.r.height, items: [] }; rows.push(row); }
    row.items.push(it);
  });

  // ---- 3. 行内先剔"外壳"，再按 X 方向切"连续的条" ----
  //
  // ⚠⚠ 剔外壳必须放在**切条之前**（行层）。上一版放在 bar 层，没用 ——
  //    那时 `lastRight` 已经被外壳顶到行尾了。用户 2026-10-17 的日志：
  //      栏目条 4 条 —— 1视频 / 2章节测验 / 4.1 神经元与感知机 / 已完成
  //    后两条其实是右侧目录树里的文字，位置恰好和栏目条同一水平高度。
  //    程序把它们当栏目点开 → **跳回了已完成的章节**。
  //
  //    外壳长这样：<div class="wrap">（宽 1440，文字只有「1视频 2章节测验」）
  //      · 只有 1 个子元素 → 过 `children.length > 2` 初筛
  //      · 文字 9 个字     → 过 `t.length > 24` 初筛
  //      · right 接近整屏  → 把 lastRight 顶到行尾
  const bars = [];
  rows.forEach(function (row) {
    const inners = row.items.filter(function (it) {
      let n = 0;
      for (let j = 0; j < row.items.length; j++) {
        const o = row.items[j];
        if (o.el !== it.el && it.el.contains(o.el)) n++;
      }
      return n < 2;                 // 含 ≥2 个其它候选 → 是外壳，不是栏目项
    });
    if (inners.length < 2) return;
    inners.sort(function (a, b) { return a.r.left - b.r.left; });
    let cur = [];
    let prevRight = null;
    const flush = function () {
      if (cur.length >= 2) bars.push({ items: cur.slice() });
      cur = [];
    };
    inners.forEach(function (it) {
      // ⚠ 只跟**上一个元素**的右边界比，**不要取 Math.max** ——
      //   取 max 的话，一个整行宽的元素会把右边界永久留在行尾，
      //   后面每个元素 `left - lastRight` 都是负数，"间隔 >60px 断开"
      //   永远不触发，右侧目录就被并进来了。（这正是那个 bug。）
      if (prevRight !== null && it.r.left - prevRight > 60) flush();
      cur.push(it);
      prevRight = it.r.left + it.r.width;
    });
    flush();
  });

  // ---- 4. 去重（父子同时命中时保留外层）+ 打分 ----
  const result = [];
  bars.forEach(function (bar) {
    // ⚠ 先去"容器"，再做"保留外层"去重 —— 顺序不能反。
    //
    //   一条栏目条的 DOM 常常是：<div class="tabs"><span>视频</span>
    //   <span>测验</span></div>。那个 div **只有 2 个子元素**，
    //   能通过前面的 `children.length > 2` 初筛，于是也进了候选。
    //   而"保留外层"的去重会先收下 div、再把两个 span 全丢掉，
    //   结果 kept 只剩 1 条 → 整条栏目条被判无效。
    //
    //   实测（tools\dbg_tabrow.py）：
    //     候选：['1 视频 2 章节测验', '1 视频', '2 章节测验']
    //     去重后：1 条  ← 2 条栏目的页面就是这么被判死的
    //   3 条以上的页面碰不到，因为那时 div 有 ≥3 个子元素，早被初筛排除。
    //
    //   判据：**同一行里包含了 2 个以上其它候选 → 它是外壳，不是栏目项。**
    const inners = bar.items.filter(function (it) {
      let n = 0;
      for (let j = 0; j < bar.items.length; j++) {
        const o = bar.items[j];
        if (o.el !== it.el && it.el.contains(o.el)) n++;
      }
      return n < 2;
    });
    const kept = [];
    inners.forEach(function (it) {
      for (let i = 0; i < kept.length; i++) {
        const k = kept[i];
        if (k.el === it.el) return;
        if (k.el.contains(it.el)) return;                      // 已有外层 → 丢内层
        if (it.el.contains(k.el)) { kept[i] = it; return; }     // 内层换成外层
      }
      kept.push(it);
    });
    // ⚠ 原来是 `kept.length < 3`（至少 3 条）。但真实页面里确实存在
    //   **只有 2 条**的版本 ——「1 视频 / 2 章节测验」。
    //   卡 3 条的后果是：那一页判不成横向栏目页 → 走通用路径 →
    //   章节测验永远不会被处理（用户 2026-10-17 报的就是这个）。
    //
    //   放宽到 2 条，但**加补偿判据**：正好 2 条时，两条都必须命中栏目名。
    //   一条「视频」一条「测验」，这基本不可能是什么普通文字块。
    if (kept.length < 2) return;
    if (kept.length === 2) {
      let named = 0;
      kept.forEach(function (x) { if (score(x.t) > 0) named++; });
      if (named < 2) return;                 // 两条里有一条不认识 → 不认
    }
    const xs = kept.map(function (x) { return x.r.left; });
    const xr = kept.map(function (x) { return x.r.left + x.r.width; });
    if (Math.max.apply(null, xr) - Math.min.apply(null, xs) < 120) return;
    // ★ 2026-10-26：右侧栏里的「目录 / 讨论 / 笔记 / 标注」也是一排短文字块，
    //   几何上与栏目条一模一样（用户："有时候会点右边的讨论和笔记"）。
    //   内容区的栏目条从左侧开始；整排都落在屏幕右侧 62% 以外的，一律不是它。
    if (Math.min.apply(null, xs) > (window.innerWidth || 1200) * 0.62) return;
    let sc = 0;
    kept.forEach(function (x) { sc += score(x.t); });
    if (sc < 60) return;                      // 一个栏目名都没命中 → 不是栏目条
    result.push({ score: sc + kept.length, items: kept });
  });
  result.sort(function (a, b) { return b.score - a.score; });

  // ---- 5. 打标记 ----
  // ⚠ 跨两次 evaluate 传元素只能靠 DOM 属性：Playwright 不能把元素句柄
  //   当返回值序列化出来。打完标记下一次按属性名取即可。
  document.querySelectorAll('[data-dsh-tabrow]').forEach(function (e) {
    e.removeAttribute('data-dsh-tabrow');
    e.removeAttribute('data-dsh-tabtext');
  });
  const out = [];
  result.slice(0, 3).forEach(function (bar, ri) {
    const items = [];
    bar.items.forEach(function (it, ii) {
      it.el.setAttribute('data-dsh-tabrow', ri + '-' + ii);
      it.el.setAttribute('data-dsh-tabtext', it.t);
      items.push({
        i: ii, text: it.t,
        x: Math.round(it.r.left), y: Math.round(it.r.top),
        w: Math.round(it.r.width), h: Math.round(it.r.height),
        active: isActive(it.el),
      });
    });
    out.push({ row: ri, score: bar.score, items: items });
  });
  return out;
}
"""

# 点栏目项：把整串指针事件都补上。
# ⚠ 学习通这类页面大量用**事件委托**（监听挂在容器或 document 上）。
#   只 dispatch 一个 click 在部分版本上会被忽略，所以按真实用户的操作顺序
#   pointerdown → mousedown → pointerup → mouseup → click 全发一遍，
#   并且 bubbles=true，让委托方能收到。
_CX_TAB_CLICK_JS = r"""
(ref) => {
  const e = document.querySelector('[data-dsh-tabrow="' + ref + '"]');
  if (!e) return { ok: false, why: 'element-gone' };
  const r = e.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  const o = { bubbles: true, cancelable: true, view: window,
              clientX: x, clientY: y, button: 0 };
  ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (n) {
    let ev = null;
    try {
      ev = (n.indexOf('pointer') === 0 && typeof PointerEvent === 'function')
        ? new PointerEvent(n, o) : new MouseEvent(n, o);
    } catch (err) {
      try { ev = new MouseEvent(n, o); } catch (e2) { ev = null; }
    }
    if (ev) { try { e.dispatchEvent(ev); } catch (err) { /* 忽略 */ } }
  });
  return { ok: true, x: Math.round(x), y: Math.round(y),
           text: (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 20) };
}
"""

# 页面"指纹"：用来判断"这一下点没点中"。
# 只看会随栏目切换而变化的东西：所在文档地址、#iframe 的 src、
# <video> 个数、当前高亮的栏目名、可见正文长度。
# ⚠ ① 别用栏目项自己的 class 当判据 —— 有的版本点了以后不给 active 类。
#  ② 这个 JS 要对**每个框架**各跑一遍，上层把结果拼起来（见
#     `_cx_tab_fingerprint`）：栏目条有可能在 #iframe 里面，
#     只盯主文档会"点了它却说没变化"。
# 栏目名里出现这些词的，当「一整份卷子」处理。
# ⚠ 用 `search` 不用 `match`：栏目名可能是「2 章节测验」「小节测验」「本章作业」。
_QUIZ_TAB_RE = re.compile(r"测验|测试|作业|练习")

# 取「横向栏目」当前内容所在的地址（#iframe 的 src）
_CX_TAB_FRAME_URL_JS = r"""
() => {
  try {
    const f = document.querySelector('#iframe');
    if (!f) return '';
    return String(f.getAttribute('src') || f.src || '');
  } catch (e) { return ''; }
}
"""

_CX_TAB_PRINT_JS = r"""
() => {
  let href = '';
  try { href = String(location.href || ''); } catch (e) { /* 忽略 */ }
  let src = '';
  try {
    const f = document.querySelector('#iframe');
    if (f) src = String(f.getAttribute('src') || f.src || '');
  } catch (e) { /* 忽略 */ }
  let nv = 0;
  try { nv = document.querySelectorAll('video').length; } catch (e) { /* 忽略 */ }
  let act = [];
  try {
    document.querySelectorAll('[data-dsh-tabrow]').forEach(function (e) {
      const c = (typeof e.className === 'string' ? e.className : '');
      if (/(^|[\s_-])(active|current|cur|on|selected|checked)([\s_-]|$)/i.test(c)) {
        act.push(e.getAttribute('data-dsh-tabtext') || '?');
      }
    });
  } catch (e) { /* 忽略 */ }
  let len = 0;
  try {
    len = ((document.body.innerText || '').replace(/\s+/g, ' ').trim()).length;
  } catch (e) { /* 忽略 */ }
  return href + '#' + src + '|' + nv + '|' + act.join(',') + '|' + len;
}
"""

# 把播放器"点起来"。
#
# ⚠ 为什么必须有这一步（用户 2026-10-16 截图 + 日志）：
#   学习通这一版的播放器是**自定义 Vue 组件**：封面图盖在 <video> 上，
#   正中间一个圆形播放按钮。不点它的话 <video> 停在
#   `preload=none` 的状态 —— `duration` 读出来是 0/NaN。程序等的判据是
#   "found 且 duration > 0"，于是**一直判"没有可播视频"**，等满 20 秒走人：
#       3学习视频：等 20 秒仍没有可播视频 … 按文档类处理
#   但用户眼睛看到的是"视频明明就在那儿，只是没点播放"。
#
# 返回三样东西，让 Python 决定怎么点：
#   · video   —— 最大可见 <video> 的位置（没有就是 null）
#   · paused  —— 它现在是不是暂停着（**已经在播就别再点**，点了反而会暂停）
#   · hits    —— 像播放按钮的元素及其位置（按可信度排）
_CX_PLAY_JS = r"""
() => {
  function vis(e) {
    if (!e) return false;
    const r = e.getBoundingClientRect();
    if (r.width < 12 || r.height < 12) return false;
    const s = getComputedStyle(e);
    if (!s) return false;
    return s.display !== 'none' && s.visibility !== 'hidden'
           && parseFloat(s.opacity || '1') > 0.05;
  }
  function rc(e) {
    const r = e.getBoundingClientRect();
    return { x: Math.round(r.left), y: Math.round(r.top),
             w: Math.round(r.width), h: Math.round(r.height) };
  }

  const vids = Array.prototype.slice.call(document.querySelectorAll('video')).filter(vis);
  vids.sort(function (a, b) {
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    return (rb.width * rb.height) - (ra.width * ra.height);
  });
  const v = vids[0] || null;

  // ★ 调 play() **之前**先记下暂停状态。
  //   为什么必须分开记：`play()` 会让 `paused` 立刻变 false（哪怕稍后被拒绝），
  //   只读调用之后的值，就分不清"本来就在播"和"脚本刚把它点起来了" ——
  //   而"看着成了、其实被平台按停"正是最难查的那种假成功。
  const wasPaused = v ? !!v.paused : null;

  // ① 先直接 play() 试试 —— 有些播放器吃这一套，一次就成了
  let jsErr = '';
  if (v) {
    try { v.muted = true; } catch (e) { /* 忽略 */ }
    try {
      const p = v.play();
      if (p && typeof p.catch === 'function') {
        p.catch(function (e) { window.__dshPlayErr = String(e); });
      }
    } catch (e) { jsErr = String(e); }
  }

  // ② 收集"像播放按钮"的元素。选择器按可信度**从前往后排**，
  //    头部那几个（Video.js 的 big-play、各种 play-btn 类名）命中率最高。
  const SEL = [
    '.vjs-big-play-button', '[class*=big-play]', '[class*=bigPlay]',
    '[class*=play-btn]', '[class*=playBtn]', '[class*=play-button]',
    '[class*=playButton]', '[class*=video-play]', '[class*=videoPlay]',
    '[class*=play-icon]', '[class*=playIcon]', '[class*=poster-play]',
    '[aria-label*=播放]', '[title*=播放]', '[class*=mask][class*=play]',
  ];
  const hits = [];
  const seen = [];
  function push(how, e) {
    if (!e || !vis(e)) return;
    for (let i = 0; i < seen.length; i++) if (seen[i] === e) return;
    seen.push(e);
    hits.push({ how: how, r: rc(e) });
  }
  SEL.forEach(function (s) {
    try { document.querySelectorAll(s).forEach(function (e) { push(s, e); }); }
    catch (e) { /* 忽略 */ }
  });
  // 文字就是「播放」/ 播放图标的
  try {
    document.querySelectorAll('div,span,a,button,i,em').forEach(function (e) {
      if (e.children.length > 1) return;
      const t = (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
      if (!/^(播放|▶|►|▶️)$/.test(t)) return;
      push('text:' + t, e);
    });
  } catch (e) { /* 忽略 */ }

  return {
    video: v ? rc(v) : null,
    wasPaused: wasPaused,
    paused: v ? !!v.paused : null,
    dur: v ? (Number(v.duration) || 0) : 0,
    vcount: vids.length,
    jsErr: jsErr,
    hits: hits.slice(0, 8),
  };
}
"""


@dataclass
class LessonResult:
    index: int
    title: str = ""
    seconds: float = 0.0
    duration: float = 0.0
    rate: float = 1.0
    finished: bool = False
    note: str = ""


@dataclass
class CourseResult:
    ok: bool = False
    lessons: list[LessonResult] = field(default_factory=list)
    stopped_reason: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
class CourseRunner:
    """在已登录的浏览器里自动播课。

    只做三件事：设倍速、必要时点播放、播完点下一节。
    不伪造进度上报 —— 进度以平台自己的显示为准。
    """

    def __init__(self, *, headless: bool = False, cdp_url: str | None = None,
                 log: Callable[[str], None] = print,
                 status: Callable[[str], None] | None = None,
                 stop=None,
                 client=None,
                 auto_quiz: bool = False,
                 quiz_submit: bool = True,
                 single_page: bool = False,
                 discuss_force: bool = False) -> None:
        # ⚠ 先把 log 赋给 self，再建 driver ——
        #   driver 需要它来打 `[blind] ...` 这类埋点标记。
        #   反过来写会 AttributeError（自己踩过一次）。
        self.log = log
        self.status = status or (lambda _s: None)
        self.stop = stop
        self.driver = BrowserDriver(headless=headless, cdp_url=cdp_url,
                                    log=self.log)
        # ---- 课中弹题自动作答 ----
        # `client` 是模型客户端（作业作答那边用的同一个）。
        # **没有客户端就不可能自动答** —— 这时无论开关怎么设都只等不答，
        # 而不是报错或假装答了。
        self.client = client
        self.auto_quiz = bool(auto_quiz)
        # 单页模式：只处理浏览器当前这一页（不翻章/不切节）
        self.single_page = bool(single_page)
        # 强制处理目录已打勾的讨论（目录的打勾不一定可信）
        self.discuss_force = bool(discuss_force)
        self.quiz_answered = 0      # 自动答成功的次数（给小结用）
        self.quiz_failed = 0        # 尝试过但没答上的次数
        # 章节测验答完是否自动交卷（网课设置里的分支，默认开）
        self.quiz_submit = bool(quiz_submit)
        self.chapter_quiz_done = 0
        # 每份试卷的真实结局（供汇总行使用）
        self.last_quiz_submitted = False
        self.last_quiz_blocked = False  # 章节测验答完的份数（给小结用）
        self.chapter_quiz_failed = 0  # 章节测验试过但没答成的份数

    # ---- 小工具 ----
    def _alive(self) -> bool:
        if self.stop is not None:
            try:
                self.stop.check()
            except Exception:
                return False
        return self.driver.is_alive()
    def _cx_click_next_in_catalog(self) -> str:
        """「下一节」点不动时，从右侧章节目录点下一条。

        返回一句说明；点不到返回空串。

        为什么需要（用户 2026-10-17 16:03「这不是最后一节」）：
        `下一节` 点了页面没变化，而目录里明明还有第五、六章。
        这条是**兜底**：不写死类名，按"目录项文字形状 + 高亮状态"找下一条。
        """
        try:
            frames = self._frames()
        except Exception:
            return ""
        for fr in frames:
            try:
                r = fr.evaluate(_CX_CATALOG_NEXT_JS) or {}
            except Exception:
                continue
            if not r.get("ok"):
                why = str(r.get("why") or "")
                if why and "只找到" not in why:
                    self.log(f"    · 目录兜底：{why}")
                    self._log_catalog_dump(r.get("dump") or [])
                continue

            # ★ 先把目录真实结构打出来。
            #   2026-10-17 17:42 实测：目录里那个元素**点了不导航**，
            #   而日志里只有一句"目录里点了…→…"，完全看不出为什么。
            self._log_catalog_dump(r.get("dump") or [])

            before = self._cx_chapter_key()
            # ① 先试**真实鼠标**点击（很多站点的目录只认 trusted 事件）
            try:
                self.driver.click_in_frame(fr, float(r["x"]), float(r["y"]))
            except Exception as e:
                self.log(f"    · 目录真实点击失败：{type(e).__name__}")
            time.sleep(1.6)
            try:
                self.driver.wait_for_load(extra_ms=600)
            except Exception:
                pass
            if self._cx_chapter_key() != before:
                return (f"目录里点了「{r.get('from')}」→「{r.get('to')}」"
                        f"（chapterId 已变）")

            # ② 没变 → 再试 `<a href>` 直接导航
            href = str(r.get("href") or "").strip()
            if href and not href.lower().startswith("javascript"):
                try:
                    fr.evaluate("(h) => { location.href = h; }", href)
                    time.sleep(2.0)
                    self.driver.wait_for_load(extra_ms=800)
                except Exception:
                    pass
                if self._cx_chapter_key() != before:
                    return (f"目录里用 href 跳转到「{r.get('to')}」"
                            f"（chapterId 已变）")

            # ③ 都没用 → 如实说
            self.log(f"    · 目录里点了「{r.get('to')}」（<{r.get('tag')}>），"
                     f"但 chapterId 没变 —— 这个元素可能不带导航")
        return ""

    def _log_catalog_dump(self, rows) -> None:
        """把目录前几条的真实结构打进日志（诊断用，只读）。"""
        if not rows:
            return
        self.log(f"    · 目录结构（前 {len(rows)} 条）：")
        for i, d in enumerate(rows, 1):
            mark = " ← 当前" if d.get("cur") else ""
            extra = []
            if d.get("href"):
                extra.append("href=" + str(d.get("href"))[:50])
            if d.get("onclick"):
                extra.append("onclick")
            line = (f"        [{i}] <{d.get('tag')} class=\"{d.get('cls')}\"> "
                    f"{d.get('t')}{(' ' + ' '.join(extra)) if extra else ''}{mark}")
            self.log(line)
            if d.get("pcls"):
                self.log(f"              父级：{d.get('pcls')}")

    def _page_looks_chaoxing(self) -> bool:
        """不管当前走的是哪条分支，先判断"这是不是学习通那类页面"。

        只用于**兜底动作前的安全阀**：通用模式里要不要去点右侧目录，
        必须先在结构上确认它确实是学习通那种「左侧/右侧章节目录」，
        否则在别的平台上乱点目录是纯粹的负优化。
        """
        try:
            u = (self.driver.page.url or "").lower()
        except Exception:
            u = ""
        if "chaoxing" in u or "mooc1" in u or "mooc2" in u:
            return True
        try:
            return bool(self.driver.page.evaluate(
                "() => document.querySelectorAll("
                "'.posCatalog_select, .posCatalog, #chapterTree').length"))
        except Exception:
            return False

    def _try_catalog_next(self) -> str:
        """通用模式下「下一节」点不动时的兜底：从章节目录点下一条。

        返回一句说明（点到了）/空串（没试或没成功）。
        """
        if not self._page_looks_chaoxing():
            return ""
        try:
            got = self._cx_click_next_in_catalog()
        except Exception:
            got = ""
        if got:
            self.log(f"    · 改走目录：{got}")
        return got

    def _cx_click_continue(self) -> str:
        """点弹题结果层上的「继续学习」。点到了返回按钮文字，否则空串。

        为什么要有这一步（用户 2026-10-17 14:16 截图 + 日志）：
            14:16:18 ✔ 已自动作答：已作答（B）
            14:16:18 等待课中弹题作答…（最多等 15 分钟）
        答完不是自动继续，而是弹一个「恭喜你，答对了！」的结果层，
        **必须点「继续学习」视频才会接着播**。原来的代码只会等这个层消失，
        可它不会自己消失 —— 于是白等最多 15 分钟。
        """
        # ⚠ 这是“锦上添花”的动作，**绝不能抛**。
        #   它被调用的位置在 _auto_answer_quiz() 的 try 之外，
        #   一旦抛异常会把整节课的刷课打断。
        #   实测：测试桩的 CourseRunner 没有 driver 属性 →
        #   AttributeError: 'CourseRunner' object has no attribute 'driver'
        try:
            frames = self._frames()
        except Exception:
            return ""
        for fr in frames:
            try:
                got = fr.evaluate(_CX_CONTINUE_JS) or ""
            except Exception:
                continue
            if got:
                return str(got)
        return ""

    def _click_quiz_close(self) -> str:
        """点「关闭」把弹题（或答对后的结果层）关掉；点到返回文字，否则空串。

        智慧树 AI 助教这版弹题没有「继续学习」，答完/判分后要手动点
        「关闭」那个白色弹窗，视频才会继续。

        ⚠ 2026-10-23 用户：「答对了没有点击关闭」。真机日志 14:14：
            选中态已确认：A → 5 秒内没继续播放，换 B → C → D
        A 明明是对的，但结果层的「关闭」不在题面容器里（题面还留在原地，
        结果层是**另一个**弹层），老代码只在题面容器内找 → 找不到 → 不点 →
        当成"没答上"继续换选项。
        现在：题面容器 → 可见弹层 → 全页唯一「关闭」，三级兜底；
        并且**所有框架**都找一遍（结果层可能在主文档、题面在 iframe）。
        """
        p = self._quiz_probe()
        fr0 = p.get("frame")
        sel = str(p.get("sel") or "")
        frames = []
        if fr0 is not None:
            frames.append(fr0)
        try:
            frames.extend([f for f in self._frames() if f not in frames])
        except Exception:
            pass
        for fr in frames:
            try:
                got = str(fr.evaluate(_QUIZ_CLOSE_JS, sel) or "")
            except Exception:
                continue
            if got:
                if not getattr(self, "_quiz_close_logged", False):
                    self._quiz_close_logged = True
                    self.log(f"      · 已点「{got}」关闭弹题")
                return got
        return ""

    def _quiz_looks_correct(self) -> bool:
        """弹题是不是已经显示「答对了」（结果层）。见 `_QUIZ_CORRECT_JS`。"""
        p = self._quiz_probe()
        sel = str(p.get("sel") or "")
        try:
            frames = self._frames()
        except Exception:
            return False
        if p.get("frame") is not None:
            frames = [p["frame"]] + [f for f in frames if f is not p["frame"]]
        for fr in frames:
            try:
                if bool(fr.evaluate(_QUIZ_CORRECT_JS, sel)):
                    return True
            except Exception:
                continue
        return False

    def _quiz_visible_buttons(self) -> list[str]:
        """诊断用：弹层里现在能看到哪些按钮/短文字。"""
        try:
            frames = self._frames()
        except Exception:
            return []
        for fr in frames:
            try:
                got = fr.evaluate(_QUIZ_BUTTONS_JS, "") or []
            except Exception:
                continue
            if got:
                return [str(x) for x in got][:12]
        return []

    def _cx_presence_guard(self) -> int:
        """把「在场守卫」装进每个 frame。返回**这次新装了几个**。

        幂等：JS 里有 `window.__dshPresence` 判重，重复调用只返回 'already'。
        但 frame 重载会丢掉它，所以调用方要**定期重装**（见播放循环）。
        """
        if not bool(getattr(config, "COURSE_PRESENCE_GUARD", True)):
            return 0
        fresh = 0
        for fr in self._frames():
            try:
                r = fr.evaluate(_PRESENCE_GUARD_JS)
            except Exception:
                continue
            if r == "installed":
                fresh += 1
        return fresh

    def _cx_presence_blocked(self) -> int:
        """守卫一共拦掉了多少次 mouseout（给小结/日志用）。"""
        best = 0
        for fr in self._frames():
            try:
                r = fr.evaluate(_PRESENCE_COUNT_JS) or {}
            except Exception:
                continue
            try:
                best = max(best, int(r.get("blocked") or 0))
            except Exception:
                continue
        return best

    def _frames(self):
        """主框架 + 所有子框架。播放器常在 iframe 里。"""
        out = [self.driver.page.main_frame]
        for fr in self.driver.page.frames:
            if fr != self.driver.page.main_frame:
                out.append(fr)
        return out

    def _probe(self) -> dict:
        for fr in self._frames():
            try:
                r = fr.evaluate(_PROBE_JS)
            except Exception:
                continue
            if r and r.get("found"):
                r["_frame"] = fr
                return r
        return {"found": False}

    # ---- 平台进度（走适配器注册表）----
    def _platform_progress(self):
        """问适配器："平台自己说这一节学完没有？"

        为什么做成独立方法：**注册表里没有匹配的适配器时返回 found=False**，
        上层就会退回原来的播放位置判据 —— 也就是**行为与改动前完全一致**。
        这条很重要：不能让未知页面因为这次改动而变差。

        适配器是懒加载的（每次问一次），因为 `course.py` 反过来被
        adapters 引用，模块级 import 会成环。
        """
        try:
            from .core import PlatformProgress, pick_adapter
            # pick_adapter 内部会自动触发适配器注册（见 core.adapter.ensure_registered）
            url = ""
            try:
                url = self.driver.page.url or ""
            except Exception:
                pass
            ad = pick_adapter(url, driver=self.driver, log=self.log,
                              status=self.status)
            if ad is None:
                return PlatformProgress()
            # 把停止信号也给它 —— 适配器里有些地方会长时间等待
            # （比如等课中弹题消失），不给信号就没法及时响应"停止"。
            try:
                ad.set_stop(getattr(self, "stop", None))
            except Exception:
                pass
            return ad.progress(self.driver.page, None)
        except Exception:
            return PlatformProgress()

    def _catalog(self) -> dict:
        """读平台自己的课程目录与进度（智慧树四套结构逐个尝试）。

        这是"以平台进度为准"的关键：拿不到就退回看 video.currentTime。
        """
        for fr in self._frames():
            try:
                r = fr.evaluate(_CATALOG_JS, ZHIHUISHU_CATALOGS)
            except Exception:
                continue
            if r and r.get("matched"):
                r["_frame"] = fr
                return r
        return {"matched": False}

    def _setup(self, frame, mute: bool) -> dict:
        """只负责静音 + 起播。**不在这里改倍速** —— 倍速走平台自己的菜单。"""
        try:
            return frame.evaluate(_SETUP_JS, [mute]) or {}
        except Exception as e:
            return {"ok": False, "why": f"{type(e).__name__}: {e}"}

    def _find_speed(self) -> dict:
        """在当前各框架里找平台提供的倍速选项。"""
        for fr in self._frames():
            try:
                r = fr.evaluate(_SPEED_JS, [""])
            except Exception:
                continue
            if r and (r.get("rates") or r.get("toggles")):
                r["_frame"] = fr
                return r
        return {"rates": [], "toggles": [], "current": None}

    def _apply_speed(self, want: float, info: dict, video_frame) -> tuple[float, str]:
        """把倍速调到"平台允许的不超过 want 的最大值"。

        返回 (实际生效倍速, 说明)。
        原则：**只点平台自己的倍速选项**，不直接写 video.playbackRate ——
        那样等于绕过平台限制，平台也常常会改回去或干脆不计进度。
        """
        rates = list(info.get("rates") or [])
        toggles = list(info.get("toggles") or [])
        frame = info.get("_frame") or video_frame

        # 先按平台硬上限钳一次：智慧树是 1.8，超过会被播放器内核改回去，
        # 设了也白设（开源项目 Autovisor 同样钳到 1.8）。
        capped = min(want, config.COURSE_MAX_SPEED)
        cap_note = ""
        if capped < want - 1e-6:
            cap_note = f"（平台倍速上限 {config.COURSE_MAX_SPEED}×，已按上限设）"

        # 没找到倍速控件 → 先试着展开倍速菜单再找一次
        if not rates and toggles:
            for tg in toggles[:2]:
                try:
                    frame.get_by_text(tg["text"], exact=True).first.click(timeout=1500)
                    time.sleep(0.5)
                except Exception:
                    try:
                        # 审计 C-30：坐标是 iframe 内的，必须换算到页面坐标，
                        # 否则 iframe 有偏移时会点到别处。
                        self.driver.click_in_frame(
                            frame, tg["x"] + tg["w"] / 2, tg["y"] + tg["h"] / 2)
                        time.sleep(0.5)
                    except Exception:
                        continue
                again = self._find_speed()
                if again.get("rates"):
                    rates = list(again["rates"])
                    frame = again.get("_frame") or frame
                    break

        if not rates:
            # 找不到倍速菜单 → 只能直接设播放器倍速（钳到上限）。
            # 这一步不算"绕过平台"：设的就是平台上限内的值。
            try:
                frame.evaluate(_FORCE_RATE_JS, capped)
                p = self._probe()
                real = float(p.get("rate") or 0) if p.get("found") else 0.0
                if real and abs(real - capped) < 0.05:
                    return real, f"已设为 {capped}×（直接设播放器）{cap_note}"
                return real or capped, (f"尝试设 {capped}×，页面实际 {real}×"
                                        f"（可能被平台限制）")
            except Exception as e:
                return 0.0, f"设置倍速失败：{type(e).__name__}"

        allowed = sorted(set(r["rate"] for r in rates))
        # 挑"不超过（目标值 且 平台上限）的最大值"
        usable = [x for x in allowed if x <= capped + 1e-6]
        if not usable:
            return 0.0, (f"平台只提供 {allowed} 这些倍速，均大于 {capped}×，保持默认速度")
        target = max(usable)

        # 已经就是这个倍速就不用点
        cur = info.get("current")
        if cur is not None and abs(cur - target) < 1e-6:
            return target, f"平台已是 {target}×"

        pick = next((r for r in rates if abs(r["rate"] - target) < 1e-6), None)
        if pick is None:
            return 0.0, f"平台提供 {allowed}，但没找到 {target}× 的可点元素"

        try:
            frame.get_by_text(pick["text"], exact=True).first.click(timeout=2000)
        except Exception:
            try:
                # 同上：iframe 内坐标必须加框架原点（审计 C-30）
                self.driver.click_in_frame(
                    frame, pick["x"] + pick["w"] / 2, pick["y"] + pick["h"] / 2)
            except Exception as e:
                return 0.0, f"点击 {pick['text']} 失败：{type(e).__name__}"
        time.sleep(0.4)

        # 回读真实倍速，确认平台认账
        p = self._probe()
        real = float(p.get("rate") or 0) if p.get("found") else 0.0
        if real and abs(real - target) < 0.05:
            note = f"已设为 {target}×"
            if abs(target - want) > 1e-6:
                note += (f"（平台可用档位 {allowed}，上限 {config.COURSE_MAX_SPEED}×，"
                         f"你要的 {want}× 不可用）")
            return real, note
        if real:
            return real, (f"点了 {target}×，页面实际是 {real}×"
                          f"（平台提供 {allowed}）")
        return target, f"点了 {target}×，但读不到实际倍速（平台提供 {allowed}）"

    def _find_next(self) -> list[dict]:
        for fr in self._frames():
            try:
                hits = fr.evaluate(_NEXT_JS)
            except Exception:
                continue
            if hits:
                for h in hits:
                    h["_frame"] = fr
                return hits
        return []

    def _titles(self, video_frame=None) -> list[str]:
        """取"当前这一节"的标题。

        ⚠ 视频在 iframe 里时，标题通常写在**外层文档**（父框架），
          iframe 内部反而没有。所以查找顺序是：
            视频所在框架 → 它的父框架 → 主文档 → 所有框架兜底
          （踩过的坑：只查"视频框架 + 主文档"，而实际标题在两者的中间层，
            结果永远是「标题未取到」。）
        """
        cands: list = []
        if video_frame is not None:
            cands.append(video_frame)
            try:
                cands.append(video_frame.parent_frame)
            except Exception:
                pass
        cands.append(self.driver.page.main_frame)
        try:
            cands.extend(self._frames())
        except Exception:
            pass

        seen = set()
        for fr in cands:
            if fr is None or id(fr) in seen:
                continue
            seen.add(id(fr))
            try:
                got = fr.evaluate(_TITLE_JS) or []
            except Exception:
                continue
            if got:
                return got
        return []

    def _click_next(self, cand: dict) -> bool:
        fr = cand.get("_frame") or self.driver.page.main_frame
        # 先按文字点，失败再按坐标点（有些按钮挂在很怪的容器上）
        try:
            loc = fr.get_by_text(cand["text"], exact=True).first
            loc.click(timeout=2500)
            return True
        except Exception:
            pass
        try:
            cx = cand["x"] + cand["w"] / 2
            cy = cand["y"] + cand["h"] / 2
            # ⚠ 审计 C-30：cand 的 x/y 来自 `getBoundingClientRect()`，
            #   在 iframe 内部是**相对该 iframe** 的坐标；
            #   而 `page.mouse.click` 用的是主页面视口坐标。
            #   iframe 一旦有偏移（几乎总是有），就会点到别的地方 ——
            #   可能点到无关链接，而这里还会 `return True` 谎报成功。
            #   `click_in_frame` 会把框架原点加上去。
            self.driver.click_in_frame(fr, cx, cy)
            return True
        except Exception:
            return False

    def _sidebar_next_lesson(self) -> str:
        """没有「下一节」按钮时，从**右侧目录**点下一条。

        智慧树这版就是：右侧目录每条是 `li.video`，当前那条带 `current_play`，
        点 li 上任意位置就能切过去（切完 `<video>` 的 src 会变）。
        返回一句说明（点到了）/ 空串（没有下一条或点不了）。

        ⚠ 绝不在"找不到当前高亮"时瞎猜一条 —— 那会跳到不相干的章节，
          还把用户的进度搞乱。找不到就如实返回空串，由调用方停下并说明。
        """
        for fr in self._frames():
            try:
                r = fr.evaluate(_SIDEBAR_NEXT_JS) or {}
            except Exception:
                continue
            if not r.get("ok"):
                why = str(r.get("why") or "")
                if why and "只找到" not in why:
                    self.log(f"    · 侧栏目录：{why}")
                continue
            try:
                self.driver.click_in_frame(fr, float(r["x"]), float(r["y"]))
            except Exception as e:
                self.log(f"    · 侧栏点击失败：{type(e).__name__}")
                continue
            return (f"点了「{r.get('from')}」→「{r.get('to')}」"
                    f"（目录 {r.get('count')} 条）")
        return ""

    def _sidebar_progress(self) -> dict:
        """读「平台记的当前这一节进度」（%）。

        返回 `{"ok": True, "pct": 73, "text": "0.1 引言 73% 00:13:51"}`；
        页面上没有这种百分比时返回 `{"ok": False}` —— 调用方**必须**退回
        老判据，不能因为读不到就判「没播完」。
        """
        for fr in self._frames():
            try:
                r = fr.evaluate(_SIDEBAR_PROGRESS_JS) or {}
            except Exception:
                continue
            if r.get("ok"):
                r["_frame"] = fr
                return r
        return {"ok": False}

    def _seek_to_platform_pct(self, frame, pct: float) -> dict:
        """把当前视频拨回平台记到的位置（补看没被记上的那一段）。"""
        try:
            return frame.evaluate(_SEEK_BY_PCT_JS, float(pct)) or {}
        except Exception as e:
            return {"ok": False, "why": f"{type(e).__name__}: {e}"}

    def _wait_video_change(self, src: str, secs: float | None = None) -> bool:
        """点完「下一节」后，等视频源真的换掉。

        只认「源变了」—— 页面标题/高亮变了都不算，之前吃过亏：
        点了目录高亮动了、视频根本没换，于是被记成新的一节。
        """
        limit = float(secs if secs is not None else _ADVANCE_WAIT_SEC)
        t0 = time.time()
        while time.time() - t0 < limit:
            time.sleep(1)
            q = self._probe()
            if q.get("found") and (q.get("src") or "") != src:
                return True
        return False

    def _looks_like_login_page(self) -> bool:
        """当前页是不是**登录页**。

        2026-10-23 客户日志：30 次运行里十几次停在 `passport2.chaoxing.com/login`，
        软件 4 秒后就报"找不到可播放的视频（当前页面：用户登录）" ——
        客户完全不知道是自己没登录。
        """
        try:
            u = str(self.driver.page.url or "")
            t = str(self.driver.page.title() or "")
        except Exception:
            return False
        return bool(re.search(
            r"passport\d*\.chaoxing|/login|/signin|/auth|用户登录|扫码登录",
            u + " " + t, re.I))

    # ---- A 类：资源卡片式课程页 ----
    #
    # 命名说明：这个方法原先叫 `_is_ai_course`（因为最先适配的是智慧树 AI 版），
    # 但它实际上判的是**页面结构**——「左侧目录 + 右侧资源卡片列表」。
    # 改成按结构命名，避免读代码的人以为只支持那一家的那一个版本。
    def _is_resource_card_course(self) -> bool:
        """当前页是不是「资源卡片式」课程页（左侧目录 + 右侧资源卡片）。

        判据只看**页面结构**，不绑域名：
          找得到「知识点（目录项）」或「资源卡片」，就算这一类。

        ⚠ 踩过的坑：最初只要域名含 ai-smart-course 就认定是这类页面，
          但**同一个域名下不止一种页面**（学习页 / 目录页 / 还有别的），
          真实页面上曾因此判定成立却读不到资源，最后报"未播完任意一节"。
          所以域名只作为**日志提示**，真正的判据是结构。

        实测代表：智慧树 AI 版课程。别的平台只要是这套结构，同样会命中。
        """
        url = host = ""
        try:
            url = self.driver.page.url or ""
            host = self.driver.page.evaluate("() => location.host") or ""
        except Exception:
            pass

        counts = self._ai_counts()
        has_struct = any(isinstance(v, int) and v > 0 for v in counts.values())
        is_host = "ai-smart-course" in (host or url)

        self.log(f"· 页面自检：知识点 {counts.get('topic')} 个、"
                 f"资源卡片 {counts.get('card')} 张、"
                 f"资源容器 {counts.get('detail_container')} 个")
        if is_host and not has_struct:
            # 最常见的真实原因：没停在"能看到资源列表"的那一页
            self.log("⚠ 域名看着像智慧树 AI 版课程，但读不到知识点/资源卡片 ——"
                     " 多半是页面还没加载完，或者没停在「能看到资源列表」的那一页")
        # 以**页面结构**为准（不绑域名）：本地自测页是 file:// 也一样能跑。
        return has_struct

    # ---- C 类：超星/学习通 章节任务点式课程页 ----
    #
    # 结构来源：开源项目 OCS(ocsjs) 的 chaoxing 适配（已在自测页逐条验证）。
    # 它是国内支持学习通最成熟的脚本之一，选择器经过大量真实页面检验。
    #
    # 学习通的结构和上面两类都不同，特点是**两层 iframe**：
    #   顶层文档
    #     ├─ 左侧章节树   .chapter_item（含 <a>）
    #     ├─ 任务点计数   document.getElementsByClassName('jobCount')  ← 未完成任务点
    #     ├─ 任务点标签   .tabtags span（视频 / 章节测验 切换）
    #     └─ #iframe  ← 第 1 层：任务点列表
    #          └─ .ans-attach-ct（一个任务点）
    #               └─ iframe  ← 第 2 层：真正的播放器，<video> 在这里
    #
    # ⚠ 两个关键坑（OCS 注释里写得很明白）：
    #   ① 「必须用原生 JS 点击」—— jobCount 的父级 <a> 用 jQuery .click()
    #      界面**不会跳转**。所以下面一律走 DOM 原生 click()。
    #   ② 跳转要点的是 `jobCount.parentNode` 里的那个 <a>，不是 jobCount 自己。
    def _is_chaoxing_course(self) -> bool:
        """当前页是不是学习通/超星的章节任务点式课程页。

        判据：页面上同时存在未完成任务点(.jobCount) 与内容层(#iframe)。
        只认结构，不绑域名 —— 同一套模板的自建站也能命中。
        """
        try:
            r = self.driver.page.evaluate(
                """() => ({
                    jobs: document.getElementsByClassName('jobCount').length,
                    iframe: document.querySelectorAll('#iframe').length,
                    chapters: document.querySelectorAll('.chapter_item').length,
                    tabs: document.querySelectorAll('.tabtags span').length,
                    pos: document.querySelectorAll('.posCatalog_select').length,
                })""") or {}
        except Exception:
            return False
        self.log(f"· 页面自检（学习通式）：任务点 {r.get('jobs', 0)} 个、"
                 f"章节 {r.get('chapters', 0)} 个、内容层 {r.get('iframe', 0)} 个、"
                 f"任务标签 {r.get('tabs', 0)} 个、目录项 {r.get('pos', 0)} 个")
        return bool(r.get("jobs")) and bool(r.get("iframe"))

    def _cx_job_count(self) -> int:
        """未完成任务点数量（0 = 这门课刷完了）。"""
        try:
            return int(self.driver.page.evaluate(
                "() => document.getElementsByClassName('jobCount').length") or 0)
        except Exception:
            return 0

    def _cx_chapter_progress(self) -> dict:
        """目录式页面：当前这一章**还剩几个任务点**。

        为什么单独做：这版页面的 `.jobCount` 一个都没有，整门课的进度写在
        `#_studystate` 的 `unfinishCount` 里，而**本章**的进度写在当前高亮
        目录项的 `input.jobUnfinishCount` / `.orangeNew` 上。拿整门课的数字
        去回答"这一节学完没有"就是 2026-10-23 那个假"已播完"的来源。

        返回 `{found, unfin, title, total_left}`：
          · `found=False` → 这一页读不到本章进度，调用方必须当成**未知**
          · `unfin == 0`  → 这一章真的做完了
          · `total_left`  → 整门课还剩多少（-1 = 没读到）
        """
        tree = self._cx_catalog_tree()
        if not tree.get("ok"):
            return {"found": False}
        leaves = list(tree.get("leaves") or [])
        cur = next((x for x in leaves if x.get("active")), None)
        if cur is None:
            return {"found": False}
        unfin = int(cur.get("unfin") if cur.get("unfin") is not None else -1)
        if cur.get("finished"):
            unfin = 0
        elif unfin < 0:
            return {"found": False}          # 没有角标数字 → 读不到，别猜
        total_left = -1
        m = re.search(r"unfinishCount\s*:\s*(\d+)", str(tree.get("state") or ""))
        if m:
            total_left = int(m.group(1))
        return {"found": True, "unfin": max(0, unfin),
                "title": str(cur.get("title") or ""),
                "total_left": total_left}

    def _cx_job_probe(self) -> dict:
        """未完成任务点 + **这一页到底有没有任务点 UI** 的一次性读数。

        为什么不能只用 `_cx_job_count()`（2026-10-23 真机日志倒逼出来的）：
          这一版的页面**一个 `.jobCount` 都不渲染**，读出来就是 0；
          可 0 在老版页面里的含义是「全都做完了」。两者混为一谈的后果是
          适配器一路报「任务点已全部完成」→ 每节 2 秒就记成"已播完" →
          反复点「下一节」却永远停在同一段视频上（日志里 2% / 9% / 16%
          就是同一段视频在继续播）。

        所以：`found=False` 表示**这一页根本没有任务点角标、读不到进度**，
        调用方必须当成"未知"，退回播放位置判据；只有 `found=True` 时，
        `jobs == 0` 才真的表示"全做完了"。
        """
        try:
            r = self.driver.page.evaluate(
                """() => ({
                    jobs: document.getElementsByClassName('jobCount').length,
                    ui: document.querySelectorAll(
                        '.chapter_item, .posCatalog_select, .posCatalog,'
                        + ' .tabtags span, #chapterTree, #chapterTreeBox').length,
                })""") or {}
        except Exception:
            return {"found": False, "jobs": 0, "ui": 0}
        jobs = int(r.get("jobs") or 0)
        ui = int(r.get("ui") or 0)
        return {"found": bool(jobs or ui), "jobs": jobs, "ui": ui}

    def _cx_job_title(self, idx: int) -> str:
        """第 idx 个任务点所属的章节标题（给日志看）。"""
        try:
            return str(self.driver.page.evaluate(
                """(i) => {
                    const jc = document.getElementsByClassName('jobCount');
                    if (!jc[i]) return '';
                    const a = jc[i].parentNode.getElementsByTagName('a')[0];
                    return a ? (a.innerText || '').replace(/\\s+/g,' ').trim().slice(0, 50) : '';
                }""", idx) or "")
        except Exception:
            return ""

    def _cx_click_job(self, idx: int) -> bool:
        """点进第 idx 个任务点。

        ⚠ 必须用**原生** click()。OCS 明确记着：超星这里用 jQuery 的
          .click() 界面不会跳转，所以不能走 Playwright 的 locator.click()
          去点——那会走真实鼠标事件，遇到 Vue 的委托绑定同样会失效。
          直接派发 DOM click 事件是这里唯一稳定的办法。
        """
        try:
            return bool(self.driver.page.evaluate(
                """(i) => {
                    const jc = document.getElementsByClassName('jobCount');
                    if (!jc[i]) return false;
                    const a = jc[i].parentNode.getElementsByTagName('a')[0];
                    if (!a) return false;
                    a.click();
                    return true;
                }""", idx))
        except Exception:
            return False

    def _cx_tabs(self) -> int:
        """任务点标签数（视频 / 章节测验 …）。"""
        try:
            return int(self.driver.page.evaluate(
                "() => document.querySelectorAll('.tabtags span').length") or 0)
        except Exception:
            return 0

    def _cx_click_tab(self, idx: int) -> bool:
        try:
            return bool(self.driver.page.evaluate(
                """(i) => {
                    const t = document.querySelectorAll('.tabtags span');
                    if (!t[i]) return false;
                    t[i].click();
                    return true;
                }""", idx))
        except Exception:
            return False

    def _cx_finished(self) -> int:
        """当前章节里已标记完成的任务点数（在 iframe 内）。"""
        best = 0
        for fr in self._frames():
            try:
                n = int(fr.evaluate(
                    "() => document.querySelectorAll('.ans-job-finished').length") or 0)
                best = max(best, n)
            except Exception:
                continue
        return best

    def _cx_title(self) -> str:
        """当前章节标题（优先读高亮的那一项）。"""
        try:
            return str(self.driver.page.evaluate(
                """() => {
                    const a = document.querySelector('.chapter_item.active');
                    const t = (a && (a.innerText || a.textContent) || '')
                        .replace(/\\s+/g,' ').trim();
                    return t.slice(0, 60);
                }""") or "")
        except Exception:
            return ""

    def _run_chaoxing_course(self, res: CourseResult, speed: float, mute: bool,
                             max_items: int, t0: float) -> CourseResult:
        """学习通/超星：按「未完成任务点」逐个推进。

        推进策略（照 OCS 的 clickNext 思路简化）：
          1. 数出未完成任务点 .jobCount
          2. 逐个点进去（点它的父级 <a>，走原生 click）
          3. 进去后先切任务点标签（视频/测验），再找视频
          4. 有视频 → 播完；没视频（文档等）→ 点开等一下就算过
          5. 回到 1；任务点清空 或 连续多次没进展 就停
        """
        self.log(f"目标倍速：{speed}×（会挑平台提供的、不超过它的最大值）")

        done_jobs = 0
        stall = 0

        while done_jobs < max_items:
            if not self._alive():
                res.stopped_reason = "用户停止"
                break

            total = self._cx_job_count()
            if total == 0:
                self.log("✔ 页面上已经没有未完成的任务点了，这门课刷完")
                break

            # 每次取「最后一个」未完成任务点。
            # ⚠ 为什么不是第一个：`.jobCount` 是按章节顺序排的，
            #   点完一个它就会被平台移除，所以取哪个都能推进；
            #   取最后一个可以避开"第一项往往在本章最上面、刚看过"的重复。
            idx = 0
            title = self._cx_job_title(idx)
            self.log(f"—— 剩余未完成任务点 {total} 个，进入：{title or '(无名)'} ——")
            if not self._cx_click_job(idx):
                self.log("· ⚠ 点不动这个任务点，停止以免空转")
                res.stopped_reason = "任务点点不动（页面结构可能变了）"
                break
            time.sleep(2.5)
            self.driver.wait_for_load(extra_ms=600)

            tab_n = self._cx_tabs()
            if tab_n > 1:
                self.log(f"· 本章有 {tab_n} 个任务标签，逐个看一遍")
            for ti in range(max(1, tab_n)):
                if not self._alive():
                    break
                if tab_n > 1:
                    self._cx_click_tab(ti)
                    time.sleep(1.5)
                r = self._cx_handle_current(speed, mute, title, ti)
                if r is not None:
                    res.lessons.append(r)
                    if r.finished:
                        done_jobs += 1

            # 判断这一轮有没有真的推进
            after = self._cx_job_count()
            if after < total:
                stall = 0
                self.log(f"✔ 任务点推进：{total} → {after}")
            else:
                stall += 1
                self.log(f"⚠ 任务点数量没变（仍是 {after}），"
                         f"这一节可能不计入或页面没换（连续 {stall} 次）")
                if stall >= 3:
                    self.log("✘ 连续多次没有推进，停止以免空转")
                    res.stopped_reason = "连续多次没有换成新的任务点，停止以免空转"
                    break
                # 换个任务点试试（可能第一个是卡住的）
                if self._cx_click_job(-1):
                    time.sleep(2.0)

        res.ok = len(res.lessons) > 0
        self.log("")
        self.log(f"===== 刷课结束：共 {len(res.lessons)} 节，"
                 f"{sum(1 for x in res.lessons if x.finished)} 节播完，"
                 f"用时 {time.time() - t0:.0f} 秒 =====")
        if res.stopped_reason:
            self.log(f"停止原因：{res.stopped_reason}")
        # 章节测验的份数单独报一行 —— 只在**答过**的时候报，
        # 没答过测验的课不该多一行「章节测验 0 份」。
        if self.chapter_quiz_done or self.chapter_quiz_failed:
            # ★ 按**真实结局**说，不按开关说。
            #   （2026-10-17 17:18：上一行刚说"没确认交上"，
            #    这一行却报"已交卷"—— 自相矛盾）
            if getattr(self, "last_quiz_blocked", False):
                how = "⚠ 被验证码拦住，未交卷"
            elif getattr(self, "last_quiz_submitted", False):
                how = "已交卷"
            elif self.quiz_submit:
                how = "⚠ 答完了但没确认交上，请手动检查"
            else:
                how = "已填好、未交卷"
            tail = (f"，{self.chapter_quiz_failed} 份没答成"
                    if self.chapter_quiz_failed else "")
            self.log(f"· 章节测验：{self.chapter_quiz_done} 份答完{tail}（{how}）")
        return res

    def _resume_after_quiz(self, tries: int = 4) -> bool:
        """弹题关闭后主动把视频点起来。

        真机实测：智慧树 AI 弹题点「关闭」后，弹层没了，但 `<video>` 仍是
        `paused=True` —— 只靠 `_set_video_rate()` 不会起播，必须补一次
        `_cx_press_play()`（它会先判断“已经在播就别点”，不会把播放点停）。
        """
        for i in range(max(1, int(tries))):
            try:
                v = self._any_video()
            except Exception:
                v = {}
            if v.get("found") and not v.get("paused") and not v.get("ended"):
                return True
            try:
                note = self._cx_press_play(v.get("_frame"))
            except Exception:
                note = ""
            self.log(f"    · 弹题关闭后尝试继续播放"
                     f"（第 {i + 1} 次）" + (f"：{note}" if note else ""))
            time.sleep(1.0)
        return False

    def _cx_press_play(self, frame=None) -> str:
        """对着播放器点一下「播放」。做成了就返回一句说明，否则返回空串。

        为什么必须有这一步（用户 2026-10-16 的截图 + 日志）：
          学习通这一版播放器是自定义 Vue 组件，封面盖在 `<video>` 上，
          中间一个圆形播放按钮。不点它，`<video>` 一直停在
          `preload=none` —— `duration` 读出来是 0。而等待循环的判据是
          "found 且 duration > 0"，于是**一直判"没有可播视频"**、
          等满 20 秒走人，日志里写的是"按文档类处理"。
          用户看到的却是"视频就在那儿，只是没点播放"。

        三层尝试，哪层先成算哪层：
          ① JS 里 `v.muted = true; v.play()`（有的播放器认）
          ② 真实鼠标点播放按钮 —— 自定义播放器只认 trusted 事件
          ③ 真实鼠标点画面中心（多数播放器点画面 = 播放/暂停）

        ⚠ 已经在播就**一个都别点**：点画面等于暂停，会把好好的播放打断。
        """
        fr = frame
        # ★ 先走 **videojs 播放器**（证据：平台走 techCall_ 暂停，
        #   反过来也必须走同一层才真的能播起来；element.play() 会被包装器按回去）
        try:
            _pp = (fr.evaluate(_PLAYER_PLAY_JS) if fr is not None
                   else self.driver.page.evaluate(_PLAYER_PLAY_JS)) or ""
        except Exception:
            _pp = ""
        if _pp in ("player.play()", "already"):
            time.sleep(1.0)
            now = self._any_video()
            if now.get("found") and now.get("paused") is False:
                return f"videojs 播放器起播（{_pp}）"
        try:
            r = fr.evaluate(_CX_PLAY_JS) if fr is not None else \
                self.driver.page.evaluate(_CX_PLAY_JS)
        except Exception:
            try:
                fr = self.driver.page.main_frame
                r = self.driver.page.evaluate(_CX_PLAY_JS) or {}
            except Exception:
                return ""
        r = r or {}
        if fr is None:
            fr = self.driver.page.main_frame

        # 本来就在播 → 一个都别碰
        if r.get("wasPaused") is False:
            return "已经在播放（不用点）"
        # ① 脚本 `play()` 就起来了？
        #    ⚠ 判据必须是**过一会儿再看它有没有真的在播**，
        #      不能只看"读得到时长"：学习通这一版被平台按停时
        #      时长照样读得到，光看时长会得出"点上了"的假结论。
        #      （`play()` 被拒绝时，浏览器会把 paused 再设回 true，
        #        所以要等一小会儿再回读。）
        if r.get("video") and r.get("paused") is False:
            # ⚠⚠ 判据必须是「**进度真的往前走了**」，不是「这一刻没暂停」。
            #
            #   2026-10-17 13:21 实测：`play()` 之后 `paused` 立刻变 false，
            #   0.8 秒后回读仍是 false → 这里直接 return "直接 play() 起播"。
            #   于是五次"恢复"全部空转，**一次都没点到播放按钮**；
            #   而本函数注释里早就写着"自定义播放器只认 trusted 事件"——
            #   真正管用的第 ② 层永远没执行到。
            #
            #   现在读两次 currentTime，差值 > 0.3 秒才算真的在播。
            _t0 = float(self._any_video().get("currentTime") or 0)
            time.sleep(1.2)
            now = self._any_video()
            _t1 = float(now.get("currentTime") or 0)
            if (now.get("found") and now.get("paused") is False
                    and _t1 > _t0 + 0.3):
                return (f"直接 play() 起播"
                        f"（时长 {float(now.get('duration') or 0):.0f} 秒，"
                        f"进度 {_t0:.0f}→{_t1:.0f}）")
            # 没往前走 → 别宣称成功，继续往下走 ②（真实鼠标点按钮）

        # ② 真实鼠标点播放按钮
        for h in (r.get("hits") or [])[:3]:
            rr = h.get("r") or {}
            try:
                self.driver.click_in_frame(
                    fr,
                    float(rr.get("x") or 0) + float(rr.get("w") or 0) / 2,
                    float(rr.get("y") or 0) + float(rr.get("h") or 0) / 2)
            except Exception:
                continue
            time.sleep(0.8)
            now = self._any_video()
            if now.get("found") and now.get("paused") is False:
                return (f"点了播放按钮（{h.get('how')}）"
                        + (f"，时长 {float(now.get('duration') or 0):.0f} 秒"
                           if float(now.get("duration") or 0) > 0 else ""))

        # ③ 点画面中心
        vv = r.get("video") or {}
        if vv:
            try:
                self.driver.click_in_frame(
                    fr,
                    float(vv.get("x") or 0) + float(vv.get("w") or 0) / 2,
                    float(vv.get("y") or 0) + float(vv.get("h") or 0) / 2)
                time.sleep(0.8)
                now = self._any_video()
                if now.get("found") and now.get("paused") is False:
                    return "点了视频画面中心"
            except Exception:
                pass

        # 全都没成 → 把现场线索带回去，别静默
        bits = []
        if r.get("jsErr"):
            bits.append(f"play() 抛错：{r['jsErr']}")
        if not r.get("video"):
            bits.append("页面上没有可见的 <video>")
        if not (r.get("hits") or []):
            bits.append("也没找到像播放按钮的元素")
        return "试过点播放但没成" + ("（" + "；".join(bits) + "）" if bits else "")

    def _cx_handle_current(self, speed: float, mute: bool,
                           title: str, tab_idx: int,
                           *, record_doc: bool = True,
                           video_wait: float = 20.0) -> LessonResult | None:
        """处理当前任务点标签下的内容：有视频就播，没视频就当作已过。

        `record_doc=False` 时，没视频**不记成一条课时**（返回 None）。
        横向栏目那条路径要用它：导读/课件/阅读这几条本来就没有视频，
        记成"课时"会把小结里的节数灌水，也会让 `res.ok` 变成假成功。

        `video_wait` 是等视频出现的最长秒数。栏目路径里，明显不是视频的
        栏目（导读/课件/阅读）不需要等 20 秒 —— 5 条栏目 ×20 秒 = 白等 100 秒。
        """
        # ⚠ 必须**轮询等视频出现**。
        #   学习通的播放器在两层 iframe 里，点进任务点之后要等
        #   #iframe → .ans-attach-ct → iframe 逐层加载完才拿得到 <video>。
        #   而 _probe() 本身不等待（一次没找到就返回 found=False），
        #   所以只探一次会稳定报"找不到视频"——实测就是这个原因。
        #
        # ⚠⚠ 光"找到 <video>"还不够（用户 2026-10-16 截图）：
        #   这一版播放器把封面盖在视频上，不点播放按钮 `duration` 就是 0。
        #   所以等到"找到元素 + 读不到时长"时，要**主动去点播放**，
        #   而不是干等 20 秒然后判"没有可播视频"。
        info: dict = {}
        pressed = 0
        deadline = time.time() + max(0.5, video_wait)
        while time.time() < deadline:
            if not self._alive():
                break
            info = self._any_video()
            if info.get("found") and float(info.get("duration") or 0) > 0:
                break
            # 找到 <video> 但拿不到时长（多半是封面盖着/停在 preload=none）
            # → 点播放。最多试 3 次，免得把"点了会暂停"的情况点坏。
            if info.get("found") and pressed < 3:
                note = self._cx_press_play(info.get("_frame"))
                pressed += 1
                if note:
                    self.log(f"  · {note}")
            time.sleep(1.0)

        if info.get("found") and float(info.get("duration") or 0) > 0:
            # 有可播视频 → 走通用播放逻辑（会自动钳倍速、盯进度）
            return self._ai_play_video(speed, mute,
                                       title or f"任务点{tab_idx + 1}",
                                       prev_percent=None, prev_src="",
                                       card_dur=0.0)

        # 没视频：可能是文档/PPT 类任务点，点开停一下就算完成
        fin = self._cx_finished()
        # ★ 把"到底卡在哪一步"写清楚 —— 这一句就是下次排障的唯一线索。
        #   以前两种情况都只写"没有可播视频"，根本分不出是
        #   "页面上真没有 <video>" 还是"有视频、只是没点播放"。
        if info.get("found"):
            self.log(f"  {title or '任务点'}：等了 {video_wait:.0f} 秒，"
                     f"**找得到 <video> 但读不到时长**"
                     f"（duration={float(info.get('duration') or 0):.1f}、"
                     f"paused={info.get('paused')}）—— 播放器多半还停在封面上")
        else:
            self.log(f"  {title or '任务点'}：等了 {video_wait:.0f} 秒，"
                     f"整个页面（含所有 iframe）都没有 <video>"
                     f"（本章已标记完成的任务点 {fin} 个），按文档类处理")
        time.sleep(1.0)
        if not record_doc:
            return None
        return LessonResult(index=0, title=title or f"任务点{tab_idx + 1}",
                            seconds=1.0, duration=0.0, rate=0.0,
                            finished=True, note="无视频，点开即过")

    # ---- C2 类：学习通新版「横向栏目」章节页 ----
    #
    # ⚠ 这一类是**实测报错**倒逼出来的（2026-10-16 日志）：
    #     · 页面自检（学习通式）：任务点 0 个、章节 0 个、内容层 1 个、任务标签 0 个
    #     停止原因：页面上找不到可播放的视频（当前页面：章节详情）
    #   新版页面**一个 .jobCount 也没有**，于是 `_is_chaoxing_course()` 判否，
    #   直接掉进通用播放器逻辑；而视频在「3 学习视频」栏目里，
    #   不点那一条它根本不加载 → 必然"找不到视频"。
    def _cx_tab_rows(self) -> list[dict]:
        """找出页面上的「横向栏目条」（按几何位置认，不绑类名）。

        返回 `[{row, score, items:[{i,text,active,x,y,w,h}], _frame}]`，
        按可信度排序，只留最可信的那一条（跨框架比）。
        同时把命中元素打上 `data-dsh-tabrow` 标记，供点击用。

        ⚠ **每个框架都要扫**：这一版页面里栏目条既可能在主文档，
          也可能在 `#iframe` 里面（不同学校、不同版本不一样）。
          只扫主文档会"整页都找不到栏目条"。
        """
        best: dict | None = None
        for fr in self._frames():
            try:
                rows = fr.evaluate(_CX_TABROW_JS) or []
            except Exception:
                continue
            for r in rows:
                if not isinstance(r, dict) or not r.get("items"):
                    continue
                if best is None or float(r.get("score") or 0) > float(best.get("score") or 0):
                    best = r
                    best["_frame"] = fr
        return [best] if best else []

    def _cx_tab_texts(self) -> list[str]:
        """当前栏目条上有哪几条（给日志看）。"""
        rows = self._cx_tab_rows()
        if not rows:
            return []
        return [str(x.get("text") or "") for x in (rows[0].get("items") or [])]

    def _cx_tab_fingerprint(self) -> str:
        """页面指纹：用来判断"这一下点没点中"。

        把**所有框架**各自的指纹拼起来 —— 栏目条和它切换出来的内容
        可能都不在主文档里，只盯主文档会误判成"点了没反应"。
        """
        parts: list[str] = []
        for i, fr in enumerate(self._frames()):
            try:
                parts.append(f"{i}:{fr.evaluate(_CX_TAB_PRINT_JS) or ''}")
            except Exception:
                parts.append(f"{i}:x")        # 读不到（跨域/正在销毁）也要留个位
        return " || ".join(parts)

    def _cx_tab_frame_url(self) -> str:
        """取「横向栏目」**当前那一条**内容的地址（`#iframe` 的 src）。

        ⚠ 要**逐帧**找：栏目条和它装内容的 `#iframe` 都可能不在主文档里。
          只读主文档会拿不到地址。

        ⚠⚠ 拿到之后**必须补成绝对地址**。学习通这个 `#iframe` 的 src 常常是
          相对路径（`work/doHomeWorkNew?chapterId=...`），而
          `BrowserDriver.to_file_url()` 对相对路径是原样返回的（它只处理
          `http(s)://` 和本地绝对路径），于是 `page.goto("work/...")`
          直接报 **Cannot navigate to invalid URL** ——
          用户 2026-10-17 的日志里章节测验就是这么一直打不开的。
        """
        from urllib.parse import urljoin

        base = ""
        try:
            base = str(self.driver.page.url or "")
        except Exception:
            base = ""

        raw = ""
        for fr in self._frames():
            try:
                u = str(fr.evaluate(_CX_TAB_FRAME_URL_JS) or "").strip()
                if u:
                    raw = u
                    break
            except Exception:
                continue
        if not raw:
            # 兜底：有的版本没有 #iframe，整页就是一个文档
            self.log(f"    · 栏目内容没有 #iframe.src，改用当前页地址：{base[:96]}")
            return base if base.startswith(("http://", "https://", "file://")) else ""

        # 协议相对（//host/path）也要补
        if raw.startswith("//"):
            raw = (base.split(":", 1)[0] if ":" in base else "https") + ":" + raw
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", raw):
            raw = urljoin(base, raw)
        self.log(f"    · 栏目内容地址：{raw[:110]}")
        return raw

    # ---- C3 类：学习通「目录式」章节页（mooc2=1，#coursetree）----
    def _is_chaoxing_catalog_course(self) -> bool:
        """当前页是不是这版「目录式」章节页。

        判据：有 `#coursetree`、里面真的有条目、且有内容层 `#iframe`。
        不绑域名 —— 同一套模板（泛雅/超星）都可能命中。
        """
        try:
            r = self.driver.page.evaluate(
                """() => ({
                    tree: document.querySelectorAll('#coursetree').length,
                    leaves: document.querySelectorAll(
                        '#coursetree .posCatalog_select .posCatalog_name').length,
                    active: document.querySelectorAll(
                        '#coursetree .posCatalog_select.posCatalog_active').length,
                    iframe: document.querySelectorAll('#iframe').length,
                })""") or {}
        except Exception:
            return False
        self.log(f"· 页面自检（学习通目录式）：章节树 {r.get('tree', 0)} 个、"
                 f"章节 {r.get('leaves', 0)} 条、当前高亮 {r.get('active', 0)} 条、"
                 f"内容层 {r.get('iframe', 0)} 个")
        return bool(r.get("tree")) and bool(r.get("leaves")) and bool(r.get("iframe"))

    def _cx_catalog_tree(self) -> dict:
        """读出整棵章节目录（每章：id / 标题 / 是否完成 / 还剩几个任务点）。"""
        for fr in self._frames():
            try:
                r = fr.evaluate(_CX_CATALOG_TREE_JS) or {}
            except Exception:
                continue
            if r.get("ok"):
                return r
        return {"ok": False, "leaves": []}

    def _cx_active_chapter(self) -> str:
        """当前高亮的那一章的 chapterId（读不到返回空串）。"""
        js = ("""() => {
            const a = document.querySelector(
                '#coursetree .posCatalog_select.posCatalog_active');
            if (!a) return '';
            let id = String(a.id || '').replace(/^cur/, '');
            if (id) return id;
            const n = a.querySelector('.posCatalog_name');
            const oc = String((n && n.getAttribute && n.getAttribute('onclick')) || '');
            const m = oc.match(/getTeacherAjax\\([^)]*?['"](\\d{4,})['"]\\s*\\)/);
            return m ? m[1] : '';
        }""")
        for fr in self._frames():
            try:
                v = str(fr.evaluate(js) or "").strip()
                if v:
                    return v
            except Exception:
                continue
        return ""

    def _cx_content_knowledgeid(self) -> str:
        """内容层（knowledge/cards）当前加载的是哪一章。

        ⚠ 这是**比高亮类名更硬**的判据：页面自己的 iframe 地址里就带着
          `knowledgeid=<chapterId>`。高亮类名万一手抖没更新，这里也不会骗人。
        """
        for fr in self._frames():
            try:
                u = str(getattr(fr, "url", "") or "")
            except Exception:
                continue
            m = re.search(r"knowledgeid=(\d+)", u)
            if m:
                return m.group(1)
        return ""

    def _cx_open_chapter(self, leaf: dict) -> str:
        """打开目录里的某一章。成功返回一句说明，失败返回空串。

        两级：① 真实鼠标点目录项（可信事件）；② 直接调用页面自己的
        `getTeacherAjax(课程, 班级, 章节)` —— 这个函数就在目录项的
        onclick 里，是页面自己的导航入口，比模拟点击更可靠。
        两级都用「高亮章节 + iframe 的 knowledgeid」双判据复核。
        """
        cid = str(leaf.get("id") or "")
        if not cid:
            return ""

        # ① 真实鼠标点击
        fr = None
        try:
            for f in self._frames():
                try:
                    r = f.evaluate(_CX_CLICK_CATALOG_ITEM_JS, cid) or {}
                except Exception:
                    continue
                if r.get("ok"):
                    fr = f
                    break
            if fr is not None:
                self.driver.click_in_frame(fr, float(r["x"]), float(r["y"]))
                time.sleep(1.2)
                try:
                    self.driver.wait_for_load(extra_ms=600)
                except Exception:
                    pass
                if self._cx_active_chapter() == cid or self._cx_content_knowledgeid() == cid:
                    return "点击目录"
        except Exception:
            pass

        # ② 直接调页面的 getTeacherAjax(...)
        m = re.search(
            r"getTeacherAjax\(\s*'([^']*)'\s*,\s*'([^']*)'\s*,\s*'([^']*)'\s*\)",
            str(leaf.get("onclick") or ""))
        if m:
            try:
                self.driver.page.main_frame.evaluate(
                    """(a) => {
                        if (typeof getTeacherAjax !== 'function') return false;
                        getTeacherAjax(a[0], a[1], a[2]);
                        return true;
                    }""", [m.group(1), m.group(2), m.group(3)])
                time.sleep(1.6)
                try:
                    self.driver.wait_for_load(extra_ms=800)
                except Exception:
                    pass
                if self._cx_active_chapter() == cid or self._cx_content_knowledgeid() == cid:
                    return "调用页面 getTeacherAjax"
            except Exception:
                pass
        return ""

    def _cx_current_cards_frame(self):
        """当前这一章的 cards 内容层（`knowledge/cards`，且章节 id 对得上）。

        ⚠ 为什么必须对 id（2026-10-23 用户日志）：切章之后，**上一章的
          cards iframe 还会在 frames 里存活一小会儿**。拿它读"完成角标"，
          会把上一章的状态当成本章的 —— 表现就是"总是有几节被跳过"。
          （03:05 的日志：刚切到 3.2，1 秒后就报"这一栏已标记完成"，
           接着整章 0 节。）

        id 优先取目录里高亮的那一条（目录式页面跳章**不改 URL**），
        取不到才退回 URL 的 chapterId。
        """
        cid = ""
        try:
            cid = str(self._cx_active_chapter() or "")
        except Exception:
            cid = ""
        if not cid:
            try:
                m = re.search(r"chapterId=(\d+)", str(self.driver.page.url or ""))
                cid = m.group(1) if m else ""
            except Exception:
                cid = ""
        fallback = None
        for fr in self._frames():
            try:
                u = str(getattr(fr, "url", "") or "")
            except Exception:
                continue
            if "knowledge/cards" not in u:
                continue
            if cid and f"knowledgeid={cid}" in u:
                return fr
            if fallback is None:
                fallback = fr
        return fallback if not cid else None

    def _cx_video_job_done(self):
        """当前这一章的**视频任务点**是不是已完成。

        返回 True / False；页面上根本认不出"视频任务点"时返回 None。

        ⚠ 不能用 `_cx_finished()` 代替：它数的是**本章所有**已完成任务点。
          同一章里测验做完了、视频没做时，那个数也 > 0 ——
          视频就被误判成"已完成"直接跳过（2026-10-23 用户日志：
          03:02「已标记完成（1 个）→ 跳过播放」，接着整章 0 节）。
        """
        fr = self._cx_current_cards_frame()
        if fr is None:
            return None
        try:
            r = fr.evaluate(_CX_VIDEO_JOB_DONE_JS) or {}
        except Exception:
            return None
        if not r.get("seen"):
            return None
        return bool(r.get("done"))

    def _cx_chapter_jobs(self) -> dict:
        """本章内容层里的任务点清单（视频/文档/作业，各几个已完成）。"""
        fr = self._cx_current_cards_frame()
        frames = [fr] if fr is not None else []
        frames.extend([f for f in self._frames() if f not in frames])
        for f in frames:
            try:
                r = f.evaluate(_CX_CHAPTER_JOBS_JS) or {}
            except Exception:
                continue
            if r.get("ok"):
                return r
        return {"ok": False}

    def _cx_video_points(self) -> list[dict]:
        """本章**所有**视频任务点（含已完成的）。

        2026-10-23 用户：「学习通同一个任务点只看第一个视频。这是个漏洞」。
        一个章节里可能挂着好几个视频任务点，之前只播了第一个就往下走。
        """
        fr = self._cx_current_cards_frame()
        frames = [fr] if fr is not None else []
        frames.extend([f for f in self._frames() if f not in frames])
        for f in frames:
            try:
                got = f.evaluate(_CX_VIDEO_POINT_LIST_JS) or []
            except Exception:
                continue
            if got:
                for p in got:
                    p["_cards_frame"] = f
                return got
        return []

    def _cx_mark_child_frame(self, cards_frame, idx: int):
        """给"第 idx 个任务点的 iframe"打标记，再找出它对应的 Playwright 子框架。

        为什么要绕这一步：一个 cards 层里可能同时挂着好几个
        `ananas/modules/video/index.html`，URL 一模一样，**没法按 URL 区分**；
        但 `frame.frame_element()` 能拿到"这个 frame 属于哪个 <iframe>"，
        配合标记就能精确对上。
        """
        js = r"""(i) => {
            document.querySelectorAll('[data-dsh-vframe]').forEach(function (e) {
                e.removeAttribute('data-dsh-vframe');
            });
            const ct = document.querySelectorAll('.ans-attach-ct')[i];
            if (!ct) return false;
            const f = ct.querySelector('iframe');
            if (!f) return false;
            f.setAttribute('data-dsh-vframe', '1');
            try { ct.scrollIntoView({block: 'center'}); } catch (err) {}
            return true;
        }"""
        try:
            has_iframe = bool(cards_frame.evaluate(js, int(idx)) or False)
        except Exception:
            return None
        if not has_iframe:
            # 视频直接放在 cards 层里（老自测页 / 部分模板）→ 就用 cards 这个框架
            return cards_frame
        for fr in self._frames():
            try:
                el = fr.frame_element()
            except Exception:
                continue
            try:
                if el is not None and el.evaluate(
                        "(e) => e.hasAttribute('data-dsh-vframe')"):
                    return fr
            except Exception:
                continue
        return None

    def _cx_play_chapter_videos(self, res, speed: float, mute: bool,
                                title: str, max_play: int = 20) -> int:
        """把本章**所有未完成的视频任务点**逐个播完。返回播了几条。

        ⚠ 2026-10-23 用户：「学习通循环看一个视频」。
          平台播完有时**不会立刻**给任务点打 `.ans-job-finished`（要刷新才更新），
          而视频地址里的 `at_=…` 防盗链参数每次加载都会变 ——
          只按"src 有没有播过"去重会失效，于是同一段视频被一遍遍重播。
          现在按**任务点身份**（序号 + 标题）去重：同一个任务点一轮只播一次。
        """
        played = 0
        tried_src: set = set()
        attempted: set = set()
        while played < max_play:
            if not self._alive():
                break
            points = self._cx_video_points()

            def _ident(x: dict) -> tuple:
                # 优先用"贴在 DOM 上的稳定编号"；老结构取不到才退回序号+标题。
                if x.get("vp"):
                    return ("vp", str(x.get("vp")))
                return ("ti", int(x.get("i") or 0), str(x.get("title") or ""))

            todo = [p for p in points
                    if not p.get("fin") and _ident(p) not in attempted]
            if not todo:
                if points:
                    left = [p for p in points if not p.get("fin")]
                    if left:
                        self.log(f"    · 还有 {len(left)} 个视频任务点本轮已经播过"
                                 f"（平台没标完成）→ 不再重复")
                    else:
                        self.log(f"    · 本章视频任务点都完成了（{len(points)} 个）")
                break
            p = todo[0]
            attempted.add(_ident(p))
            cards = p.get("_cards_frame")
            fr = self._cx_mark_child_frame(cards, int(p.get("i") or 0))
            if fr is None:
                self.log(f"    · 视频任务点「{p.get('title') or ''}」的播放器还没加载出来"
                         f" → 先跳过")
                break
            try:
                src = str(fr.evaluate(
                    "() => { const v = document.querySelector('video');"
                    " return v ? (v.currentSrc || v.src || '') : ''; }") or "")
            except Exception:
                src = ""
            if src and src in tried_src:
                self.log("    · 同一段视频本轮已经播过 → 不再重复")
                break
            self.log(f"    · 本章视频 {played + 1}/{len(points)}："
                     f"{p.get('title') or '视频任务点'}")
            self._video_frame_hint = fr
            try:
                r = self._cx_handle_current(speed, mute,
                                            f"{title} · 视频{played + 1}",
                                            tab_idx=0, record_doc=False,
                                            video_wait=20.0)
            finally:
                self._video_frame_hint = None
            if r is None:
                self.log("    · 这个视频打不开 → 不再继续本章的视频")
                break
            res.lessons.append(r)
            played += 1
            if src:
                tried_src.add(src)
            self.log(f"      视频{played} 结束："
                     f"{'✔ 已播完' if r.finished else '⚠ 未播完'}"
                     f"（{r.duration:.0f} 秒，用时 {r.seconds:.0f} 秒）")
        return played

    def _cx_scroll_frame(self, fr, max_steps: int = 90) -> bool:
        """把某个框架里的内容**滚到底**（PDF/PPT/文档类任务点靠这个完成）。

        为什么这么做：用户 2026-10-23 截图 —— 「内嵌下划式 ppt 需要滑动完
        才算完成」。学习通的这些查看器把滚动位置报给平台，不滚到底就一直
        "待完成"。

        做法：找页面里**滚动余量最大**的那个容器，按每步约 0.8 屏往下滚，
        每步停 0.22 秒（像人在看），到底后再停 1 秒让平台结算。
        返回是否真的滚过。
        """
        try:
            info = fr.evaluate(_SCROLL_PROBE_JS) or {}
        except Exception:
            return False
        if not info.get("ok"):
            return False
        h = float(info.get("h") or 0) or 600.0
        step = max(240.0, h * 0.8)
        for _ in range(max_steps):
            if not self._alive():
                return False
            try:
                r = fr.evaluate(_SCROLL_STEP_JS, step) or {}
            except Exception:
                break
            if not r.get("ok"):
                break
            time.sleep(0.22)
            if float(r.get("after") or 0) <= float(r.get("before") or 0) + 1:
                break            # 到底了
        time.sleep(1.0)          # 给平台的"滚到底"判定留点时间
        return True

    def _cx_scroll_docs(self) -> int:
        """把本章里"文档/PPT"这类任务点逐个滚到底。返回滚过几个框架。"""
        n = 0
        for fr in self._frames():
            try:
                u = str(getattr(fr, "url", "") or "")
            except Exception:
                continue
            if not u or not _DOC_FRAME_RE.search(u):
                continue
            if not self._alive():
                break
            if self._cx_scroll_frame(fr):
                n += 1
                self.log(f"    · 已滚到底：{u[:80]}")
        return n

    # ---- 章节测验：自动作答（可自动交卷）----
    def _frame_inside(self, fr, ancestor, max_up: int = 6) -> bool:
        """`fr` 是不是在 `ancestor` 这个框架里面（含自身）。"""
        f = fr
        for _ in range(max_up):
            if f is None:
                return False
            if f is ancestor:
                return True
            try:
                f = f.parent_frame
            except Exception:
                return False
        return False

    def _cx_quiz_targets(self) -> list[dict]:
        """本章有哪几份卷子可以自动作答：`[{url, title, key, kind}]`。

        2026-10-23 用户要求「刷课时遇到的所有题目和任务一键自动完成」：
        **作业也做**（`work/doHomeWorkNew` 打头的都算），不再只看标题。
        唯一例外是**考试**：URL 或标题命中考试类的一律跳过并说明原因
        （产品承诺 + 风险最高的一项）。

        ⚠ 2026-10-23 自检修正：只认**当前这一章** cards 层里的卷子。
          切章之后上一章的 iframe 还会存活一会儿，不筛的话会把上一章的
          测验/作业**再交一遍**（重复提交比少做更糟）。
        """
        rows: list[dict] = []
        for fr in self._frames():
            try:
                got = fr.evaluate(_CX_TASKPOINT_LIST_JS) or []
            except Exception:
                continue
            if got:
                rows.extend([r for r in got if isinstance(r, dict)])

        out: list[dict] = []
        seen: set = set()
        answered = set(getattr(self, "_answered_quiz_keys", set()) or set())
        cur_cards = self._cx_current_cards_frame()

        for fr in self._frames():
            if cur_cards is not None and not self._frame_inside(fr, cur_cards):
                continue          # 上一章的残留帧，跳过
            try:
                u = str(getattr(fr, "url", "") or "")
            except Exception:
                continue
            if not u or not _QUIZ_URL_RE.search(u):
                continue
            m = _QUIZ_KEY_RE.search(u)
            key = (m.group(2) if m else u[:120])
            if key in seen or key in answered:
                continue
            seen.add(key)
            title = ""
            for r in rows:
                if key and key in str(r.get("src") or ""):
                    title = str(r.get("text") or "")
                    break
            if _EXAM_URL_RE.search(u) or _EXAM_TITLE_RE.search(title):
                self.log(f"    · 跳过考试任务点（{title[:36] or u[:56]}）"
                         f"—— 考试不代做")
                continue
            kind = "测验" if _QUIZ_TITLE_RE.search(title) else "作业"
            out.append({"url": u, "title": title[:60], "key": key, "kind": kind})
        return out

    # ---- 分节标签（一个章节测验挂多份卷子时） ----
    def _cx_section_tabs(self) -> list[dict]:
        """读「分节」标签：`[{i,id,text,active}]`；没有就返回 []。

        结构见 `_CX_SECTION_TABS_JS` 上方注释。只有 ≥2 个时才值得逐个切。
        """
        self._sect_tab_frame = None
        for fr in self._frames():
            try:
                got = fr.evaluate(_CX_SECTION_TABS_JS) or []
            except Exception:
                continue
            rows = [t for t in got if isinstance(t, dict)]
            if rows:
                self._sect_tab_frame = fr
                return rows
        return []

    def _cx_click_section_tab(self, idx: int) -> bool:
        """点第 idx 个分节标签，并确认它真的变成 active。

        2026-10-26：点完多等一会儿 —— 学习通换分节时 iframe 重新加载，
        有时候 1 秒内 active 还没变；原来只等 1.2 秒就判失败，会误跳过第 2 节。
        """
        fr = getattr(self, "_sect_tab_frame", None)
        if fr is None:
            self._cx_section_tabs()
            fr = getattr(self, "_sect_tab_frame", None)
        if fr is None:
            return False
        for target in (0, 1):
            try:
                ok = bool(fr.evaluate(_CX_SECTION_TAB_CLICK_JS,
                                      {"i": idx, "target": target}))
            except Exception:
                ok = False
            if not ok:
                continue
            try:
                self.driver.wait_for_load(extra_ms=600)
            except Exception:
                pass
            # 最多等 6 秒，active 落到目标下标上就算成功
            for _ in range(8):
                time.sleep(0.75)
                tabs = self._cx_section_tabs()
                if not tabs:
                    break
                act = [k for k, t in enumerate(tabs) if t.get("active")]
                if act and act[0] == idx:
                    return True
            if not tabs:
                return False
        return False


    # ---- 讨论区（2026-10-26 用户要求：讨论也要能自动刷） ----
    def _cx_discuss_targets(self) -> list[dict]:
        """本章的讨论任务点：`[{url,title,desc,finished}]`。

        结构（2026-10-26 实测）：
          卡片 iframe → ananas/modules/insertbbs/index.html
            → 内层 bbscircle/chapter?mtopicid=...
              → #topicMainDiv[data="groupweb.../replysList?..."]
        点它才进真正的「话题详情」页，回复框在那里。
        是否已完成看**卡片**上的 `ans-job-finished` —— 已完成的不重复回复。
        """
        att: list[dict] = []
        for fr in self._frames():
            try:
                rows = fr.evaluate(_CX_DISCUSS_ATTACH_JS) or []
            except Exception:
                continue
            att.extend([r for r in rows if isinstance(r, dict)])
        if not att:
            return []
        tops: list[dict] = []
        for fr in self._frames():
            try:
                t = fr.evaluate(_CX_TOPIC_CARD_JS)
            except Exception:
                t = None
            if isinstance(t, dict) and t.get("url"):
                tops.append(t)
        out: list[dict] = []
        for i, t in enumerate(tops):
            fin = bool(att[i].get("fin")) if i < len(att) else False
            out.append({"url": str(t.get("url") or ""),
                        "title": str(t.get("title") or "")[:120],
                        "desc": str(t.get("desc") or "")[:600],
                        "finished": fin})
        return out

    def _cx_make_discussion_reply(self, title: str, desc: str) -> str:
        """让模型写一段学生口吻的讨论回复。"""
        if self.client is None:
            return ""
        prompt = ("请为下面这个课程讨论话题写一段学生本人的回复（第一人称，120~220 字）。"
                  "要具体、真诚，可以结合自己的学习打算或看法；不要复述题目原文，"
                  "不要提 AI/模型，不要用 Markdown，不要加标题或引号，只输出正文。\n\n"
                  f"话题：{title}\n说明：{desc}")
        try:
            res = self.client.chat(
                [{"role": "system",
                  "content": "你是帮学生写课程讨论回复的助手，只输出回复正文。"},
                 {"role": "user", "content": prompt}],
                temperature=0.7, max_tokens=500, timeout=config.LM_TIMEOUT)
            text = str(getattr(res, "text", "") or "").strip()
        except Exception as e:
            self.log(f"    ✘ 讨论回复生成失败（{type(e).__name__}: {str(e)[:60]}）")
            return ""
        text = text.strip().strip('"“”「」')
        text = re.sub(r"\s+", " ", text).strip()
        return text[:400]

    def _cx_answer_discussion_page(self, url: str, title: str, desc: str) -> bool:
        """打开话题详情 → 生成回复 → 填进「回复话题」→ 点「回复」→ 核验。"""
        old_page = self.driver.page
        page = None
        self.log(f"    → 打开讨论：{title or url[:60]}")
        try:
            page = self.driver.context.new_page()
            self.driver.page = page
            page.goto(url, wait_until="domcontentloaded",
                      timeout=config.NAV_TIMEOUT_MS)
            self.driver.wait_for_load(extra_ms=800)
            ta = page.locator('textarea[placeholder="回复话题"]').first
            ta.wait_for(state="visible", timeout=12000)
            text = self._cx_make_discussion_reply(title, desc)
            if not text:
                self.log("    · ⚠ 没生成出回复正文 → 跳过这条讨论")
                return False
            ta.fill(text)
            page.wait_for_timeout(300)
            clicked = False
            for sel in (".addReply", ".replyBtn", "button:has-text('回复')"):
                try:
                    page.locator(sel).first.click(timeout=3000)
                    clicked = True
                    break
                except Exception:
                    continue
            if not clicked:
                self.log("    · ⚠ 没找到「回复」按钮（页面结构可能变了）")
                return False
            ok = False
            for _ in range(12):
                page.wait_for_timeout(1000)
                try:
                    body = page.evaluate(
                        "() => document.body ? document.body.innerText : ''") or ""
                except Exception:
                    body = ""
                if text[:16] in body:
                    ok = True
                    break
            if ok:
                self._last_discuss_reply = text
                self.log(f"    ✔ 已回复讨论（{len(text)} 字）：{text[:36]}…")
            else:
                self.log("    ⚠ 点了「回复」但页面没看到内容 —— 可能还在审核，或提交没成功")
            return ok
        except Exception as e:
            self.log(f"    ✘ 讨论回复失败（{type(e).__name__}: {str(e)[:70]}）")
            return False
        finally:
            try:
                if page is not None and not page.is_closed():
                    page.close()
            except Exception:
                pass
            try:
                if old_page is not None and not old_page.is_closed():
                    self.driver.page = old_page
            except Exception:
                pass

    def _cx_answer_discussions(self, force: bool = False) -> int:
        """自动回复本节未完成的讨论任务点，返回回复条数。

        force=True 时**连目录已打勾的也处理** —— 2026-10-26 用户反馈：
        「这些讨论虽然目录已经打勾，但是并未真实完成」。
        """
        if not getattr(config, "COURSE_DISCUSS_AUTO", True):
            self.log("    （讨论自动回复已关闭 → 跳过）")
            return 0
        if not self.auto_quiz:
            self.log("    （「自动作答」没开 → 讨论跳过）")
            return 0
        if self.client is None:
            self.log("    （没有可用的模型客户端 → 讨论跳过，请先填 API Key）")
            return 0
        targets = self._cx_discuss_targets()
        if not targets:
            self.log("    （这一节没有讨论任务点）")
            return 0
        if force:
            todo = list(targets)
            self.log("    （强制模式：目录已打勾的讨论也处理）")
        else:
            todo = [t for t in targets if not t.get("finished")]
        if not todo:
            self.log(f"    · {len(targets)} 个讨论任务点都已完成 → 不重复回复")
            return 0
        self.log(f"  · 本节有 {len(todo)} 条讨论待回复（自动生成）")
        done = 0
        for t in todo:
            if not self._alive():
                break
            if self._cx_answer_discussion_page(t["url"], t["title"], t["desc"]):
                done += 1
        return done

    def _cx_process_section(self, res, speed: float, mute: bool, title: str,
                            target: dict,
                            *, reopen_after_quiz: bool = True,
                            force_discuss: bool = False) -> tuple[int, int, int]:
        """处理**当前分节**里的任务点：①视频 ②文档/PPT ③测验/作业。

        返回 `(滚到底的文档数, 作答题卷份数)`。

        2026-10-26 抽出来的原因：一个章节可能挂着多个「第 X 节」标签，
        视频/文档/测验都跟着标签换内容，所以整段流程要按分节各跑一遍
        （见章节循环里的 `_cx_section_tabs()` 分支）。原来的三段逻辑一字未改。
        """
        scrolled = quizzes = 0
        jobs = self._cx_chapter_jobs()
        if jobs.get("ok"):
            self.log(f"· 本节任务点 {jobs.get('fin')}/{jobs.get('total')} 已完成"
                     + (f"（视频：{jobs.get('videoFin')} 个已完成、"
                        f"{jobs.get('videoUnfin')} 个未完成）"
                        if (jobs.get("videoFin") or jobs.get("videoUnfin")) else ""))

        # ---- ① 视频任务点：**本节有几个就播几个**（已完成的别重看）----
        if not jobs.get("ok") or jobs.get("videoUnfin"):
            n_v = self._cx_play_chapter_videos(res, speed, mute, title)
            if n_v == 0:
                self.log("  · 这一节没有可播的视频（可能只有文档/作业）")
        else:
            self.log("  · 视频任务点已经完成 → 不重看，接着看文档/PPT")

        # ---- ② 文档/PPT 任务点：**滚到底才算完成** ----
        rest_jobs = self._cx_chapter_jobs()
        rest = (int(rest_jobs.get("total") or 0) - int(rest_jobs.get("fin") or 0)
                if rest_jobs.get("ok") else 0)
        if rest > 0:
            n = self._cx_scroll_docs()
            if n:
                scrolled += n
                self.log(f"  · 滚动了 {n} 个文档/PPT 任务点（平台要求滑到底）")
                time.sleep(1.2)
                rest_jobs = self._cx_chapter_jobs()
                rest = (int(rest_jobs.get("total") or 0)
                        - int(rest_jobs.get("fin") or 0)
                        if rest_jobs.get("ok") else rest)

        # ---- ③ 章节测验：自动作答 + 自动交卷 ----
        if rest > 0:
            qn = self._cx_answer_chapter_quizzes()
            if qn:
                quizzes += qn
                self.log(f"  · 测验/作业：{qn} 份已作答")
                # 交完卷刷新一下本章，平台才会把任务点标成完成。
                # 多分节时不在这里刷（会把标签切回第一节），由章节循环最后统一刷。
                if reopen_after_quiz:
                    try:
                        self._cx_open_chapter(target)
                        time.sleep(1.0)
                        self.driver.wait_for_load(extra_ms=600)
                    except Exception:
                        pass

        # ---- ④ 讨论区：自动回复（讨论不算任务点，所以不受 rest 限制）----
        dn = self._cx_answer_discussions(
            force=force_discuss or bool(getattr(self, "discuss_force", False)))
        if dn:
            self.log(f"  · 讨论：{dn} 条已回复")
        return scrolled, quizzes, dn

    def _cx_answer_chapter_quizzes(self) -> int:
        """把本章的章节测验逐份作答（开关打开时自动交卷）。返回答了几份。"""
        if not self.auto_quiz:
            self.log("    （「自动作答」没开 → 测验/作业跳过）")
            return 0
        if self.client is None:
            self.log("    （没有可用的模型客户端 → 测验/作业跳过，"
                     "请先在设置里填 API Key）")
            return 0
        targets = self._cx_quiz_targets()
        if not targets:
            self.log("    （这一章没找到可自动作答的试卷页面）")
            return 0
        self.log(f"  · 本章有 {len(targets)} 份测验/作业，开始自动作答…"
                 + ("（答完自动交卷）" if self.quiz_submit else "（只填答案，不交卷）"))
        done = 0
        for t in targets:
            if not self._alive():
                break
            if self._cx_answer_quiz_page(t["url"], t["title"], t.get("key") or ""):
                done += 1
        return done

    def _cx_answer_quiz_page(self, url: str, title: str, key: str = "") -> bool:
        """在**新标签页**里打开一份测验，交给答题引擎作答；完事关页回课程页。

        为什么开新标签页而不是就地答：这一版的卡片层里**同时挂着好几个**
        任务点的 iframe（视频/文档/两份测验），就地扫会把别的任务点也算进去。
        新页里只有这一份卷子，落笔/交卷都干净。

        ⚠ 同一份卷子**一轮里只交一次**：`key` 会记进 `_answered_quiz_keys`。
          重复提交比少做更糟（作业可能被覆盖、测验可能不让再交）。
        """
        if key and key in set(getattr(self, "_answered_quiz_keys", set()) or set()):
            self.log(f"    · 「{title or key}」这一轮已经交过了 → 跳过")
            return False
        old_page = self.driver.page
        quiz_page = None
        r = None
        self.log(f"    → 打开题目页：{title or url[:60]}")
        try:
            from .agent import SolverAgent
            quiz_page = self.driver.context.new_page()
            self.driver.page = quiz_page
            try:
                quiz_page.bring_to_front()
            except Exception:
                pass
            quiz_page.goto(url, wait_until="domcontentloaded",
                           timeout=config.NAV_TIMEOUT_MS)
            self.driver.wait_for_load(extra_ms=600)
            ag = SolverAgent(
                client=self.client,
                log=lambda s: self.log("      " + str(s)),
                status=self.status,
                auto_submit=self.quiz_submit,
            )
            r = ag.run_web(None, driver=self.driver, pause_for_login=False)
        except Exception as e:
            # 自动作答属于"锦上添花"，它自己出错绝不能影响刷课
            self.log(f"    ✘ 章节测验作答失败（{type(e).__name__}: {str(e)[:60]}）")
            self.chapter_quiz_failed = getattr(self, "chapter_quiz_failed", 0) + 1
            return False
        finally:
            try:
                if quiz_page is not None and not quiz_page.is_closed():
                    quiz_page.close()
            except Exception:
                pass
            try:
                if old_page is not None and not old_page.is_closed():
                    self.driver.page = old_page
                    old_page.bring_to_front()
            except Exception:
                pass

        answered = len(getattr(r, "answered", []) or [])
        failed = len(getattr(r, "failed", []) or [])
        err = str(getattr(r, "error", "") or "")
        if not answered:
            self.chapter_quiz_failed = getattr(self, "chapter_quiz_failed", 0) + 1
            self.log(f"    ⚠ 「{title or '题目页'}」没扫到可作答的题"
                     + (f"：{err[:60]}" if err else ""))
            return False

        submitted = bool(getattr(r, "submitted", False))
        self.chapter_quiz_done = getattr(self, "chapter_quiz_done", 0) + 1
        self.last_quiz_submitted = submitted
        self.last_quiz_blocked = ("验证码" in err) or ("人机校验" in err)
        if submitted:
            how = "已交卷"
        elif self.last_quiz_blocked:
            how = "⚠ 被验证码拦住，未交卷（请手动完成）"
        elif self.quiz_submit:
            how = "⚠ 答完了但没确认交上，请手动检查"
        else:
            how = "已填好、未交卷"
        self.log(f"    ✔ 「{title or '题目页'}」落笔 {answered} 题"
                 f"{('，失败 ' + str(failed) + ' 题') if failed else ''}（{how}）")
        if key:
            done_keys = set(getattr(self, "_answered_quiz_keys", set()) or set())
            done_keys.add(key)
            self._answered_quiz_keys = done_keys
        return True

    def _run_chaoxing_catalog_course(self, res: CourseResult, speed: float,
                                     mute: bool, max_items: int,
                                     t0: float) -> CourseResult:
        """学习通目录式：按**章节目录**推进，不再依赖「下一节」按钮。

        为什么必须这样（2026-10-23 真机）：
          这版页面的「下一节」在**本章任务点没做完时被平台拦着**，
          点了没反应；而这一章的 3 个任务点里有 2 个是作业/文档，
          刷课脚本永远做不完 → 卡在同一章无限重做。
          所以改成：直接按目录打开"第一个没完成、没处理过"的章节，
          有未完成的视频就播，没有（或只有作业）就跳过并说清楚。

        每一章的结局都会记账（`visited`），**绝不重复进同一章**。
        """
        self.log(f"目标倍速：{speed}×（会挑平台提供的、不超过它的最大值）")

        visited: set = set()
        chap_no = 0
        scrolled = 0
        quizzes = 0
        discuss = 0
        open_fail = 0
        guard = 0

        while len(res.lessons) < max_items:
            if not self._alive():
                res.stopped_reason = "用户停止"
                break

            guard += 1
            if guard > 200:
                res.stopped_reason = "处理了 200 章还没结束，先停下（可能页面结构异常）"
                break

            tree = self._cx_catalog_tree()
            if not tree.get("ok"):
                res.stopped_reason = "页面上找不到章节树（#coursetree）"
                break
            leaves = list(tree.get("leaves") or [])
            if not leaves:
                res.stopped_reason = "章节树里没有可点的章节"
                break

            # 从"当前章"开始按目录顺序找：第一个没完成、且没处理过的
            start = 0
            for i, leaf in enumerate(leaves):
                if leaf.get("active"):
                    start = i
                    break
            target = None
            for leaf in leaves[start:] + leaves[:start]:
                if str(leaf.get("id")) in visited:
                    continue
                if leaf.get("finished"):
                    continue
                target = leaf
                break

            if target is None:
                left = [x for x in leaves if not x.get("finished")]
                if left:
                    res.stopped_reason = (
                        f"剩下 {len(left)} 个章节还有 "
                        f"{sum(int(x.get('unfin') or 0) for x in left)} 个任务点没完成"
                        f"（脚本会播视频、滚文档/PPT；章节测验和作业要另外做）")
                else:
                    res.stopped_reason = "目录里所有章节都已完成"
                break

            # ---- 打开这一章 ----
            if not target.get("active"):
                self.status(f"打开「{target.get('title') or '章节'}」…")
                how = self._cx_open_chapter(target)
                if not how:
                    open_fail += 1
                    self.log(f"· ⚠ 打不开「{target.get('title') or target.get('id')}」"
                             f"（连续 {open_fail} 次）")
                    visited.add(str(target.get("id")))
                    if open_fail >= 3:
                        res.stopped_reason = "连续 3 个章节都打不开（页面结构可能变了）"
                        break
                    time.sleep(1.0)
                    continue
                open_fail = 0
                self.log(f"· 已打开（{how}）")
            visited.add(str(target.get("id")))
            chap_no += 1

            time.sleep(0.8)
            try:
                self.driver.wait_for_load(extra_ms=600)
            except Exception:
                pass

            title = str(target.get("title") or f"第 {chap_no} 章")
            self.log(f"—— {title} ——")
            self.status(f"第 {chap_no} 章：{title}")

            # ---- 分节：一个章节可能挂着多个「第 X 节」标签 ----
            #
            # 2026-10-26 用户：「一个页面有多个章节测验，1 可以，2、3 就不行」，
            # 以及「课件导读只会翻第一分节」。实测：这些标签就在课程页主文档里
            #
            #   <div class="prev_list"><ul class="prev_ul clearfix">
            #     <li id="dct1" class="active">…第五章第一节…</li>
            #     <li id="dct2" class="c2">…第五章第二节…</li>
            #     <li id="dct3" class="c3">…第五章第三节…</li>
            #   </ul></div>
            #
            # 一次只挂一节的内容，所以**整段流程（视频/文档/测验）都要按分节跑一遍**。
            sect = self._cx_section_tabs()
            if len(sect) >= 2:
                order = ([t for t in sect if t.get("active")]
                         + [t for t in sect if not t.get("active")])
                self.log(f"· 本章有 {len(sect)} 个分节标签，逐个处理："
                         + " / ".join(str(t.get("text") or "") for t in order))
                for n, t in enumerate(order):
                    if not self._alive():
                        break
                    if n:
                        if not self._cx_click_section_tab(t.get("i")):
                            self.log(f"  · ⚠ 第 {n + 1} 个分节点不动，跳过（"
                                     f"{t.get('text') or '?'}）")
                            continue
                        time.sleep(1.2)
                    self.log(f"  · —— 分节 {n + 1}/{len(order)}："
                             f"{t.get('text') or '?'} ——")
                    _s, _q, _d = self._cx_process_section(
                        res, speed, mute, title, target, reopen_after_quiz=False)
                    scrolled += _s
                    quizzes += _q
                    discuss += _d
                # 全部分节处理完，回到本章开头重新对一次任务点
                try:
                    self._cx_open_chapter(target)
                    time.sleep(1.0)
                    self.driver.wait_for_load(extra_ms=600)
                except Exception:
                    pass
                rest_jobs = self._cx_chapter_jobs()
                rest = (int(rest_jobs.get("total") or 0)
                        - int(rest_jobs.get("fin") or 0)
                        if rest_jobs.get("ok") else rest)
            else:
                _s, _q, _d = self._cx_process_section(
                    res, speed, mute, title, target, reopen_after_quiz=True)
                scrolled += _s
                quizzes += _q
                discuss += _d
                rest_jobs = self._cx_chapter_jobs()
                rest = (int(rest_jobs.get("total") or 0)
                        - int(rest_jobs.get("fin") or 0)
                        if rest_jobs.get("ok") else rest)

            # ---- ④ 还剩的如实说 ----
            if rest_jobs.get("ok") and rest > 0:
                _names = {"video": "视频", "work": "作业/测验", "doc": "文档/PPT"}
                _todo = []
                for _t in (rest_jobs.get("types") or []):
                    if not str(_t).endswith(":todo"):
                        continue
                    _todo.append(_names.get(str(_t).split(":", 1)[0], "其它"))
                self.log(f"  · 本章还剩 {rest} 个任务点没完成"
                         + (f"（{'、'.join(_todo)}）" if _todo else "")
                         + " —— 平台没标完成，可能要刷新或手动处理")

        res.ok = len(res.lessons) > 0 or scrolled > 0 or quizzes > 0
        self.log("")
        done_n = sum(1 for x in res.lessons if x.finished)
        self.log(f"===== 刷课结束：{len(res.lessons)} 个视频"
                 f"（{done_n} 个播完）、{scrolled} 个文档/PPT 已滚到底、"
                 f"{quizzes} 份测验/作业已作答、{discuss} 条讨论已回复，"
                 f"用时 {time.time() - t0:.0f} 秒 =====")
        if res.stopped_reason:
            self.log(f"停止原因：{res.stopped_reason}")
        return res

    def _cx_answer_chapter_quiz(self, tab_text: str,
                               pages_before: list | None = None) -> bool:
        """把「章节测验」这一栏的整份卷子答掉。成功返回 True。

        ## 两种形态都要支持

        1. **内嵌 iframe**（学习通）：卷子就在课程页的 `#iframe` 里，就地答；
        2. **新标签页**（智慧树这一版）：点「章节测验」会 `window.open`
           一个新页面；答完必须**关掉新页、回到课程页**，否则刷课循环
           还停在旧页上，下一节也点不动。

        `pages_before` 是点栏目之前 `context.pages` 的快照；有新增页就
        认定是新标签页。
        """
        # 开关没开 → 说清楚原因，别静默跳过（用户会以为程序坏了）
        if not self.auto_quiz:
            self.log("    （「课中弹题自动作答」没开 → 本章测验一并跳过）")
            return False
        if self.client is None:
            self.log("    （没有可用的模型客户端 → 本章测验跳过。"
                     "请先在设置里填 API Key）")
            return False

        old_page = self.driver.page
        before = list(pages_before or [])
        quiz_page = None
        try:
            for p in self.driver.context.pages:
                if p.is_closed():
                    continue
                if p is old_page:
                    continue
                if p not in before:
                    quiz_page = p
                    break
        except Exception:
            quiz_page = None

        if quiz_page is not None:
            self.log("    → 检测到章节测验在**新标签页**，切过去作答…")
            try:
                quiz_page.bring_to_front()
                quiz_page.wait_for_load_state("domcontentloaded", timeout=15000)
            except Exception:
                pass
            self.driver.page = quiz_page
            try:
                self.driver.wait_for_load(extra_ms=800)
            except Exception:
                pass
        else:
            url = self._cx_tab_frame_url()
            if not url or url.lower().startswith("about:"):
                self.log("    ⚠ 拿不到测验页的地址（#iframe 没有 src）→ 跳过")
                return False
            # ★ 内嵌形态：不新开标签页，卷子就在课程页的 `#iframe` 里，就地答。
            self.log(f"    → 就地作答（内嵌在课程页里）：{url[:84]}")

        try:
            from .agent import SolverAgent
            ag = SolverAgent(
                client=self.client,
                log=lambda s: self.log("      " + str(s)),
                status=self.status,
                auto_submit=self.quiz_submit,
            )
            # url=None：借用 driver 时 `run_web` 不会导航，直接在当前页扫。
            # 扫描穿透 iframe，所以内嵌的题一样能扫到、点得到。
            r = ag.run_web(
                None,
                driver=self.driver,          # ★ 借进来，共用同一个
                pause_for_login=False,       # 已经登录过了，不要再等
            )
        except Exception as e:
            # 自动作答属于"锦上添花"，它自己出错绝不能影响刷课
            self.log(f"    ✘ 章节测验自动作答失败（{type(e).__name__}: "
                     f"{str(e)[:70]}）→ 当作没做，继续刷课")
            self.chapter_quiz_failed += 1
            return False
        finally:
            if quiz_page is not None:
                try:
                    if not quiz_page.is_closed():
                        quiz_page.close()
                except Exception:
                    pass
                try:
                    if old_page is not None and not old_page.is_closed():
                        self.driver.page = old_page
                        old_page.bring_to_front()
                        self.driver.wait_for_load(extra_ms=500)
                except Exception:
                    pass
                self.log("    · 已关闭测验页，返回课程页")

        answered = len(getattr(r, "answered", []) or [])
        failed = len(getattr(r, "failed", []) or [])
        err = str(getattr(r, "error", "") or "")
        if err:
            self.log(f"    ⚠ 作答报告：{err[:80]}")
        if answered:
            self.chapter_quiz_done = getattr(self, "chapter_quiz_done", 0) + 1
            # ★ 按**实际结果**说，不按开关说。
            #   原来写的是 `"已交卷" if self.quiz_submit else ...` ——
            #   只看开关，于是日志里明明有"三次尝试都没能确认提交成功"，
            #   下一行却报"（已交卷）"。那是在骗用户。
            #
            # ★ 同时记下这一份的**真实结局**，给最后的汇总行用。
            #   2026-10-17 17:18 又自相矛盾了一次：
            #     这一行说"⚠ 答完了但没确认交上"，
            #     汇总行却说"1 份答完（已交卷）"。
            self.last_quiz_submitted = bool(getattr(r, "submitted", False))
            self.last_quiz_blocked = ("验证码" in err) or ("人机校验" in err)
            if self.last_quiz_submitted:
                how = "已交卷"
            elif self.last_quiz_blocked:
                how = "⚠ 被验证码拦住，未交卷（请你手动完成）"
            elif self.quiz_submit:
                how = "⚠ 答完了但没确认交上，请手动检查"
            else:
                how = "已填好、未交卷"
            self.log(f"    ✔ 「{tab_text}」处理完：落笔 {answered} 题"
                     f"{('，失败 ' + str(failed) + ' 题') if failed else ''}（{how}）")
            return True
        # ⚠ 别再说"没扫到可作答的题（可能是纯文本页面）"了 ——
        #   2026-10-17 14:33 的日志里明明写着「识别到 2 道选择题」，
        #   下一行却说"没扫到"，用户完全看不出是被字体加密拦下的。
        #   现在：引擎给了原因就**如实转述**，没给才说"没扫到"。
        _why = str(getattr(r, "error", "") or "").strip()
        if _why:
            self.log(f"    ⚠ 「{tab_text}」没作答：{_why}")
        else:
            self.log(f"    ⚠ 「{tab_text}」没扫到可作答的题"
                     f"（可能是纯文本页面）→ 当作文档跳过")
        return False

    def _cx_click_tab_text(self, text: str) -> bool:
        """按栏目名点开它。点中了返回 True。

        两级点击（和 `_cx_click_job` 同源的思路）：
          ① 原生 DOM 事件 —— 这一版页面是事件委托 + 前端路由，
             直接派发整串指针事件比重放真实鼠标更稳；
          ② 真实鼠标点坐标 —— 原生事件被 preventDefault 吃掉时兜底
             （坐标要经过 `click_in_frame` 换算框架原点）。
        每次点完都拿 `_cx_tab_fingerprint()` 前后对比，
        **只有页面真的变了才算点中**，不靠"没报错"糊弄过去。
        """
        want = (text or "").strip()
        if not want:
            return False
        for attempt in (0, 1):
            rows = self._cx_tab_rows()
            if not rows:
                return False
            fr = rows[0].get("_frame") or self.driver.page.main_frame
            ref = ""
            info: dict = {}
            for it in (rows[0].get("items") or []):
                if str(it.get("text") or "").strip() == want:
                    ref = f"{rows[0].get('row')}-{it.get('i')}"
                    info = it
                    break
            if not ref:
                return False

            before = self._cx_tab_fingerprint()
            if attempt == 0:
                try:
                    r = fr.evaluate(_CX_TAB_CLICK_JS, ref) or {}
                except Exception:
                    r = {}
                if not r.get("ok"):
                    continue
            else:
                try:
                    self.driver.click_in_frame(
                        fr,
                        float(info.get("x") or 0) + float(info.get("w") or 0) / 2,
                        float(info.get("y") or 0) + float(info.get("h") or 0) / 2)
                except Exception:
                    return False

            for _ in range(8):                 # 最多等 ~4 秒让内容换过来
                time.sleep(0.5)
                if self._cx_tab_fingerprint() != before:
                    return True
        return False

    # 学习通页面顶部那排**全站导航**（不是本章栏目）。
    # 2026-10-23 用户日志：栏目条被读成「1.9 政策导读 / 目录 / 讨论 / 笔记 / 标注」，
    # 于是程序把「目录」「讨论」当栏目逐个点开，白跑 30 秒还在原地。
    # 栏目条是**本章内容**的分栏（视频/测验/课件/阅读…），出现这排导航就说明认错了。
    _CX_GLOBAL_NAV = {
        "目录", "讨论", "笔记", "标注", "更多", "资料", "公告", "通知",
        "作业", "考试", "成绩", "统计", "首页", "课程信息", "回到顶部",
    }

    def _cx_tabs_look_like_global_nav(self, texts: list[str]) -> bool:
        """这排"栏目"是不是全站导航？是的话不能按栏目条处理。"""
        norm = [re.sub(r"[\s\d.、（）()【】\[\]]+", "", str(t or ""))
                for t in texts]
        norm = [t for t in norm if t]
        if len(norm) < 2:
            return False
        hits = sum(1 for t in norm if t in self._CX_GLOBAL_NAV)
        return hits >= 2 and hits * 2 >= len(norm)

    def _is_chaoxing_tabs_course(self) -> bool:
        """当前页是不是学习通新版的「横向栏目」章节页。

        判据（全部满足才认，宁可漏认也不能抢走别的页面的处理权）：
          ① 有内容层 `#iframe`（栏目内容装在这里）
          ② **没有**老模板的标记（`.jobCount` / `.tabtags`）
             —— 老页面已经在上面那条路径里处理过了，这里只管新版
          ③ 页面上真的存在一条「横向栏目条」
             （≥2 条 + 栏目名命中；正好 2 条时要求两条都命中 ——
              真实页面里有「1 视频 / 2 章节测验」这种只有两条的版本）
        """
        try:
            has_iframe = bool(self.driver.page.evaluate(
                "() => document.querySelectorAll('#iframe').length"))
        except Exception:
            return False
        if not has_iframe:
            return False
        if self._cx_job_count() or self._cx_tabs():
            return False
        rows = self._cx_tab_rows()
        if not rows:
            return False
        items = rows[0].get("items") or []
        texts = [str(x.get("text") or "") for x in items]
        if self._cx_tabs_look_like_global_nav(texts):
            self.log("· 这一排像全站导航（目录/讨论/笔记/标注…），不当栏目条："
                     + " / ".join(texts))
            return False
        self.log("· 页面自检（学习通横向栏目）：栏目条 "
                 f"{len(items)} 条 —— "
                 + " / ".join(str(x.get("text") or "") for x in items))
        return True

    def _cx_find_next_across_tabs(self, items: list[dict]) -> dict | None:
        """在这一版页面里找「下一节」，找不到返回 None。

        ⚠ 为什么不能只按当前栏目找（2026-10-16 实测）：
          底部那个「下一节」是**跟着栏目内容一起渲染的** ——
          切到「3 学习视频」以后它就不在 DOM 里了，`_find_next()` 返回空，
          程序于是误判成"这门课刷到头了"：
              页面上没有「下一节」了，这门课刷到头了
              停止原因：已到最后一节
          但用户截图里能直接看到：本章导读那一版底部**有**「下一节」，
          学习视频那一版底部**没有**。

        做法：当前栏目先找一遍；没有就按栏目顺序逐个点回去再找，
        找到就返回并说明是在哪一栏找到的。
        """
        hits = self._find_next()
        if hits:
            return hits[0]
        for it in items:
            text = str(it.get("text") or "").strip()
            if not text:
                continue
            if not self._alive():
                return None
            if not self._cx_click_tab_text(text):
                continue
            time.sleep(1.0)
            self.driver.wait_for_load(extra_ms=400)
            hits = self._find_next()
            if hits:
                self.log(f"· 「下一节」在「{text}」这一栏里")
                return hits[0]
        return None

    def _cx_chapter_key(self) -> str:
        """这一章的身份。用来判断「是不是又回到了同一章」。

        ## 为什么要它（用户 2026-10-17 14:42 实测）

        学习通每一章的**栏目条都长一样**（`1视频 / 2章节测验`），
        所以拿"栏目指纹"判断"下一节有没有真的翻页"是不可靠的 ——
        实测那次就判成了"变了"，然后在**已完成的同一节**里无限重做。

        翻页一定会变的只有 URL 里的 `chapterId`，所以优先用它。
        拿不到才退回"栏目指纹 + 标题"。
        """
        try:
            u = self.driver.page.url or ""
        except Exception:
            u = ""
        m = re.search(r"chapterId=(\d+)", u)
        if m:
            return "cid:" + m.group(1)
        fp = ""
        try:
            fp = str(self._cx_tab_fingerprint() or "")
        except Exception:
            fp = ""
        title = ""
        try:
            got = self._titles()
            title = (got[0] if got else "").strip()
        except Exception:
            title = ""
        if fp or title:
            return f"fp:{fp}|{title}"
        return ""

    def _run_chaoxing_tabs_course(self, res: CourseResult, speed: float, mute: bool,
                                  max_items: int, t0: float) -> CourseResult:
        """学习通新版：按「横向栏目」逐条点开，本章过完点「下一节」。

        推进策略：
          1. 读出栏目条上的每一条（本章导读 / 目标与导学 / 学习视频 / …）
          2. 逐条点开：★ 带"视频"的那条排最前 —— 只有它是有进度的任务点
          3. 每条点开后等 `#iframe` 换内容，再在两层 iframe 里找 `<video>`
             有视频 → 播完；没视频（导读/课件/阅读）→ 直接跳过，不记成课时
          4. 本章栏目都点过 → 点底部「下一节」，回到 1
          5. 没有「下一节」或点了页面不再变化 → 停
        """
        self.log(f"目标倍速：{speed}×（会挑平台提供的、不超过它的最大值）")
        stalled = 0
        # ⚠ `next_stalled` 必须放在 `while` **外面**。
        #   原来写在循环体里（每轮 `= 0`），于是 `next_stalled >= 2`
        #   **永远不成立**，「连点两次没变化就停」那条分支是死代码
        #   —— 2026-10-17 14:42 在已完成的那一节里无限重做就是这么来的。
        next_stalled = 0
        # 已经处理过的章节（见 `_cx_chapter_key`）。
        # 第二次进同一章 = 「下一节」没真的翻页 → 直接停，别死循环。
        visited: set = set()
        # 目录兜底试过几次 —— 防止"点不动 → 又试 → 又点不动"的死循环
        cat_tries = 0

        while len(res.lessons) < max_items:
            if not self._alive():
                res.stopped_reason = "用户停止"
                break

            rows = self._cx_tab_rows()
            if not rows:
                res.stopped_reason = "页面上找不到「横向栏目条」（页面结构可能变了）"
                # 诊断埋点：停下时把"页面上到底有什么"记一笔，
                # 下一次拿到日志就能判断是页面改版还是判据漏了。
                try:
                    _d = self.driver.page.evaluate(
                        """() => ({
                            url: location.href.slice(0, 160),
                            iframes: document.querySelectorAll('iframe').length,
                            pos: document.querySelectorAll('.posCatalog_select').length,
                            chapters: document.querySelectorAll('.chapter_item').length,
                            videos: document.querySelectorAll('video').length,
                        })""") or {}
                except Exception:
                    _d = {}
                if _d:
                    self.log(f"· 停止时页面：{_d.get('url')}（框 {_d.get('iframes')} / "
                             f"目录项 {_d.get('pos')} / 章节 {_d.get('chapters')} / "
                             f"video {_d.get('videos')}）")
                break
            items = list(rows[0].get("items") or [])
            self.log("—— 本章栏目：" +
                     " / ".join(str(x.get("text") or "") for x in items) + " ——")

            # 章节标题只用来写日志。新版页面没有 `.chapter_item.active`
            # （`_cx_title()` 会返回空），所以退回通用的标题查找。
            chap = ""
            try:
                got = self._titles()
                chap = (got[0] if got else "").strip()
            except Exception:
                chap = ""

            # ★ 视频类排最前。栏目是按"导读 → 视频 → 测验 → 课件 → 阅读"
            #   排的，按页面顺序点会有很长一段没有视频，日志里看着像卡住。
            order = sorted(
                items,
                key=lambda x: 0 if re.search(r"视频|录像|微课", str(x.get("text") or "")) else 1,
            )

            # ★ 同一章第二次进来 = 「下一节」没真的翻页 → 停。
            #
            #   这条是**结构性**的：不管「下一节」是没点到、被禁用、
            #   还是已经是最后一节，都不会在已完成的那一节里无限重做。
            #   （2026-10-17 14:42 用户报的就是这个，最后手动停的。）
            _key = self._cx_chapter_key()
            if _key:
                if _key in visited:
                    # ★ 「又回到同一章」是**确定**信号（比栏目指纹可靠）。
                    #   先试目录兜底，再决定要不要停。
                    #
                    #   ⚠ 2026-10-17 17:18 实测：上一版把兜底放在
                    #     `_cx_tab_fingerprint() == before` 那个分支里，
                    #     而那一次指纹**变了**（页面上多了一个"已完成"角标）
                    #     → 兜底被跳过 → 直接撞上这里就停了。
                    if cat_tries < 2:
                        cat_tries += 1
                        _cat = self._cx_click_next_in_catalog()
                        if _cat:
                            self.log(f"⚠ 又回到同一章（{_key}）—— "
                                     f"改走目录：{_cat}")
                            time.sleep(2.0)
                            self.driver.wait_for_load(extra_ms=800)
                            continue
                        self.log(f"⚠ 又回到同一章（{_key}），"
                                 f"目录里也找不到下一条")
                    res.stopped_reason = ("又回到了同一章"
                                          "（「下一节」和目录都没能翻页）")
                    self.log(f"⚠ 又回到同一章（{_key}）——停下来，不再重做")
                    break
                visited.add(_key)

            moved = False
            for it in order:
                if not self._alive() or len(res.lessons) >= max_items:
                    break
                text = str(it.get("text") or "").strip()
                if not text:
                    continue
                self.log(f"—— 点开栏目：{text} ——")
                pages_before: list = []
                try:
                    pages_before = list(self.driver.context.pages)
                except Exception:
                    pages_before = []
                if not self._cx_click_tab_text(text):
                    self.log("· ⚠ 这一条点了页面没反应，跳过")
                    continue
                time.sleep(1.0)
                self.driver.wait_for_load(extra_ms=600)

                is_video_tab = bool(re.search(r"视频|录像|微课", text))

                # ★★ 已经看完的视频**不要再播一遍**（用户 2026-10-17 要求）：
                #    "看过的视频还看，如果遇到看完的视频应该直接检查对应章节测验"
                #
                #    判据用**平台自己打的角标** `.ans-job-finished`，
                #    不用 `video.currentTime` —— 平台重新打开时常把播放位置重置。
                #
                #    ⚠⚠ 2026-10-23 修正：原来用的是 `_cx_finished()`，
                #      它数的是**本章所有**已完成任务点。同一章里测验做完了、
                #      视频没做时，那个数也 > 0 → 视频被误判成"已完成"直接
                #      跳过（用户日志 03:02「已标记完成（1 个）→ 跳过播放」，
                #      接着整章 0 节，用户看到的就是"总是有几节被跳过"）。
                #      现在只认**视频任务点**自己的角标，并且只读
                #      "当前这一章的 cards 层"（旧帧里的角标不算数）。
                if is_video_tab:
                    time.sleep(1.2)          # 等这一栏的内容真的加载出来
                    vdone = self._cx_video_job_done()
                    if vdone is None:
                        # 认不出"视频任务点"结构 → 退回旧判据，但说清楚
                        try:
                            done_n = self._cx_finished()
                        except Exception:
                            done_n = 0
                        if done_n > 0:
                            self.log(f"  · 这一栏已标记完成（已完成任务点 {done_n} 个，"
                                     f"回退判据）→ 跳过播放，直接去看后面的测验")
                            continue
                    elif vdone:
                        self.log("  · 这一栏的**视频任务点**已完成 → "
                                 "跳过播放，直接去看后面的测验")
                        continue

                    # ★ 一个任务点里可能挂着好几个视频（2026-10-23 用户：
                    #   「学习通同一个任务点只看第一个视频」）→ 逐个播完。
                    #   只有在页面上真能找到"视频任务点"结构时才接管；
                    #   老结构（认不出 .ans-attach-ct）原样走下面的通用处理。
                    if self._cx_video_points():
                        n_v = self._cx_play_chapter_videos(
                            res, speed, mute,
                            f"{chap or self._cx_title()} · {text}".strip(" ·"))
                        if n_v:
                            moved = True
                            continue

                # ★ 「章节测验」这一栏是**一整份卷子** ——
                #   不能当文档跳过，否则这一章的测验永远不做完，
                #   学习通会认为整章没学完，后面的章节也可能不放行。
                if (not is_video_tab) and _QUIZ_TAB_RE.search(text):
                    if self._cx_answer_chapter_quiz(text, pages_before):
                        moved = True
                        continue          # 卷子处理过了，别再当文档走一遍
                r = self._cx_handle_current(
                    speed, mute, f"{chap or self._cx_title()} · {text}".strip(" ·"),
                    int(it.get("i") or 0),
                    record_doc=False,
                    video_wait=20.0 if is_video_tab else 3.0,
                )
                if r is not None:
                    res.lessons.append(r)
                    moved = True

            if len(res.lessons) >= max_items:
                break

            if moved:
                stalled = 0
                # ⚠ 注意：**不要**在这里清 `next_stalled`。
                #   原来是共用一个 `stalled`，答完测验 moved=True 就清零，
                #   于是「下一节」点不动永远攒不到 3 次 →
                #   同一章被反复重做（用户 2026-10-17 13:06 就是手动停的）。
                #   两个计数各管各的：这个只管"下一节有没有把章节换掉"。
            else:
                stalled += 1
                self.log(f"⚠ 这一章没找到可播视频（连续 {stalled} 次）")

            # ★ 用户已经点了停止 / 浏览器已经关了 → **别再动页面**。
            #
            #   2026-10-17 13:23 实测：停止之后这里继续点「下一节」，
            #   撞上已被回收的浏览器，抛 TargetClosedError，
            #   把一次正常的停止记成了 ok:false + 一串原始异常。
            #   上面"逐条点栏目"那个循环里有 `_alive()`，这里漏了。
            if not self._alive():
                res.stopped_reason = res.stopped_reason or "用户停止"
                break

            # ---- 本章过完 → 下一节 ----
            nxt = self._cx_find_next_across_tabs(items)
            if not nxt:
                self.log("✔ 整个页面上都没有「下一节」了，这门课刷到头了")
                res.stopped_reason = "已到最后一节"
                break
            # ★ 指纹要在**找完按钮之后**取：找按钮的过程可能切过栏目，
            #   拿切换前的指纹去比，会把"下一页真的换了"判成"没变化"。
            before = self._cx_tab_fingerprint()
            self.log(f"· 点「{nxt.get('text')}」进入下一节")
            if not self._click_next(nxt):
                res.stopped_reason = "「下一节」点不动（页面结构可能变了）"
                break
            time.sleep(2.0)
            self.driver.wait_for_load(extra_ms=800)
            if self._cx_tab_fingerprint() == before:
                next_stalled += 1
                self.log(f"⚠ 点完「下一节」页面没变化（连续 {next_stalled} 次）")
                # ★ 先试**目录兜底**：右侧章节列表里点下一条。
                #   用户 2026-10-17 16:03「这不是最后一节」——
                #   「下一节」点不动，但目录里还有第五、六章。
                _cat = self._cx_click_next_in_catalog()
                if _cat:
                    self.log(f"    · 改走目录：{_cat}")
                    time.sleep(2.0)
                    self.driver.wait_for_load(extra_ms=800)
                    continue
                if next_stalled >= 2:
                    # ⚠ 别再说"多半已经是最后一节"了。
                    #   2026-10-17 16:03 用户截图：四章之后还有第五、六章，
                    #   但日志写的是"多半已经是最后一节" —— 结论错了，用户一眼就看出来了。
                    #   实际上只能说"「下一节」点了没反应"，不能推断是最后一节。
                    res.stopped_reason = ("「下一节」连点 {0} 次页面都没变化"
                                          "（按钮可能被禁用，也可能页面结构变了；"
                                          "已试过从右侧目录点下一条）").format(next_stalled)
                    break
            else:
                next_stalled = 0

        res.ok = len(res.lessons) > 0
        self.log("")
        self.log(f"===== 刷课结束：共 {len(res.lessons)} 节，"
                 f"{sum(1 for x in res.lessons if x.finished)} 节播完，"
                 f"用时 {time.time() - t0:.0f} 秒 =====")
        if res.stopped_reason:
            self.log(f"停止原因：{res.stopped_reason}")
        # 章节测验的份数单独报一行 —— 只在**答过**的时候报，
        # 没答过测验的课不该多一行「章节测验 0 份」。
        if self.chapter_quiz_done or self.chapter_quiz_failed:
            # ★ 按**真实结局**说，不按开关说。
            #   （2026-10-17 17:18：上一行刚说"没确认交上"，
            #    这一行却报"已交卷"—— 自相矛盾）
            if getattr(self, "last_quiz_blocked", False):
                how = "⚠ 被验证码拦住，未交卷"
            elif getattr(self, "last_quiz_submitted", False):
                how = "已交卷"
            elif self.quiz_submit:
                how = "⚠ 答完了但没确认交上，请手动检查"
            else:
                how = "已填好、未交卷"
            tail = (f"，{self.chapter_quiz_failed} 份没答成"
                    if self.chapter_quiz_failed else "")
            self.log(f"· 章节测验：{self.chapter_quiz_done} 份答完{tail}（{how}）")
        return res

    # 兼容旧名字（代码里可能还有历史调用点；保留别名比逐个改安全）
    _is_ai_course = _is_resource_card_course

    def _ai_counts(self) -> dict:
        """各关键选择器的命中数（诊断用）。"""
        try:
            return self.driver.page.evaluate(
                """(sel) => {
                    const out = {};
                    ['topic','card','detail_container','detail_title',
                     'card_done','card_pages','module_head','progress_text']
                      .forEach(function (k) {
                        try { out[k] = document.querySelectorAll(sel[k]).length; }
                        catch (e) { out[k] = 'ERR'; }
                    });
                    return out;
                }""", AI_SELECTORS) or {}
        except Exception:
            return {}

    def _ai_scan(self) -> dict:
        """读 AI 版课程页的目录 / 资源卡片 / 播放器状态。"""
        for fr in self._frames():
            try:
                r = fr.evaluate(_AI_SCAN_JS, AI_SELECTORS)
            except Exception:
                continue
            if r and r.get("isAI"):
                r["_frame"] = fr
                return r
        return {"isAI": False}

    # 课中弹题的判据。集中放在类属性里，方便：
    #   ① 一处增删（网页改版时只改这里）
    #   ② 命中时能报出"是哪一条命中的"，误判好排查
    #
    # 来源：开源调研（Autovisor / OCS）列出的各代弹题 DOM。
    # 注意分两档：强判据（命中即算）和弱判据（必须**真的带选项**才算，
    # 否则会把普通提示框误判成弹题、白白暂停视频）。
    # ★ 分两档，判据是"**这个名字是不是只可能是弹题**"。
    #
    # ⚠ 踩过的坑：`.topic-title` 原来在 STRONG 里（命中即算、不看选项），
    #   但**智慧树的 "topic" 同时也是"章节"** —— 课程页把章节名渲染成
    #   可见的 `.topic-title` 时会被当成弹题。
    #   后果不是"多等一下"，而是：
    #     暂停视频 → 等 15 分钟 → reason="课中弹题等待超时（可能误判）" → **整节跳过**。
    #
    #   而**弹题一定带选项** —— 这比任何 CSS 类名都硬。
    #   所以把"标题/通用容器型"的名字挪进 _QUIZ_TITLE，要求它附近真的有选项。
    _QUIZ_STRONG = (
        ".ai-test-question-wrapper",    # 智慧树新版 AI 弹题（名字唯一指向弹题）
        ".ai-class-exercise-dialog",    # 智慧树 AI 课堂练习
        "#playTopic-dialog",            # 老版弹题对话框外层
        # ⚠ 这里**只放容器**。`.ans-videoquiz-opt` 是**选项**（每个选项一个），
        #   放进来会先命中选项：sel 被当成容器 → 在选项内部再找选项 → 0 个；
        #   title 还会取成"第一个选项的文字"（用户 2026-10-17 日志里那句
        #   "A、它是一个单一的…"其实是选项 A，不是题干）。它属于 _QUIZ_OPTION。
        ".ans-videoquiz-box",           # 超星视频内弹题容器
        # 万一这一版换了容器类名，多留几条同类候选 ——
        # 命中会在日志里打出具体是哪条（`判据 xxx`），方便排障。
        ".ans-videoquiz", "#videoquiz-box", ".videoquiz-box",
    )
    # 标题 / 通用容器型判据：**必须在本元素或上溯 3 层内找到 ≥2 个选项**才算。
    # `.topic-title` 是智慧树弹题题面，但"topic"也是章节 —— 靠选项区分。
    # `.ss2077-custom-dialog` 是通用弹层名，同理。
    _QUIZ_TITLE = (
        ".topic-title",                 # 智慧树课中弹题题面（★ 与章节标题同名）
        ".ss2077-custom-dialog",        # 部分版本的自定义弹层
        # ⚠ **不要把** `.ans-videoquiz-tit` / `-title` / `-topic` 加进来。
        #   那几条是**题面**。`_quiz_probe` 的 JS 是"先查标题型、再查强判据"，
        #   加了之后 sel 会指到题面，而 `_auto_answer_quiz()` 把 sel 当**容器**
        #   传给 `answer_quiz()` → 在题面里找选项 → 一个都找不到。
        #   （实测：加了以后 sel = '.ans-videoquiz-tit'。方案 §3.2② 这一条是错的。）
        #   容器由 `_QUIZ_STRONG` 负责认，那边已经补了同类候选。
    )
    # 一页里出现这么多可见的同名标题元素 → 那是**列表**（章节表），不是一道题。
    _QUIZ_TITLE_LIST_MIN = 3
    _QUIZ_WEAK = (
        # 弱判据：常见的通用弹层，必须带 ≥2 个选项才算弹题
        ".el-dialog", ".vjs-modal-dialog", ".layui-layer",
        "[role=dialog]", ".modal", ".ant-modal",
    )
    # 弱判据下方的"选项"候选
    _QUIZ_OPTION = (
        # ★ `... li` 在容器前面，理由见 `videoquiz.OPTION_SELS` 那段注释：
        #   学习通的 `.ans-videoquiz-opt` 是**选项列表的 UL**，不是单个选项。
        #   只数它的话永远是 1 个 → 判"没有选项"。
        ".ans-videoquiz-opt > li", ".ans-videoquiz-opt li",
        ".ans-videoquiz-box li",
        ".topic-item", ".ans-videoquiz-opt", ".el-radio",
        ".answer-item", ".option-item", ".ai-answer-item", ".ai-option-item",
        "input[type=radio]",
        "input[type=checkbox]", ".option", ".choice",
        "label", ".opt")

    def _quiz_probe(self) -> dict:
        """探测课中弹题，返回详细信息（而不是光一个 bool）。

        返回 `{found, sel, frame, opts, weak}`：
          · `sel`   命中的选择器（排查误判时最关键）
          · `frame` 在哪个框架里命中的
          · `opts`  看到几个选项
          · `weak`  是不是靠弱判据命中的

        ⚠ 两处原来都写错了，这里一并修正：
          ① **只在顶层文档找** —— `page.evaluate()` 不穿透 iframe。
             而超星/学习通的弹题就在播放器那层 iframe 里，
             于是"课中弹题"这个功能对它们**等于没实现**。
          ② 判据覆盖不全 —— 只有老版两条选择器，新版 AI 弹题
             （`.ai-test-question-wrapper` 等）完全没认。
        """
        strong = list(self._QUIZ_STRONG)
        titles = list(self._QUIZ_TITLE)
        list_min = int(self._QUIZ_TITLE_LIST_MIN)
        weak = list(self._QUIZ_WEAK)
        opts = list(self._QUIZ_OPTION)
        # ⚠ 必须是 **raw 字符串**：里面有 JS 正则的 \\s，
        #   非 raw 的 """ 会触发 SyntaxWarning: invalid escape sequence。
        js = r"""(args) => {
            const [strong, titles, listMin, weak, opts] = args;
            function visible(e) {
                if (!e) return false;
                const s = getComputedStyle(e);
                const r = e.getBoundingClientRect();
                return s.display !== 'none' && s.visibility !== 'hidden'
                    && parseFloat(s.opacity || '1') > 0.05
                    && r.width > 0 && r.height > 0;
            }
            function textOf(e) {
                return (e.innerText || e.textContent || '')
                    .replace(/\s+/g, ' ').trim().slice(0, 60);
            }
            // 在 e 自身 + 上溯 levels 层内数选项。
            // 为什么上溯：弹题的选项通常是**题面的兄弟**（题面 .topic-title
            // 和选项 .el-radio 一起装在 .el-dialog 里），不在题面内部。
            function optCount(e, levels) {
                // ⚠ 必须**按元素去重**再计数。
                //   opts 里有多条互相重叠（.ans-videoquiz-opt > li /
                //   .ans-videoquiz-opt li / .ans-videoquiz-box li 命中的
                //   是同样几个 li），逐条累加会把 2 个选项数成 7 个。
                //   日志里的「选项 N 个」是排障的第一手信息，虚高会误导。
                let n = e, hops = 0;
                while (n && hops <= levels) {
                    const seen = new Set();
                    for (const o of opts) {
                        try {
                            n.querySelectorAll(o).forEach(function (x) { seen.add(x); });
                        } catch (err) {}
                    }
                    if (seen.size >= 2) return seen.size;
                    n = n.parentElement; hops++;
                }
                return 0;
            }
            // ① 标题型判据：**必须真的有选项**，并且不能是"一列标题"
            for (const sel of titles) {
                let list = [];
                try { list = document.querySelectorAll(sel); } catch (e) { continue; }
                const vis = [];
                for (const e of list) { if (visible(e)) vis.push(e); }
                // 章节列表护栏：一页里好几个同名可见标题 → 那是目录，不是题
                if (vis.length >= listMin) continue;
                for (const e of vis) {
                    const c = optCount(e, 3);
                    if (c >= 2) {
                        return { found: true, sel: sel, opts: c, weak: false,
                                 title: textOf(e) };
                    }
                }
            }
            // ② 强判据（名字唯一指向弹题的容器）：命中即算
            for (const sel of strong) {
                let list = [];
                try { list = document.querySelectorAll(sel); } catch (e) { continue; }
                for (const e of list) {
                    if (visible(e)) {
                        // 顺手把选项数出来：光给 -1 的话，日志里只能看到
                        // 「选项 -1 个」，分不清"结构不同"还是"根本没选项"。
                        const c = optCount(e, 1);
                        return { found: true, sel: sel,
                                 opts: (c >= 2 ? c : -1), weak: false,
                                 title: textOf(e) };
                    }
                }
            }
            // ② 弱判据：必须真的带 ≥2 个选项
            for (const sel of weak) {
                let list = [];
                try { list = document.querySelectorAll(sel); } catch (e) { continue; }
                for (const e of list) {
                    if (!visible(e)) continue;
                    let n = 0;
                    for (const o of opts) {
                        try { n += e.querySelectorAll(o).length; } catch (err) {}
                    }
                    if (n >= 2) return { found: true, sel: sel,
                                         opts: n, weak: true,
                                         title: textOf(e) };
                }
            }
            return { found: false, sel: "", opts: 0, weak: false };
        }"""
        for fr in self._frames():
            try:
                r = fr.evaluate(js, [strong, titles, list_min, weak, opts])
            except Exception:
                continue
            if r and r.get("found"):
                r["frame"] = fr
                try:
                    r["frame_url"] = (fr.url or "")[:80]
                except Exception:
                    r["frame_url"] = ""
                return r
        return {"found": False, "sel": "", "opts": 0, "weak": False}

    def _ai_quiz_visible(self) -> bool:
        """页面上是不是弹出了"课中弹题"（答完才能继续播的那种）。

        判据见 `_QUIZ_STRONG` / `_QUIZ_WEAK`；**会遍历所有 iframe**。
        """
        try:
            return bool(self._quiz_probe().get("found"))
        except Exception:
            return False

    def _quiz_settled(self) -> bool:
        """弹题是否已经放行：**只认弹层消失**。

        ⚠ 不能拿“视频在走”当成已答完：智慧树这版弹题弹出来时视频
          仍然在播（paused=False），如果据此返回成功，就会跳过点「关闭」，
          弹层一直挂在上面，主循环白等。
        """
        try:
            if not self._ai_quiz_visible():
                return True
        except Exception:
            pass
        now = time.time()
        if now - getattr(self, "_quiz_click_at", 0.0) >= 0.8:
            self._quiz_click_at = now
            got = ""
            try:
                got = self._cx_click_continue()
            except Exception:
                got = ""
            if not got:
                # 智慧树 AI 助教这版没有「继续学习」，是「关闭」。
                try:
                    got = self._click_quiz_close()
                except Exception:
                    got = ""
        return False

    def _auto_answer_quiz(self, probe: dict) -> bool:
        """尝试自动答掉当前这道课中弹题。返回是否成功落笔。

        ⚠ **任何失败都必须让调用方回退到"等用户手动答"** ——
          这是这个功能的安全底线：宁可没答，也不能卡住或点错。
        """
        if not self.auto_quiz:
            return False
        if self.client is None:
            # 开关开着但没有模型客户端（没配 API Key）→ 说清楚，别静默
            self.log("    （已开启自动作答，但没有可用的模型客户端 ——"
                     "请先在设置里填 API Key；本次改为等你手动答）")
            return False
        frame = probe.get("frame")
        sel = probe.get("sel") or ""
        if frame is None or not sel:
            return False
        try:
            from .videoquiz import answer_quiz
            # 有 driver 才等“视频真的继续”；测试里用 __new__ 造的对象没有 driver，
            # 传 None 就保持旧行为（点完就返回）。
            has_driver = bool(getattr(self, "driver", None))
            is_done = self._quiz_settled if has_driver else None
            # ★ 「答对了」也要能认出来：否则关闭没点上时，会被当成答错
            #   一路换 B/C/D，把对的答案改掉（2026-10-23 真机日志 14:14）。
            is_accepted = self._quiz_looks_correct if has_driver else None
            ok, note = answer_quiz(
                self.client, frame, sel,
                log=lambda s: self.log(s),
                is_done=is_done,
                is_accepted=is_accepted,
            )
        except Exception as e:
            # 自动作答属于"锦上添花"，它自己出错绝不能影响刷课
            self.log(f"    ✘ 自动作答异常（{type(e).__name__}: {str(e)[:60]}）"
                     f"—— 交给你手动答")
            self.quiz_failed += 1
            return False
        if ok:
            self.quiz_answered += 1
            self.log(f"    ✔ 已自动作答：{note}")
            # ★ 答完不是自动继续：会弹出「恭喜你，答对了！」的结果层，
            #   必须点「继续学习」视频才会接着播（用户 2026-10-17 14:16 截图）。
            #   这里立刻点一次；`_wait_quiz_done()` 的轮询里还会补点
            #   （结果层可能是判分后才渲染的，这会儿可能还没有）。
            time.sleep(0.6)
            try:
                _c = self._cx_click_continue()
            except Exception:
                _c = ""
            if _c:
                self.log(f"      · 已点「{_c}」继续")
        else:
            self.quiz_failed += 1
            if "此前已作答" in str(note):
                # 不是失败：这道题早就答过了，只是弹层还挂着。别写成 ✘。
                self.quiz_failed -= 1
                self.log(f"    · {note}")
                # ★ 复盘态：选项是禁用的，再点也没用；而**反复点「关闭」**
                #   正是最像机器人的动作（2026-10-23 14:31 真机：连点三次「关闭」
                #   之后 4 秒，平台就弹了「检测到异常脚本」）。
                #   所以这一题只点一次，之后纯等待。
                self._quiz_already_answered = True
            else:
                self.log(f"    ✘ 没答上：{note}")
        return ok

    _ANTI_CHEAT_JS = r"""
    () => {
      // 只在"页面可见文字"里找，不去翻 <script>/注释（那里全是文案）
      try {
        const t = (document.body && (document.body.innerText || '')) || '';
        const hit = t.indexOf('检测到异常脚本') >= 0
                 || t.indexOf('关闭插件') >= 0
                 || t.indexOf('异常脚本') >= 0;
        if (!hit) return '';
        // 把命中的那一段抓出来（最多 60 字），日志里能看清是哪个平台的提示
        const i = Math.max(0, t.indexOf('异常脚本') - 20);
        return t.slice(i, i + 60).replace(/\s+/g, ' ').trim();
      } catch (e) { return ''; }
    }
    """

    def _detect_anti_cheat(self) -> str:
        """平台反作弊弹窗（「检测到异常脚本」）出现了没有。返回命中文字。

        ## 为什么要专门认这一句

        2026-10-23 智慧树真机：自动答完课中弹题后，平台盖上
        「检测到异常脚本，为保证您的正常学习进度，请您关闭插件后，
        回到学堂重新进入视频学习页正常学习」。

        这一页从这一刻起**不会再记进度** —— 继续跑既浪费时间，
        又可能让账号的风险更高。所以一旦认出来就如实停下，
        并且把"该怎么恢复"写进停止原因里。

        代价：每轮多一次 `evaluate`（毫秒级，且在已有 probe 旁边，可接受）。
        """
        try:
            txt = self._eval_all_frames(self._ANTI_CHEAT_JS) or ""
            return str(txt).strip()
        except Exception:
            return ""

    def _eval_all_frames(self, js: str) -> str:
        """在页面的所有框架里跑一段 JS，返回第一个非空结果。"""
        try:
            page = getattr(self.driver, "page", None)
            if page is None:
                return ""
            for fr in page.frames:
                try:
                    r = fr.evaluate(js)
                except Exception:
                    continue
                if r:
                    return str(r)
        except Exception:
            pass
        return ""

    def _handle_video_quiz(self, speed: float) -> tuple[bool, str]:
        """主循环里"遇到课中弹题就答一次"。返回 `(是否处理过, 结束原因)`。

        结束原因：`""`（正常，继续播）/ `"stopped"` / `"timeout"`。

        ⚠ 为什么要抽成独立方法（2026-10-23 智慧树真机）：
          弹题处理原来**只写在 `_ai_play_video()` 里**，而智慧树这门课走的是
          **通用播放器模式** —— 那条循环从来没检查过弹题。于是弹窗挂在页面
          上、平台把视频按停，日志里只有
              · 进度卡在 508s 超过 45 秒，尝试重新起播…
          一直耗到平台结算（98%）就切走了，弹题一次都没答。
        """
        try:
            if not self._ai_quiz_visible():
                return False, ""
        except Exception:
            return False, ""

        self.quiz_seen = int(getattr(self, "quiz_seen", 0)) + 1
        probe = self._quiz_probe()
        self.log(f"  · 遇到课中弹题（第 {self.quiz_seen} 次）——"
                 + ("尝试自动作答…" if (self.auto_quiz and self.client)
                    else "已暂停等待，请手动答完，答完会自动继续播放"))
        self.log(f"    （判据 {probe.get('sel')}"
                 f"{'，弱判据' if probe.get('weak') else ''}"
                 f"，选项 {probe.get('opts')} 个，"
                 f"框架 {probe.get('frame_url') or '主文档'}）")
        if probe.get("title"):
            self.log(f"    题目文字：{probe.get('title')}")

        # 每道题单独计：这些标记只用来"打一次日志"，别串到下一题
        self._quiz_close_logged = False
        self._quiz_diag_logged = False
        self._quiz_close_tries = 0
        self._quiz_already_answered = False

        # ★ 弹出来就"秒答"是最扎眼的特征之一（人至少要看几秒题）。
        #   2026-10-23 14:3x 用户截图：智慧树弹「检测到异常脚本」，
        #   时间点正是自动答完课中弹题之后。这里先停顿 1.2~2.6 秒再动，
        #   点击本身也改成真实鼠标优先（见 videoquiz.click_option）。
        if self.auto_quiz and self.client:
            _pause = random.uniform(1.2, 2.6)
            self.log(f"  · 停顿 {_pause:.1f} 秒再作答（避免「弹出来就秒答」这种机器特征）")
            time.sleep(_pause)

        self._auto_answer_quiz(probe)
        self.status(f"等待课中弹题作答…（最多等 "
                    f"{config.COURSE_QUIZ_MAX_WAIT_MIN:.0f} 分钟）")
        spent, why = self._wait_quiz_done()
        self.quiz_waited = float(getattr(self, "quiz_waited", 0.0)) + spent

        if why == "timeout":
            self.log(f"  ✘ 弹题等待超过 {config.COURSE_QUIZ_MAX_WAIT_MIN:.0f} 分钟仍未消失，"
                     f"可能判据误命中了 —— 本条跳过")
            self.log(f"    命中的判据是 {probe.get('sel')}，可以据此判断是不是误判")
            return True, why
        if why == "answered":
            self.log(f"  · 弹题已消失（等了 {spent:.0f} 秒），继续播放")
            # 答完平台常把视频按停：补一次倍速 + 主动起播。
            # ⚠ 倍速用**平台实际允许的那个**（`_rate_actual`），不是用户想要的值 ——
            #   这一版播放器「任务点未完成前不许倍速」，每塞一次就再暂停一次。
            try:
                self._set_video_rate(float(getattr(self, "_rate_actual", 0) or speed))
            except Exception:
                pass
            try:
                if not self._resume_after_quiz():
                    self.log("    · 仍未继续播放，主循环会继续尝试")
            except Exception:
                pass
        return True, why

    def _wait_quiz_done(self, *, poll: float | None = None) -> tuple[float, str]:
        """等课中弹题消失。返回 `(等了多久, 结束原因)`。

        ⚠ 必须有硬上限（原实现没有）：
          判据是启发式的，一旦命中一个**永远不消失**的元素，
          `while visible(): sleep()` 就是个死循环 —— 刷课永久卡住，
          用户只能手动点停止。这类"静默卡死"比报错难排查得多。

        结束原因取值：
          · `"answered"` 弹题消失（正常，用户答完了）
          · `"timeout"`  超过 `COURSE_QUIZ_MAX_WAIT_MIN` 分钟
          · `"stopped"`  用户点了停止
        """
        if poll is None:
            poll = config.COURSE_QUIZ_POLL_SEC
        limit = config.COURSE_QUIZ_MAX_WAIT_MIN * 60
        t0 = time.time()
        clicks = 0
        while True:
            if not self._alive():
                return time.time() - t0, "stopped"
            if not self._ai_quiz_visible():
                return time.time() - t0, "answered"
            if time.time() - t0 > limit:
                return time.time() - t0, "timeout"
            # ★ 每轮都补点一次「继续学习」。
            #
            #   只在上面的 `_auto_answer_quiz()` 里点一次是不够的：
            #   结果层（"恭喜你，答对了！"+[继续学习]）是**判分之后**才渲染的，
            #   答完那一瞬间页面上还没有它。所以这里要一直补，
            #   直到弹题层消失（`_ai_quiz_visible()` 为假）为止。
            #   上限 20 次，避免判据误命中时无限点击。
            if clicks < (1 if getattr(self, "_quiz_already_answered", False) else 20):
                try:
                    got = self._cx_click_continue()
                except Exception:
                    got = ""
                if not got:
                    # 智慧树 AI 助教这版没有「继续学习」，只有「关闭」。
                    # ⚠ 2026-10-23 实测：这里原来只点「继续学习」，
                    #   于是多选答错（不轮选）时**永远关不掉**，
                    #   只能干等 15 分钟超时。
                    try:
                        got = self._click_quiz_close()
                    except Exception:
                        got = ""
                if got:
                    clicks += 1
                    self.log(f"      · 已点「{got}」继续（第 {clicks} 次）")
            time.sleep(poll)

    def _video_frame(self):
        """当前视频所在的框架（没找到就返回主框架）。

        ⚠ 为什么必须有这个：`self.driver.page.evaluate()` **只在顶层文档执行**。
          学习通/超星的播放器在**第 2 层 iframe** 里（#iframe → .ans-attach-ct
          → iframe → video），在顶层跑设置倍速/起播的 JS 等于**什么都没做** ——
          实测表现就是"日志说已设为 1.5×，实际仍是 1×、进度 0 秒不动"。
          所以凡是碰播放器的操作，都要落到这个框架上执行。
        """
        try:
            p = self._probe()
            if p.get("found") and p.get("_frame") is not None:
                return p["_frame"]
        except Exception:
            pass
        try:
            s = self._ai_scan()
            if s.get("video", {}).get("found") and s.get("_frame") is not None:
                return s["_frame"]
        except Exception:
            pass
        return self.driver.page.main_frame

    def _set_video_rate(self, rate: float) -> float:
        """给播放器设静音 + 倍速 + 起播，回读实际倍速。

        AI 版播放器带 `vjs-controls-disabled`（没有倍速菜单），
        只能直接改 playbackRate，所以这里必须**自己钳到平台上限**，
        否则设的值会被播放器内核改回去（用户实测智慧树最高 1.5×）。

        ⚠ 改动记录：原来固定用 `self.driver.page.evaluate`，只在顶层执行。
          对智慧树 AI 版（video 在顶层）没问题，但学习通的 video 在
          **两层 iframe** 里 —— 那行 JS 完全没碰到视频，于是"日志说设好了、
          实际倍速还是 1×"。现在改成**在视频所在框架里执行**。
        """
        want = min(float(rate or 1), config.COURSE_MAX_SPEED)
        frame = self._video_frame()
        res = {}
        try:
            res = frame.evaluate(_AI_VIDEO_JS, [want, True]) or {}
        except Exception:
            # 万一那个框架正好被换掉（detached），退回顶层再试一次
            try:
                res = self.driver.page.evaluate(_AI_VIDEO_JS, [want, True]) or {}
            except Exception:
                pass
        time.sleep(0.35)
        v = self._any_video()
        real = float(v.get("rate") or 0) if v.get("found") else 0.0
        if real and abs(real - want) > 0.05:
            self.log(f"· 平台把倍速改成了 {real}×（请求 {want}×）")
        # 把"界面上倍速标签有没有同步改掉"也记下来 ——
        # 否则实际已经加速、但用户看界面还以为没开倍速。
        if res.get("labelUpdated"):
            self.log(f"· 播放器倍速标签已同步为 X {want}")
        return real or want

    def _any_video(self) -> dict:
        """拿当前正在播的视频状态 —— **跨两类课程页通用**。

        ⚠ 为什么要抽这个函数（真踩过）：
          `_ai_play_video` 原来直接调 `_ai_scan()`，而那是**智慧树 AI 版
          专用**的扫描（要靠它的资源卡片结构才认）。换成学习通这类页面时
          `_ai_scan` 一律返回 `isAI:False`，于是**明明页面上有 video 也报
          "找不到可播放的 <video>"** —— 实测日志就长这样：
              [等视频 1] alive=True found=True dur=600   ← 通用探测找到了
              ⚠ 打不开视频：页面上找不到可播放的 <video>   ← 播放逻辑却没找到
          现在统一走"先通用探测、再退回 AI 版扫描"，两条路都能用。

        ★ 2026-10-23 新增 `_video_frame_hint`：学习通**一个任务点里可能挂着
          好几个视频**，通用探测只会挑"面积最大"的那个 —— 于是永远只播第一个。
          指定 hint 后，只认那个框架里的 video（没加载好就返回 found=False，
          让调用方等它，而不是退回全局乱挑）。
        """
        hint = getattr(self, "_video_frame_hint", None)
        if hint is not None:
            try:
                r = hint.evaluate(_PROBE_JS) or {}
            except Exception:
                r = {}
            if r.get("found"):
                r["_frame"] = hint
                return r
            # ⚠ 不退回全局：否则会把"别的视频"当成当前这个，重复播放同一段
            return {"found": False}

        # ① 通用探测：任意框架里最大的那个可见 video
        p = self._probe()
        if p.get("found"):
            return p
        # ② 退回 AI 版课程页的扫描（它带 currentSrc 等信息，判"换视频"更准）
        try:
            s = self._ai_scan()
            v = s.get("video") or {}
            if v.get("found"):
                return v
        except Exception:
            pass
        return {"found": False}

    def _ai_play_video(self, speed: float, mute: bool, label: str,
                       prev_percent: int | None = None,
                       prev_src: str = "",
                       card_dur: float = 0.0) -> LessonResult:
        """把当前打开的视频看到底。"""
        t_start = time.time()
        cur = dur = 0.0
        finished = False
        rate_used = 0.0
        waited = 0.0
        last_pos = -1.0
        stalled = 0.0
        last_report = 0.0
        last_rate_check = 0.0
        near_done_since = 0.0      # 首次进入"接近播完(≥98%)"的时刻，0=还没到
        reason = ""

        # 等视频就绪（元数据可能还没加载）。
        #
        # ⚠ 这里有个隐蔽的坑，真实日志抓到的：
        #     15:21:13 · 打开视频：机器学习核心范式（00:02:30）   ← 卡片 150 秒
        #     15:21:15 · 视频时长 363 秒（06:02）                ← 读成了**上一条**的时长！
        #     15:21:46   · 播放中 45s/151s（30%）                ← 45 秒后才读到真值
        #   原因：判据只有 `duration > 0`，而**上一条视频的 duration 也 > 0**，
        #   于是新播放器还没加载就被当成"已就绪"，读到了残留时长。
        #   后果：等待上限算错（363 秒 vs 150 秒），而且日志会误导排查。
        #   修法：连同 **视频地址** 和 **播放位置** 一起判断，
        #   只有地址变了（或位置归零）才算真的换成了新视频。
        # ⚠ 这里的 prev_src 必须由**调用方在点击之前**传进来。
        #   踩过的坑：在函数内部扫描取 prev_src，而此时卡片已经点过、
        #   新视频早开始播了 —— prev_src 和当前 src 完全相同，
        #   "地址变了"这个判据永远不成立，只能白等到超时。
        #   （自测页日志：prev_src 与 cur_src 一模一样，且 cur 已经 1.0 秒）
        switched = False
        last_v: dict = {}
        # 自适应等待（不要固定等满）：
        #   地址一变就立刻走；没变最多等 6 秒，够新视频加载元数据了。
        #   ⚠ 上一版固定等满 12 秒，导致每条视频白等 12 秒 ——
        #     回归测试从 60 秒涨到 117 秒，这是我引入的性能回归。
        deadline = time.time() + 6.0
        while time.time() < deadline:
            v = self._any_video()
            last_v = v
            if v.get("found"):
                src = str(v.get("src") or "")
                vdur = float(v.get("duration") or 0)
                if src and prev_src and src != prev_src:
                    switched = True                       # 地址变了 = 换视频了
                if switched and vdur > 0:
                    break
                # ⚠ 别用 `cur0 < 1.0` 当判据：点击后我们还要 sleep 1.2 秒，
                #   等第一次扫描时视频早就播过 1 秒了（实测 cur=1.0），
                #   于是这个条件**永远不成立**，只能白等到 6 秒超时。
                #   改用卡片上写的时长来确认"这就是新视频"：
                #   卡片时长和播放器时长对得上，就说明播放器已经加载好了。
                if vdur > 0 and card_dur > 0 and abs(vdur - card_dur) <= 1.0:
                    switched = True
                    break
                # 实在对不上：只要读到时长、且不是上一条的残留，也认
                if (not prev_src) and vdur > 0 and (
                        card_dur <= 0 or abs(vdur - card_dur) <= 2.0):
                    switched = True
                    break
            time.sleep(0.4)
        if not last_v.get("found"):
            # 明确说明"为什么没播" —— 之前这里静默返回，看不出是页面没有
            # video 元素、还是加载不出来。
            self.log(f"  ⚠ 打不开视频：页面上找不到可播放的 <video>"
                     f"（video 元素={'有' if last_v.get('found') else '没有'}）")
            return LessonResult(index=0, title=label, seconds=0.0, duration=0.0,
                                rate=0.0, finished=False,
                                note="页面上找不到可播放的视频元素")
        if not switched:
            self.log("  · （没等到播放器切换，按当前时长继续 —— 注意核对下面的时长）")

        rate_used = self._set_video_rate(speed)
        dur = float(last_v.get("duration") or 0)
        self.log(f"· 视频时长 {dur:.0f} 秒"
                 f"（{time.strftime('%M:%S', time.gmtime(int(dur)))}）")
        if rate_used:
            self.log(f"· 已设为 {rate_used}×")
        else:
            self.log("· ⚠ 倍速没设上（读不到实际倍速）")

        # ★ 装「在场守卫」。
        #   证据（out\pause_trace.json）：6 次暂停前 0~3ms 都有一个 mouseout，
        #   目标是 .vjs-control-bar / .sp_function / 播放器 iframe。
        #   守卫在 capture 阶段把这些事件吞掉，平台就看不到"鼠标走了"。
        if bool(getattr(config, "COURSE_PRESENCE_GUARD", True)):
            _g = self._cx_presence_guard()
            self.log(f"· 🛡 在场守卫已装（{_g} 个 frame）"
                     if _g else "· 🛡 在场守卫已在（无需重装）")

        # ★ 平台不让加速就**认了**，后面一律只申请它允许的那个值。
        #
        # ⚠ 2026-10-16 实测：学习通这一版的播放器明确写着
        #     "观看时长需 > 总时长的 90%（未完成任务点前，当前视频不可倍速、不可拖动）"。
        #   我们每轮把 1.5× 塞回去，它的播放器就**再暂停一次**：
        #       19:59:07 · 已设为 1.0×
        #       19:59:10 · 平台把倍速改成了 1.0×（请求 1.5×）
        #       19:59:12 · 平台把倍速改成了 1.0×（请求 1.5×）   … 一直刷
        #       19:59:43 · 播放中 1s/640s（0%）                ← 50 秒只走了 1 秒
        #   所以这里把"重设倍速"的目标从 `speed` 换成 `rate_used`
        #   —— 不再跟平台对着干，也就不再触发它把视频按停。
        want_rate = float(rate_used or 1.0)
        if rate_used and speed > rate_used + 0.05:
            self.log(f"· 这一版播放器不让加速（请求 {speed}×，平台只给 {rate_used}×）——"
                     f"后面不再反复申请，免得触发它的防作弊把视频按停")

        # 等待上限：**按视频时长动态算**，不要固定值。
        #
        # ⚠ 踩过的坑：原来固定 COURSE_MAX_WAIT_MIN（3 分钟），
        #   结果 13 分 15 秒的视频播到 3 分钟就被强制切走 ——
        #   用户看到的就是"没看完一整节课就自动切换"。
        #   现在按"这个视频在平台倍速下大概要播多久"留足余量。
        if dur > 0:
            wait_limit = (dur / max(rate_used or 1, 0.5)) * config.COURSE_WAIT_HEADROOM
            # 至少给 5 分钟，防止短视频被算得太紧
            wait_limit = max(wait_limit, 300.0)
        else:
            wait_limit = config.COURSE_MAX_WAIT_MIN * 60      # 读不到时长才用兜底
        self.log(f"· 本条最长等待 {wait_limit / 60:.1f} 分钟"
                 f"（按 {dur:.0f}s ÷ {rate_used or 1}× 留 "
                 f"{config.COURSE_WAIT_HEADROOM}× 余量）")
        if mute:
            try:
                self.driver.page.evaluate(
                    "() => { const v=document.querySelector('video');"
                    " if (v) v.muted = true; }")
            except Exception:
                pass

        quiz_total = 0.0       # 等弹题累计花了多久（不算学习时长）
        quiz_count = 0         # 这次遇到几次弹题
        # ★ 从「累计次数」改成「连续失败次数」（方案 §4.1）：
        #   进度往前走了就清零，不按整节累计。
        resume_fail = 0
        last_resume_try = 0.0
        # 守卫要定期重装：frame 重载/切栏目会把注入的脚本丢掉
        last_guard = 0.0
        last_chal_check = 1e9  # 人机校验的上次检查时刻（立刻查一次）
        # 防挂机：平台看"有没有人在操作"。我们只做最小动作 ——
        # 视频确实在播、但很久没有真实输入时，轻移一下鼠标。
        # **不伪造进度、不上报心跳、不碰平台的时长校验**（见 keepalive.py）。
        keepalive = KeepAlive(
            page=self.driver.page,
            interval=config.COURSE_KEEPALIVE_SEC,
            log=self.log,
            enabled=config.COURSE_KEEPALIVE,
        )
        while True:
            if not self._alive():
                reason = "用户停止"
                break
            time.sleep(config.COURSE_POLL_SEC)

            # ---- 课中弹题 ----
            # ---- 人机校验 / 验证码 ----
            # ⚠ 平台因为自动化弹验证码时，页面会**整个停住不动** ——
            #   不检测的话表现就是"刷课莫名其妙卡在同一节"，
            #   用户完全看不出发生了什么。
            #
            #   检测到就**停下并说清楚**，绝不去解
            #   （验证码是平台的人机校验，自动解等于绕过反爬 ——
            #    与"不绕过人脸识别与活体检测"是同一条铁律）。
            #
            #   每 15 秒查一次：`detect_challenge()` 要遍历所有 frame，
            #   而轮询是 2 秒一轮，每轮都查太浪费。
            if waited - last_chal_check >= 15.0:
                last_chal_check = waited
                try:
                    ch = self.driver.detect_challenge()
                except Exception:
                    ch = {"found": False}
                if ch.get("found"):
                    self.log("  ✘ 页面出现**人机校验 / 验证码** —— 已停止。")
                    self.log(f"     命中特征：{ch.get('how')}"
                             + (f"　附近的文字：{ch.get('hint')}"
                                if ch.get("hint") else ""))
                    self.log("     平台会因为你刷得太快/太规律而弹这个。")
                    self.log("     **请到浏览器窗口里手动输入验证码**，"
                             "再点一次「开始刷课」继续。")
                    self.log("     （程序不会替你识别或填写验证码 ——"
                             "那属于绕过平台的人机校验。）")
                    reason = "人机校验 / 验证码（需你手动处理）"
                    break

            # 网课放到一半常常弹一道题，答完才让继续。
            # 处理原则（照搬 Autovisor）：
            #   · 检测到弹题就**暂停计时**，不算进学习时长
            #     （平台本来就要求"有效学习时长"，把等待算进去反而可疑）
            #   · 等它消失后 continue，下一轮继续播
            #   · 开关打开时**先尝试自动作答**（videoquiz.py）；答不出来就回退到等待
            if self._ai_quiz_visible():
                quiz_count += 1
                probe = self._quiz_probe()
                self.log(f"  · 遇到课中弹题（第 {quiz_count} 次）——"
                         + ("尝试自动作答…" if (self.auto_quiz and self.client)
                            else "已暂停等待，请手动答完，答完会自动继续播放"))
                # 把"命中哪条判据"记下来：万一这是误判，这条日志就是唯一线索
                # ★ 把"它以为的题目"打出来。
                #   误判最难查的地方就是"日志只说命中了某条判据、
                #   却不说它以为题目是什么" —— 有这一行，一眼就能看出
                #   "哦，它把章节标题当成题了"。
                self.log(f"    （判据 {probe.get('sel')}"
                         f"{'，弱判据' if probe.get('weak') else ''}"
                         f"，选项 {probe.get('opts')} 个，"
                         f"框架 {probe.get('frame_url') or '主文档'}）")
                if probe.get("title"):
                    self.log(f"    题目文字：{probe.get('title')}")
                # ★ 先尝试自动答。
                #   答对了 → 后面的 _wait_quiz_done() 会很快看到弹题消失、立刻继续播；
                #   没答上 → 完全等于以前的行为（等你手动答）。
                #   所以这一步**只可能变好，不会变坏**。
                self._auto_answer_quiz(probe)
                self.status(f"等待课中弹题作答…（最多等 "
                            f"{config.COURSE_QUIZ_MAX_WAIT_MIN:.0f} 分钟）")
                spent, why = self._wait_quiz_done()
                quiz_total += spent
                if why == "stopped":
                    reason = "用户停止"
                    break
                if why == "timeout":
                    # ★ 这里原来会**永久卡住**：原来那个 while 没有 deadline，
                    #   判据一旦误命中就再也出不来。现在到点就如实退出并说明原因。
                    self.log(f"  ✘ 弹题等待超过 "
                             f"{config.COURSE_QUIZ_MAX_WAIT_MIN:.0f} 分钟仍未消失，"
                             f"可能判据误命中了 —— 本条跳过")
                    self.log(f"    命中的判据是 {probe.get('sel')}"
                             f"，可以据此判断是不是误判")
                    reason = "课中弹题等待超时（可能误判）"
                    break
                self.log(f"  · 弹题已消失（等了 {spent:.0f} 秒），继续播放")
                self.status(f"{label} 播放中…")
                # 答完题后平台可能把视频暂停了 → 重新起播并确认倍速
                self._set_video_rate(speed)
                # ★ 智慧树 AI 弹题：点完「关闭」视频仍是 paused，必须主动点播放
                if not self._resume_after_quiz():
                    self.log("    · 仍未继续播放，主循环会继续尝试")
                last_rate_check = waited
                last_report = waited      # 免得立刻又打一条进度
                keepalive.poke()          # 刚答完题，相当于有人在，重置计时
                continue

            waited += config.COURSE_POLL_SEC
            v = self._any_video()
            if not v.get("found"):
                # ⚠ 不是"一次没探到就收工"：播放器重载、切栏目、平台把
                #   播放器重新挂载时，中间会有几秒钟页面上真没有 <video>。
                #   实测日志正是"刚播到 1 秒就报 页面上已经没有 <video> 了" ——
                #   那会儿播放器正在重载。所以给它 8 秒再确认一次。
                got: dict = {}
                for _ in range(8):
                    if not self._alive():
                        break
                    time.sleep(1.0)
                    waited += 1.0
                    got = self._any_video()
                    if got.get("found"):
                        break
                if got.get("found"):
                    v = got
                elif not self._alive():
                    reason = "用户停止"
                    break
                else:
                    # 说明为什么退出 —— 之前这里是静默 break，日志只剩
                    # "未播完（4%）"，看不出是页面把播放器收了、还是切换了页面。
                    reason = "页面上已经没有 <video> 了（播放器被收起或页面切走）"
                    break
            cur = float(v.get("currentTime") or 0)
            dur = float(v.get("duration") or dur or 0)
            # 视频在正常前进 → 说明确实在学，顺手做一次保活检查。
            # 放在这里（而不是循环开头）是有意的：**只在视频真的在播时**才保活。
            if not v.get("paused") and not v.get("ended"):
                keepalive.tick()
            if v.get("ended"):
                finished = True
                reason = "播到结尾"
                break
            # ------------------------------------------------------------------
            # ★ 「算不算播完」的判据调整（针对"平台不记进度"这个老问题）
            #
            # 原来的写法是 `cur/dur >= 0.98` 就立刻 break。真机日志暴露了它的后果：
            #     监督学习    ✔ 已播完（98%）→ 卡片刻度 69% → 69%（未变化）
            #     核心范式小结 ✔ 已播完（98%）→ 卡片刻度 72% → 72%（未变化）
            #   四条视频全部"播完"，平台「必学」进度一条都没涨；
            #   而用户手动一停止，平台立刻跳到 6/6。
            #
            # 这说明：**平台是在视频真正走到结尾（触发它自己的 ended 逻辑）
            #   时才记数的**，而我们在 98% 就退出了循环、紧接着还关掉了播放器，
            #   平台那次"结算"就永远没机会发生。
            #
            # 所以现在：0.98 不再直接结束，而是**再等一小会儿看能不能走到结尾**；
            #   只有长时间卡在 98% 不动（确实到不了结尾）才按 98% 收尾。
            #   注意这里**没有延长任何播放时长** —— 视频本身还是播那么久，
            #   只是不再提前掐断最后那 2%。
            if dur and cur / dur >= config.COURSE_DONE_RATIO:
                if near_done_since <= 0:
                    near_done_since = waited
                    self.log(f"  · 已到 {cur / dur * 100:.1f}%，"
                             f"再等一会儿确认走到结尾…")
                elif waited - near_done_since >= 20.0:
                    # 卡在 98% 超过 20 秒 → 这视频到不了结尾了，按 98% 收尾
                    finished = True
                    reason = f"进度到 {cur / dur * 100:.0f}%（未触发结尾事件）"
                    break
            else:
                near_done_since = 0.0
            if v.get("paused"):
                # 被暂停（切后台 / 平台拦下）→ 恢复播放。
                # ⚠ 这一段是 2026-10-16 实测改的，原来只有 `_set_video_rate(speed)`
                #   一行，两个毛病：
                #   ① 它用 `speed`（1.5×）去重设倍速，而这一版播放器
                #      "未完成任务点前不可倍速" —— 每塞一次就再暂停一次，
                #      变成"暂停→重设 1.5×→被按停→再重设"的死循环。
                #      现在改成用 `rate_used`（平台实际允许的值），不再挑事。
                #   ② 光靠 `v.play()` **起不来**：它的自定义播放器不认脚本起播
                #      （没有用户手势），必须用**真实鼠标**把播放按钮点一下。
                #      所以这里改调 `_cx_press_play()`。
                # ★ 「连续失败 + 慢重试」，**永不完全放弃**（方案 §4.1）。
                #
                #   原来写的是 `resume_tries < 5` / `== 5`：
                #   累计 5 次之后就打一行日志、整节再也不救。
                #   2026-10-17 13:28 那节 1450 秒的视频，前 3 分半用完额度，
                #   后面 20 分钟一直停在那里（用户看到的就是"进度不动"）。
                #
                #   现在：连续失败到上限后，间隔从"每次循环"退化成 30 秒一次，
                #   但**不会停止尝试**。
                _can_try = True
                if resume_fail >= int(config.COURSE_RESUME_FAIL_MAX):
                    _can_try = (waited - last_resume_try) >= 30.0
                if _can_try:
                    last_resume_try = waited
                    resume_fail += 1
                    note = self._cx_press_play(v.get("_frame"))
                    self.log(f"  · 视频被暂停了，尝试恢复"
                             f"（连续第 {resume_fail} 次）"
                             + (f"：{note}" if note else "（没能恢复）"))
                    self._set_video_rate(want_rate)
                    last_rate_check = waited
                elif resume_fail == int(config.COURSE_RESUME_FAIL_MAX):
                    # 到阈值了 —— 但**只是放慢，不是放弃**。
                    # 以后每隔 30 秒还会再试一次（见上面 `_can_try` 的退避）。
                    # 原来的写法是"打一行日志、整节再也不救"，
                    # 那样日志看着正常、进度一直是 0，最难查。
                    # ★ "为什么被暂停"要写下来 —— 光说"平台在拦"是猜。
                    #   这三种原因的处理完全不同：
                    #     · document.hidden=true      → 页面被切到后台了（切回来就好）
                    #     · hasFocus=false            → 窗口失焦（点一下窗口）
                    #     · video.error 非空          → 解码/网络失败（等或换源）
                    _why = ""
                    try:
                        _fr = v.get("_frame")
                        _why = (_fr or self.driver.page).evaluate(
                            """() => {
                                let out = [];
                                try {
                                    out.push('visible=' + document.visibilityState);
                                    out.push('focus=' + document.hasFocus());
                                } catch (e) {}
                                try {
                                    const vs = document.querySelectorAll('video');
                                    if (vs.length) {
                                        const x = vs[0];
                                        out.push('ready=' + x.readyState);
                                        out.push('net=' + x.networkState);
                                        out.push('err=' + (x.error ? x.error.code : 0));
                                        out.push('muted=' + x.muted);
                                    }
                                } catch (e) {}
                                return out.join(' ');
                            }""") or ""
                    except Exception:
                        _why = ""
                    self.log(f"  ⚠ 已连续 {resume_fail} 次没能恢复 —— "
                             f"改成**每 30 秒慢重试**（不会放弃）。"
                             "多半是平台在拦（未完成任务点前不允许倍速/切走页面）"
                             + (f"　现场：{_why}" if _why else ""))
            # 倍速被平台改回去 → 立刻补设。
            # 参考 Autovisor 的 video_optimize：它是**每 2 秒轮询**设置倍速的，
            # 比"等到暂停才补"稳得多（有些内核会周期性把倍速重置回 1×）。
            #
            # ⚠ 这里的目标也一律用 `want_rate`（= 平台实际允许的值）：
            #   拿 `speed` 去补，就会重新触发上面那条死循环。
            if want_rate and abs(float(v.get("rate") or 1) - want_rate) > 0.05:
                self._set_video_rate(want_rate)
                last_rate_check = waited
            # 兜底：每 20 秒主动重设一次，顺便把界面标签也刷新
            elif waited - last_rate_check >= 20:
                last_rate_check = waited
                now_rate = self._set_video_rate(want_rate)
                if now_rate and abs(now_rate - want_rate) > 0.05:
                    want_rate = now_rate
            # 每 60 秒重装一次在场守卫 —— frame 重载会把它丢掉，
            # 而"换了播放器"正是平台最爱按暂停的时刻。
            if bool(getattr(config, "COURSE_PRESENCE_GUARD", True)) \
                    and waited - last_guard >= 60.0:
                last_guard = waited
                if self._cx_presence_guard():
                    self.log("  · 🛡 在场守卫已重装（播放器重载过）")
            if cur > last_pos + 0.2:
                last_pos = cur
                stalled = waited
                # ★ 真的往前播了 → 说明之前的恢复是**有效**的，连续失败清零。
                #   这就是"按连续失败算"和"按累计次数算"的区别：
                #   一节长视频里频繁暂停-恢复（但每次都救回来了）不会累积。
                if resume_fail:
                    self.log(f"  · 已恢复播放（上次中断后进度 {cur:.0f}s）")
                    resume_fail = 0
            elif waited - stalled > 60:
                if v.get("paused"):
                    # ★ 暂停时进度本来就不动 —— **不能拿它判"卡死"**（方案 §4.2）。
                    #   原来这里直接 break：暂停一会儿就被判成卡住、整节丢掉。
                    #   冻结计时，等恢复后再重新起算（下面要是恢复失败还有上限兜底）。
                    stalled = waited
                else:
                    reason = f"进度卡在 {cur:.0f}s 超过 60 秒"
                    break
            # 每 30 秒报一次播放进度，方便从日志判断"到底有没有在播"
            if waited - last_report >= 30:
                last_report = waited
                pct = (cur / dur * 100) if dur else 0
                self.log(f"  · 播放中 {cur:.0f}s/{dur:.0f}s（{pct:.0f}%）"
                         f" 倍速 {v.get('rate')}×")
            # 等待上限：**按视频时长动态算**，而不是固定 3 分钟。
            #
            # ⚠ 踩过的坑：原来是固定 COURSE_MAX_WAIT_MIN（3 分钟），
            #   结果 13 分 15 秒的视频播到 3 分钟就被强制切走 ——
            #   用户看到的就是"没看完一整节课就自动切换"。
            #   正确做法：按"这个视频在平台倍速下大概要播多久"再留余量。
            if waited > wait_limit:
                reason = (f"单条等待超过上限 {wait_limit / 60:.1f} 分钟"
                          f"（时长 {dur:.0f}s ÷ 倍速 {rate_used or 1}"
                          f" ×{config.COURSE_WAIT_HEADROOM} 余量）")
                break

        secs = time.time() - t_start
        pct = f"{cur / dur * 100:.0f}%" if dur else "?"

        # ------------------------------------------------------------------
        # 播完后只**很快看一眼**卡片百分比，不做长时间等待。
        #
        # 这里曾经写成"最多等 12 秒，等平台把进度记上"，结果：
        #   · 每条视频白等 13.7 秒（实测），回归从 60 秒涨到 111 秒
        #   · 而且这个判据本身**不可靠**：播完后右侧列表已经换成下一条，
        #     按题名根本找不回这张卡，只能得出 "0% → 0%" 这种**假结论**
        #     （就误报过：`监督学习` 明明播完了却显示"平台没记上进度"）
        #
        # 真正可靠的判据是「必学 n/n」——外层循环每次都会读，那才是权威。
        # 所以这里只做一次即时回读、且**找不到就明说**，绝不硬等。
        # ------------------------------------------------------------------
        card_before = prev_percent
        try:
            _, card_after = self._ai_card_percent(label, prev_percent)
        except Exception:
            card_after = None

        if card_before is not None:
            if card_after is None:
                self.log(f"  · 卡片刻度：播放前 {card_before}% → 播放后列表已换走"
                         f"（以「必学 n/n」为准）")
            elif card_after != card_before:
                self.log(f"  · 卡片刻度：播放前 {card_before}% → 播放后 {card_after}%")
            else:
                self.log(f"  · 卡片刻度：播放前 {card_before}% → 播放后 {card_after}%"
                         f"（未变化）")

        # ★ 把"自动答了几道弹题"报出来。
        #   不加这一行，用户看完整个刷课过程也不知道自动作答有没有干活 ——
        #   和之前"答了却报 0 道"是同一类观感问题。
        _qz = ""
        if quiz_count:
            _qz = f"，弹题 {quiz_count} 道"
            if self.quiz_answered:
                _qz += f"（自动答对 {self.quiz_answered} 道"
                if self.quiz_failed:
                    _qz += f"，{self.quiz_failed} 道没答上"
                _qz += "）"
            elif self.quiz_failed:
                _qz += f"（{self.quiz_failed} 道没答上，已等你手动答）"
        self.log(f"  {label}：{'✔ 已播完' if finished else '⚠ 未播完'}"
                 f"（{pct}，用时 {secs:.0f} 秒）"
                 + (f"，其中等弹题 {quiz_total:.0f} 秒" if quiz_total >= 1 else "")
                 + _qz
                 + ("" if finished else f"　停止原因：{reason or '未知'}"))
        return LessonResult(index=0, title=label, seconds=round(secs, 1),
                            duration=round(dur, 1), rate=rate_used, finished=finished,
                            note="" if finished else
                            f"未完成（到 {cur:.0f}s / {dur:.0f}s）{reason}")

    def _ai_card_percent(self, label: str, prev: int | None) -> tuple[int | None, int | None]:
        """回读某张卡片当前的百分比（用于判断平台有没有记进度）。

        返回 (播放前的值, 现在的值)。读不到就是 None。
        """
        try:
            s = self._ai_scan()
            for c in (s.get("cards") or []):
                nm = (c.get("name") or c.get("full") or "").strip()
                if nm and (nm == (label or "").strip() or nm in (label or "")
                           or (label or "") in nm):
                    return prev, c.get("percent")
        except Exception:
            pass
        return prev, None

    def _ai_handle_card(self, idx: int, speed: float, mute: bool) -> LessonResult | None:
        """点开第 idx 张资源卡并按类型处理。

        PPT：点开 → 稍等 → 关闭（用户说明："点开关闭即可"）
        视频：点开 → 播完 → 关闭
        """
        s = self._ai_scan()
        cards = s.get("cards") or []
        if idx >= len(cards):
            return None
        card = cards[idx]
        label = card["name"] or card["full"]
        # 类型：有时长 = 视频（要播），有页数 = 文档（点开关闭即可）
        is_doc = bool(card.get("isPpt")) and not card.get("isVideo")
        kind = "PPT/文档" if is_doc else "视频"
        self.log(f"· 打开{kind}：{label}"
                 f"（{card['duration'] or card['pages'] or '—'}）")

        # ★ 在**点击之前**记下当前播放器的地址。
        #   点完之后再记就已经是新视频了，那样根本判断不出"有没有切换"。
        prev_src = str((s.get("video") or {}).get("src") or "")

        # ★ 卡片上写的时长（"HH:MM:SS"）—— 用来确认"播放器真的换成了这条"。
        #   比等播放器报 duration 可靠得多：点击后我们还要等 1.2 秒，
        #   那会儿新视频已经开播，靠 currentTime==0 之类的判据全都来不及。
        card_dur = 0.0
        _dm = re.match(r"^(\d{1,2}):(\d{2}):(\d{2})$", (card.get("duration") or "").strip())
        if _dm:
            card_dur = (int(_dm.group(1)) * 3600 + int(_dm.group(2)) * 60
                        + int(_dm.group(3)))

        if not self._ai_click_card(idx):
            return LessonResult(index=idx, title=label, seconds=0.0, duration=0.0,
                                rate=0.0, finished=False, note="卡片点不开")
        time.sleep(1.2)

        if is_doc:
            # 文档：等它渲染出来，然后关掉
            for _ in range(10):
                s2 = self._ai_scan()
                if s2.get("ppt"):
                    break
                time.sleep(0.5)
            time.sleep(1.0)                 # 给平台记进度的时间
            self._ai_close_player()
            self.log(f"  {label}：✔ 已打开并关闭（文档类）")
            return LessonResult(index=idx, title=label, seconds=1.0, duration=0.0,
                                rate=0.0, finished=True, note="文档，点开即完成")

        r = self._ai_play_video(speed, mute, label,
                                prev_percent=card.get("percent"),
                                prev_src=prev_src,
                                card_dur=card_dur)

        # ------------------------------------------------------------------
        # ★ 播完后**先别关播放器**，等平台把这一条记上（最多 15 秒）。
        #
        # 为什么：真机日志显示，四条视频全部"播完"，平台「必学」进度
        #   一条都没涨；而用户手动一停止，平台立刻跳到 6/6。
        #   说明平台是在**离开播放器/收到它自己的结算事件**时才记数的，
        #   而我们播完立刻就关，那次结算没机会发生。
        #
        # 判据用**平台自己的进度文字**（「必学 n/n」）——上一版用"卡片刻度"
        #   有过误报（列表换走后按题名找不到卡，得出假的 0%→0%），
        #   所以这次用不会骗人的那个。
        if r.finished and not is_doc:
            before = self._ai_progress_text()
            # 先立刻回读一次：很多情况下平台在视频结束前就记上了，
            # 这时**完全不用等**（避免无谓地拖慢整轮）。
            time.sleep(1.5)
            now = self._ai_progress_text()
            if before and now and now != before:
                self.log(f"  · 平台进度已刷新：{before} → {now}")
            elif before:
                # 还没刷新 → 短等一会儿。8 秒足够覆盖服务端结算的常见延迟，
                # 再长就是白白拖时间（真机日志里进度是"下一次读"才变的）。
                for i in range(4):
                    if not self._alive():
                        break
                    time.sleep(2.0)
                    now = self._ai_progress_text()
                    if now and now != before:
                        self.log(f"  · 平台进度已刷新：{before} → {now}（等了 {(i + 1) * 2} 秒）")
                        break
                else:
                    self.log(f"  · 平台进度暂未刷新（仍是 {before}）——"
                             f"外层会再核对一次")

        self._ai_close_player()
        return r

    def _ai_progress_text(self) -> str:
        """当前知识点的「必学 n/n」进度文字（平台自己的权威判据）。

        读不到就返回空串 —— 调用方据此跳过等待，不要硬等。
        结构与 `_ai_progress_of` 保持一致：进度存在 topics 列表每一项里。
        """
        try:
            s = self._ai_scan()
        except Exception:
            return ""
        # 优先取"当前高亮"的那个知识点，其次取第一个有进度的
        for t in (s.get("topics") or []):
            if t.get("active") and (t.get("progress") or ""):
                return str(t.get("progress"))
        for t in (s.get("topics") or []):
            if t.get("progress"):
                return str(t.get("progress"))
        return ""

    def _ai_click_card(self, idx: int) -> bool:
        """点资源卡片。先按文字定位，再退回索引定位。"""
        try:
            loc = self.driver.page.locator(AI_SELECTORS["detail_container"]).first \
                .locator(AI_SELECTORS["card"]).nth(idx)
            loc.scroll_into_view_if_needed(timeout=2500)
            loc.click(timeout=3000)
            return True
        except Exception:
            pass
        try:
            s = self._ai_scan()
            cards = s.get("cards") or []
            if idx < len(cards):
                fr = s.get("_frame") or self.driver.page.main_frame
                box = fr.evaluate(
                    """(arg) => {
                        const c = document.querySelectorAll(arg[0]);
                        const e = c[arg[1]];
                        if (!e) return null;
                        const r = e.getBoundingClientRect();
                        return {x: r.x + r.width / 2, y: r.y + r.height / 2};
                    }""", [AI_SELECTORS["card"], idx])
                if box:
                    # 审计 C-30：box 是该框架内坐标，要换算到页面坐标
                    self.driver.click_in_frame(fr, box["x"], box["y"])
                    return True
        except Exception:
            pass
        return False

    def _ai_close_player(self) -> None:
        """关闭当前播放器 / 返回资源列表。

        Video.js 的播放器一般是覆盖在资源列表上的浮层，关法因页面而异，
        所以这里按"从最可能的顺序"逐个试。

        ⚠ 审计 C-34：原来有两处**会做危险动作还谎报成功**：
          ① 选择器写成 `.close-btn, .btn-close, .video-close, [class*=close]`，
             最后那个 `[class*=close]` 会命中页面上**任意**类名含 close 的元素
             （cookie 横幅的关闭叉、弹窗遮罩、甚至广告位），
             取 `.first` 点一下就当"关掉了" → 播放器其实还开着，
             而调用方以为收尾完成，接着去点下一张卡 → 点不动 → 空转。
          ② 兜底是 `mouse.click(5, 5)` —— 页面左上角，
             那里通常是 Logo / 主导航，点下去可能**跳走整个页面**。

          现在：关按钮限定在**播放器容器内**找；兜底改成发 Esc 并**回读确认**；
          实在关不掉就如实返回，不做危险点击。
        """
        page = self.driver.page
        # 播放器容器（尽量收紧，避免命中全局的 close 元素）
        player_scope = (
            ".video-js, .prism-player, .vjs-tech, [class*=player], "
            "[class*=video], .el-dialog, .ss2077-custom-dialog"
        )
        close_sel = (".close-btn, .btn-close, .video-close, .vjs-close-button, "
                     "[aria-label*=关闭], [title*=关闭]")

        # ① 在播放器容器里找关闭按钮
        for scope in (player_scope, None):
            try:
                if scope:
                    loc = page.locator(scope).first.locator(close_sel).first
                else:
                    loc = page.locator(close_sel).first
                loc.click(timeout=1200)
                time.sleep(0.8)
                if not self._player_still_open():
                    return
            except Exception:
                continue

        # ② 按 Esc（无害：不会跳页），按下后回读确认
        try:
            page.keyboard.press("Escape")
            time.sleep(0.8)
            if not self._player_still_open():
                return
        except Exception:
            pass

        # ③ 关不掉就**如实返回**，绝不点 (5,5) 那种盲点。
        #    调用方会按"还开着"来处理，比点飞页面安全得多。
        self.log("  · 播放器似乎没关掉（没找到可靠的关闭按钮），继续下一步")

    def _player_still_open(self) -> bool:
        """判断播放器浮层是否还开着（用于确认"关闭"真的生效）。"""
        try:
            r = self.driver.page.evaluate(
                """() => {
                    const sels = ['.video-js', '.prism-player',
                                  '[class*=player]', 'video'];
                    for (const s of sels) {
                        for (const e of document.querySelectorAll(s)) {
                            if (!e.offsetParent) continue;
                            const r = e.getBoundingClientRect();
                            if (r.width > 200 && r.height > 120) {
                                const st = getComputedStyle(e);
                                if (st.display !== 'none'
                                    && st.visibility !== 'hidden') return true;
                            }
                        }
                    }
                    return false;
                }""")
            return bool(r)
        except Exception:
            # 读不出来就不敢断言"关掉了"
            return True

    # ---- 智慧树 AI 版课程：主循环 ----
    def _run_ai_course(self, res: CourseResult, speed: float, mute: bool,
                       max_items: int, t0: float) -> CourseResult:
        """按「知识模块 → 知识点 → 必学资源」三层推进。

        与老版最大的不同：老版是"点下一节"，这里是**遍历资源卡片列表**。
        完成判据一律看平台自己的 `.finished-icon`（「已完成」角标），
        而不是我们自己记录的播放时长。

        ⚠ 踩过的坑：最初写成"每轮找第一个未完成的知识点"，结果所有知识点
          学完之后它还会被反复选中 —— **没有"已访问"概念就会死循环**。
          现在改成按模块轮转，每个模块只处理一次，处理完就换下一个模块。
        """
        s = self._ai_scan()
        if not s.get("isAI"):
            res.error = "这不是 AI 版课程页（没找到知识点/资源卡片结构）"
            self.log(f"✘ {res.error}")
            return res

        self.log(f"识别到 AI 版课程：{len(s.get('topics') or [])} 个知识点，"
                 f"{len(s.get('cards') or [])} 张必学资源卡")

        done_n = 0

        # 找出**真正含知识点**的模块。
        # ⚠ 踩过的坑：原来把页面上所有 .el-collapse-item__header 都当模块数，
        #   真实页面里混着「知识单元：…」这种节点，还有空模块 ——
        #   实测数出 16 个但日志里只出现过 15 个名字，还整个跳过了 [4/16]。
        #   现在只取"这个折叠块里确实有知识点"的那些。
        mod_indexes = self._ai_module_indexes()
        self.log(f"共 {len(mod_indexes)} 个知识模块待处理")
        if not mod_indexes:
            self.log("⚠ 一个含知识点的模块都没找到 —— 目录可能还在加载，"
                     "或当前页不是「能看到知识点目录」的那一页")

        prev_topics: list[str] = []
        self._dbg_sigs: list = []
        for pos, mi in enumerate(mod_indexes):
            if len(res.lessons) >= max_items:
                res.stopped_reason = f"达到上限 {max_items} 条资源"
                break
            if not self._alive():
                res.stopped_reason = "用户停止"
                break

            mod_name = self._ai_module_name(mi)
            total_mod = len(mod_indexes)

            # 展开第 mi 个模块 —— 这是"能不能进入下一个模块"的关键。
            # ⚠ 踩过的坑：原来用 .el-collapse-item__wrap 的 aria-hidden/高度
            #   判断是否展开，真实页面上这个判据一直为"展开"，于是**连点都不点**，
            #   16 个模块全都在读第一个模块的知识点（用户原话：
            #   "他一直在第一个知识模块里选择，不会进入下一个"）。
            #   现在改用 Element UI 标准的折叠头 is-active 类，并验证真的转移了。
            if not self._ai_expand_module(mi):
                self.log(f"===== 知识模块 [{pos + 1}/{total_mod}] {mod_name} =====")
                self.log("· ⚠ 没能展开这个模块，跳过（否则会一直读上一个模块的内容）")
                continue

            # 记下展开瞬间的**本模块**知识点
            st_mod = self._ai_wait_topics()
            mod_topics = [t.get("name") for t in (st_mod.get("topics") or [])
                          if t.get("visible") and t.get("mod") == mi]
            if not mod_topics:
                self.log(f"===== 知识模块 [{pos + 1}/{total_mod}] {mod_name} =====")
                self.log("· 展开后没等到可见知识点（可能这一节没有内容）")
                continue
            self.log(f"===== 知识模块 [{pos + 1}/{total_mod}] {mod_name} =====")
            self.log(f"· 本模块知识点（{len(mod_topics)} 个）：" +
                     "、".join(x[:14] for x in mod_topics[:6]))

            # 防呆：本模块的知识点如果**全都在上一个模块里出现过**，
            # 说明模块其实没换（目录是累积展开的，全在就会完全重合）。
            if prev_topics and all(x in prev_topics for x in mod_topics):
                self.log("· ⚠ 本模块列出的知识点全部在上一个模块里出现过 ——"
                         " 模块切换没生效，跳过以免空转")
                continue
            prev_topics = mod_topics

            # 这个模块下的知识点，逐个处理
            visited: set[str] = set()
            round_no = 0
            for _ in range(60):
                if len(res.lessons) >= max_items:
                    break
                if not self._alive():
                    res.stopped_reason = "用户停止"
                    break
                round_no += 1

                st = self._ai_scan()
                cand = None
                for t in (st.get("topics") or []):
                    if not t.get("visible"):
                        continue
                    # ★ 只处理**属于当前展开模块**的知识点。
                    #   目录是累积展开的：点开模块 2 之后，模块 1 的 5 个知识点
                    #   还排在最前面，"取第一个没访问过的"会一直落在模块 1 上。
                    if t.get("mod") is not None and t.get("mod") != mi:
                        continue
                    name = t.get("name") or ""
                    if not name or name in visited:
                        continue
                    cand = t
                    break
                if cand is None:
                    break                       # 这个模块的知识点都处理过了

                visited.add(cand["name"])

                # 点选知识点 —— **只点一次**。
                # ⚠ 原来为了"确保选中"最多点 3 次，但这个控件是点击切换的，
                #   点第 2 下就取消了，状态被点乱。
                sig_before = self._ai_cards_sig()
                picked = self._ai_select_topic(cand["name"], prev_sig=sig_before)

                # 等资源列表**换过**（不是"有卡片"——旧知识点的卡片还在页面上）
                st = self._ai_wait_cards(prev_sig=sig_before)
                cards = st.get("cards") or []
                sig_after = self._ai_cards_sig(st)

                self.log(f"—— 知识点：{cand['name']}　"
                         f"{self._ai_progress_of(st, cand['name'])} ——")

                # 诊断：把点击前后的卡片名单都记下来。
                # 这是为了定位「必学 4/5 却读到全完成」——只有对比前后名单，
                # 才能判断到底是"列表没换（读到上一条）"还是"角标判断错了"。
                if len(self._dbg_sigs) < 40:
                    self._dbg_sigs.append((cand["name"], sig_before, sig_after))
                    self.log("· [对比] 点击前：" + (sig_before[:90] or "(空)"))
                    self.log("· [对比] 点击后：" + (sig_after[:90] or "(空)"))

                # ★★ 最重要的一道保险 ★★
                # 列表指纹**一点没变** → 现在页面上显示的还是**上一个知识点**的资源。
                # 绝不能拿它去判断"已完成"，否则会得出
                # 「必学 4/5 但 5 条必学资源都已完成」这种自相矛盾、且会漏刷的结论。
                #
                # 但**本模块第一轮要豁免**：刚展开模块时列表本来就是当前知识点的，
                # 指纹不变是正常的（误判会白白跳过第一个知识点）。
                if round_no > 1 and sig_before and sig_after == sig_before:
                    self.log("· ⚠ 右侧资源列表没有切换过来（指纹未变）——"
                             " 拿到的可能是上一个知识点的内容，跳过以免误判")
                    continue

                todo = [c for c in cards if not c.get("done")]
                if not picked and todo:
                    self.log("· （切换确认超时，但列表确实变了，继续处理）")
                if not cards:
                    self.log("· 资源列表一直没加载出来（等超时了），跳过这个知识点")
                    continue
                # 把读到的卡片逐条打出来，便于对照
                self.log("· 读到的必学资源：" + " ｜ ".join(
                    (c["name"] or c["full"])[:16]
                    + ("(PPT)" if c.get("isPpt") else "")
                    + (f"[进度{c['percent']}%]" if c.get("percent") is not None else "")
                    for c in cards[:8]))

                # ★★★ 完成判据：以**平台自己的进度**为准 ★★★
                #
                # ⚠ 这里踩了最久的一个坑：一直用卡片上的 `.finished-icon` 判断
                #   "已完成"。实测真实页面**每一张卡片都带这个类、而且都可见**
                #   （角标类名清一色 `finished-icon`，个别带 `!bg-[#1FA1FF]`），
                #   它根本不是完成标记 —— 于是每个知识点都被判成"全完成"直接跳过，
                #   表现就是"光翻页不看课"。
                #
                #   平台自己在左侧写着「必学 4/5」，那就是权威：还差 1 条。
                #   这也印证了调研 Autovisor 时看到的同一条原则：
                #   **以平台记录的进度为准**。
                prog = self._ai_progress_of(st, cand["name"])
                need = self._ai_need_count(prog)
                if need is None:
                    # 读不到进度（页面结构变了）→ 退回按卡片自己算
                    todo = [c for c in cards if not c.get("done")]
                    self.log(f"· （读不到「必学 n/n」进度，按卡片角标判断："
                             f"待完成 {len(todo)} 条）")
                elif need <= 0:
                    self.log(f"· 平台进度「{prog}」显示已全部完成，跳过")
                    continue
                else:
                    # 平台说还差 need 条 → 这些卡片要逐条做。
                    # 不去猜"是哪几条"，按顺序全部做一遍，做完回读进度确认。
                    todo = list(cards)
                    self.log(f"· 平台进度「{prog}」→ 还差 {need} 条，"
                             f"按顺序处理这 {len(todo)} 条卡片")

                # 挑选顺序（★ 这里曾经完全写反了）：
                #
                # 真实页面的卡片上：
                #   · 有进度百分比且 < 100%  → **未完成**（如「什么是机器学习 3%」）
                #   · 没有百分比             → 已完成 / 不需要学
                #     （用户截图佐证：`机器学习基本框架 已完成`、`什么是机器学习 3%`）
                #
                # 我原来优先挑 `percent === null` 的，正好把**已完成**的排在前面，
                # 于是每次都去播已经看完的视频，真正没看完的 3% 那条永远轮不到。
                # 现在按"未完成程度"排序：**有小数百分比的排最前，数字越小越优先**。
                def pick_key(c: dict):
                    p = c.get("percent")
                    if p is None:
                        return (3, 0)          # 没进度数字 → 放最后
                    if p >= 100:
                        return (2, 0)          # 满进度 → 也算完成
                    return (0, p)              # 未完成：数字越小越靠前

                handled: set[str] = set()

                for _2 in range(len(cards) + 4):
                    if len(res.lessons) >= max_items:
                        break
                    if not self._alive():
                        res.stopped_reason = "用户停止"
                        break

                    # 回读平台进度：够了就停
                    st_now = self._ai_scan()
                    prog_now = self._ai_progress_of(st_now, cand["name"])
                    need_now = self._ai_need_count(prog_now)
                    if need_now is not None and need_now <= 0:
                        self.log(f"  ✔ 平台进度已变为「{prog_now}」，这个知识点完成")
                        break

                    skipped = getattr(self, "_ai_skipped", set())
                    pool = [x for x in (st_now.get("cards") or [])
                            if (x["name"] or x["full"]) not in skipped
                            and (x["name"] or x["full"]) not in handled]
                    if not pool:
                        self.log(f"  · 这个知识点的卡片都试过了，"
                                 f"但进度仍是「{prog_now}」——可能平台不计入")
                        break
                    pool.sort(key=pick_key)
                    target = pool[0]

                    name = target["name"] or target["full"]
                    handled.add(name)
                    r = self._ai_handle_card(target["idx"], speed, mute)
                    if r is None:
                        self.log("· 卡片点不开，跳过这条以免卡住")
                        self._ai_mark_local_skip(name)
                        continue
                    res.lessons.append(r)
                    if r.finished:
                        done_n += 1
                    time.sleep(1.5)

                    # 回读平台进度，确认有没有推进
                    after_st = self._ai_scan()
                    prog_after = self._ai_progress_of(after_st, cand["name"])
                    if prog_after and prog_after != prog_now:
                        self.log(f"  ✔ 平台进度推进：{prog_now} → {prog_after}")
                    else:
                        self.log(f"  ⚠ 平台进度没变（仍是 {prog_after}）——"
                                 f" 这一条可能不计入，继续试下一条")

        res.ok = done_n > 0
        self.log("")
        self.log(f"===== 刷课结束：处理 {len(res.lessons)} 条资源，"
                 f"{done_n} 条播完，用时 {time.time() - t0:.0f} 秒 =====")
        if not res.lessons:
            res.stopped_reason = res.stopped_reason or "没有找到需要完成的资源"
        elif not res.stopped_reason:
            res.stopped_reason = "所有知识点都已处理完"
        if res.stopped_reason:
            self.log(f"停止原因：{res.stopped_reason}")
        # 章节测验的份数单独报一行 —— 只在**答过**的时候报，
        # 没答过测验的课不该多一行「章节测验 0 份」。
        if self.chapter_quiz_done or self.chapter_quiz_failed:
            # ★ 按**真实结局**说，不按开关说。
            #   （2026-10-17 17:18：上一行刚说"没确认交上"，
            #    这一行却报"已交卷"—— 自相矛盾）
            if getattr(self, "last_quiz_blocked", False):
                how = "⚠ 被验证码拦住，未交卷"
            elif getattr(self, "last_quiz_submitted", False):
                how = "已交卷"
            elif self.quiz_submit:
                how = "⚠ 答完了但没确认交上，请手动检查"
            else:
                how = "已填好、未交卷"
            tail = (f"，{self.chapter_quiz_failed} 份没答成"
                    if self.chapter_quiz_failed else "")
            self.log(f"· 章节测验：{self.chapter_quiz_done} 份答完{tail}（{how}）")
        return res

    def _ai_wait_topics(self, timeout: float = 10.0) -> dict:
        """等"可见的知识点"出现。

        点开一个折叠模块之后，里面的知识点要等 Vue 渲染才可见。
        固定 sleep 会抢跑 —— 实测因此读到 0 个可见知识点，
        然后直接跳到下一个模块，而手风琴又把刚展开的那个收起来了。
        """
        end = time.time() + timeout
        last: dict = {}
        while time.time() < end:
            if not self._alive():
                break
            st = self._ai_scan()
            last = st
            vis = [t for t in (st.get("topics") or []) if t.get("visible")]
            if vis and (st.get("cards") or True):
                return st
            time.sleep(0.4)
        return last

    def _ai_module_indexes(self, timeout: float = 12.0) -> list[int]:
        """返回**真正含知识点**的折叠头下标（按 DOM 顺序）。

        只认"这个折叠块里确实有 .section-item-collapse-info"的那些，
        这样「知识单元：…」和空模块都会被排除掉。

        ⚠ 还要**等数量稳定**：真实页面有 68 个知识点、16 个模块，
          如果目录还没渲染完就开跑，只会数到前几个模块。
          连续两次读到相同数量才认为渲染完了。
        """
        end = time.time() + timeout
        last: list[int] = []
        stable = 0
        while time.time() < end:
            if not self._alive():
                break
            try:
                cur = list(self.driver.page.evaluate(
                    """(sel) => {
                        const heads = [...document.querySelectorAll(
                            'button.el-collapse-item__header')];
                        const out = [];
                        heads.forEach(function (h, i) {
                            const item = h.closest('.el-collapse-item');
                            if (!item) return;
                            if (!item.querySelector(sel.topic)
                                && !item.querySelector('.section-item-collapse-info')) return;
                            out.push(i);
                        });
                        return out;
                    }""", AI_SELECTORS) or [])
            except Exception:
                cur = []
            if cur and cur == last:
                stable += 1
                if stable >= 2:                 # 连续两次一致 → 认为稳定了
                    return cur
            else:
                stable = 0
            last = cur
            time.sleep(0.6)
        return last

    def _ai_module_count(self, timeout: float = 12.0) -> int:
        """等目录渲染出来，返回知识模块（折叠头）的数量。"""
        end = time.time() + timeout
        n = 0
        while time.time() < end:
            if not self._alive():
                break
            try:
                n = int(self.driver.page.evaluate(
                    "() => document.querySelectorAll("
                    "'button.el-collapse-item__header').length"))
            except Exception:
                n = 0
            if n > 0:
                return n
            time.sleep(0.5)
        return n

    def _ai_module_name(self, mi: int) -> str:
        try:
            return (self.driver.page.locator(
                "button.el-collapse-item__header").nth(mi).inner_text() or "") \
                .replace("\n", " ").strip()[:30]
        except Exception:
            return ""

    def _ai_module_state(self, mi: int) -> dict:
        """第 mi 个知识模块的展开状态（多个判据一起看）。

        ⚠ 踩过的坑：一开始只看 .el-collapse-item__wrap 的 aria-hidden / 高度，
          真实页面上这个判据**一直是"展开"**，于是程序以为不用点，
          结果 16 个模块全都在读第一个模块的知识点（用户原话：
          "他一直在第一个知识模块里选择，不会进入下一个"）。

        Element UI 手风琴的标准标记是**折叠头自身的 `is-active` 类**，
        所以现在把它当主要判据，另外两个当辅助。
        """
        try:
            return self.driver.page.evaluate(
                """(mi) => {
                    const heads = [...document.querySelectorAll(
                        'button.el-collapse-item__header')];
                    const h = heads[mi];
                    if (!h) return { exists: false };
                    const item = h.closest('.el-collapse-item');
                    const wrap = item
                        ? item.querySelector('.el-collapse-item__wrap') : null;
                    const cls = String(h.className || '');
                    const isActive = /(^|\\s)is-active(\\s|$)/.test(cls);
                    const itemActive = item
                        ? /(^|\\s)is-active(\\s|$)/.test(String(item.className || ''))
                        : false;
                    const hidden = wrap ? wrap.getAttribute('aria-hidden') : null;
                    const h2 = wrap ? wrap.getBoundingClientRect().height : 0;
                    const topics = item
                        ? item.querySelectorAll('.section-item-collapse-info').length
                        : 0;
                    let visTopics = 0;
                    if (item) {
                        item.querySelectorAll('.section-item-collapse-info')
                          .forEach(function (e) {
                            const r = e.getBoundingClientRect();
                            if (r.width > 0 && r.height > 0) visTopics++;
                          });
                    }
                    return { exists: true, isActive: isActive,
                             itemActive: itemActive, hidden: hidden,
                             wrapHeight: h2, topics: topics,
                             visTopics: visTopics,
                             text: (h.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 24) };
                }""", mi) or {"exists": False}
        except Exception:
            return {"exists": False}

    def _ai_module_open(self, mi: int) -> bool:
        """第 mi 个知识模块当前是不是展开的。"""
        st = self._ai_module_state(mi)
        if not st.get("exists"):
            return False
        if st.get("isActive") or st.get("itemActive"):
            return True
        # 没有 is-active 标记时（别的实现）退回看可见知识点
        return bool(st.get("visTopics"))

    def _ai_expand_module(self, mi: int) -> bool:
        """把第 mi 个模块**确实展开**，并在必要时重试。

        返回是否成功。这是"能不能进入下一个模块"的关键一步：
        原来只看 aria-hidden 就认为已展开、连点都不点，于是永远停在第一个模块。
        """
        st = self._ai_module_state(mi)
        if not st.get("exists"):
            return False
        if st.get("isActive") or st.get("itemActive"):
            return True                     # 已经开着

        head = "button.el-collapse-item__header"
        for attempt, how in enumerate(("locator 点击", "DOM click", "点标题文字"), 1):
            try:
                if how == "locator 点击":
                    loc = self.driver.page.locator(head).nth(mi)
                    loc.scroll_into_view_if_needed(timeout=2500)
                    loc.click(timeout=3000)
                elif how == "DOM click":
                    self.driver.page.evaluate(
                        """(mi) => {
                            const h = document.querySelectorAll(
                                'button.el-collapse-item__header')[mi];
                            if (h) { h.scrollIntoView({block:'center'}); h.click(); }
                        }""", mi)
                else:
                    name = st.get("text") or ""
                    if not name:
                        continue
                    self.driver.page.get_by_text(name, exact=False).first.click(timeout=2500)
            except Exception as e:
                self.log(f"· 展开模块第 {attempt} 次（{how}）没点到：{type(e).__name__}")
                continue

            # 等 is-active 转移过来
            end = time.time() + 4.0
            while time.time() < end:
                time.sleep(0.4)
                now = self._ai_module_state(mi)
                if now.get("isActive") or now.get("itemActive"):
                    return True
            self.log(f"· 展开模块第 {attempt} 次（{how}）后，该模块仍未变为展开状态")

        now = self._ai_module_state(mi)
        self.log(f"⚠ 模块 [{mi}] {st.get('text')} 三种方式都没能展开"
                 f"（is-active={now.get('isActive')} 可见知识点={now.get('visTopics')}）")
        return False

    def _ai_progress_of(self, st: dict, name: str) -> str:
        """取指定知识点的"必学 n/n"进度（比拿 active 那个准）。"""
        for t in (st.get("topics") or []):
            if (t.get("name") or "") == name:
                return t.get("progress") or ""
        for t in (st.get("topics") or []):
            if t.get("active"):
                return t.get("progress") or ""
        return ""

    def _ai_need_count(self, progress: str) -> int | None:
        """从"必学 4/5"算出还差几条；解析不出来返回 None。"""
        m = re.search(r"(\d+)\s*/\s*(\d+)", progress or "")
        if not m:
            return None
        done, total = int(m.group(1)), int(m.group(2))
        return max(0, total - done)

    def _ai_cards_sig(self, st: dict | None = None) -> str:
        """当前资源列表的"指纹"（用卡片名字拼），用来判断列表有没有换过。"""
        s = st if st is not None else self._ai_scan()
        names = [ (c.get("name") or c.get("full") or "")[:24]
                  for c in (s.get("cards") or []) ]
        return "|".join(names)

    def _ai_wait_cards(self, timeout: float = 12.0, need_visible: bool = True,
                       prev_sig: str | None = None) -> dict:
        """等资源卡片加载出来，返回最后一次扫描结果。

        ⚠ 两个坑都在这里踩过：
          · 点选知识点后右侧列表**异步重载**，固定 sleep 会抢跑（读到 0 张）；
          · 更隐蔽的是 **旧知识点的卡片还留在页面上**，只看"有没有卡片"
            会立刻误判成加载完成 —— 所以传入 prev_sig 时，
            必须等指纹**真的变了**才算换好。
        """
        end = time.time() + timeout
        last: dict = {}
        while time.time() < end:
            if not self._alive():
                break
            st = self._ai_scan()
            last = st
            cards = st.get("cards") or []
            if not cards or (need_visible and not any(c.get("visible") for c in cards)):
                time.sleep(0.5)
                continue
            if prev_sig is None or self._ai_cards_sig(st) != prev_sig:
                return st
            time.sleep(0.5)
        return last

    def _ai_select_topic(self, name: str, prev_sig: str | None = None) -> bool:
        """按名字点选左侧知识点。

        ★ 关键是**只点一次**。

        ⚠ 踩过的坑（最坑的一次）：原来为了"确保选中"，依次试了三种点法
          （点名字 → 点容器 → 真实鼠标），一轮最多点 3 次。
          但这个页面的知识点是**点击切换**的 —— 点第 1 下选中、第 2 下取消、
          第 3 下又选中。于是状态被点乱，日志里出现
          「必学 4/5 但 5 条必学资源都已完成」这种自相矛盾的结果
          （读到的其实是上一个知识点的列表）。

        ⚠ 另一个坑：不能用 `active` 类名判断是否切换成功 ——
          真实页面的 active 更新滞后或有别的语义，误判会导致重复点击。
          **可靠的判据是右侧资源列表有没有换**（卡片指纹变化）。

        返回：是否"确定"已经切到目标知识点（指纹变了，或本来就是这个）。
        """
        js = r"""
        (arg) => {
          const [sel, want] = arg;
          const norm = (e) => (e.innerText || e.textContent || '')
              .replace(/\s+/g, ' ').trim();
          const items = [...document.querySelectorAll(sel.topic)];
          let target = null;
          for (const e of items) {
            const r = e.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) continue;
            const t = norm(e).replace(/必学\s*\d+\s*\/\s*\d+/, '').trim();
            if (t.indexOf(want) !== 0) continue;
            target = e; break;
          }
          if (!target) return { ok: false, why: 'not-found' };
          target.scrollIntoView({ block: 'center' });
          const box = target.getBoundingClientRect();
          return { ok: true,
                   x: box.x + Math.min(box.width / 2, 60),
                   y: box.y + box.height / 2 };
        }
        """
        try:
            info = self.driver.page.evaluate(js, [AI_SELECTORS, name]) or {}
        except Exception:
            return False
        if not info.get("ok"):
            return False

        # 只点一次：优先点名字节点（真实页面可点的是里面的名字）
        clicked = False
        try:
            self.driver.page.get_by_text(name, exact=False).first.click(timeout=2000)
            clicked = True
        except Exception:
            pass
        if not clicked:
            try:
                self.driver.page.mouse.click(info["x"], info["y"])
                clicked = True
            except Exception:
                pass
        if not clicked:
            return False

        # 判断是否真的切过去了：等资源列表指纹变化
        if prev_sig is None:
            time.sleep(0.6)
            return True
        end = time.time() + 4.0
        while time.time() < end:
            time.sleep(0.4)
            if self._ai_cards_sig() != prev_sig:
                return True                     # ★ 列表换了 = 切换成功
        # 指纹没变：可能是"本来就在这个知识点上"，也可能是没点中。
        # 两种情况都不该再点（再点就是取消选中），交给调用方按列表内容判断。
        return False

    def _ai_topic_is_active(self, name: str) -> bool:
        try:
            return bool(self.driver.page.evaluate(
                """(arg) => {
                    const [sel, want] = arg;
                    for (const e of document.querySelectorAll(sel.topic)) {
                        if (!/(^|\\s)active(\\s|$)/.test(String(e.className || ''))) continue;
                        const t = (e.innerText || '').replace(/\\s+/g, ' ').trim();
                        if (t.indexOf(want) === 0) return true;
                    }
                    return false;
                }""", [AI_SELECTORS, name]))
        except Exception:
            return False

    # 本地记下"这条跳过了"，避免同一个点不开的卡片被反复重试导致死循环
    def _ai_mark_local_skip(self, name: str) -> None:
        skipped = getattr(self, "_ai_skipped", None)
        if skipped is None:
            skipped = set()
            self._ai_skipped = skipped
        skipped.add(name)
        if len(skipped) >= 50:
            self._ai_skipped = set()

    # ---- 主流程 ----
    def _page_looks_like_quiz(self) -> bool:
        """当前标签页（含 iframe）里有没有作业/试卷控件。"""
        for fr in self._frames():
            try:
                if fr.evaluate(_CX_QUIZ_PAGE_JS):
                    return True
            except Exception:
                continue
        return False

    def _run_single_page_quiz(self, res: CourseResult, t0: float,
                              title: str = "") -> CourseResult:
        """当前页本身就是作业/试卷：直接在当前页交给答题引擎。"""
        if self.client is None:
            self.log("单页模式：当前页是作业/试卷，但没有可用的模型客户端 → 跳过"
                     "（先在设置里填 API Key）")
            res.error = "没有可用的模型客户端"
            res.stopped_reason = "单页模式完成（缺模型）"
            return res
        self.log(f"单页模式：识别到作业/试卷页（{title or '未命名'}）→ 直接在当前页作答")
        try:
            from .agent import SolverAgent
            ag = SolverAgent(
                client=self.client,
                log=lambda s: self.log("      " + str(s)),
                status=self.status,
                auto_submit=self.quiz_submit,
            )
            r = ag.run_web(None, driver=self.driver, pause_for_login=False)
            res.ok = bool(r.ok)
            res.error = str(r.error or "")
        except Exception as e:
            res.error = f"{type(e).__name__}: {str(e)[:120]}"
            self.log(f"✘ 单页作答出错：{res.error}")
        res.stopped_reason = "单页模式完成（作业/试卷）"
        res.seconds = time.time() - t0
        self.log("")
        self.log(f"===== 单页完成：作业/试卷作答{'成功' if res.ok else '未确认'}，"
                 f"用时 {res.seconds:.0f} 秒 =====")
        return res

    def _run_single_page(self, res: CourseResult, speed: float, mute: bool,
                         max_lessons: int, t0: float) -> CourseResult:
        """只处理浏览器当前这一页：视频 / 文档 / 测验 / **讨论**，各跑一遍就停。

        2026-10-26 用户：「能不能做一次单页自动刷题。这些讨论虽然目录已经打勾，
        但是并未真实完成」。目录打勾 / 卡片 `ans-job-finished` 并不完全可信，
        所以单页模式默认**强制处理讨论**（`discuss_force`）。
        """
        title = ""
        try:
            got = self._titles()
            title = (got[0] if got else "").strip()
        except Exception:
            title = ""
        try:
            cur_url = str(self.driver.page.url or "")
        except Exception:
            cur_url = ""
        try:
            cur_title = str(self.driver.page.title() or "")
        except Exception:
            cur_title = ""
        try:
            is_course = bool(self.driver.looks_like_course_url(cur_url))
        except Exception:
            is_course = False

        # ---- 当前页本身就是一份卷子时，直接在当前页作答 ----
        # 2026-10-26 用户：「为什么不能自动读取打开的网页」——他停在
        # mooc2/work/dowork 作业页点「单页自动」，旧逻辑只会说
        # 「不是课程页面」。现在先识别页面类型再分流。
        if not is_course:
            if _EXAM_URL_RE.search(cur_url) or _EXAM_TITLE_RE.search(cur_title):
                self.log("✘ 当前页是考试页面 —— 考试不代做（软件的产品约定）")
                res.error = "考试页面不代做"
                res.stopped_reason = "考试页面不代做"
                return res
            if (_QUIZ_URL_RE.search(cur_url)
                    or re.search(r"作业|测验|答题|试卷|测试", cur_title)
                    or self._page_looks_like_quiz()):
                return self._run_single_page_quiz(res, t0, cur_title)

        self.log("单页模式：只处理浏览器当前这一页，不翻章、不切节")
        n_doc = n_quiz = n_disc = 0
        try:
            n_doc, n_quiz, n_disc = self._cx_process_section(
                res, speed, mute, title or "当前页", {},
                reopen_after_quiz=False,
                force_discuss=bool(getattr(self, "discuss_force", False)))
        except Exception as e:
            res.error = f"{type(e).__name__}: {str(e)[:120]}"
            self.log(f"✘ 单页处理出错：{res.error}")
        res.ok = bool(res.lessons or n_doc or n_quiz or n_disc)
        res.stopped_reason = "单页模式完成"
        res.seconds = time.time() - t0
        self.log("")
        self.log(f"===== 单页完成：{len(res.lessons)} 个视频、{n_doc} 个文档/PPT、"
                 f"{n_quiz} 份测验/作业、{n_disc} 条讨论已回复，"
                 f"用时 {res.seconds:.0f} 秒 =====")
        return res

    def run(self, url: str | None = None, *, speed: float | None = None,
            mute: bool | None = None, auto_next: bool | None = None,
            max_lessons: int | None = None) -> CourseResult:
        speed = config.COURSE_SPEED if speed is None else speed
        mute = config.COURSE_MUTE if mute is None else mute
        auto_next = config.COURSE_AUTO_NEXT if auto_next is None else auto_next
        max_lessons = config.COURSE_MAX_LESSONS if max_lessons is None else max_lessons

        res = CourseResult()
        t0 = time.time()
        try:
            self.status("打开课程页…")

            # ⚠ 只有当用户**明确填了网址**时才导航过去。
            #   否则就用"准备浏览器当前正打开的那一页" —— 用户在「打开浏览器登录」
            #   那一步已经手动进到课程页了，再按配置里的旧网址跳一次，会把页面
            #   带到一个不相干的地方（实测出现过：跳到 singleCourse/knowledgeStudy，
            #   那不是资源列表页，于是报"未播完任意一节"）。
            cur_before = ""
            try:
                cur_before = self.driver.page.url or ""
            except Exception:
                pass
            target = ""
            if url:
                target = self.driver.to_file_url(url) or url
                self.log(f"按你填写的网址打开：{target[:100]}")
                self.driver.open(target)
                self.driver.wait_for_load(extra_ms=600)
            else:
                self.driver.open(None)          # 只接管，不导航
                self.log(f"沿用浏览器当前页面（未填网址）：{cur_before[:100]}")

            self.log(f"页面：{self.driver.page.title()}")
            self.log(f"地址：{self.driver.page.url[:110]}")

            # ★ 先判断"这是不是课程页"，**在开跑之前**就说清楚。
            #   2026-10-23 客户日志：30 次运行有 21 次抓到了百度/个人空间，
            #   2 秒后只得到一句"找不到可播放的视频（当前页面：翻译）"——
            #   客户以为软件坏了，其实是自己没停在课程页上。
            not_course_page = False
            try:
                not_course_page = not self.driver.looks_like_course_url(
                    self.driver.page.url)
            except Exception:
                not_course_page = False
            if not_course_page:
                self.log("⚠ 当前标签页看起来**不是课程页面** —— 请在浏览器里打开"
                         "学习通/智慧树的课程页（能看到左侧目录、右侧视频的那一页），"
                         "或把课程网址填到上面的输入框")

            # ★ 登录页：**最常见**的一种失败（客户 30 次运行里十几次停在 passport2，
            #   每次都是 4 秒后报"找不到可播放的视频（当前页面：用户登录）"，
            #   客户根本不知道是自己没登录）。现在停下来等，登录后自动继续。
            login_page = self._looks_like_login_page()
            if login_page:
                wait_sec = float(getattr(config, "COURSE_LOGIN_WAIT_SEC", 180.0) or 0)
                _wait_txt = (f"{wait_sec / 60:.0f} 分钟" if wait_sec >= 60
                             else f"{wait_sec:.0f} 秒")
                self.log(f"⚠ 当前页面是**登录页** —— 请在浏览器窗口里登录学习通；"
                         f"程序最多等 {_wait_txt}，登录成功后会自动继续")
                self.status("等待登录…")
                deadline = time.time() + max(0.0, wait_sec)
                while time.time() < deadline and self._alive():
                    time.sleep(2.0)
                    if not self._looks_like_login_page():
                        login_page = False
                        self.log("✔ 已登录，继续刷课")
                        break
                if login_page:
                    self.log("⚠ 等待期间没有检测到登录完成")

            # ---- 单页模式：只处理当前这一页（2026-10-26 用户要求）----
            if getattr(self, "single_page", False):
                return self._run_single_page(res, speed, mute, max_lessons, t0)

            # ---- 资源卡片式课程页走单独一条路径 ----
            # 它和播放器式页面不是一套 DOM（资源卡片列表 vs 单个 <video> + 下一节），
            # 强行用老逻辑会"识别不到课时、原地空转"。
            if self._is_resource_card_course():
                self.log("检测到「资源卡片式」课程页，按资源列表模式刷课")
                return self._run_ai_course(res, speed, mute, max_lessons, t0)

            # ---- 超星/学习通 章节任务点式，也走单独一条路径 ----
            # 它的播放器藏在**两层 iframe** 里，而且推进要靠"未完成任务点"
            # （原生 DOM click，不能用 Playwright 的真实鼠标点击）。
            # 老逻辑只在当前层找 <video> + 找「下一节」按钮，对它完全无效。
            if self._is_chaoxing_course():
                self.log("检测到「章节任务点式」课程页（超星/学习通模板），"
                         "按任务点推进模式刷课")
                return self._run_chaoxing_course(res, speed, mute, max_lessons, t0)

            # ---- 学习通新版「横向栏目」章节页，再单独一条路径 ----
            # ⚠ 必须排在 `_is_chaoxing_course()` **后面**：新版页面一个
            #   `.jobCount` 都没有，上面那条判否；而老版页面在课程刷完后
            #   jobCount 也会变 0，靠"有没有 .tabtags/.jobCount"把它们分开。
            # 它的视频藏在「3 学习视频」栏目里 —— 不点开那一条，
            # 页面上根本没有 <video>，通用逻辑只会报"找不到可播放的视频"。
            if self._is_chaoxing_tabs_course():
                self.log("检测到「横向栏目式」章节页（学习通新版），"
                         "按栏目逐条点开播放")
                tabs_res = self._run_chaoxing_tabs_course(
                    res, speed, mute, max_lessons, t0)
                # ★ 2026-10-23：栏目模式是**启发式**认出来的，真机上有两种误判
                #   （用户日志 2026-10-23 19:30~19:35）：
                #     ① 把「目录 / 讨论 / 笔记 / 标注」那排全站导航当成栏目条
                #        （已在 `_is_chaoxing_tabs_course` 里挡掉）；
                #     ② 把「横向视频列表」当成栏目条 —— 点开没有 <video>，
                #        点完「下一节」后又找不到栏目条。
                #   这两次的共同表现是**一节没刷到就整轮放弃**（日志「共 0 节」），
                #   而页面上其实还有 84 条章节目录可以推进。
                #   所以改成：没刷到课时、又不是用户主动停的，就接着往下试
                #   （目录式 → 通用播放器），而不是直接返回。
                if tabs_res.lessons or "用户停止" in str(tabs_res.stopped_reason or ""):
                    return tabs_res
                self.log(f"⚠ 栏目模式没刷到课时（{tabs_res.stopped_reason or '未知原因'}）"
                         " —— 改走目录式/通用模式接着试")
                res = tabs_res          # 保留这一轮已产生的 failed/error 记录

            # ---- 学习通「目录式」章节页（mooc2=1，#coursetree）----
            # ⚠ 必须排在通用逻辑**前面**：这版页面没有 .jobCount / .tabtags /
            #   横向栏目条，上面三条全判否；而它的「下一节」在任务点没做完时
            #   被平台拦着 —— 掉进通用逻辑就是"原地空转"（2026-10-23 真机）。
            if self._is_chaoxing_catalog_course():
                self.log("检测到「目录式」章节页（学习通/泛雅），"
                         "按章节目录逐章推进")
                return self._run_chaoxing_catalog_course(
                    res, speed, mute, max_lessons, t0)

            # ★ 三条专用路径都没认出来 → 用通用播放器模式。
            #
            #   这一行是**诊断用**的（2026-10-23 用户日志里最缺的就是它）：
            #   学习通这类页面一旦漏认，表现一模一样 ——
            #   每节 2 秒判完、「下一节」点不动、原地空转，但从日志里看不出
            #   到底走的是哪条路、页面上有什么。把结构指纹打出来，
            #   下一次日志就能直接定位是"判据太窄"还是"页面真的变了"。
            try:
                _diag = self.driver.page.evaluate(
                    """() => ({
                        host: location.host,
                        jobs: document.getElementsByClassName('jobCount').length,
                        pos: document.querySelectorAll('.posCatalog_select').length,
                        chapters: document.querySelectorAll('.chapter_item').length,
                        iframes: document.querySelectorAll('iframe').length,
                    })""") or {}
            except Exception:
                _diag = {}
            self.log("· 未匹配到专用页面模式，按通用播放器模式刷课"
                     + (f"（{_diag.get('host')}：任务点 {_diag.get('jobs')} / "
                        f"目录项 {_diag.get('pos')} / 章节 {_diag.get('chapters')} / "
                        f"框架 {_diag.get('iframes')}）" if _diag else ""))

            self.log(f"目标倍速：{speed}×（会挑平台提供的、不超过它的最大值）")

            cur_src = ""            # 当前正在播的视频源
            cur_frame = None        # 当前视频所在框架（标题要在它外层找）
            lesson_no = 0           # 「正在学第几节」——只有换源才 +1
            recorded = 0            # 已经记进结果里的节数
            stall = 0
            next_stall = 0               # 「下一节」连续没翻页的次数
            seen_src: set[str] = set()   # 已经记过的视频源（防「下一节」没翻页时重复记）
            while recorded < max_lessons:
                if not self._alive():
                    res.stopped_reason = "用户停止"
                    break

                info = self._probe()
                if not info.get("found"):
                    self.status("等待视频出现…")
                    time.sleep(1.5)
                    info = self._probe()
                    if not info.get("found"):
                        titles = self._titles(cur_frame)
                        if login_page:
                            # 停在登录页 → "找不到视频"是**必然**的，直说原因
                            res.stopped_reason = (
                                "当前停在**登录页**，还没登录 —— 请先在浏览器里"
                                "登录学习通，再点「开始刷课」")
                        elif not_course_page:
                            # 不是课程页时，"找不到视频"是**必然**的 ——
                            # 别让客户去猜「翻译」两个字是什么意思。
                            res.stopped_reason = (
                                "当前标签页不是课程页面 —— 请先在浏览器里打开课程页"
                                "（能看到左侧目录、右侧视频的那一页），"
                                "或把课程网址填到上面的输入框")
                        else:
                            res.stopped_reason = ("页面上找不到可播放的视频"
                                                  + (f"（当前页面：{titles[0]}）"
                                                     if titles else ""))
                        break

                frame = info["_frame"]
                cur_frame = frame
                src = info.get("src") or ""

                # ★ 同一段视频又回来了 = 上一轮的「下一节」根本没翻页。
                #
                #   2026-10-23 真机日志：一节课被记成 3 节（"2% / 9% / 16%"
                #   其实是同一段 9:34 的视频在继续播），最后还报"3 节播完"。
                #   这里直接拦住：这一节不重复记，先试一次目录兜底，
                #   还不动就如实停下（并说清是「下一节」没翻页）。
                if src and src in seen_src:
                    next_stall += 1
                    self.log(f"· 又回到同一段视频 —— 上一轮的「下一节」没有翻页"
                             f"（连续 {next_stall} 次，这一节不重复记）")
                    if next_stall == 1 and self._try_catalog_next():
                        time.sleep(2.0)
                        try:
                            self.driver.wait_for_load(extra_ms=800)
                        except Exception:
                            pass
                        continue
                    if next_stall >= 2:
                        res.stopped_reason = ("「下一节」点了没翻页：视频还是同一段"
                                              "（已试过从目录点下一条）")
                        break
                    time.sleep(3.0)
                    continue

                # ---- 换节：只有视频源真的变了才算新的一节 ----
                if src and src != cur_src:
                    cur_src = src
                    lesson_no += 1
                    stall = 0
                    titles = self._titles(frame)
                    title = titles[0] if titles else ""
                    self.log(f"—— 第 {lesson_no} 节：{title or '(标题未取到)'} ——")
                    self.status(f"第 {lesson_no} 节播放中…")

                    # 换节后重新调一次倍速（有的平台每节重置）
                    sp_info = self._find_speed()
                    real, note = self._apply_speed(speed, sp_info, frame)
                    if note:
                        self.log(f"· {note}")
                    if real:
                        self._rate_actual = real

                # 静音 + 起播（倍速不在这里改）
                if info.get("paused"):
                    self._setup(frame, mute)

                # ---- 播放监控 ----
                cur = float(info.get("currentTime") or 0)
                dur = float(info.get("duration") or 0)
                t_start = time.time()
                waited = 0.0
                last_pos = cur
                stalled_since = 0.0
                finished = False
                # 平台进度是否已被判定为"读错了"（见下面那段矛盾判据）。
                # 只对**这一节**生效，换节后重新置 False。
                pprog_ignored = False
                # 「播放器到头、平台没记满」时已经拨回去补看过几次（每节独立）
                rewind_tries = 0
                # 防挂机（同 `_ai_play_video` 里的那份说明：
                # 只做"证明有人在"的最小动作，不伪造进度、不上报心跳）
                keepalive = KeepAlive(
                    page=self.driver.page,
                    interval=config.COURSE_KEEPALIVE_SEC,
                    log=self.log,
                    enabled=config.COURSE_KEEPALIVE,
                )

                while True:
                    if not self._alive():
                        res.stopped_reason = "用户停止"
                        break
                    time.sleep(config.COURSE_POLL_SEC)
                    waited += config.COURSE_POLL_SEC

                    # ★ 课中弹题：智慧树/学习通会在播放途中弹题，并**把视频按停**。
                    #   这段处理原来只写在 `_ai_play_video()` 里，而智慧树这门课
                    #   走的是通用播放器模式 —— 弹窗挂在那儿没人管，日志里只有
                    #   「进度卡在 508s 超过 45 秒」，一直耗到平台结算。
                    _handled, _qwhy = self._handle_video_quiz(speed)
                    if _handled:
                        if _qwhy == "stopped":
                            res.stopped_reason = "用户停止"
                            break
                        if _qwhy == "timeout":
                            # 只结束**这一节**，不把整轮刷课停掉：
                            # 判据可能是误命中，后面还有别的章节要刷。
                            self.log("  · 本节按未播完处理，继续下一节")
                            break
                        # 答完继续看这一节：把"卡住"计时清零，别立刻又判卡住
                        last_pos = cur
                        stalled_since = waited
                        self.status(f"第 {lesson_no} 节播放中…")
                        continue

                    # ★ 平台反作弊弹窗：出现就**立刻停**，别硬跑。
                    #
                    #   2026-10-23 智慧树《大学生心理健康》真机：
                    #   自动答完课中弹题后，平台盖上「检测到异常脚本，
                    #   请您关闭插件后，回到学堂重新进入视频学习页」。
                    #   继续跑只会让这个账号更危险，而且这一页已经被标记，
                    #   播多久都不会被记 —— 不如如实停下、把话说清楚。
                    _flag = self._detect_anti_cheat()
                    if _flag:
                        res.stopped_reason = (
                            "平台弹出反作弊提示（检测到异常脚本）—— 已立即停止。"
                            "请关掉弹窗，回课程目录后重新进入这一节视频；"
                            "若再次出现，请到设置里关掉「课中弹题自动作答」"
                            "并把倍速设为 1.0× 再试")
                        self.log("⚠⚠ 平台提示「检测到异常脚本」—— 本轮立即停止"
                                 "（继续播放既不会被记进度，也可能连累账号）")
                        self.log(f"   触发位置：{_flag}")
                        break

                    p = self._probe()
                    if not p.get("found"):
                        break                   # 视频消失，可能已自动翻页
                    if src and (p.get("src") or "") != src:
                        break                   # 已经换节
                    cur = float(p.get("currentTime") or 0)
                    dur = float(p.get("duration") or dur or 0)
                    if p.get("paused") and not p.get("ended"):
                        self._setup(p["_frame"], mute)

                    # ★★★ 平台进度优先于播放位置 ★★★
                    #
                    # 这是补上"以平台记录的进度为完成判据"这条铁律的最后一段。
                    # 原来这里只认 `cur / dur >= 0.98` 和 `ended` —— 都是**猜**：
                    # 播放器到结尾 ≠ 平台记上了。真机上见过视频播到 98%、
                    # 平台「必学 4/6」纹丝不动，于是这一节被反复重刷。
                    #
                    # 现在每轮都问一次适配器"平台自己说学完没有"：
                    #   · 平台说完成  → 直接算完成（比播放位置更权威）
                    #   · 平台读不到  → 返回 found=False，**行为与改动前完全一致**
                    #     （这点很重要：不能让未知页面因为这次改动而变差）
                    pprog = self._platform_progress()

                    # ★ 防御：平台说"这一节已完成"，可视频才放到 2% ——
                    #   那这条进度八成是在数**整门课**（比如"还剩 0 个任务点"），
                    #   不是"这一节学完了"。2026-10-23 的真机日志就是这样：
                    #   每节 2 秒判完、一节课被记成 3 节，然后「下一节」永远
                    #   点不动（平台见你没看完，本来就不放行）。
                    #   只在**刚开播那几秒**出现明显矛盾时才忽略它，
                    #   并且会打一行日志说明，不会悄悄改行为。
                    if (pprog.complete and not pprog_ignored
                            and not p.get("ended")
                            and dur >= 30 and cur >= 0
                            and cur / dur < 0.8 and waited <= 5.0):
                        pprog_ignored = True
                        self.log(f"· ⚠ 平台进度说这一节已完成，但视频只放到 "
                                 f"{cur:.0f}s/{dur:.0f}s —— 这条进度可能是在数"
                                 f"整门课，改按播放进度继续")
                    if pprog.complete and not pprog_ignored:
                        finished = True
                        self.log(f"· 平台进度显示这一节已完成（{pprog.describe()}）")
                        break

                    # ★★★ 播放器到头 ≠ 平台记满 ★★★
                    #
                    # 2026-10-23 真机日志（智慧树 12:05）：这一节一进来就是
                    # 00:13:51/00:13:51，2 秒判「已播完」切走，可侧栏写着 73%
                    # —— 平台根本没记满，用户说的就是「不刷完自动切下一个」。
                    # 只要读得到平台的百分比，就以它为准（读不到就走下面的老判据）。
                    if p.get("ended") or (dur and cur / dur >= config.COURSE_DONE_RATIO):
                        sp = self._sidebar_progress()
                        pct_now = sp.get("pct") if sp.get("ok") else None
                        if pct_now is not None and pct_now < _PLATFORM_PCT_DONE:
                            if rewind_tries < _REWIND_TRIES:
                                rewind_tries += 1
                                self.log(
                                    f"· ⚠ 播放器已到头，但平台只记了 {pct_now}%"
                                    f"（{str(sp.get('text') or '')[:36]}）—— 不算播完，"
                                    f"拨回 {pct_now}% 处继续看"
                                    f"（第 {rewind_tries}/{_REWIND_TRIES} 次）")
                                rw = self._seek_to_platform_pct(p["_frame"], pct_now)
                                if rw.get("ok"):
                                    self._setup(p["_frame"], mute)
                                    last_pos = float(rw.get("t") or 0)
                                    stalled_since = waited
                                    continue
                                self.log("  · 拨回去失败（播放器不认 currentTime）"
                                         " —— 退回按播放位置判")
                            else:
                                self.log(
                                    f"· ⚠ 补看 {_REWIND_TRIES} 次，平台仍只记 "
                                    f"{pct_now}% —— 这一节**不判已播完**，先停在这里")
                                res.stopped_reason = (
                                    f"平台进度停在 {pct_now}%（播放器已到头），"
                                    f"为避免「假播完」先停下 —— 可以手动把这一节"
                                    f"看完，再点开始接着刷")
                                break
                        elif pct_now is not None:
                            self.log(f"· 平台进度确认这一节已完成"
                                     f"（{str(sp.get('text') or '')[:36]}）")

                    if p.get("ended"):
                        finished = True
                        break
                    if dur and cur / dur >= config.COURSE_DONE_RATIO:
                        finished = True
                        break
                    if cur > last_pos + 0.2:
                        # ⚠ 这一行原来**根本不存在** —— 上一版只声明了
                        #   `last_pos = cur` 就再没更新过它。
                        #   于是 `cur > last_pos + 0.2` 永远为假，
                        #   下面那个"卡住就重播"的 elif **永远进不去**，
                        #   等于这个容错逻辑是死的。现在补上更新。
                        last_pos = cur
                        stalled_since = waited
                        keepalive.tick()      # 视频在前进 → 顺手做一次保活检查
                    elif waited - stalled_since > config.COURSE_STALL_SEC:
                        self.log(f"· 进度卡在 {cur:.0f}s 超过 "
                                 f"{config.COURSE_STALL_SEC:.0f} 秒，尝试重新起播…")
                        self._setup(p["_frame"], mute)
                        stalled_since = waited
                        # 重播也算一次动作，重置保活计时
                        keepalive.poke()
                    if waited > config.COURSE_MAX_WAIT_MIN * 60:
                        self.log(f"· 单节等待超过 {config.COURSE_MAX_WAIT_MIN} 分钟，跳过")
                        break

                secs = time.time() - t_start
                rate_used = float(getattr(self, "_rate_actual", 0) or 0)
                lesson = LessonResult(
                    index=lesson_no,
                    title=(self._titles(cur_frame) or [""])[0],
                    seconds=round(secs, 1),
                    duration=round(dur, 1),
                    rate=rate_used,
                    finished=finished,
                    note="" if finished else (
                        "已播放到结尾" if (cur and dur and cur / dur >= 0.9)
                        else f"未完成（到 {cur:.0f}s / {dur:.0f}s）"),
                )
                res.lessons.append(lesson)
                if src:
                    seen_src.add(src)
                recorded += 1
                pct = f"{cur / dur * 100:.0f}%" if dur else "?"
                self.log(f"  第 {lesson_no} 节结束：{'✔ 已播完' if finished else '⚠ 未播完'}"
                         f"（{pct}，用时 {secs:.0f} 秒）")

                if res.stopped_reason:
                    break

                if not auto_next:
                    res.stopped_reason = "已关闭「自动下一节」"
                    break

                # ---- 点下一节：按钮 → 侧栏目录 → 章节目录，逐条兜底 ----
                #
                # 有的平台**根本没有「下一节」按钮**（智慧树就是），下一节要
                # 从右侧目录里点。用户 2026-10-23：「无法切换下一节是因为他
                # 没有下一节按键，需要在侧栏手动选择」。
                #
                # 2026-10-23 又一条：「刷完不切下一个课题」—— 原来只点第一条
                # 候选，点不动就整轮停下（按钮被遮/被禁用/换了版都会踩到）。
                # 现在每条路都试一遍，并且**每条都复核「视频源真的换了」**，
                # 全都失败才如实停下。
                moved = False
                moved_by = ""
                entry_found = False

                cands = self._find_next() or []
                # 去掉「包着别的候选」的容器（例如整个顶栏的 text 里也含
                # 「下一节」）—— 点容器中心只会点到空白，甚至在真机上点到
                # 别的链接。只点最内层那个按钮。
                cands = [c for c in cands
                         if not any(o is not c and _rect_contains(c, o)
                                    for o in cands)]
                for c in cands[:2]:
                    entry_found = True
                    self.log(f"· 点击「{c['text']}」进入下一节")
                    self.status(f"进入第 {lesson_no + 1} 节…")
                    try:
                        okc = self._click_next(c)
                    except Exception:
                        okc = False
                    self.driver.wait_for_load(extra_ms=800)
                    if okc and self._wait_video_change(src):
                        moved, moved_by = True, f"「{c['text']}」按钮"
                        break
                    self.log(f"· 「{c['text']}」点了没换节 —— 换别的路子再试")

                if not moved:
                    how = self._sidebar_next_lesson()
                    if how:
                        entry_found = True
                        self.log(f"· 侧栏目录：{how}")
                        self.status(f"进入第 {lesson_no + 1} 节…")
                        self.driver.wait_for_load(extra_ms=800)
                        if self._wait_video_change(src):
                            moved, moved_by = True, "侧栏目录"
                        else:
                            self.log("· 侧栏点了也没换节 —— 再试章节目录")
                    else:
                        self.log("· 页面上没有「下一节」按钮，侧栏目录里也没有下一条")

                if not moved:
                    got = self._try_catalog_next()
                    if got:
                        entry_found = True
                        self.driver.wait_for_load(extra_ms=800)
                        if self._wait_video_change(src):
                            moved, moved_by = True, "章节目录"

                if moved:
                    stall = 0
                    self.log(f"· 已换到下一节（{moved_by}）")
                elif not entry_found:
                    res.stopped_reason = ("找不到「下一节」按钮，侧栏目录里也没有下一条了"
                                          "（可能整门课已学完）")
                    break
                else:
                    stall += 1
                    self.log(f"· 等新视频超时（连续 {stall} 次，按钮/侧栏/目录都试过）")
                    if stall >= 3:
                        res.stopped_reason = ("连续多节都没能换成新视频"
                                              "（按钮、侧栏、章节目录都试过），"
                                              "停止以免空转")
                        break

            else:
                res.stopped_reason = f"达到上限 {max_lessons} 节"

            res.ok = any(l.finished for l in res.lessons)
            self.log("")
            done_n = sum(1 for l in res.lessons if l.finished)
            self.log(f"===== 刷课结束：共 {len(res.lessons)} 节，"
                     f"{done_n} 节播完，用时 {time.time() - t0:.0f} 秒 =====")
            if res.stopped_reason:
                self.log(f"停止原因：{res.stopped_reason}")
            # 章节测验的份数单独报一行 —— 只在**答过**的时候报，
            # 没答过测验的课不该多一行「章节测验 0 份」。
            if self.chapter_quiz_done or self.chapter_quiz_failed:
                # ★ 按**真实结局**说，不按开关说。
                #   （2026-10-17 17:18：上一行刚说"没确认交上"，
                #    这一行却报"已交卷"—— 自相矛盾）
                if getattr(self, "last_quiz_blocked", False):
                    how = "⚠ 被验证码拦住，未交卷"
                elif getattr(self, "last_quiz_submitted", False):
                    how = "已交卷"
                elif self.quiz_submit:
                    how = "⚠ 答完了但没确认交上，请手动检查"
                else:
                    how = "已填好、未交卷"
                tail = (f"，{self.chapter_quiz_failed} 份没答成"
                        if self.chapter_quiz_failed else "")
                self.log(f"· 章节测验：{self.chapter_quiz_done} 份答完{tail}（{how}）")
            return res
        except Exception as e:
            # ★ 用户点了停止之后，浏览器可能已经被回收（关窗口 / shutdown_all），
            #   这时任何页面操作都会抛 TargetClosedError / PlaywrightError ——
            #   那是**预期**的，不该报成"出错"。
            #
            #   2026-10-17 13:23 的日志里，一次正常的"用户停止"被记成了
            #     {"ok": false, "error": "TargetClosedError: Page.wait_for_timeout ..."}
            #   看上去像程序崩了，其实是收尾时多动了一下页面。
            _stopped = False
            if self.stop is not None:
                try:
                    self.stop.check()
                except Exception:
                    _stopped = True
            if _stopped:
                res.stopped_reason = res.stopped_reason or "用户停止"
                self.log("⏹ 已停止（收尾阶段的页面异常已忽略）")
                return res
            res.error = f"{type(e).__name__}: {e}"
            self.log(f"✘ 出错：{res.error}")
            return res
        finally:
            try:
                self.driver.close()
            except Exception:
                pass
