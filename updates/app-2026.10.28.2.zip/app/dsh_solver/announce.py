# -*- coding: utf-8 -*-
"""公告：从远端仓库读一个 JSON 文件，在软件里显示给用户。

设计原则（很重要）：
  · **绝不影响主功能**。所有网络动作都在后台线程、有超时、有缓存目录，
    任何异常都吞掉 —— 拉不到公告就当作"没有公告"，答题/刷课照常。
  · **不要求用户联网后台**，也不上报任何信息，只做一次 HTTP GET。
  · 只在用户**真正打开界面**时才顺带刷新一次，不常驻轮询。

远端文件格式（announcements.json）：
{
  "version": 3,
  "updated": "2026-10-14 09:00",
  "items": [
    {"id": "2026-10-14-fix", "title": "标题", "body": "正文",
     "level": "info",              // info | warn | important
     "until": "2026-12-31"}        // 可选，过期就不再显示
  ]
}

作者只需要往仓库里改这个文件，所有用户下次打开软件就能看到。
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from . import config

# ---------------------------------------------------------------------------
# 远端位置
#
# 设计成"仓库叫什么都行"：先按 AUTHOR 账号下的仓库列表**自动找**
# 哪个仓库里有 announcements.json，找到就用它；找不到再回退到
# 下面这个约定名字。这样作者以后想换仓库名也不用改软件。
# ---------------------------------------------------------------------------
AUTHOR = os.environ.get("DSHS_ANNOUNCE_OWNER", "CYBSYC1").strip()
REPO_NAME = os.environ.get("DSHS_ANNOUNCE_REPONAME", "MuRaSame-Study-Assistant").strip()
ANNOUNCE_FILE = os.environ.get("DSHS_ANNOUNCE_FILE", "announcements.json").strip()

# 约定仓库（找不到其它就用它）
DEFAULT_REPO = f"{AUTHOR}/{REPO_NAME}"

# 运行时可被覆盖（announce_check.py 就靠这个临时换仓库）
REPO = os.environ.get("DSHS_ANNOUNCE_REPO", "").strip() or DEFAULT_REPO
FILE = ANNOUNCE_FILE

# 本地缓存（离线也能看到上次拉到的公告）
CACHE_FILE = config.OUT_DIR / "announcement_cache.json"
SEEN_FILE = config.OUT_DIR / "announcement_seen.json"

TIMEOUT = 8            # 兼容旧名（别再直接用，用下面分档的）
# ⚠ 为什么要分档：原来所有通道都用 8 秒，而候选有 5 个通道 × 2 个分支 = 10 次，
#   全失败时实测要等 **36.9 秒** —— 用户会觉得软件卡死了。
#   分档之后：
#     · 代理：3 秒足够（实测都是百毫秒级返回，3 秒还没回来说明它挂了）
#     · API：4 秒（要跑 JSON 编解码）
#     · raw 直连：国内基本连不上，给 4 秒纯属碰运气，不该拖累整体
TIMEOUT_CALL = 4       # API / raw 直连
TIMEOUT_PROXY = 3      # 加速代理
TIMEOUT_DISCOVER = 5   # 自动发现仓库时列目录（只跑一次）
CACHE_TTL = 600        # 10 分钟内不重复请求（作者改完公告，用户很快就能看到）

# 自动发现的结果缓存（同一次运行里不用反复问 API）
_discovered: str | None = None
# 实际命中的分支（仓库默认分支叫 master 时自动纠正，图片路径也跟着对）
_resolved_branch: str = ""


def _branch() -> str:
    """当前认定可用的分支（拉取成功后会被自动纠正）。"""
    env = os.environ.get("DSHS_ANNOUNCE_BRANCH", "").strip()
    if env:
        return env
    return _resolved_branch or "main"


def _branches() -> list[str]:
    """要依次尝试的分支。

    很多人建仓库时默认分支是 master 而不是 main，写死一个分支会导致
    "文件明明在仓库里却拉不到"。环境变量 DSHS_ANNOUNCE_BRANCH 可强制指定。
    """
    env = os.environ.get("DSHS_ANNOUNCE_BRANCH", "").strip()
    if env:
        return [env]
    if _resolved_branch:
        return [_resolved_branch]           # 已经知道哪个对了，不用再试
    return ["main", "master"]


def _channels_for(repo: str, branch: str | None = None
                  ) -> list[tuple[str, str]]:
    """按"大概率最快"排序的读取通道。

    返回 `[(类别, url), ...]`，类别取值：
      · `"proxy"` 加速代理（有响应，404 说明文件真的不在）
      · `"api"`   GitHub contents API（未登录 60 次/小时/整栋楼，很容易 403）
      · `"raw"`   raw.githubusercontent 直连（国内常被重置）

    ⚠ 为什么要把类别带出来：不同类别该给不同超时，也影响"哪个错误最可信"。
      实测（2026-10，中国大陆）：
        · 加速代理 ghfast.top    ✔ 通、最快 —— 首选
        · 加速代理 gh-proxy.com  ✔ 通 —— 备用
        · raw.githubusercontent  ✘ 连接被重置，只当最后碰运气
        · GitHub API 直连        ✔ 偶尔通，但极易 403，排在代理后面

    顺序：代理1 → 代理2 → 代理3 → API → raw 直连。
    代理放前面是因为它们**既能反映真实状态（404 可信）又不受限流影响**。
    """
    br = branch or _branch()
    raw = f"https://raw.githubusercontent.com/{repo}/{br}/{FILE}"
    api = f"https://api.github.com/repos/{repo}/contents/{FILE}?ref={br}"
    return [
        ("proxy", f"https://ghfast.top/{raw}"),
        ("proxy", f"https://gh-proxy.com/{raw}"),
        ("proxy", f"https://ghproxy.net/{raw}"),
        ("api", api),
        ("raw", raw),
    ]


# 单条分支里，代理那一档的通道数（用来判断"是不是三个代理都试完了"）。
_PROXY_COUNT = 3


def _channels() -> list[tuple[str, str]]:
    """当前仓库的通道表（带类别）。保留给诊断脚本用。"""
    return _channels_for(REPO)


def raw_base() -> str:
    """仓库里"原始文件"的基地址，用于把公告里的**相对图片路径**拼成可访问 URL。

    优先走加速代理 —— 实测 raw.githubusercontent 在国内不通。
    """
    return (f"https://ghfast.top/https://raw.githubusercontent.com/"
            f"{REPO}/{_branch()}/")


def discover_repo() -> str | None:
    """在作者账号下的公开仓库里找哪个含有公告文件。

    为什么需要：作者不用记住"仓库必须叫什么名字"，随便建一个、
    把 announcements.json 放进去就行。找不到就返回 None。

    ⚠ 这条路依赖 GitHub API（`/users/<name>/repos`），而未登录时它是
      **60 次/小时/出口 IP** —— 很容易已经 403。所以：
        · 它只是"锦上添花"，`REPO`（默认约定的那个）始终是第一选择；
        · 403 时**安静返回 None**，不要因此把整体流程变慢或变吵。
    """
    global _discovered
    if _discovered:
        return _discovered
    try:
        req = urllib.request.Request(
            f"https://api.github.com/users/{AUTHOR}/repos"
            f"?per_page=100&sort=updated",
            headers={"User-Agent": "MSM-Homework-Helper",
                     "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(req, timeout=TIMEOUT_DISCOVER) as r:
            repos = json.loads(r.read().decode("utf-8", "replace"))
        if not isinstance(repos, list):
            return None
        for rp in repos:                       # 已按最近更新排序
            if rp.get("private"):
                continue
            full = rp.get("full_name") or ""
            if not full:
                continue
            data, _ = fetch_from(full)
            if data is not None:
                _discovered = full
                return full
    except Exception:
        return None
    return None


# ---------------------------------------------------------------------------
# 图片支持
#
# 单条公告可以带图，三种写法都行：
#   "image": "data:image/png;base64,..."   ← 内嵌（推荐：一次请求全拿到，离线也能看）
#   "image": "img/notice1.png"             ← 仓库里的相对路径，自动拼成 raw 地址
#   "image": "https://xxx/x.png"           ← 外链
# 另外支持 "images": [ ... ] 放多张。
# ---------------------------------------------------------------------------
MAX_IMAGE_CHARS = 4 * 1024 * 1024      # 单张图（base64 后）上限，防手滑塞进巨图


def _resolve_image(src: Any) -> str:
    """把图片字段规整成能直接塞进 <img src> 的值。"""
    s = str(src or "").strip()
    if not s:
        return ""
    if len(s) > MAX_IMAGE_CHARS:
        return ""                        # 太大：宁可不显示，也不拖垮界面
    low = s.lower()
    if low.startswith(("http://", "https://", "data:image/")):
        return s
    return raw_base() + s.lstrip("./")   # 相对路径 → 仓库 raw 地址


def _fetch_once(url: str, timeout: float | None = None) -> dict[str, Any] | None:
    req = urllib.request.Request(
        url, headers={"User-Agent": "MSM-Homework-Helper",
                      "Accept": "application/vnd.github+json, application/json"})
    with urllib.request.urlopen(req, timeout=timeout or TIMEOUT) as r:
        raw = r.read()
    if not raw:
        return None
    data = json.loads(raw.decode("utf-8", "replace"))
    # GitHub contents API 返回的是 {content: base64, encoding: base64}
    if isinstance(data, dict) and data.get("content") and data.get("encoding") == "base64":
        import base64
        text = base64.b64decode(data["content"]).decode("utf-8", "replace")
        return json.loads(text)
    return data if isinstance(data, dict) else None


def _http_reason(e: urllib.error.HTTPError) -> str:
    """把 HTTP 错误翻译成**能指导下一步**的原因。

    ⚠ 为什么不能只写 "HTTP 403"：
      GitHub API 未登录时按**出口 IP** 限流 60 次/小时 ——
      一栋楼、一个公司出口很容易用光。用户看到 403 完全不知道该干什么，
      而正确动作其实很明确："这条通道不必管它，代理通道不受影响"。
      所以这里读一下响应体，把"限流"和"权限/私有仓库"区分开。
    """
    code = e.code
    if code == 404:
        # 代理通道返回 404 是**可信**的：说明仓库在，但文件/分支不对
        return "HTTP 404（文件或分支不存在）"
    if code == 403:
        body = ""
        try:
            body = e.read()[:300].decode("utf-8", "replace").lower()
        except Exception:
            pass
        if "rate limit" in body or "limit exceeded" in body:
            return "HTTP 403（GitHub API 限流，换代理通道即可）"
        return "HTTP 403（被拒绝：可能是私有仓库或触发了风控）"
    if code in (401,):
        return "HTTP 401（需要登录/令牌）"
    if code >= 500:
        return f"HTTP {code}（GitHub 或代理服务端故障，稍后再试）"
    return f"HTTP {code}"


def _error_rank(reason: str) -> int:
    """失败原因的可信度排序 —— **数字越小越可信**。

    ⚠ 原来的 bug：`fetch_from` 返回的是**循环里最后一个**异常。
      于是"三个代理都 404（文件没上传）"最后会被报成
      `URLError`（最后一个 raw 直连连不上），
      作者按提示会去查网络 —— 方向完全反了，
      真实原因是"文件没提交"。

      可信度：404（明确的"文件不在"）> 403（限流/权限）> 其它 HTTP > 网络错误
    """
    r = str(reason)
    if "404" in r:
        return 0
    if "403" in r:
        return 1
    if "401" in r:
        return 2
    if r.startswith("HTTP"):
        return 3
    # 网络类（URLError / TimeoutError / ConnectionReset…）最不可信：
    # 它只说明"这条通道连不上"，不代表文件不在
    return 9


def fetch_from(repo: str) -> tuple[dict[str, Any] | None, str]:
    """从指定仓库依次试各通道，返回 (数据, 说明)。

    分支会依次试 main / master；哪个通道先成功就记下分支，
    公告里的相对图片路径也按这个分支拼。

    ⚠ 失败时返回的是**最可信**的原因，不是最后一个（见 `_error_rank`）。
    """
    global _resolved_branch
    best: str = ""          # 最可信的失败原因
    last: str = ""          # 最后一次失败原因（仅作兜底）
    tried = 0
    early_exit = False
    for branch in _branches():
        got_404 = 0         # 本条分支上，代理通道返回了几个 404
        proxy_seen = 0
        for kind, url in _channels_for(repo, branch):
            tried += 1
            try:
                data = _fetch_once(
                    url, TIMEOUT_PROXY if kind == "proxy" else TIMEOUT_CALL)
                if data is not None:
                    _resolved_branch = branch
                    return data, url.split("/")[2]
            except urllib.error.HTTPError as e:
                r = _http_reason(e)
                last = r
                if "404" in r:
                    got_404 += 1
                if not best or _error_rank(r) < _error_rank(best):
                    best = r
            except Exception as e:
                last = type(e).__name__      # 超时 / 连接被重置
                # 网络类原因**不参与**可信度竞争
            finally:
                if kind == "proxy":
                    proxy_seen += 1
                # ---- 提前收工（必须写在 finally 里！）----
                #
                # ⚠ 这是一个很隐蔽的坑：一开始我把判断写在循环体末尾，
                #   结果**永远不生效** —— 因为上面两个 except 分支末尾都有
                #   `continue`，而 `finally` 先执行、`continue` 随后就跳过了
                #   循环体剩余部分。实测就是"10 条通道全试完、
                #   耗时 13 秒"，而逐条累加其实只要 5.8 秒。
                #
                #   为什么可以收工：代理返回 404 是**权威**的
                #   （仓库在、文件真不在），再试 API / raw 也一定拿不到。
                if (kind == "proxy" and proxy_seen >= _PROXY_COUNT
                        and got_404 >= _PROXY_COUNT):
                    last = last or "HTTP 404（文件或分支不存在）"
                    early_exit = True
        if early_exit:
            break
    if best:
        return None, best
    return None, (last or (f"没有可用通道（试了 {tried} 次）"))


def probe_from(repo: str) -> list[tuple[str, str, str]]:
    """逐个通道试一遍，**不做降级、不写缓存**，只为诊断。

    返回 [(分支, 通道URL, 结果说明), ...]，结果说明形如：
      "OK"                        读到了
      "HTTP 404（文件或分支不存在）"  仓库在但文件没上传 / 分支不对
      "HTTP 403（GitHub API 限流…）" 这条通道不用管，代理通道不受影响
      "URLError"                  网络不通（超时 / 连接被重置）
    """
    rows: list[tuple[str, str, str]] = []
    for branch in _branches():
        for kind, url in _channels_for(repo, branch):
            try:
                data = _fetch_once(
                    url, TIMEOUT_PROXY if kind == "proxy" else TIMEOUT_CALL)
                rows.append((branch, url, "OK" if data is not None else "空内容"))
            except urllib.error.HTTPError as e:
                rows.append((branch, url, _http_reason(e)))
            except Exception as e:
                rows.append((branch, url, type(e).__name__))
    return rows


def fetch_remote() -> tuple[dict[str, Any] | None, str]:
    """从"作者账号下任意含公告的仓库"拉取。

    顺序：
      ① 约定仓库名（DEFAULT_REPO）—— 命中的话最快
      ② 自动发现：在作者账号的公开仓库里找哪个有公告文件
         （这样作者仓库叫什么都行，换名字也不用改软件）
    """
    global REPO
    data, source = fetch_from(REPO)
    if data is not None:
        return data, source

    found = discover_repo()
    if found and found != REPO:
        data2, source2 = fetch_from(found)
        if data2 is not None:
            REPO = found                  # 后续图片相对路径也按这个仓库拼
            return data2, source2
    return None, source


# ---------------------------------------------------------------------------
def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, obj: Any) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    except Exception:
        pass


def _valid_items(data: dict) -> list[dict]:
    """把远端数据规整成可显示的条目，并剔掉过期的。"""
    items = data.get("items")
    if not isinstance(items, list):
        return []
    today = time.strftime("%Y-%m-%d")
    out = []
    for it in items:
        if not isinstance(it, dict):
            continue
        title = str(it.get("title") or "").strip()
        body = str(it.get("body") or "").strip()
        if not title and not body:
            continue
        until = str(it.get("until") or "").strip()
        if until and until < today:          # 已过期
            continue
        out.append({
            "id": str(it.get("id") or f"{title[:20]}-{until}"),
            "title": title[:80],
            "body": body[:2000],
            "level": str(it.get("level") or "info"),
            "until": until,
            "image": _resolve_image(it.get("image")),
            "images": [x for x in (
                _resolve_image(v) for v in (it.get("images") or [])
            ) if x][:6],
        })
    return out


def _seen_state() -> dict:
    """读整个「公告状态」文件（已读 id + 用户偏好）。"""
    st = _read_json(SEEN_FILE)
    return st if isinstance(st, dict) else {}


def _seen_ids() -> set[str]:
    ids = _seen_state().get("ids")
    return set(ids) if isinstance(ids, list) else set()


def mark_seen(ids: list[str]) -> None:
    cur = _seen_ids()
    cur.update(str(i) for i in ids)
    # ⚠ **不能整份覆写** —— 这个文件里还存着 muted（"下次不再提示"）。
    #   写成 `_write_json(SEEN_FILE, {"ids": ...})` 的话，
    #   用户点一次「确认」就把自己勾的"下次不再提示"抹掉了，
    #   下次开软件又弹 —— 而他明明勾过，只会觉得"勾了没用"。
    st = _seen_state()
    st["ids"] = sorted(cur)[-200:]                          # 只留最近 200 条
    _write_json(SEEN_FILE, st)


def is_muted() -> bool:
    """用户是不是选过「下次不再提示」。"""
    return bool(_seen_state().get("muted"))


def set_muted(muted: bool) -> None:
    """记住/取消「下次不再提示」。同样**整份读改写**，保住 ids。"""
    st = _seen_state()
    st["muted"] = bool(muted)
    _write_json(SEEN_FILE, st)


def get_announcement(force: bool = False, *, allow_network: bool = True) -> dict:
    """取公告（给界面用）。

    返回：
      {"items": [...], "unread": [...], "updated": "...", "source": "..."}
      items  = 全部（未过期）
      unread = 其中用户还没点过"知道了"的
      muted  = 用户勾过「下次不再提示」→ 界面**不要自动弹窗**
               （顶部横幅与左边栏公告页照旧，只是不主动打断）
    """
    cache = _read_json(CACHE_FILE)
    fresh = False
    try:
        fresh = (time.time() - float(cache.get("_fetched_at") or 0)) < CACHE_TTL
    except Exception:
        fresh = False

    if allow_network and (force or not fresh):
        data, source = fetch_remote()
        if data is not None:
            cache = dict(data)
            cache["_fetched_at"] = time.time()
            cache["_source"] = source
            _write_json(CACHE_FILE, cache)
        # 拉不到就沿用旧缓存（离线也能看上次的公告）

    items = _valid_items(cache)
    seen = _seen_ids()
    muted = is_muted()
    unread = [i for i in items if i["id"] not in seen]
    return {
        "items": items,
        "unread": unread,
        "muted": muted,
        "updated": str(cache.get("updated") or ""),
        "source": str(cache.get("_source") or ("缓存" if cache else "")),
    }


# ---------------------------------------------------------------------------
# 测试钩子（生产环境为空，一行都不执行）
#
# ⚠ 必须放在**文件最末尾**。第一版我把它放在 imports 之后（第 51 行），
#   而 `def fetch_from(...)` 在第 311 行 —— 钩子先把 `fetch_from` 换成假的，
#   紧接着模块自己又用 `def` 把它覆盖回真的，**钩子等于没装**。
#   而且因为外面包了 try/except 静默处理，这个错误完全不报，
#   表现是"隔离没生效、测试仍然被真实公告污染" —— 查了很久。
#   （已实测：钩子放在末尾才真正生效。）
#
# 为什么需要它：公告是**真实联网**拉取的，而真实仓库里随时可能真的有公告。
# 这让"验证界面怎么渲染公告"这类用例变得不确定：
#   用例预置 3 条假数据 → 服务的后台预取拿去跟真实仓库一拉 → 覆盖成真实内容
#   → 断言全崩，而且时好时坏（取决于真实仓库当时有没有内容）。
#
# 试过但**不行**的办法：
#   · 只预置缓存       —— 预取用 force=True，照样覆盖
#   · 仓库名指向不存在 —— `fetch_remote` 会 `discover_repo()` 自动找回真实仓库
#   · sitecustomize   —— 嵌入式 Python **不加载** sitecustomize，实测无效
#
# 用法：设置 DSHS_TEST_FETCH_PY 指向一个 .py 文件，它需提供 `install(module)`。
_TEST_HOOK = os.environ.get("DSHS_TEST_FETCH_PY", "").strip()
if _TEST_HOOK:
    try:
        import importlib.util as _ilu
        _spec = _ilu.spec_from_file_location("_dsh_test_fetch", _TEST_HOOK)
        if _spec and _spec.loader:
            _mod = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
            if hasattr(_mod, "install"):
                _mod.install(__import__(__name__, fromlist=["x"]))
    except Exception:
        # 钩子失败绝不能影响主流程 —— 它只是测试便利设施。
        # ⚠ 但**不要**在这里彻底静默：把原因写进 stderr，
        #   否则钩子坏了也看不出来（我正是被这一点坑了半天）。
        import sys as _sys
        import traceback as _tb
        print("[announce] 测试钩子加载失败：", file=_sys.stderr)
        _tb.print_exc(file=_sys.stderr)

