"""预算护栏：进程级「调用次数 / Token / 估算成本」上限。

为什么需要（作者在 v1.1.0 交付说明里承认没做 A3）：
  `usage.py` 只做事后统计（落盘 out\\usage.json），**没有任何闸门**。
  一份 40 题的卷子加上补问可能产生几十次云端请求，用户只能事后看统计，
  没有"花到某个数就停"的保险。

做法：
  · 闸门只装在 `lms.py::chat()` —— 那是**所有模型请求的唯一漏斗**。
  · 基线 = 首次 `check()/status()` 时 `usage.meter().snapshot()["totals"]` 的快照。
    meter 会先把历史 out\\usage.json 载入，所以必须减掉基线，
    剩下的增量（calls / total_tokens / cost_est）才是"本次运行"的。
  · 上限来自 config（环境变量 DSHS_MAX_CALLS / DSHS_MAX_TOKENS /
    DSHS_MAX_COST_CNY），**默认全 0 = 不限制**：此时 check() 直接返回，
    不碰 meter、不建基线，零副作用。
  · **fail-open**：本模块任何内部异常都按"未超限"处理，绝不因为护栏自己
    出问题而挡住正常请求。唯一对外抛出的异常是 BudgetExceeded。

不做的事（别误读）：
  · **进程级**，不是按天：重启即归零，不是"每日额度"。
  · **不是账单**：cost_est 只是按 usage.py 内置单价估算，实际扣费以服务商为准。
  · 只拦 lms.chat，不拦公告检查 / 余额查询这类非模型网络请求。
"""
from __future__ import annotations

import threading

from . import config

# 0 / 0.0 表示"该维度不限制"。
_ZERO_LIMITS = {"calls": 0, "tokens": 0, "cost_cny": 0.0}
_ZERO_USED = {"calls": 0, "tokens": 0, "cost_cny": 0.0}

# 进程起点快照（None = 还没取过；reset() 会清回 None）。
_baseline_totals: dict | None = None
_lock = threading.RLock()


class BudgetExceeded(Exception):
    """本次运行已超出预算上限。str(e) 是可直接展示给用户的中文说明。"""


# ------------------------------------------------------------------ 内部
def _as_int(v) -> int:
    try:
        return max(0, int(v))
    except (TypeError, ValueError):
        return 0


def _as_float(v) -> float:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    # NaN / ±Inf 都当 0，避免把比较搞乱
    if f != f or f in (float("inf"), float("-inf")):
        return 0.0
    return f


def _current_totals() -> dict:
    """读 meter() 的当前累计。

    ⚠ `meter()` 单例在 **lms.py** 里（usage.py 只定义 UsageMeter 类）。
    这里用**函数内延迟 import**，绝不放在模块顶层：lms 顶层 `import usage`，
    而 budget 又是在 `lms.chat()` 里被 import 的，顶层 import lms 会成环。
    运行时 lms 早已完整加载（预算检查只从 lms.chat 进入），不成环。
    """
    try:
        from . import lms
        totals = (lms.meter().snapshot() or {}).get("totals") or {}
    except Exception:
        return dict(_ZERO_USED)
    return {
        # snapshot 的字段名：calls / total_tokens / cost_est
        "calls": _as_int(totals.get("calls")),
        "tokens": _as_int(totals.get("total_tokens")),
        "cost_cny": _as_float(totals.get("cost_est")),
    }


def _baseline() -> dict:
    """进程起点快照：第一次调用时取一次，之后一直复用。"""
    global _baseline_totals
    with _lock:
        if _baseline_totals is None:
            _baseline_totals = _current_totals()
        return dict(_baseline_totals)


def _enabled(lim: dict) -> bool:
    return lim["calls"] > 0 or lim["tokens"] > 0 or lim["cost_cny"] > 0.0


def _fmt_money(v: float) -> str:
    """0.001 → '0.001'；1.0 → '1'。别让浮点尾巴出现在给用户看的消息里。"""
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    return s or "0"


def _reasons(lim: dict, used: dict) -> list[str]:
    """把超限的维度变成可操作的中文说明（每条都带环境变量名）。"""
    out: list[str] = []
    if lim["calls"] and used["calls"] >= lim["calls"]:
        out.append(
            f"本次运行已调用 {used['calls']} 次模型（上限 {lim['calls']} 次）。"
            "要提高上限：设置环境变量 DSHS_MAX_CALLS 后重启，"
            "或把它设为 0 关闭次数限制"
        )
    if lim["tokens"] and used["tokens"] >= lim["tokens"]:
        out.append(
            f"本次运行已消耗 {used['tokens']} tokens（上限 {lim['tokens']}）。"
            "要提高上限：设置环境变量 DSHS_MAX_TOKENS 后重启，"
            "或把它设为 0 关闭 token 限制"
        )
    if lim["cost_cny"] and used["cost_cny"] + 1e-9 >= lim["cost_cny"]:
        out.append(
            f"本次运行估算花费 ¥{_fmt_money(used['cost_cny'])}"
            f"（上限 ¥{_fmt_money(lim['cost_cny'])}）。"
            "要提高上限：设置环境变量 DSHS_MAX_COST_CNY 后重启，"
            "或把它设为 0 关闭费用限制"
        )
    return out


# ------------------------------------------------------------------ 公开 API
def limits() -> dict:
    """当前上限：calls（次）/ tokens（输入+输出）/ cost_cny（元）；0 = 不限制。"""
    try:
        return {
            "calls": _as_int(getattr(config, "BUDGET_MAX_CALLS", 0)),
            "tokens": _as_int(getattr(config, "BUDGET_MAX_TOKENS", 0)),
            "cost_cny": _as_float(getattr(config, "BUDGET_MAX_COST_CNY", 0.0)),
        }
    except Exception:
        return dict(_ZERO_LIMITS)


def status() -> dict:
    """已用 / 上限 / 是否超限 / 原因。供日志与 /api/budget 使用。

    ⚠ 任何内部异常都退化成"未超限"，**绝不向外抛** —— 这个函数可能在
    后台线程里被调用，护栏自己不能变成新的崩溃源。
    """
    try:
        lim = limits()
        base = _baseline()
        cur = _current_totals()
        used = {
            "calls": max(0, cur["calls"] - base["calls"]),
            "tokens": max(0, cur["tokens"] - base["tokens"]),
            "cost_cny": round(max(0.0, cur["cost_cny"] - base["cost_cny"]), 6),
        }
        reasons = _reasons(lim, used)
        return {
            "enabled": _enabled(lim),
            "limits": lim,
            "baseline": base,
            "used": used,
            "exceeded": bool(reasons),
            "reasons": reasons,
            "reason": "；".join(reasons),
        }
    except Exception:
        return {
            "enabled": False,
            "limits": dict(_ZERO_LIMITS),
            "baseline": dict(_ZERO_USED),
            "used": dict(_ZERO_USED),
            "exceeded": False,
            "reasons": [],
            "reason": "",
        }


def check() -> None:
    """发模型请求前调用：超限抛 BudgetExceeded，否则静默返回。

    · 默认（三个上限全 0）：**第一件事就 return**，不读用量、不建基线，
      所以对现有行为零影响。
    · 任何非 BudgetExceeded 的异常都被吞掉（fail-open）。
    """
    try:
        lim = limits()
        if not _enabled(lim):
            return
        st = status()
        if st.get("exceeded"):
            raise BudgetExceeded(
                "预算护栏已停止继续请求："
                + (st.get("reason") or "本次运行已超出预算上限")
                + "。这只是进程内估算，实际扣费以服务商账单为准。"
            )
    except BudgetExceeded:
        raise
    except Exception:
        # fail-open：护栏自己坏了，也绝不影响正常请求
        return


def reset() -> None:
    """测试/调试用：清掉基线。

    下一次 check()/status() 会拿"现在"的累计当新起点，相当于本次运行重新计数。
    """
    global _baseline_totals
    with _lock:
        _baseline_totals = None
