# -*- coding: utf-8 -*-
r"""网课「课中弹题」的自动作答。

## 这个模块解决什么

网课放到一半会弹一道题，答完才让继续。`course.py` 原本只做
"检测 → 暂停计时 → 等用户手动答 → 继续播"。

这里补上**自动作答**，并且**兼顾智慧树与学习通（超星）**两家。

## 为什么不能直接复用作答模块那套 `scan()`

`BrowserDriver.scan()` 是**扫整页**（还会遍历所有 iframe）——
那是为作业页设计的。网课播放页上可能同时有：
播放器、章节目录、讨论区、**以及一堆作业题**。

直接用它扫，会把整页的题都收进来，然后"答"到跟弹题无关的控件上。

所以这里做的是**限定范围的扫描**：
从命中的判据元素出发，往上找到"装着这道弹题的那个容器"（最多上溯 4 层），
**只在这个容器里**找题面和选项。

## 两家平台的 DOM（来自实测采集与开源调研）

智慧树：

    .el-dialog                       ← 弹层
      .topic-title                   ← 题面（老版）
      .topic-item                    ← 选项
    新版 AI 弹题装在 .ai-test-question-wrapper / .ai-class-exercise-dialog 里，
    选项是 .topic-item 或 label.el-radio

学习通 / 超星：

    .ans-videoquiz-box               ← 弹题容器
      （题面常是容器里的第一段文字）
      .ans-videoquiz-opt             ← 选项

两家的共同点：**选项都是"块级元素 + 一点选中态"**，
不一定有原生 `input`。所以点选与回读都必须同时认：
  · 原生控件   `input.checked`
  · ARIA       `aria-checked="true"`
  · 类名       `active / selected / checked / on / cur / current`

## 安全边界

  ① **默认不开启**，界面上有开关；关掉时行为与以前完全一致（只等不答）
  ② 答不出来（扫不到选项 / 模型返回看不懂 / 点击没生效）
     **一律回退到"等用户手动答"**，绝不卡住、绝不乱点
  ③ 只点**这道弹题容器内**的选项；容器外的一律不碰
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable

# ---------------------------------------------------------------------------
# 选项 / 提交按钮的候选选择器
#
# ⚠ 这些选择器**互相重叠**（`label` 里套 `input[type=radio]` 时两个都命中），
#   所以扫描时会做"取最内层、按元素去重"，不能直接数 `querySelectorAll().length`。
# ---------------------------------------------------------------------------
OPTION_SELS = (
    # ⚠⚠ 顺序有意义：按顺序尝试、先命中的算数。**`... li` 必须在容器前面。**
    #
    #   学习通这版弹题的 DOM 是：
    #     <div class="ans-videoquiz-box">
    #       <div class="ans-videoquiz-tit">题面</div>
    #       <ul class="ans-videoquiz-opt">      ← 这是**选项列表的 UL**
    #         <li>选项 A</li><li>选项 B</li>
    #       </ul>
    #     </div>
    #
    #   原来把 `.ans-videoquiz-opt` 当成"单个选项"，全页只数出 1 个（那个 UL），
    #   于是 SCAN_QUIZ_JS 的"少于 2 个就 return null"直接判扫不到 ——
    #   用户 2026-10-17 日志里的「判据 .ans-videoquiz-opt，选项 -1 个」
    #   和「✘ 没答上：扫不到弹题选项」都是这个。
    ".ans-videoquiz-opt > li",     # ★ UL 的直接子项 = 真正的选项
    ".ans-videoquiz-opt li",       # 再宽松一层
    ".ans-videoquiz-box li",       # 容器类名换了但仍是 li 列表时
    "#videoquiz-box li",
    ".ans-videoquiz-opt",          # 容器：留作兜底（SCAN 会取最内层去重）
    ".topic-item",          # 智慧树选项
    ".answer-item", ".option-item",   # 智慧树 AI 助教弹题（判断题）
    ".ai-answer-item", ".ai-option-item",
    ".el-radio",            # 元素 UI 的单选
    ".el-checkbox",         # 元素 UI 的多选
    "input[type=radio]",
    "input[type=checkbox]",
    ".option", ".choice", ".opt", "label",
)

# 提交按钮：按**文字**找，而不是按类名 —— 两家的按钮类名都不可靠
SUBMIT_TEXTS = ("确定", "提交", "确认", "提交答案", "确定答案", "完成",
                "submit", "confirm", "ok", "check")

# 题面候选（容器里第一个像标题的元素）
STEM_SELS = (".topic-title", ".stem", ".q-title", ".question-title",
             # 学习通这版的题面类名有几种写法，都收进来 ——
             # 不靠"容器文字减选项"去拼题干（那样容易把「提交」之类的
             # 按钮文字混进来，用户 2026-10-17 日志里"题目文字"就是选项 A）。
             ".ans-videoquiz-tit", ".ans-videoquiz-title",
             ".ans-videoquiz-topic", ".videoquiz-title",
             ".title", "h3", "h4", "p")

# SCAN：限定在容器内，返回题面 / 选项 / 按钮。
# 由调用方传入容器选择器和"怎么算选中"的判定。
SCAN_QUIZ_JS = r"""(args) => {
    const [containerSel, optSels, stemSels, submitTexts, maxUp] = args;

    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05
            && r.width > 0 && r.height > 0;
    }
    function txt(e) {
        return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }

    // ① 定位弹题容器。
    //    ⚠ 判据可能命中"题面"而不是"容器"（`.topic-title` 就是），
    //      所以要往上走到一个真正**装着选项**的祖先。
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return null;
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }

    // ② 收集选项候选，**取最内层 + 按元素去重**。
    //    因为 optSels 互相重叠（label 套 input），不去重会把一个选项数成好几遍。
    let cands = [];
    for (const s of optSels) { for (const e of all(s, root)) { if (visible(e)) cands.push(e); } }
    // ⚠⚠ **先按元素去重**。
    //   optSels 里有多条互相重叠（比如 `.ans-videoquiz-opt > li`、
    //   `.ans-videoquiz-opt li`、`.ans-videoquiz-box li` 命中的是**同样几个 li**），
    //   不去重的话同一个 li 会被推进来好几遍 ——
    //   实测自测页上 2 个选项变成了 6 个：
    //     options = ['对','对','对','错','错','错']
    //   模型看到 6 个选项、按字母选，而落笔是**按索引**点 → 直接点错。
    //   原来的代码只做了"去掉包含别人的外层"，没处理"同一个元素被多次命中"。
    cands = Array.from(new Set(cands));
    // 再去掉"包含另一个候选"的外层元素：只留最内层
    cands = cands.filter(function (e) {
        return !cands.some(function (o) { return o !== e && e.contains(o); });
    });
    if (cands.length < 2) return null;
    // 按文档顺序排（去重后顺序可能乱）
    cands.sort(function (a, b) {
        const p = a.compareDocumentPosition(b);
        return (p & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1;
    });

    // ③ 每个候选算出"可点击的选项元素"和"显示文字"。
    //    裸 input 自己没有文字，要拿它外层（label 或父元素）的文字。
    function optText(e) {
        let t = txt(e);
        if (t.length >= 1) return t;
        const p = e.closest('label') || e.parentElement;
        return p ? txt(p) : '';
    }
    const options = cands.map(function (e, i) {
        let t = optText(e);
        // 去掉开头的字母圈：`A`、`(A)`、`A.`、`A、`（与作业模块同一套规则）
        // ⚠ 一定要把字母**去掉**，不能留着：
        //   render() 会自己加 `A. ` 前缀，留着就变成 `B. B Agent 可以…`。
        t = t.replace(/^[（(]\s*([A-Ja-j])\s*[)）]\s*/, '')
             .replace(/^([A-Ja-j])\s*[.、:：)）]\s*/, '')
             .replace(/^([A-Ja-j])\s+/, '')
             .replace(/\s+/g, ' ').trim();
        return { i: i, text: t.slice(0, 200) };
    });

    // ④ 题面：容器里第一个像标题的元素；找不到就用容器自己的文字去掉选项部分。
    let stem = '';
    for (const s of stemSels) {
        for (const e of all(s, root)) {
            if (!visible(e)) continue;
            // 题面不能是某个选项本身
            if (cands.some(function (c) { return c === e || e.contains(c); })) continue;
            const t = txt(e);
            if (t.length >= 4) { stem = t; break; }
        }
        if (stem) break;
    }
    if (!stem) {
        let t = txt(root);
        for (const o of options) { if (o.text) t = t.split(o.text).join(' '); }
        stem = t.replace(/\s+/g, ' ').trim().slice(0, 300);
    }

    // ⑤ 提交按钮：容器内按文字找（类名两家都不可靠）
    let submit = -1;
    const btns = all('button, a, span, div, input[type=button], input[type=submit]', root)
        .filter(visible);
    for (let i = 0; i < btns.length; i++) {
        const e = btns[i];
        if (cands.some(function (c) { return c === e || e.contains(c) || c.contains(e); })) continue;
        const t = (txt(e) || e.value || '').trim().toLowerCase();
        if (!t || t.length > 8) continue;
        if (submitTexts.some(function (w) { return t === w; })) {
            submit = i;
            break;
        }
    }

    // ⑥ 判定题型：有原生 checkbox / 多个可多选 的 → multi；否则 single
    let multi = false;
    for (const c of cands) {
        const inp = c.matches && c.matches('input') ? c : c.querySelector('input');
        if (inp && inp.type === 'checkbox') multi = true;
        const cc = (c.className && String(c.className)) || '';
        if (/checkbox|multiple|multi-select|multi_choice/i.test(cc)) multi = true;
    }
    // ★ 智慧树 AI 助教这版是**自定义多选**：没有原生 checkbox，
    //   题面里直接写「【多选题】」。只看 input 会把它当单选，
    //   模型回 "ABC" 时被当成"点击没生效"，于是整题不答。
    const qtext = ((stem || '') + ' ' + ((root && root.innerText) || ''));
    if (/多选题|多选|不定项|多项选择|至少.{0,6}项|选出所有/.test(qtext)) {
        multi = true;
    }
    const rcls = (root && root.className && String(root.className)) || '';
    if (/multi|multiple|checkbox/i.test(rcls)) multi = true;

    // ⑥ 这道弹题**是不是已经答过了**。
    //
    //   2026-10-23 14:31 真机：智慧树答完之后弹层不会立刻消失，而是停在
    //   「正确 【单选题】… 正确答案：A」的复盘态，**选项已经是禁用的**。
    //   我们却把它当成一道新题，逐个选项点过去 —— 全部"没有变化"，
    //   然后连点三次「关闭」。这一串动作正是平台判「异常脚本」时
    //   最像机器人的行为（紧接着就弹了那个提示框）。
    //   认出来就只点关闭、不碰选项。
    const _rootTxt = ((root && (root.innerText || root.textContent)) || '');
    const answered = /^(正确|错误|回答正确|回答错误)\b/.test(String(stem || '').trim())
                  || /回答正确|回答错误|正确答案\s*[:：]|恭喜你.?答对/.test(_rootTxt);

    return {
        stem: stem.slice(0, 400),
        options: options,
        submit: submit,
        multi: multi,
        answered: answered,
        rootTag: root.tagName + (root.className ? '.' + String(root.className).split(' ')[0] : ''),
    };
}"""

# CLICK：按索引点选（在同一个 frame 里执行）
CLICK_OPTION_JS = r"""(args) => {
    const [containerSel, optSels, idx, maxUp] = args;
    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05 && r.width > 0 && r.height > 0;
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return false;
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }
    let cands = [];
    for (const s of optSels) { for (const e of all(s, root)) { if (visible(e)) cands.push(e); } }
    cands = cands.filter(function (e) {
        return !cands.some(function (o) { return o !== e && e.contains(o); });
    });
    cands.sort(function (a, b) {
        const p = a.compareDocumentPosition(b);
        return (p & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1;
    });
    const el = cands[idx];
    if (!el) return false;
    // 裸 input：点它的外层（label）通常才会触发组件的选中逻辑
    let target = el;
    if (el.matches && el.matches('input') && el.type !== 'text') {
        target = el.closest('label') || el.parentElement || el;
    } else {
        // ★★ 点在**最内层的内容元素**上。
        //
        //   2026-10-23 智慧树实测：处理函数挂在 `li.topic-item` 的
        //   **子元素 `.item-topic`** 上。在 li 上派发的事件只会往上冒泡，
        //   **不会**往下走到子元素 —— 于是"点了没反应"、一个选项都选不上
        //   （用户：「课中答题可以判断，但没有成功落笔」）。
        //   点最内层，事件冒泡时子/父两边的处理函数都会触发。
        const inner = el.querySelector(
            '.item-topic, .answer-item, .option-item, .ai-answer-item, label');
        if (inner) target = inner;
    }
    try { target.scrollIntoView({block: 'center'}); } catch (e) {}
    // 真实事件流：mousedown → mouseup → click
    // （有些组件只监听 mousedown/mouseup，只派发 click 不生效）
    const opts = {bubbles: true, cancelable: true, view: window};
    try { target.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (e) {}
    try { target.dispatchEvent(new MouseEvent('mouseup', opts)); } catch (e) {}
    try { target.click(); } catch (e) {}
    // 原生控件兜底：直接置位并派发 change
    const inp = (el.matches && el.matches('input')) ? el : el.querySelector('input');
    if (inp && (inp.type === 'radio' || inp.type === 'checkbox')) {
        try {
            inp.checked = true;
            inp.dispatchEvent(new Event('input', {bubbles: true}));
            inp.dispatchEvent(new Event('change', {bubbles: true}));
        } catch (e) {}
    }
    return true;
}"""

# READBACK：读回"哪些选项被选中了"
READBACK_JS = r"""(args) => {
    const [containerSel, optSels, maxUp] = args;
    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05 && r.width > 0 && r.height > 0;
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return [];
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }
    let cands = [];
    for (const s of optSels) { for (const e of all(s, root)) { if (visible(e)) cands.push(e); } }
    cands = cands.filter(function (e) {
        return !cands.some(function (o) { return o !== e && e.contains(o); });
    });
    cands.sort(function (a, b) {
        const p = a.compareDocumentPosition(b);
        return (p & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1;
    });
    // 选中态：原生 / ARIA / 类名，三种都要认（两家平台各不相同）
    // ⚠ class 是**空格分隔**的（`class="topic-item active"`），正则只认 `-` 和 `_` 会**永远匹配不上** —— 而智慧树用的正是这种写法。
    const SEL_RE = /(^|[\s\-_])(active|selected|checked|on|cur|current|choose|chosen)([\s\-_]|$)/i;
    const out = [];
    cands.forEach(function (e, i) {
        let hit = false;
        const inp = (e.matches && e.matches('input')) ? e : e.querySelector('input');
        if (inp && inp.checked) hit = true;
        let n = e, hops = 0;
        while (n && hops < 3 && !hit) {
            if (n.getAttribute && n.getAttribute('aria-checked') === 'true') hit = true;
            if (n.getAttribute && n.getAttribute('aria-selected') === 'true') hit = true;
            const cn = (n.className && String(n.className)) || '';
            if (SEL_RE.test(cn)) hit = true;
            n = n.parentElement; hops++;
        }
        // 智慧树 #playTopic-dialog：选中态在**子元素** `.item-topic.active` 上，
        // 不在 .topic-item 自己身上；只看祖先会永远读不到。
        if (!hit) {
            let kids = [];
            try { kids = Array.prototype.slice.call(e.querySelectorAll('*'), 0, 20); }
            catch (err) { kids = []; }
            for (const k of kids) {
                if (k.getAttribute && (k.getAttribute('aria-checked') === 'true'
                        || k.getAttribute('aria-selected') === 'true')) {
                    hit = true;
                    break;
                }
                const kc = (k.className && String(k.className)) || '';
                if (SEL_RE.test(kc)) { hit = true; break; }
            }
        }
        if (hit) out.push(i);
    });
    return out;
}"""

# FINGERPRINT：选项区的"状态指纹"。用来判断"这一下到底点没点动"。
#
# 为什么需要它（2026-10-23 用户：「课中答题可以判断，但没有成功落笔」）：
#   老代码把 `click_option()` 有没有抛异常当成成功。可智慧树这版的处理函数
#   挂在 `.item-topic`（子元素）上，事件派发在 `li` 上根本不会触发它 ——
#   页面**一个 class 都没变**，老代码照样报「已作答」。
#   有了指纹就能问一句："点完之后，选项区有任何变化吗？"
OPTION_FP_JS = r"""(args) => {
    const [containerSel, optSels, maxUp] = args;
    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05 && r.width > 0 && r.height > 0;
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return '';
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }
    let cands = [];
    for (const s of optSels) { for (const e of all(s, root)) { if (visible(e)) cands.push(e); } }
    cands = cands.filter(function (e) {
        return !cands.some(function (o) { return o !== e && e.contains(o); });
    });
    return cands.map(function (e) {
        let s = String((e.className && e.className.baseVal !== undefined)
                       ? e.className.baseVal : (e.className || ''));
        const inner = e.querySelector('.item-topic, .answer-item, .option-item, label');
        if (inner) s += '|' + String((inner.className && inner.className.baseVal !== undefined)
                                     ? inner.className.baseVal : (inner.className || ''));
        const inp = e.querySelector('input');
        if (inp) s += '|chk=' + (inp.checked ? 1 : 0);
        s += '|aria=' + (e.getAttribute('aria-checked') || '')
                + '/' + (e.getAttribute('aria-selected') || '');
        return s;
    }).join(';');
}"""

# MARK：给"最内层可点元素"打个标记，供 Playwright 用**真实鼠标**点它。
MARK_OPTION_JS = r"""(args) => {
    const [containerSel, optSels, idx, maxUp] = args;
    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05 && r.width > 0 && r.height > 0;
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return false;
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }
    let cands = [];
    for (const s of optSels) { for (const e of all(s, root)) { if (visible(e)) cands.push(e); } }
    cands = cands.filter(function (e) {
        return !cands.some(function (o) { return o !== e && e.contains(o); });
    });
    const el = cands[idx];
    if (!el) return false;
    const target = el.querySelector(
        '.item-topic, .answer-item, .option-item, .ai-answer-item, label') || el;
    try { target.setAttribute('data-dsh-click-opt', '1'); } catch (e) { return false; }
    return true;
}"""

# SUBMIT：点提交按钮（按文字找，与扫描同一套规则）
SUBMIT_JS = r"""(args) => {
    const [containerSel, optSels, submitTexts, maxUp] = args;
    function visible(e) {
        if (!e) return false;
        const s = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden'
            && parseFloat(s.opacity || '1') > 0.05 && r.width > 0 && r.height > 0;
    }
    function all(sel, root) {
        try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
        catch (e) { return []; }
    }
    function txt(e) {
        return (e.innerText || e.textContent || e.value || '').replace(/\s+/g, ' ').trim();
    }
    let roots = all(containerSel).filter(visible);
    if (!roots.length) return false;
    let root = roots[0];
    for (let up = 0; up <= maxUp; up++) {
        let n = 0;
        for (const s of optSels) { n += all(s, root).length; }
        if (n >= 2) break;
        if (!root.parentElement) break;
        root = root.parentElement;
    }
    // ★ 按“可点击性”优先收集，而不是直接一条选择器查。
    //
    //   ⚠ 踩过的坑：`querySelectorAll('button, a, span, div, …')`
    //     按 **DOM 顺序** 返回，**父元素排在子元素前面**。
    //     而包裹按钮的 `div`（智慧树 `<div class="btns">`、
    //     学习通 `<div class="foot">`）的 innerText 就是里面按钮的文字
    //     —— 于是文字匹配先命中外层 `div`。
    //     点一个 `div` **不会触发子 `button` 的 click 监听器**，
    //     所以“提交成功”是假的，弹题不会消失。
    let btns = [];
    const tiers = ['button, input[type=submit], input[type=button], a',
                   'span', 'div'];
    for (const t of tiers) {
        for (const e of all(t, root)) {
            if (!visible(e)) continue;
            // 跳过“包含另一个已收集候选”的外层元素
            if (btns.some(function (o) { return e.contains(o); })) continue;
            btns.push(e);
        }
    }
    for (const e of btns) {
        const t = txt(e).toLowerCase();
        if (!t || t.length > 8) continue;
        if (submitTexts.some(function (w) { return t === w; })) {
            try { e.scrollIntoView({block: 'center'}); } catch (err) {}
            const opts = {bubbles: true, cancelable: true, view: window};
            try { e.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (err) {}
            try { e.dispatchEvent(new MouseEvent('mouseup', opts)); } catch (err) {}
            try { e.click(); } catch (err) {}
            return true;
        }
    }
    return false;
}"""


@dataclass
class QuizQuestion:
    """一道课中弹题。"""
    stem: str = ""
    options: list[dict] = field(default_factory=list)   # [{i, text}]
    submit: int = -1
    multi: bool = False
    root_tag: str = ""
    # ★ 这道题**是不是已经答过了**（复盘态：显示「正确 / 正确答案：A」，选项已禁用）。
    #   见 SCAN_QUIZ_JS 里 ⑥ 的说明：把复盘态当新题去点，是平台判「异常脚本」
    #   时最像机器人的行为。
    answered: bool = False

    def render(self) -> str:
        """给模型看的样子（紧凑、带字母）。"""
        letters = "ABCDEFGHIJ"
        out = [f"(课中弹题) {self.stem or '（题面未识别）'}"]
        for k, o in enumerate(self.options):
            L = letters[k] if k < len(letters) else str(k)
            out.append(f"  {L}. {o.get('text', '')}")
        if self.multi:
            out.append("（这是多选题，可能不止一个答案）")
        return "\n".join(out)

    def letters(self) -> list[str]:
        letters = "ABCDEFGHIJ"
        return [letters[k] if k < len(letters) else str(k)
                for k in range(len(self.options))]


# 提示词：只让它给字母，程序自己去点 DOM（与作业模块同一套约定）
QUIZ_SYSTEM = """你在替用户做网课的「课中弹题」。只输出一个 JSON 对象，不要 markdown，不要多余文字。

要求：
- 单选题：{"answer":"B"}
- 多选题：{"answer":"ABC"}
- 判断题：选项通常只有「对」「错」两项，按字母给，例如 {"answer":"A"}
- 如果题面信息不足、完全无法判断，输出 {"answer":"","reason":"看不清题目"}
- 「题干未识别」「看不清」这类敷衍话**不要**当答案，宁可返回空 answer。"""


def _letters_from(ans: Any, n: int) -> list[int]:
    """把模型给的答案解析成选项下标列表。

    ⚠ 必须宽容：模型可能返回 "B" / "b" / "AB" / "A,B" / ["A","B"] / 1 / "1"。
      解析失败一律返回空列表 → 上层回退到"等用户手动答"，绝不乱点。
    """
    letters = "ABCDEFGHIJ"
    if ans is None:
        return []
    if isinstance(ans, (list, tuple)):
        raw = "".join(str(x) for x in ans)
    else:
        raw = str(ans)
    raw = raw.strip().upper()
    if not raw:
        return []
    out: list[int] = []
    for ch in raw:
        if ch in letters:
            k = letters.index(ch)
        elif ch.isdigit():
            k = int(ch) - 1        # 模型偶尔给 "1" 表示第一个
        elif ch in "，, 、;；/|":
            continue
        else:
            continue
        if 0 <= k < n and k not in out:
            out.append(k)
    return out


def scan_quiz(frame, container_sel: str, *, max_up: int = 4) -> QuizQuestion | None:
    """在**弹题容器内**扫一道题。扫不到返回 None。"""
    try:
        r = frame.evaluate(
            SCAN_QUIZ_JS,
            [str(container_sel), list(OPTION_SELS), list(STEM_SELS),
             [str(x).lower() for x in SUBMIT_TEXTS], int(max_up)],
        )
    except Exception:
        return None
    if not r or not r.get("options"):
        return None
    if len(r["options"]) < 2:
        return None
    return QuizQuestion(
        stem=str(r.get("stem") or ""),
        options=list(r.get("options") or []),
        submit=int(r.get("submit", -1)),
        multi=bool(r.get("multi")),
        root_tag=str(r.get("rootTag") or ""),
        answered=bool(r.get("answered")),
    )


def option_fingerprint(frame, container_sel: str, *, max_up: int = 4) -> str:
    """选项区的"状态指纹"（只看 class / checked / aria，很轻）。"""
    try:
        return str(frame.evaluate(
            OPTION_FP_JS, [str(container_sel), list(OPTION_SELS), int(max_up)]
        ) or "")
    except Exception:
        return ""


def click_option(frame, container_sel: str, idx: int, *, max_up: int = 4) -> bool:
    """点第 idx 个选项。**返回"点完之后页面真的发生了变化"**。

    ⚠ 不能把"没抛异常"当成成功：2026-10-23 智慧树实测，把合成事件派发在
      `li.topic-item` 上时，挂在子元素 `.item-topic` 的处理函数根本不会触发
      —— 页面一个 class 都没变，老代码却照样 return True，上层于是报
      「已作答」。用户看到的就是「判断了，但没有成功落笔」。

    ## 2026-10-23 14:3x：**改成真实鼠标优先**（反作弊）

    用户真机截图：智慧树弹出「提示：检测到异常脚本，为保证您的正常学习进度，
    请您关闭插件后…」。时间点正好是课中弹题被自动作答之后。

    原因：`dispatchEvent(new MouseEvent(...))` 产生的事件 `isTrusted === false`，
    平台一眼就能看出"这不是人点的"。所以顺序反过来：
      **先 Playwright 真实鼠标（可信事件）→ 页面没反应才退回合成事件。**
    真实鼠标之前还先 `mouse.move(..., steps=6)` 走一小段轨迹 ——
    直接"瞬移 + 单击"同样不像人。
    """
    before = option_fingerprint(frame, container_sel, max_up=max_up)

    # ---- ① 真实鼠标（可信事件）----
    try:
        if frame.evaluate(
                MARK_OPTION_JS,
                [str(container_sel), list(OPTION_SELS), int(idx), int(max_up)]):
            loc = frame.locator('[data-dsh-click-opt="1"]')
            try:
                box = loc.bounding_box(timeout=1200)
            except Exception:
                box = None
            if box:
                try:
                    frame.page.mouse.move(
                        box["x"] + box["width"] / 2.0,
                        box["y"] + box["height"] / 2.0, steps=6)
                    time.sleep(random.uniform(0.06, 0.18))
                except Exception:
                    pass
            loc.click(timeout=1500)
            time.sleep(0.12)
            if option_fingerprint(frame, container_sel, max_up=max_up) != before:
                return True
    except Exception:
        pass
    finally:
        try:
            frame.evaluate(
                "() => { const e = document.querySelector('[data-dsh-click-opt]');"
                " if (e) e.removeAttribute('data-dsh-click-opt'); }")
        except Exception:
            pass

    # ---- ② 退回合成事件（老路径，保持原样）----
    try:
        ok = bool(frame.evaluate(
            CLICK_OPTION_JS,
            [str(container_sel), list(OPTION_SELS), int(idx), int(max_up)],
        ))
    except Exception:
        ok = False
    if ok:
        time.sleep(0.12)
        if option_fingerprint(frame, container_sel, max_up=max_up) != before:
            return True
    return False


def read_selected(frame, container_sel: str, *, max_up: int = 4) -> list[int]:
    try:
        r = frame.evaluate(
            READBACK_JS, [str(container_sel), list(OPTION_SELS), int(max_up)]
        )
        return [int(x) for x in (r or [])]
    except Exception:
        return []


def click_submit(frame, container_sel: str, *, max_up: int = 4) -> bool:
    try:
        return bool(frame.evaluate(
            SUBMIT_JS,
            [str(container_sel), list(OPTION_SELS),
             [str(x).lower() for x in SUBMIT_TEXTS], int(max_up)],
        ))
    except Exception:
        return False


def _wait_until(is_done: Callable[[], bool], seconds: float,
                poll: float = 0.25) -> bool:
    """轮询等待 `is_done()` 为真；超时返回 False。"""
    end = time.time() + max(0.0, float(seconds))
    while time.time() < end:
        try:
            if is_done():
                return True
        except Exception:
            return False
        time.sleep(poll)
    return False


def _accepted(fn: Callable[[], bool] | None) -> bool:
    """`is_accepted` 的安全包装：没传 / 抛异常一律当"不知道"（False）。

    自动作答属于"锦上添花"，判据再多也不能把刷课打断。
    """
    if fn is None:
        return False
    try:
        return bool(fn())
    except Exception:
        return False


def answer_quiz(client, frame, container_sel: str, *,
                log: Callable[[str], None] = print,
                use_cache: bool = True,
                is_done: Callable[[], bool] | None = None,
                is_accepted: Callable[[], bool] | None = None,
                retry_wait: float = 5.0) -> tuple[bool, str]:
    """自动答一道课中弹题。返回 `(是否成功落笔, 说明)`。

    `is_done`：可选。传入后，答完会等它变真（弹层消失 / 视频继续）；
    5 秒内没继续，就**换下一个选项重试**（单选；多选不轮选）。
    不传时保持旧行为：点完提交就返回成功。

    `is_accepted`：可选。用来判断"页面已经显示答对了"。
    ⚠ 2026-10-23 用户：「答对了没有点击关闭」。真机日志里 A 已经选中且答对，
      但结果层的「关闭」没点上 → 弹层不消失 → `is_done` 一直为假 →
      这段会当成答错，**换 B/C/D 重试**，把正确答案改掉。
      有了它：换选项之前先问一句"是不是已经答对了"，是就停止轮换、如实报成功，
      关闭交给调用方继续补点。

    ⚠ **任何失败都必须能让调用方回退到"等用户手动答"** ——
      这是这个功能的安全底线：宁可没答，也不能卡住或点错。
    """
    q = scan_quiz(frame, container_sel)
    if q is None:
        return False, "扫不到弹题选项（可能判据命中但结构不同）—— 交给你手动答"

    # ★ 已经答过的复盘态：**只点关闭，一个选项都别碰**。
    #
    #   2026-10-23 14:31 真机：智慧树答完不会立刻关弹层，而是停在
    #   「正确 【单选题】… 正确答案：A」；选项已经禁用。我们把它当新题，
    #   4 个选项逐个点（全"没变化"），再连点三次「关闭」——
    #   紧接着平台就弹了「检测到异常脚本」。这一串动作太像机器人了。
    if q.answered:
        log("      · 这道弹题**已经答过**（显示「正确/正确答案」）→"
            " 只点关闭，不再点选项")
        try:
            click_submit(frame, container_sel, max_up=4)
        except Exception:
            pass
        return False, "这道题此前已作答（只关弹层，没有改答案）"

    log(f"      题面：{(q.stem or '（未识别）')[:60]}")
    log(f"      选项 {len(q.options)} 个"
        f"{'（多选）' if q.multi else ''}："
        + " / ".join(str(o.get('text', ''))[:18] for o in q.options[:4]))

    # ---- 问模型 ----
    try:
        data = client.ask_json(
            q.render(),
            system=QUIZ_SYSTEM,
            images=[],
            max_tokens=256,
        )
    except Exception as e:
        return False, f"模型请求失败（{type(e).__name__}）—— 交给你手动答"

    ans = ""
    if isinstance(data, dict):
        ans = data.get("answer", "")
    if isinstance(ans, list):
        ans = "".join(str(x) for x in ans)
    picks = _letters_from(ans, len(q.options))
    if not picks:
        why = ""
        if isinstance(data, dict):
            why = str(data.get("reason") or "")
        return False, (f"模型没给出可用答案（answer={ans!r}"
                       f"{'，' + why[:30] if why else ''}）—— 交给你手动答")
    log(f"      模型给：{'、'.join(q.letters()[k] for k in picks)}")

    # ---- 点选 ----
    before = read_selected(frame, container_sel)
    changed = 0
    for k in picks:
        if click_option(frame, container_sel, k):
            changed += 1
    if changed == 0:
        # ★ 一个选项都没点动 —— 绝不能报"已作答"。
        #   2026-10-23 用户：「课中答题可以判断，但没有成功落笔」，
        #   老代码在这里仍然返回成功，把弹窗留在页面上、日志还写"已作答"。
        return False, ("点击没生效（每个选项点完页面都没有变化）"
                       "—— 交给你手动答")
    after = read_selected(frame, container_sel)

    unknown = not after
    if unknown:
        # 有些组件不暴露选中态。不能因此判定失败 ——
        # 继续提交/等它关闭；实在不行再交人工。
        log(f"      （读不到选中态；已点 "
            f"{'、'.join(q.letters()[k] for k in picks)}，继续尝试提交/关闭）")
    else:
        # 单选：期望恰好一个选中；多选：期望选中的**包含**我们点的
        if q.multi:
            ok = all(k in after for k in picks)
        else:
            ok = len(after) == 1 and after[0] in picks

        if not ok:
            return False, (f"点击没生效（点了 {'、'.join(q.letters()[k] for k in picks)}，"
                           f"实际选中 {[q.letters()[k] if k < len(q.letters()) else k for k in after]}）"
                           f"—— 交给你手动答")
        log(f"      选中态已确认："
            f"{'、'.join(q.letters()[k] for k in after if k < len(q.letters()))}"
            + (f"（原选中 {before} → {after}）" if before != after else ""))

    # ---- 提交（有就点，没有就算了：很多弹题点完选项就自动判） ----
    if click_submit(frame, container_sel):
        log("      已点「确定/提交」")

    if is_done is None:
        if unknown:
            return True, (f"已点 {'、'.join(q.letters()[k] for k in picks)}"
                          f"（该组件不暴露选中态，无法自动回读）")
        return True, f"已作答（{'、'.join(q.letters()[k] for k in picks)}）"

    # ---- 5 秒内没继续播放 → 单选换选项重试 ----
    #
    # 背景：课中弹题答错不会自动纠正，而视频必须答对才继续。
    # 这些弹题不计入成绩，所以允许按选项逐个试；但**只限单选**，
    # 多选组合太多，不做穷举，免得乱点。
    if _wait_until(is_done, retry_wait):
        return True, (f"已作答（{'、'.join(q.letters()[k] for k in picks)}，"
                      f"已继续播放）")

    # ★ 先问一句"是不是已经答对了"：答对但「关闭」没点上时，弹层不会消失，
    #   可答案是对的 —— 这时候再去换选项只会把对的改错（真机 14:14 就是这样）。
    if _accepted(is_accepted):
        log("      · 页面显示已答对（只是弹层还没关掉）—— 不再换选项")
        return True, (f"已作答（{'、'.join(q.letters()[k] for k in picks)}，"
                      f"页面显示答对，只差关闭）")

    if q.multi:
        return False, "已作答但 5 秒内未继续播放（多选题不轮选）—— 交给你手动答"

    tried = set(picks)
    for idx in range(len(q.options)):
        if idx in tried:
            continue
        tried.add(idx)
        letter = q.letters()[idx]
        # 每换一次之前再确认一次：上一轮可能已经答对，只是没关掉
        if _accepted(is_accepted):
            log("      · 页面显示已答对 —— 停止换选项")
            return True, "已作答（页面显示答对，只差关闭）"
        log(f"      5 秒内没继续播放，换 {letter} 重试…")
        if not click_option(frame, container_sel, idx):
            continue
        time.sleep(0.15)
        sel_now = read_selected(frame, container_sel)
        if sel_now and idx not in sel_now:
            log(f"      （{letter} 没选中，跳过）")
            continue
        click_submit(frame, container_sel)
        if _wait_until(is_done, retry_wait):
            return True, f"已作答（换 {letter} 后继续播放）"

    return False, "已试遍所有选项，5 秒内仍未继续播放 —— 交给你手动答"
