# -*- coding: utf-8 -*-
"""防挂机（保持窗口活跃）。

## 这个模块在做什么，以及**不**做什么

平台的"挂机检测"大致看两件事：
  ① 视频有没有在正常前进（这条我们管不了，也不该管）
  ② 有没有人在操作（键鼠/焦点）

**长时间不动是否被判挂机，取决于平台**。我们能做的、也应该做的只有一件：
**让窗口保持"有人在"的状态**，而不是伪造学习行为。

明确不做（这是项目既定伦理，改任何代码都不破）：
  · ❌ 不伪造学习进度
  · ❌ 不发"心跳"上报（那属于伪造平台数据）
  · ❌ 不绕过平台的时长校验
  · ❌ 不模拟答题行为

只做：
  · ✅ 视频**确实在播**、但很久没有真实输入时，在页面空白处轻移一下鼠标
  · ✅ 把窗口焦点保持在页面内（不抢前台、不切窗口）

也就是说：我们只是**避免因为"完全没人碰过电脑"而被判离开**，
不改变平台对"学没学会"的任何判定。

## 为什么用"移动鼠标"而不是"切换标签/刷新"

移动鼠标是**侵入性最小**的动作：
  · 不改变页面状态（不会误点、不会跳转）
  · 不产生额外的网络请求
  · 视觉模型/用户都能一眼看出它在干什么
刷新页面会丢播放位置，点空白处可能误触，都不如移鼠标安全。
"""
from __future__ import annotations

import random
import time


class KeepAlive:
    """轻量保活：隔一段时间做一次最小动作，证明"有人在"。

    用法：
        ka = KeepAlive(page=driver.page, interval=240, log=log)
        ...
        ka.poke()        # 用户/程序做了真实动作 → 重置计时
        ka.tick()        # 每轮循环调一次；到点会自己动一下

    ⚠ 只在"确实需要"时才动。调用方负责判断"视频在播"这个前提 ——
      视频都停了还去动鼠标，那才是真的像在挂机。
    """

    def __init__(self, page=None, *, interval: float = 240.0,
                 log=None, enabled: bool = True) -> None:
        self.page = page
        # ⚠ 下限只防"负数/0 导致每轮都动鼠标"，**不要**设成大值 ——
        #   曾经写成 max(5.0, ...)，结果自测里传 0.2 秒会被静默改成 5 秒，
        #   测试看着"没生效"，其实是参数被吃了，排查半天。
        #   "间隔太小"是调用方的责任，不该在这里悄悄改。
        try:
            iv = float(interval)
        except (TypeError, ValueError):
            iv = 240.0
        self.interval = iv if iv > 0.05 else 0.05
        self.log = log
        self.enabled = enabled
        self.last = time.time()
        self.count = 0

    def poke(self) -> None:
        """记录"刚刚有真实动作"（用户答了题、点了按钮等）。"""
        self.last = time.time()

    def tick(self) -> bool:
        """到时间就轻移一下鼠标。返回是否真的动了。

        ⚠ 故意用**很小的位移**（±3px）并把鼠标停在页面中间偏下的
          "空白安全区"，避免落在链接/按钮上：
          大范围移动有可能划过某个可点元素，在有的站点上会触发 hover 菜单。
        """
        if not self.enabled:
            return False
        now = time.time()
        if now - self.last < self.interval:
            return False
        self.last = now
        try:
            pg = self.page
            if pg is None:
                return False
            # 视口尺寸；取不到就用一个保守值
            try:
                vp = pg.viewport_size or {"width": 1280, "height": 800}
            except Exception:
                vp = {"width": 1280, "height": 800}
            # 停在中间偏下：那里通常是播放器/空白，不是导航按钮
            cx = int(vp.get("width", 1280) / 2)
            cy = int(vp.get("height", 800) * 0.72)
            # ±3 像素的两步位移，产生一次真实的 mousemove
            pg.mouse.move(cx, cy)
            time.sleep(0.12)
            pg.mouse.move(cx + random.choice((-3, 3)),
                          cy + random.choice((-2, 2)))
            self.count += 1
            if self.log:
                self.log(f"  · 已 {self._human()}没有操作，"
                         f"轻移了一下鼠标（防止被判定为挂机；"
                         f"不涉及任何进度上报）")
            return True
        except Exception:
            # 保活失败绝不能影响主流程
            return False

    def _human(self) -> str:
        """把间隔说成人话（避免 0.3 秒被显示成"每 0 分钟"）。"""
        s = self.interval
        if s >= 60:
            return f"{s / 60:g} 分钟"
        return f"{s:g} 秒"

    def describe(self) -> str:
        if not self.enabled:
            return "防挂机：已关闭"
        return f"防挂机：每 {self._human()}轻移一次鼠标"
