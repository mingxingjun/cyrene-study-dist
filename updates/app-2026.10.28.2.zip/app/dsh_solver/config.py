"""全局配置：环境变量 > 默认值。所有路径都可用 DSHS_ 前缀环境变量覆盖。"""
from __future__ import annotations

import os
from pathlib import Path


def _env(name: str, default: str) -> str:
    v = os.environ.get(name)
    return v if v not in (None, "") else default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env(name, str(default)))
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(_env(name, str(default))))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    return _env(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on", "y")


# ---------------------------------------------------------------- 模型提供方
# provider=deepseek  → 走 DeepSeek 官方 API（代码默认，纯文本模型）
# provider=lmstudio  → 走本地 LM Studio（带视觉，能读图）
# 也单独认 DSHS_LM_BASE_URL / DSHS_LM_MODEL，方便手动指定任意 OpenAI 兼容端点。
PROVIDER = _env("DSHS_PROVIDER", "deepseek").strip().lower()

# ---- 本地 LM Studio ----
LM_BASE_URL = _env("DSHS_LM_BASE_URL", "http://127.0.0.1:1234/v1").rstrip("/")
LM_MODEL = _env("DSHS_LM_MODEL", "")          # 留空 = 自动挑一个已加载的模型
LM_API_KEY = _env("DSHS_LM_API_KEY", "lm-studio")

# ---------------------------------------------------------------- 接口表
# 为什么要做成一张表：provider 的判定原来散在四五个地方
# （is_cloud 判断、base_url 选择、api_key 选择、model 选择、鉴权头），
# 每加一个接口就要改好几处，漏一处就出怪问题。
# 现在集中在这里，加接口 = 加一行。
#
# 字段：
#   base  默认 base_url（用户可在界面覆盖）
#   model 默认模型名
#   env   读 API Key 的环境变量名
#   auth  鉴权方式：bearer（多数）/ api-key（Azure 系）/ none
#   think 是否会发 DeepSeek 专有的 thinking 字段（别家发了会 400）
#   vision 支持读图的模型名关键字
PROVIDERS: dict[str, dict] = {
    "deepseek": {
        "name": "DeepSeek 官方",
        "base": "https://api.deepseek.com/v1",
        "model": "deepseek-flash",
        "env": ("DSHS_DEEPSEEK_API_KEY", "DEEPSEEK_API_KEY"),
        "auth": "bearer",
        "think": True,
        "vision": ("deepseek-flash", "deepseek-v4-flash", "vision"),
    },
    "kimi": {
        "name": "Kimi（月之暗面）",
        "base": "https://api.moonshot.cn/v1",
        # kimi-latest 是通用对话模型；moonshot-v1-* 是经典系列
        "model": "kimi-latest",
        "env": ("DSHS_KIMI_API_KEY", "KIMI_API_KEY", "MOONSHOT_API_KEY"),
        "auth": "bearer",
        "think": False,
        # 月之暗面有视觉模型（moonshot-v1-*-vision-preview）
        "vision": ("vision",),
    },
    "openai": {
        "name": "OpenAI 兼容",
        "base": "https://api.openai.com/v1",
        "model": "gpt-4o-mini",
        "env": ("DSHS_OPENAI_API_KEY", "OPENAI_API_KEY"),
        "auth": "bearer",
        "think": False,
        "vision": ("gpt-4o", "gpt-4.1", "gpt-4-turbo", "o1", "o3", "vision"),
    },
    "lmstudio": {
        "name": "本机 LM Studio",
        "base": LM_BASE_URL,
        "model": LM_MODEL,
        "env": ("DSHS_LM_API_KEY",),
        "auth": "bearer",
        "think": False,
        "vision": (),          # 本地按 LM Studio 报的 type=vlm 判断
    },
}

# ⚠ 「自定义」不是这张表里的一项 —— 它的 base/model 完全由用户填。
#   用 provider="custom" 表示，配合 custom_base_url / custom_model / custom_api_key。
CUSTOM_PROVIDER = "custom"


def provider_info(name: str) -> dict:
    """取某个 provider 的元信息。未知名字返回一份"通用云端"的默认值。

    返回空 dict 会让调用方到处判空，所以这里**总是**返回一份可用的字典：
    未知 provider 按"标准 OpenAI 兼容 + Bearer 鉴权"处理。
    """
    key = (name or "").strip().lower()
    got = PROVIDERS.get(key)
    if got:
        return dict(got)
    return {"name": key or "自定义", "base": "", "model": "",
            "env": (), "auth": "bearer", "think": False, "vision": ()}


def provider_api_key(name: str) -> str:
    """按顺序从环境变量里取某个 provider 的 Key（取不到返回空串）。"""
    for env_name in provider_info(name).get("env") or ():
        v = os.environ.get(env_name, "").strip()
        if v:
            return v
    return ""


# 把上面那张表里的值接到原有的配置常量上 —— **保持向后兼容**，
# 这样 lms.py 之外的地方不用改。
#
# ⚠ 这里**不要**写死 API Key：程序要分发给别人，硬编码会把自己的 Key 一起送出去。
# Key 的来源按优先级：
#   1) 环境变量 DSHS_<平台>_API_KEY
#   2) 环境变量 <平台>_API_KEY
#   3) 界面「设置」里填的值（保存在 out/app_config.json，启动时由 app_server 覆盖进来）
DEEPSEEK_BASE_URL = _env(
    "DSHS_DEEPSEEK_BASE_URL", PROVIDERS["deepseek"]["base"]).rstrip("/")
DEEPSEEK_API_KEY = (
    _env("DSHS_DEEPSEEK_API_KEY", "")
    or os.environ.get("DEEPSEEK_API_KEY", "")
)
DEEPSEEK_MODEL = _env("DSHS_DEEPSEEK_MODEL", PROVIDERS["deepseek"]["model"])
DEEPSEEK_VISION_MODELS = tuple(PROVIDERS["deepseek"]["vision"])
DEEPSEEK_THINKING = _env_bool("DSHS_DEEPSEEK_THINKING", False)

# Kimi / 自定义接口
KIMI_BASE_URL = _env("DSHS_KIMI_BASE_URL", PROVIDERS["kimi"]["base"]).rstrip("/")
KIMI_API_KEY = provider_api_key("kimi")
KIMI_MODEL = _env("DSHS_KIMI_MODEL", PROVIDERS["kimi"]["model"])

# 自定义接口（任意 OpenAI 兼容端点）
CUSTOM_BASE_URL = _env("DSHS_CUSTOM_BASE_URL", "").rstrip("/")
CUSTOM_API_KEY = _env("DSHS_CUSTOM_API_KEY", "")
CUSTOM_MODEL = _env("DSHS_CUSTOM_MODEL", "")

# ---------------------------------------------------------------- 通用参数
LM_TEMPERATURE = _env_float("DSHS_TEMPERATURE", 0.1)
LM_TIMEOUT = _env_float("DSHS_LM_TIMEOUT", 240.0)
# 推理型模型会把大量 token 花在 reasoning 上。给太少 → content 为空（看着像"模型没回答"）。
# 8192 是实测够用的值；调小会因为思考被截断而丢掉答案。
LM_MAX_TOKENS = _env_int("DSHS_LM_MAX_TOKENS", 8192)
LM_VISION_TIMEOUT = _env_float("DSHS_LM_VISION_TIMEOUT", 300.0)
# 云端 API 要处理限流：遇到 429/5xx 时重试几次
RETRY_MAX = _env_int("DSHS_RETRY_MAX", 3)
RETRY_BACKOFF = _env_float("DSHS_RETRY_BACKOFF", 2.0)
# 是否允许把网页截图/配图发往云端。
# 默认允许（你选择全走 DeepSeek），但请知悉：这会把题目内容上传到服务商。
# 若要严格本地：设 0，图片会改用本地 LM Studio（需它在线）。
ALLOW_CLOUD_IMAGES = _env_bool("DSHS_ALLOW_CLOUD_IMAGES", True)

# ---------------------------------------------------------------- 预算护栏
# 本次运行（进程启动到退出）累计的模型调用次数 / token / 估算花费上限。
# **0 = 不限制（默认）**：此时 app\dsh_solver\budget.py 的 check() 直接放行，
# 对现有行为零影响。超限后 lms.chat() 抛 LMError，由 agent 按"模型作答失败"
# 友好提示并停止，不会继续产生费用。
#   calls    调用次数（一次 chat 请求算一次）
#   tokens   输入+输出 token 合计
#   cost_cny 按 usage.py 内置单价估算的人民币（不是账单）
# 注意：是**进程级**，不是按天；重启程序后重新计数。
BUDGET_MAX_CALLS = _env_int("DSHS_MAX_CALLS", 0)
BUDGET_MAX_TOKENS = _env_int("DSHS_MAX_TOKENS", 0)
BUDGET_MAX_COST_CNY = _env_float("DSHS_MAX_COST_CNY", 0.0)

# ---------------------------------------------------------------- 浏览器
# 可填多个渠道，逗号分隔，按顺序尝试；最后总会退回 Playwright 内置 chromium。
# 实测本机：Chrome 未安装；企业版 Edge 虽禁用了自带 --headless，但 Playwright
# 通过 msedge 渠道驱动它时 headless/有窗口都正常 —— 所以 msedge 排第一。
CHROME_CHANNEL = _env("DSHS_CHROME_CHANNEL", "msedge,chrome")
CDP_URL = _env("DSHS_CDP_URL", "http://127.0.0.1:9222")  # 连接已开启调试端口的真实浏览器
HEADLESS = _env_bool("DSHS_HEADLESS", False)
VIEWPORT_W = _env_int("DSHS_VIEWPORT_W", 1440)
VIEWPORT_H = _env_int("DSHS_VIEWPORT_H", 900)
NAV_TIMEOUT_MS = _env_int("DSHS_NAV_TIMEOUT_MS", 60000)

# ---------------------------------------------------------------- 答题行为
# 每批问几道题。**默认 3**，靠"自适应补问"兜住准确率（见下）。
#
# 历史实测（同一套 12 题，2026-10 之前的数据）：
#   batch=1 → 12/12 全对，约 215 秒      ← 一道题一次请求，太慢
#   batch=2 → 10~11/12，约 130 秒
#   batch=3 → 8~10/12，约 97 秒，模型偶尔返回不带题号的裸数组 → 顺序错位答错
#
# 当时的结论是"默认 1，准确率优先"。**2026-10-19 用户反馈太慢**，改成：
#   · 默认 3（一次请求答 3 道，图片也只上传 1 次而不是 3 次）
#   · `agent._ask_loop()` 里加**自适应补问**：这一批里没拿到可靠答案的题
#     （漏答 / 裸数组 / 置信度低于 QUIZ_MIN_CONFIDENCE）**逐题再问一次**
#
# 所以现在：常见情况一批答完 = 快；模型不听话时退回逐题 = 和原来一样准，
# **不会比 batch=1 更慢**（最坏也只是把没答上的补问一遍）。
BATCH_SIZE = _env_int("DSHS_BATCH_SIZE", 3)
# 逐题分页的作业（做一题点一次"下一题"）一页只有一题，所以轮数上限要放得下几十题。
# 真正防死循环的是 MAX_PAGES 和"翻页后指纹没变就停"，不是轮数。
MAX_ROUNDS = _env_int("DSHS_MAX_ROUNDS", 60)
MAX_PAGES = _env_int("DSHS_MAX_PAGES", 80)        # 最多翻多少页，防跑飞
AUTO_NEXT = _env_bool("DSHS_AUTO_NEXT", True)     # 自动点「下一题」
AUTO_SUBMIT = _env_bool("DSHS_AUTO_SUBMIT", False)  # 默认不自动交卷
DRY_RUN = _env_bool("DSHS_DRY_RUN", False)        # 只推理不落笔
# 答案缓存：同一道题（题干+选项一致）第二次直接复用，不再问模型。
# 对"反复刷同一套题"提速极明显；同一题号但题目内容变了也不会误用（key 含选项）。
USE_ANSWER_CACHE = _env_bool("DSHS_USE_CACHE", True)
# 每答完一轮就清掉上一轮的截图。
# 注意保留策略：是"清掉旧的、留下本轮这张"，不是全删 ——
# 界面右侧预览取的就是最新那张，全删会让预览变空白。
CLEAR_SHOTS_EACH_ROUND = _env_bool("DSHS_CLEAR_SHOTS_EACH_ROUND", True)

# ---------------------------------------------------------------- 运行模式
# web = 在网页里操作（DOM 主力，推荐）
# pc  = 真·键鼠模式：整屏截图 → 模型给动作 → 真点/真打字
#
# ⚠ PC 模式的定位（按《视觉化改造》文档的三条铁律）：
#   · 它是**兜底**，不是主力。能用 DOM 就绝不用它。
#   · 它会**抢真实鼠标键盘** —— 运行期间你不能碰电脑。
#   · 所以默认关闭 + 二次确认 + 步数上限，三件套缺一不可。
#   · 它**不做考试自动作答**（文档铁律 3）。
MODE = _env("DSHS_MODE", "web").strip().lower()
if MODE not in ("web", "pc"):
    MODE = "web"
# PC 模式的任务描述（自然语言，例如"打开记事本，把下面这段字打进去"）
PC_TASK = _env("DSHS_PC_TASK", "")
# 运行 PC 模式前是否要用户确认一次（默认要 —— 它会接管你的鼠标）
PC_CONFIRM = _env_bool("DSHS_PC_CONFIRM", True)
PC_AGENT_MAX_STEPS = _env_int("DSHS_PC_MAX_STEPS", 25)

# PC 模式每步要发一张整屏截图给模型。原图可能 2560x1600，
# 转成 data URI 后接近 **2.3 MB** —— 又慢又贵，而且模型对超大图也不见得更准。
# 这里按长边降采样到不超过 PC_SHOT_MAX_EDGE 像素（保持比例）。
# 实测 1600 长边对"找按钮/读题目"这类任务已经够用。
PC_SHOT_MAX_EDGE = _env_int("DSHS_PC_SHOT_MAX_EDGE", 1600)

# ---------------------------------------------------------------- 发图的硬护栏
# 云端多模态接口对图片尺寸有硬上限（DeepSeek 官方文档：单边最长 8192px，
# 超过会被直接拒绝：400 "You have uploaded an unsupported image"）。
# 这里留一点余量；真正动手的是 `lms._fit_image()`（只在超限时缩放，正常图不动）。
IMAGE_MAX_EDGE = _env_int("DSHS_IMAGE_MAX_EDGE", 8000)
# 字体加密页的整页/元素截图会很高（25 道题的卷子实测约 1 万像素）。
# 切成一屏多高的小图：既不会触发 8192px 上限，又能让模型按接近 1:1 的
# 分辨率读中文（整张大图会被服务端缩到 ~1300×1300，字就糊了）。
# 1600 与 `_obf_shot_stitch()` 的切片高度保持一致。
OBF_SLICE_H = _env_int("DSHS_OBF_SLICE_H", 1600)

# ---------------------------------------------------------------- 自动刷课
# 网课视频自动播放：设倍速、等待播完、点下一节，直到整章学完。
#
# ⚠ 风险提示（界面上也会写）：主流网课平台（智慧树/超星等）对刷课有风控，
#   通常表现为"进度不计入、需要重新学习"，严重时封号。倍速也常被平台限制。
#   这个功能是给"自己的课、自己看"加速用的，用不用请自行判断。
COURSE_SPEED = _env_float("DSHS_COURSE_SPEED", 1.5)     # 播放倍速
# 平台倍速上限。
#
# 智慧树 AI 版课程实测：视频播放器**控件被禁用**（`vjs-controls-disabled`），
# 没有倍速菜单，只能直接设 playbackRate；而**用户实测最高只能到 1.5×**，
# 设更高会被播放器内核改回去。
# （老版课程的参考值是 1.8；这里统一按更保守的 1.5，宁可慢一点也不白设。）
COURSE_MAX_SPEED = _env_float("DSHS_COURSE_MAX_SPEED", 1.5)
COURSE_MUTE = _env_bool("DSHS_COURSE_MUTE", True)       # 静音（很多平台要求有声才计时）
COURSE_AUTO_NEXT = _env_bool("DSHS_COURSE_AUTO_NEXT", True)   # 播完自动下一节
# 单条视频的等待上限。
#
# ⚠ 这里曾经是固定 3 分钟，结果**长视频还没播完就被强制切走** ——
#   用户的课有 13 分 15 秒的，1.5 倍速也要播 ~9 分钟，3 分钟一到就切下一条，
#   表现就是"没看完一整节课就自动切换"。
#
#   现在改成"按视频时长动态算"（见 course.py），这个值只作为**兜底**：
#   万一读不到时长，才用这个固定上限。所以调大到 60 分钟，宁可多等也别切错。
COURSE_MAX_WAIT_MIN = _env_float("DSHS_COURSE_MAX_WAIT_MIN", 60.0)
# 动态上限的额外余量（倍）。比如 13 分钟的视频、1.5 倍速 ≈ 9 分钟，
# 再乘这个余量作为硬上限，防止页面卡死时无限等。
COURSE_WAIT_HEADROOM = _env_float("DSHS_COURSE_WAIT_HEADROOM", 2.0)
# 一次最多学多少节（防跑飞）。
COURSE_MAX_LESSONS = _env_int("DSHS_COURSE_MAX_LESSONS", 500)
# 播放进度到多少算"学完"。平台一般要求 100%，但卡在 99% 很常见，
# 所以给一个阈值，到了就认为看完可以进下一节。
COURSE_DONE_RATIO = _env_float("DSHS_COURSE_DONE_RATIO", 0.98)
# 每秒检查一次播放状态
COURSE_POLL_SEC = _env_float("DSHS_COURSE_POLL_SEC", 2.0)

# ---- 课中弹题 ----
# 播放中途弹出的题，答完才让继续。程序**不替用户答题**（答错可能扣分），
# 只是暂停等待、并在答完后重新起播。
#
# ⚠ 这里必须有个上限：检测判据（"页面上有没有像弹题的元素"）本质是启发式的，
#   一旦命中一个**永远不会消失**的元素，刷课就会永久停在那里。
#   原来那个 `while visible(): sleep()` 没有任何 deadline，
#   实测表现就是"卡住不动，只能点停止"。
COURSE_QUIZ_MAX_WAIT_MIN = _env_float("DSHS_COURSE_QUIZ_MAX_WAIT_MIN", 15.0)
# 弹题轮询间隔（比视频轮询快一点，答完能尽快恢复播放）
COURSE_QUIZ_POLL_SEC = _env_float("DSHS_COURSE_QUIZ_POLL_SEC", 1.5)

# 「当前停在登录页」时等用户登录的时长（秒）。
# 2026-10-23 客户日志：30 次运行里十几次是"浏览器没登录 → 打开就是 passport2 登录页"，
# 程序 4 秒就报"找不到可播放的视频"，客户完全不知道是自己没登录。
# 现在会停下来等，登录完成后自动继续。
COURSE_LOGIN_WAIT_SEC = _env_float("DSHS_COURSE_LOGIN_WAIT_SEC", 180.0)

# ---- 课中弹题「自动作答」 ----
# 关掉时行为与以前**完全一致**：只检测弹题、暂停计时、等用户手动答。
# 开着时先尝试自动答（见 dsh_solver/videoquiz.py）；**答不出来一律回退到等待**，
# 所以这个开关只可能变好、不会变坏。
#
# ⚠ 注意：网课弹题答错通常不影响视频继续播放（答完就放行），
#   但**会影响这门课的平时分**。要不要开、想不想自己核对，请自行判断。
COURSE_QUIZ_AUTO = _env_bool("DSHS_COURSE_QUIZ_AUTO", True)
COURSE_DISCUSS_AUTO = _env_bool("DSHS_COURSE_DISCUSS_AUTO", True)   # 讨论区自动回复

# ---- 网页答题：扫描前等"内容真的渲染出来" ----
#
# ⚠ 实测踩到：学习通「作业作答」页是 **JS 异步填内容**的，打开后先是个白壳，
#   题目几秒后才写进去。而 `wait_for_load` 只等 networkidle ——
#   在 SPA 上几乎立刻返回，于是程序扫的是白页：
#     页面标题：作业作答            ← 地址和标题都对
#     识别到 0 道选择题、6 个填空    ← 把样式层当成了"填空题"
#     截图 2549x1352 全白（13KB）
#     模型回传 'reason': '题目内容缺失，仅含样式代码'
#   给一个上限：内容一到就立刻继续（不会白等满），一直没内容也如实告知。
WEB_CONTENT_WAIT_SEC = _env_float("DSHS_WEB_CONTENT_WAIT_SEC", 12.0)

# ---- 挂机检测（防"长时间不动被判定为挂机"）----
# 平台会看"有没有人在操作"。一直不碰键鼠、且视频长时间无进展时，
# 有些平台会记"离开"甚至停止计时。
#
# ⚠ 这里做的事**非常有限**，必须说清楚边界：
#   · 只做"证明有人在"的最小动作（在页面空白处轻移一下鼠标）
#   · **不伪造学习进度**、不上报心跳、不碰平台的时长校验
#   · 只有在"视频确实在播、但已经很久没有输入动作"时才动一下
# 也就是说：我们只是**让窗口保持活跃**，不改变平台对"学没学会"的判定。
COURSE_KEEPALIVE = _env_bool("DSHS_COURSE_KEEPALIVE", True)

# ---- 章节测验答完后要不要自动交卷 ----
# 学习通新版章节页顶上有「1 视频 / 2 章节测验」两栏，点「章节测验」是一整份卷子。
# True（默认）= 答完自动交卷，刷课一次跑完；
# False = 只把答案填上、不交卷，留给人看一眼。
# ⚠ 交了就不能改。所以关掉它的唯一理由就是"想先核对"。
COURSE_QUIZ_SUBMIT = _env_bool("DSHS_COURSE_QUIZ_SUBMIT", True)

# ---- 恢复播放：连续失败多少次之后，从"每次都点"退化成"每 30 秒慢重试" ----
# ⚠ 这是**退化阈值**，不是"放弃阈值"。到了之后照样会试，只是慢下来。
#
# 为什么需要这个：2026-10-17 13:28 的日志里，一节 1450 秒的视频
# 前 3 分半就暂停了 5 次、把额度用完，之后**整整 20 分钟一动不动**。
# 打一行"不再硬恢复"然后假装还在跑，是最难受的状态：
# 日志看着正常，进度一直是 0。
COURSE_RESUME_FAIL_MAX = _env_int("DSHS_COURSE_RESUME_FAIL_MAX", 30)

# ---- 「在场守卫」：鼠标离开播放器时，别让平台把视频按停 ----
# 证据（out\pause_trace.json，2026-10-17 13:54 探针）：
#   6 次暂停前 0~3ms 全都有一个 mouseout（目标是 .vjs-control-bar /
#   .sp_function / 播放器 iframe），而 visibilitychange / blur 一次都没有。
#   暂停是从 videojs-ext + all-classes（混淆层）调的。
# 做法：capture 阶段吞掉"目标是播放器"的
#   mouseout / mouseleave / pointerout / pointerleave，
#   再把 visibilityState / hidden / hasFocus 钉成"在场"。
# 代价：控制条不会自动隐藏（纯视觉）。不想要就关掉。
COURSE_PRESENCE_GUARD = _env_bool("DSHS_COURSE_PRESENCE_GUARD", True)

# ---- 置信度低于这个数就**不落笔** ----
# 为什么要有这条：2026-10-17 那两次运行，题干是平台加密字体的乱码，
# 模型只能瞎猜、给了 confidence=0.2，而程序**照样点选、照样交卷**。
# 正常题一般是 0.85~0.98，所以 0.35 这个阈值不会误伤。
# ⚠ 真要"无论如何都点"的话可以调成 0（但那样等于把这条护栏关掉）。
QUIZ_MIN_CONFIDENCE = _env_float("DSHS_QUIZ_MIN_CONFIDENCE", 0.35)

# ---- 关闭窗口时的行为 ----
#   tray = 最小化到托盘（**默认**，与改动前完全一样，不选就一切照旧）
#   exit = 完全退出程序
# ⚠ 只影响"页面被关掉"这件事。窗口的 X 按钮在预编译的启动器里，改不了。
CLOSE_ACTION = _env("DSHS_CLOSE_ACTION", "tray")

# pagehide 之后**预约退出**的宽限期（秒）。这段时间里新页面调 /api/hello 就取消。
# ⚠ 15 秒是按"用户刷新页面最多几秒"定的，不要凭感觉改小 ——
#   改小了会出现"按 F5 程序就没了"。
# DSHS_QUIT_GRACE 只为**测试**方便（测试里设 2 秒，跑得快），
# 所以不放进设置界面。
QUIT_GRACE = _env_float("DSHS_QUIT_GRACE", 15.0)
# 多久没有任何输入动作就轻动一下鼠标（秒）
COURSE_KEEPALIVE_SEC = _env_float("DSHS_COURSE_KEEPALIVE_SEC", 240.0)
# 视频进度多久没变化就认为是"卡住了/挂机了"（秒），
# 到了会尝试重新起播（原来这个值是写死的 45）
COURSE_STALL_SEC = _env_float("DSHS_COURSE_STALL_SEC", 45.0)


# ---------------------------------------------------------------- 路径
PKG_DIR = Path(__file__).resolve().parent


def _detect_project_dir() -> Path:
    r"""算出"程序根目录"，让运行数据落在该落的地方。

    ⚠ 这里踩过一个会**在交付包里生成垃圾目录**的坑：
      原来直接写 `PROJECT_DIR = PKG_DIR.parent`。源码仓库里这样是对的
      （`lmstudio-web-solver/dsh_solver` → `lmstudio-web-solver`），
      但**交付包的目录结构不一样**：

          昔涟自习室\                 ← 真正的程序根
            ├─ 昔涟自习室.exe
            ├─ runtime\python.exe
            └─ app\                   ← 包在这里
                 └─ dsh_solver\       ← PKG_DIR
                      └─ config.py

      `PKG_DIR.parent.parent` 才是程序根，而 `PKG_DIR.parent` 是 `app\`。
      后果：**任何没有先设好 DSHS_* 环境变量、却 import 了本模块的进程**，
      都会在导入期 mkdir 出 `app\out\`、`app\截图\` ——
      交付包里于是多出一堆来路不明的目录（正是审计报告 P0-4 说的现象），
      而且每个都要用户手动删。

      所以这里先探一下：父目录里有没有 `runtime\` 或启动器 exe？
      有 → 说明父目录本身才是程序根（交付版布局）。
      这样即使有人绕开 `server.py` 直接用 `runtime\python.exe` 跑，
      数据也仍然落在正确位置。
    """
    parent = PKG_DIR.parent                      # 交付包里是 app\
    try:
        # 父目录里出现 runtime\ 或启动器 → 父目录本身就是程序根
        if (parent / "runtime").is_dir():
            return parent
        for exe in ("昔涟自习室.exe", "MRS Study Assistant.exe", "启动.exe"):
            if (parent / exe).exists():
                return parent
        # 再上一层，覆盖"包直接放在根下"等其它布局
        grand = parent.parent
        if (grand / "runtime").is_dir():
            return grand
        for exe in ("昔涟自习室.exe", "MRS Study Assistant.exe", "启动.exe"):
            if (grand / exe).exists():
                return grand
    except Exception:
        pass
    return parent


PROJECT_DIR = _detect_project_dir()
OUT_DIR = Path(_env("DSHS_OUT_DIR", str(PROJECT_DIR / "out")))
RUNS_DIR = OUT_DIR / "runs"
# 截图默认放在**程序根目录下的「截图」文件夹**（独立版就是 昔涟自习室\截图\），
# 而不是埋在 out\ 里 —— 用户要靠截图排查问题时，这个位置一眼就能找到。
# 可被 DSHS_SHOT_DIR 或界面「设置 → 截图保存位置」覆盖。
SHOT_DIR = Path(_env("DSHS_SHOT_DIR", str(PROJECT_DIR / "截图")))
PROFILE_DIR = Path(_env("DSHS_PROFILE_DIR", str(PROJECT_DIR / ".chrome-profile")))
LOG_DIR = OUT_DIR / "logs"
TMP_DIR = Path(_env("DSHS_TMP_DIR", str(OUT_DIR / "tmp")))

# ⚠ 导入期 mkdir 的取舍：
#   好处是后面用的时候目录一定在；坏处是**只要 import 就会建目录** ——
#   像 `announce_check.py` 这种"只想查一次公告"的诊断脚本，
#   也会顺手在交付包里建出 out\metrics、out\logs …，等于撒垃圾。
#   所以：能建就建，**建不了就算了**（只读目录下别让 import 直接炸），
#   真正要用的时候各调用点自己再 mkdir 一次即可。
for _d in (OUT_DIR, RUNS_DIR, SHOT_DIR, LOG_DIR, TMP_DIR):
    try:
        _d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def ensure_dirs() -> None:
    """真正要用之前调一次，把该建的目录建齐。

    `import` 期只是"尽量建"，这里是"必须建"（还是失败就让它抛，
    因为那时确实没法工作，早点报错比后面莫名其妙好）。
    """
    for _d in (OUT_DIR, RUNS_DIR, SHOT_DIR, LOG_DIR, TMP_DIR):
        _d.mkdir(parents=True, exist_ok=True)


def apply_shot_dir(path: str | Path | None = None) -> Path:
    """设置截图目录（界面里可改），并确保它存在。

    返回最终生效的目录。传空则什么都不做。
    单独做成函数是因为它可能在运行时被改 —— 用户不必重启程序。
    """
    global SHOT_DIR
    if path is None:
        return SHOT_DIR
    p = str(path).strip()
    if not p:
        return SHOT_DIR
    try:
        new = Path(p).expanduser()
        new.mkdir(parents=True, exist_ok=True)
        # 真写一个文件试试，避免"看着能建目录其实没权限"
        probe = new / ".dsh_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        SHOT_DIR = new
    except Exception:
        return SHOT_DIR
    return SHOT_DIR

# Playwright 启动浏览器时要在 TEMP 下建临时目录；某些受限环境（公司策略、
# 沙箱、临时目录被清理工具锁住）会在这里报 EPERM。把 TEMP/TMP 指到工程内的
# 目录就能绕开。必须在任何 playwright 调用之前设好 —— 驱动是子进程，只读一次环境。
# DSHS_TMP_DIR="" 可关闭这个行为，改用系统 TEMP。
if _env_bool("DSHS_USE_LOCAL_TMP", True):
    os.environ["TEMP"] = str(TMP_DIR)
    os.environ["TMP"] = str(TMP_DIR)

# Playwright 自带内核的存放位置。独立版会把 Chromium 装到 out\ms-playwright，
# 这样在"目标机器没有 Edge/Chrome"的情况下也能跑，而且整个文件夹拷走即用。
# 必须在任何 playwright 调用之前设好（驱动是子进程，只读一次环境）。
_BROWSERS = OUT_DIR / "ms-playwright"
if _BROWSERS.is_dir():
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_BROWSERS))
