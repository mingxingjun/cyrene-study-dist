# -*- coding: utf-8 -*-
"""平台无关的核心引擎。

这个包里的代码**不允许出现任何具体平台的名字** —— 一条也不许，
连注释和 docstring 里也不许。判断标准很简单：
把 `dsh_solver/adapters/` 整个删掉，`import dsh_solver.core` 仍然应该成功。

（这条约束是可以用脚本检查的，见 tools/check_core_purity.py）

    core.models    —— 跨平台的数据模型（Course / Chapter / VideoState …）
    core.adapter   —— PlatformAdapter 接口 + 注册表
    core.video     —— 通用播放循环
"""
from .adapter import (PlatformAdapter, all_adapters, pick_adapter,
                      register)
from .models import (Chapter, Course, ExamPage, PlatformProgress, PlayResult,
                     VideoState)

__all__ = [
    "PlatformAdapter", "register", "all_adapters", "pick_adapter",
    "Course", "Chapter", "VideoState", "PlayResult", "ExamPage",
    "PlatformProgress",
]
