# -*- coding: utf-8 -*-
"""平台适配器接口 + 注册表。

设计原则
--------
1. **核心引擎不认识任何平台**。它只调这个文件里定义的方法。
   判断标准：把 `adapters/` 整个删掉，`core/` 应该还能 import 成功。
2. **接口要够用，但不要过度设计**。当前只有两个真实平台来检验它，
   所以宁可少定义、按需再加。
3. **适配器自己持有浏览器驱动**，接口里传的 `page` 只是给"想直接用
   Playwright 原生 API"的适配器留的口子；多数方法用不到它。
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .models import Chapter, Course, ExamPage, PlatformProgress, VideoState


class PlatformAdapter(ABC):
    """一个平台的适配器。

    子类通过实现下面这些方法来接入，核心引擎不关心它内部怎么写。
    """

    # ---- 元信息 ----
    platform_name: str = "未知平台"     # 给人看的名字
    key: str = "unknown"                # 机器名，用作日志/配置里的标识

    # ⚠ 调研结论（业界共识）：**这类平台普遍不自动交卷**。
    #   多数脚本只做到"答完"，然后提示用户自己检查后提交。
    #   有的平台的作业页反而必须自动点提交才算数。
    #   所以做成适配器的一个开关，而不是在引擎里写死。
    auto_submit_default: bool = False
    # 平台是否支持"自动推进下一节"。
    # 个别平台（SPA 类）只有**真实可信的点击**才推得动；
    # 我们用的是 Playwright，本来就能做到，所以默认 True。
    # 保留这个开关是为了将来接纯请求式的适配器。
    can_advance: bool = True

    def __init__(self, driver: Any = None, log=print, status=None) -> None:
        self.driver = driver
        self.log = log
        self.status = status or (lambda _s: None)
        # 懒建的业务引擎缓存（适配器桥接时用它复用已有逻辑）。
        # ⚠ 必须在这里显式初始化：`_bridge()` 靠 `if self._eng is not None`
        #   判断是否已建过；没有这个初始值就会 AttributeError。
        #   更要紧的是：**它绝不能在建缓存时新建第二个 Playwright** ——
        #   调用方通常已经有一个 driver，再 start 一次会直接报
        #   "using Playwright Sync API inside the asyncio loop"。
        self._eng: Any = None
        # 停止信号（由调用方通过 set_stop 注入；没注入就是永不停止）
        self._stop: Any = None

    # ------------------------------------------------------------------
    # 桥接辅助：复用 CourseRunner 里**已验证**的逻辑
    # ------------------------------------------------------------------
    def _bridge(self):
        """拿到一个可用的 `CourseRunner`，**复用本适配器的 driver**。

        为什么需要它：`course.py` 里那套平台交互逻辑是真机踩过很多坑
        才调对的（展开判据、卡片选取顺序、弹题暂停计时…）。
        在这些逻辑搬进适配器之前先**借用**它们，避免立刻出现两份
        会各自腐烂的代码。

        ⚠ 关键点：**绝不能新建第二个 Playwright**。
          `CourseRunner.__init__` 会自己建一个 `BrowserDriver`
          （即 `sync_playwright().start()`）。调用方若已有 driver，
          第二次 start 会直接报错。

          所以：**原对象有 driver 就直接把 driver 借过去**
          （用 `__new__` 绕开 `__init__`，避免它再去建浏览器）。
        """
        if self._eng is not None:
            return self._eng
        from ..course import CourseRunner
        if self.driver is not None:
            eng = CourseRunner.__new__(CourseRunner)      # 故意不跑 __init__
            eng.driver = self.driver
            eng.log = self.log
            eng.status = self.status
            eng._rate_actual = 0.0
        else:
            # 没有现成 driver 时才真的建一个（此时不会和别的实例打架）
            eng = CourseRunner(log=self.log, status=self.status)
        self._eng = eng
        return eng

    # ------------------------------------------------------------------
    # 识别与页面版本
    # ------------------------------------------------------------------
    @abstractmethod
    def match(self, url: str) -> int:
        """这个 URL 属于本平台吗？返回匹配分。

        0 = 不匹配；分数越高越优先。
        允许多个适配器命中同一个 URL（比如通用兜底和专用适配器都命中），
        由注册表挑**分数最高**的那个。
        """

    def page_type(self, url: str = "") -> str:
        """平台内部的**页面版本**标识（返回值由适配器自定义，核心引擎只当日志标签）。

        ⚠ 为什么需要这一层（调研结论）：
          同一个平台往往有**许多套互不兼容的页面** —— 实测有的平台同时存在
          六套学习页和十套作业页，DOM 完全不同。
          只按"平台"分流是不够的，那一层之下还要按"页面版本"再分一次。
          适配器用这个返回值决定走哪套选择器。
        """
        return ""

    # ------------------------------------------------------------------
    # 课程与章节
    # ------------------------------------------------------------------
    def get_courses(self, page: Any = None) -> list[Course]:
        """当前页/账号下的课程列表。

        课程页直开时返回单元素列表即可（多数场景够用）。
        """
        return []

    def get_all_chapters(self, page: Any = None, course: Course | None = None
                         ) -> list[Chapter]:
        """把**整门课**的章节一次性读出来（不是只读"当前可见的那一屏"）。

        ⚠ 为什么需要这个方法（调研结论）：
          有的平台**压根没有"下一节"按钮** —— 大章节之间必须靠
          脚本自己算出下一个目标，然后直接跳 URL。
          这类平台要求先把整门课递归展开读进内存，
          再据此决定跳哪一章。
          对它们来说，`next_chapter()` 的实现就必须建立在
          "已经拿到完整章节表"这个前提上，所以这里要单独给一个入口。

        默认实现就调 `get_chapters()` —— 结构简单的平台直接复用。
        """
        return self.get_chapters(page, course)

    @abstractmethod
    def get_chapters(self, page: Any, course: Course) -> list[Chapter]:
        """这门课的章节/知识点/任务点列表（含平台自己的完成进度）。

        允许只返回"当前这一层"能看到的 —— 平台结构简单的都这样。
        """

    def next_chapter(self, page: Any = None,
                     course: Course | None = None) -> Chapter | None:
        """挑下一个该学的节。返回 None = 这门课学完了。

        ⚠ 这个方法的默认实现刻意做成"**每次重新读一遍**"，
          而不是拿一份缓存列表去算 —— 因为平台的完成状态是**动态变化**的
          （学完一条，进度文字/角标就会变），缓存会立刻过期。

        默认策略（调研里最常见的两种）：
          ① 优先选"进度显示还差任务"的（n/n 或百分比）
          ② 其次选"没有已完成标记"的
        """
        try:
            chapters = self.get_all_chapters(page, course)
        except Exception:
            return None
        # ① 明确还差的
        for ch in chapters:
            need = ch.need
            if need is not None and need > 0:
                return ch
        for ch in chapters:
            if 0 <= ch.percent < 99.5:
                return ch
        # ② 没有完成标记的
        for ch in chapters:
            if not ch.done:
                return ch
        return None

    @abstractmethod
    def open_chapter(self, page: Any, chapter: Chapter) -> bool:
        """进入这一节。返回是否成功。"""

    # ------------------------------------------------------------------
    # 播放
    # ------------------------------------------------------------------
    @abstractmethod
    def get_video(self, page: Any) -> VideoState:
        """当前播放器状态。播放器可能在任意深度的 iframe 里。"""

    def max_rate(self) -> float:
        """本平台允许的最高倍速。默认 1.0（不加速）。"""
        return 1.0

    def set_rate(self, page: Any, rate: float) -> float:
        """设倍速，返回**实际生效**的值。

        默认实现：直接改 playbackRate 并回读。
        有的平台有倍速菜单、或者会把超限的值改回去，就需要覆盖它。
        """
        want = min(float(rate or 1.0), self.max_rate())
        v = self.get_video(page)
        if not v.found or v.frame is None:
            return 0.0
        try:
            return float(v.frame.evaluate(
                """(r) => { const v = document.querySelector('video');
                     if (!v) return 0;
                     try { v.playbackRate = r; } catch (e) {}
                     try { v.muted = true; } catch (e) {}
                     try { v.play(); } catch (e) {}
                     return v.playbackRate || 0; }""", want) or 0.0)
        except Exception:
            return 0.0

    def after_video_done(self, page: Any, chapter: Chapter) -> None:
        """一条视频播完后的收尾。

        有的平台要等它把进度结算完才认（播完立刻切走会丢进度），
        适配器可以在这里等待并确认。
        """

    def quiz_visible(self, page: Any) -> bool:
        """课中弹题是否出现（答完才能继续播）。默认没有。"""
        return False

    # 章节项 / 任务点的常见选择器（跨平台的保守集合）。
    # 只用于**定位"当前这一节"**，不是用来判断完成的 —— 判断完成时
    # 只在这个元素**内部**找标记，避免把别的章节的完成标记算进来。
    _CHAPTER_SELECTORS = (".child-info", ".chapter-item", ".file-item",
                          ".posCatalog_select", ".chapter_item",
                          ".chapter", ".section-item", ".unit-item")

    # 章节项 / 任务点的常见选择器（跨平台的保守集合）。
    # 只用于**定位"当前这一节"**，不是用来判断完成的 —— 判断完成时
    # 只在这个元素**内部**找标记，避免把别的章节的完成标记算进来。
    _CHAPTER_SELECTORS = (".child-info", ".chapter-item", ".file-item",
                          ".posCatalog_select", ".chapter_item",
                          ".chapter", ".section-item", ".unit-item")

    def progress(self, page: object = None,
                 chapter: Chapter | None = None) -> PlatformProgress:
        r"""读**平台自己记的**学习进度。

        ⚠ 这个方法为什么重要（本项目最贵的一个坑）：
          模块 docstring 把「以平台记录的进度为完成判据」列为最重要的设计，
          但实现它的那段代码（`_catalog()` + 四套目录选择器）**从未被调用过** ——
          实际生效的是 `cur / dur >= 0.98`，也就是**靠播放位置猜**。
          真机后果见过：视频播到结尾、平台一条都没记，于是同一节被反复重刷。

          这里把"这一节到底算不算学完"变成适配器必须回答的问题。

        **默认实现是通用的**：不绑平台，靠语义找（完成文案 / 计数 / 百分比）。
        找不到就返回 `found=False`，上层会**退回原来的播放位置判据** ——
        所以对未知页面不会有任何行为变化。这条很重要：
        不能让"没适配过的平台"因为这次改动而变差。

        ⚠ 两条硬约束：
          ① **只在"当前这一节"范围内找**。曾经写成全页搜索 `[class*=finish]`，
             结果把目录里**别的章节**的完成标记当成了"当前节已完成" ——
             这比不判还糟，会直接跳过没学的章节。
          ② 定位不到"当前节"就**放弃**（返回 found=False），
             宁愿退回旧判据，也不要给出错的进度。

        ⚠ 这段 JS 的转义是个坑（我第一版就栽在这）：它要穿过
          Python 源码 → Python 字符串 → JS 源码 → JS 正则 四层。
          正确做法是**先写对最终 JS，再只做一层最小转义** ——
          这里用 raw 三引号承载，所以文件里写的一个反斜杠，运行时就是一个反斜杠。
          尤其注意正则里的除号要写 `\/`（运行时 `\/`），
          多写一层变成 `\\/` 就会让 JS 提前结束正则、报
          `Invalid regular expression flags`。
        """
        if self.driver is None:
            return PlatformProgress()
        pg = getattr(self.driver, "page", None)
        if pg is None:
            return PlatformProgress()

        script = r"""(args) => {
            function txt(e) {
                return (e && (e.innerText || e.textContent) || '')
                    .replace(/\s+/g, ' ').trim();
            }
            // ---- 第一步：定位"当前这一节" ----
            const sels = args.sels || [];
            const want = args.want || '';
            let root = null;
            const CUR = /(^|[\s_-])(current|active|cur|selected|on)($|[\s_-])/i;
            for (const s of sels) {
                let list = [];
                try { list = Array.prototype.slice.call(
                        document.querySelectorAll(s)); }
                catch (e) { continue; }
                if (!list.length) continue;
                root = list.find(function (e) {
                    const c = (typeof e.className === 'string') ? e.className : '';
                    return CUR.test(c);
                }) || null;
                if (root) break;
            }
            if (!root && want) {
                for (const s of sels) {
                    let list = [];
                    try { list = Array.prototype.slice.call(
                            document.querySelectorAll(s)); }
                    catch (e) { continue; }
                    root = list.find(function (e) {
                        return ((e.innerText || e.textContent || '')
                            .replace(/\s+/g, ' ')).indexOf(want) >= 0;
                    }) || null;
                    if (root) break;
                }
            }
            if (!root) return null;          // 定位不到 → 放弃，退回旧判据

            // ---- 第二步：**只在这个元素内部**找进度 ----
            const scan = [root].concat(
                Array.prototype.slice.call(root.querySelectorAll('*')));

            // ① 完成标记（类名或短文案）
            const DONE_CLS = /(^|[\s_-])(finished|complete|completed|done|pass)($|[\s_-])/i;
            const DONE_TXT = /已完成|已学完|完成学习|completed|finished/i;
            let doneHit = '';
            for (const e of scan) {
                const c = (typeof e.className === 'string') ? e.className : '';
                if (c && DONE_CLS.test(c)) { doneHit = c.slice(0, 50); break; }
                const t = txt(e);
                if (t && t.length <= 24 && DONE_TXT.test(t)) {
                    doneHit = t; break;
                }
            }

            // ② 计数型（形如「3/5」「必学 4/5」）
            let fn = -1, total = -1, countText = '';
            const NUM = /(\d{1,4})\s*\/\s*(\d{1,4})/;
            for (const e of scan) {
                const t = txt(e);
                if (!t || t.length > 40) continue;
                const m = NUM.exec(t);
                if (m) {
                    fn = parseInt(m[1], 10); total = parseInt(m[2], 10);
                    countText = t;
                    if (total > 0) break;
                }
            }

            // ③ 百分比型（aria-valuenow / 文案 / 进度条宽度）
            let pct = -1;
            const PCT = /(\d{1,3}(?:\.\d+)?)\s*%/;
            const WID = /width\s*:\s*(\d{1,3}(?:\.\d+)?)%/;
            for (const e of scan) {
                if (e.getAttribute) {
                    const av = e.getAttribute('aria-valuenow');
                    if (av !== null && av !== '') {
                        const n = parseFloat(av);
                        if (isFinite(n)) { pct = Math.min(100, n); break; }
                    }
                    const w = WID.exec(e.getAttribute('style') || '');
                    if (w) { pct = parseFloat(w[1]); break; }
                }
                const t = txt(e);
                if (t && t.length <= 30) {
                    const m = PCT.exec(t);
                    if (m) { pct = Math.min(100, parseFloat(m[1])); break; }
                }
            }

            return { done: !!doneHit, doneHit: doneHit,
                     finished: fn, total: total,
                     countText: countText, percent: pct };
        }"""
        try:
            r = pg.evaluate(script, {
                "sels": list(self._CHAPTER_SELECTORS),
                "want": (chapter.name if chapter else "") or "",
            })
        except Exception:
            return PlatformProgress()
        if not r:
            return PlatformProgress()
        found = (bool(r.get("done"))
                 or int(r.get("total") or -1) > 0
                 or float(r.get("percent") or -1) >= 0)
        if not found:
            return PlatformProgress()
        return PlatformProgress(
            found=True,
            percent=float(r.get("percent") or -1),
            finished=int(r.get("finished") or -1),
            total=int(r.get("total") or -1),
            done=bool(r.get("done")),
            text=str(r.get("countText") or r.get("doneHit") or "")[:60],
            source="当前章节内语义扫描")
    def _frames(self, page: Any = None) -> list:
        """当前页面里的所有框架（主框架 + 全部子框架）。

        播放器、章节树经常在 iframe 里，所以适配器普遍需要遍历框架。
        """
        if self.driver is None:
            return []
        try:
            pg = getattr(self.driver, "page", None) or page
            if pg is None:
                return []
            out = [pg.main_frame]
            for fr in pg.frames:
                if fr != pg.main_frame:
                    out.append(fr)
            return out
        except Exception:
            return []

    def close_player(self, page: Any) -> None:
        """关掉当前播放器/返回列表。默认什么都不做。"""

    # ------------------------------------------------------------------
    # 答题（复用与平台无关的那条链路，这里只负责"进出"）
    # ------------------------------------------------------------------
    def get_exam(self, page: Any) -> ExamPage:
        """当前页是不是答题页。默认交给通用扫描判断。"""
        return ExamPage(is_exam=True)      # 通用扫描本来就能处理任意页面

    def submit_exam(self, page: Any) -> bool:
        """提交试卷。默认交给通用实现。"""
        return False

    # ------------------------------------------------------------------
    # 账号 / 生命周期
    # ------------------------------------------------------------------
    def get_user_info(self, page: Any = None) -> dict[str, Any]:
        """用户名等。读不到返回空字典。"""
        return {}

    def before_run(self, page: Any) -> None:
        """开始刷课/答题前的准备（有的平台要先切到某个视图）。"""

    # ------------------------------------------------------------------
    # 停止信号
    # ------------------------------------------------------------------
    def set_stop(self, stop: Any) -> None:
        """注入"用户点了停止吗"的检查器。

        为什么需要它：播放循环里有几处**会长时间等待**的地方（等课中弹题、
        等卡片渲染）。这些地方如果不查停止信号，用户点了"停止"之后程序
        还要傻等十几分钟才响应 —— 看起来就像卡死了。

        `stop` 可以是任何有 `check()` 方法的对象（抛异常表示要停），
        也可以是无参可调用对象（返回 True 表示要停）。两种都支持。
        """
        self._stop = stop

    def stopped(self) -> bool:
        """用户是不是要求停止了。**默认 False**（没注入信号就是永不停止）。"""
        stop = getattr(self, "_stop", None)
        if stop is None:
            return False
        try:
            if hasattr(stop, "check"):
                stop.check()          # 约定：抛异常 = 要停
                return False
            if callable(stop):
                return bool(stop())
        except Exception:
            return True               # check() 抛异常就是要停
        return False

    def describe(self) -> str:
        return f"{self.platform_name}({self.key})"

    # 便于日志
    def __repr__(self) -> str:      # pragma: no cover
        return f"<{type(self).__name__} {self.key}>"


# ---------------------------------------------------------------------------
# 注册表
# ---------------------------------------------------------------------------
_REGISTRY: list[type[PlatformAdapter]] = []


def register(cls: type[PlatformAdapter]) -> type[PlatformAdapter]:
    """把一个适配器类登记进来（当作装饰器用）。

        @register
        class MyPlatformAdapter(PlatformAdapter): ...
    """
    if cls not in _REGISTRY:
        _REGISTRY.append(cls)
    return cls


def all_adapters() -> list[type[PlatformAdapter]]:
    return list(_REGISTRY)


def ensure_registered() -> int:
    """确保适配器都已注册，返回注册数量。

    为什么要这样一个函数：`adapters/` 需要 import `course.py`（借用它已验证的
    逻辑），而 `course.py` 又需要能拿到适配器 —— 双向依赖。
    把"谁负责触发注册"这件事收在这一个地方，两边就都不用管顺序了。

    ⚠ 放在 core 里会不会破坏"core 与平台无关"？
      不会。它**只是 import 一个包名**，不认识里面任何适配器；
      而且失败是静默的（适配器没装 = 只有通用行为可用）。
    """
    if _REGISTRY:
        return len(_REGISTRY)
    try:
        import importlib
        importlib.import_module("dsh_solver.adapters")
    except Exception:
        pass
    return len(_REGISTRY)


def pick_adapter(url: str, *, driver=None, log=print, status=None
                 ) -> PlatformAdapter | None:
    """按匹配分挑一个适配器。都不匹配返回 None。

    分数相同时**先注册的优先** —— 所以 `adapters/__init__.py` 里
    具体平台的顺序要在通用兜底之前。
    """
    ensure_registered()
    best: tuple[int, type[PlatformAdapter]] | None = None
    for cls in _REGISTRY:
        try:
            inst = cls(driver=driver, log=log, status=status)
            score = int(inst.match(url or ""))
        except Exception:
            continue
        if score <= 0:
            continue
        if best is None or score > best[0]:
            best = (score, cls)
    if best is None:
        return None
    return best[1](driver=driver, log=log, status=status)
