# -*- coding: utf-8 -*-
"""核心编排器 —— 刷课的"主循环"。

这个文件是整套架构的收口：它把「打开课程 → 挑下一节 → 进入 → 播完 →
推进」这条**跨平台通用**的流程写一遍，具体差异全部问适配器。

**约束**：本文件里不允许出现任何平台名字（有脚本检查，见
`tools/check_core_purity.py`）。
"""
from __future__ import annotations

import time

from .. import config
from .adapter import PlatformAdapter
from .models import Course, PlayResult
from .video import play_until_done


class CourseEngine:
    """刷课引擎。只依赖适配器接口，不认识任何具体平台。"""

    def __init__(self, adapter: PlatformAdapter, *,
                 log=print, status=None, stop=None, alive=None) -> None:
        self.adapter = adapter
        self.log = log
        self.status = status or (lambda _s: None)
        self.stop = stop
        self._alive_fn = alive            # 由调用方注入"还活着吗"

    # ------------------------------------------------------------------
    def _alive(self) -> bool:
        if self.stop is not None:
            try:
                self.stop.check()
            except Exception:
                return False
        if self._alive_fn is not None:
            try:
                if not self._alive_fn():
                    return False
            except Exception:
                return False
        return True

    # ------------------------------------------------------------------
    def run(self, *, speed: float | None = None, mute: bool = True,
            auto_next: bool = True, max_lessons: int | None = None,
            ) -> list[PlayResult]:
        """把当前页面的这门课刷完。返回每条资源的播放结果。

        注意：**导航（打开哪个 URL）不在这里** —— 那是调用方的事，
        这样引擎就不依赖"用什么方式打开浏览器"。
        """
        speed = config.COURSE_SPEED if speed is None else speed
        max_lessons = config.COURSE_MAX_LESSONS if max_lessons is None else max_lessons
        a = self.adapter
        results: list[PlayResult] = []
        t0 = time.time()

        # 把停止信号交给适配器 —— 它内部有长时间等待（等课中弹题），
        # 不注入的话用户点了"停止"还要傻等十几分钟才响应。
        try:
            a.set_stop(self.stop)
        except Exception:
            pass

        a.before_run(None)

        course = Course(id="current", name="")
        try:
            cs = a.get_courses(None)
            if cs:
                course = cs[0]
                self.log(f"· 课程：{course.name or '(无名)'}")
        except Exception as e:
            self.log(f"· ⚠ 读课程信息失败（{type(e).__name__}），继续尝试")

        self.log(f"· 平台：{a.describe()}　目标倍速：{speed}×"
                 f"（平台上限 {a.max_rate()}×）")

        done_lessons = 0
        stall = 0
        seen: set[str] = set()          # 已经处理过的"节"，防同一节反复刷

        while done_lessons < max_lessons:
            if not self._alive():
                self.log("收到停止指令，正在停下…")
                break

            # ---- 挑下一节 ----
            # ⚠ 每次循环都**重新问一次**，不缓存章节表 ——
            #   平台的完成状态是动态的（学完一条，进度文字/角标立刻变），
            #   拿旧列表去算就会一直盯着同一条反复学。
            try:
                ch = a.next_chapter(None, course)
            except Exception as e:
                self.log(f"· ⚠ 读章节失败：{type(e).__name__}")
                break
            if ch is None:
                self.log("✔ 没有待完成的章节了，这门课刷完")
                break

            key = ch.id or ch.name
            self.log(f"—— 进入：{ch.name or key}"
                     + (f"　进度 {ch.finished}/{ch.total}" if ch.total >= 0 else "")
                     + " ——")

            # ---- 进入这一节 ----
            try:
                ok = a.open_chapter(None, ch)
            except Exception as e:
                self.log(f"· ⚠ 进入失败：{type(e).__name__}")
                ok = False
            if not ok:
                if key in seen:
                    # 连进都进不去，而且之前试过 → 别耗着
                    stall += 1
                    self.log(f"· ⚠ 这一节进不去（连续 {stall} 次）")
                    if stall >= 3:
                        self.log("✘ 连续进入失败，停止以免空转")
                        break
                seen.add(key)
                time.sleep(1.0)
                continue

            time.sleep(2.0)

            # ---- 播放 ----
            v = a.get_video(None)
            if not v.found:
                # 没有视频：可能是文档/PPT 类资源，打开过就算过
                self.log(f"  {ch.name or key}：没有可播视频（文档类），视为已过")
                results.append(PlayResult(title=ch.name or key, finished=True,
                                          seconds=0.0, note="无视频，点开即过"))
                done_lessons += 1
                a.close_player(None)
                continue

            r = play_until_done(a, None, ch.name or key, speed=speed, mute=mute,
                                chapter=ch)
            results.append(r)

            # ---- 播完收尾：给平台结算的机会 ----
            if r.finished:
                try:
                    a.after_video_done(None, ch)
                except Exception:
                    pass

            a.close_player(None)

            # ---- 判断有没有真的推进 ----
            try:
                nxt = a.next_chapter(None, course)
                moved = (nxt is None) or ((nxt.id or nxt.name) != key)
            except Exception:
                moved = True

            if moved:
                stall = 0
                if r.finished:
                    done_lessons += 1
            else:
                stall += 1
                self.log(f"⚠ 这一节看起来没有推进（连续 {stall} 次）"
                         f"—— 平台可能还没记上，或者这条不计入")
                if stall >= 3:
                    self.log("✘ 连续多次没有推进，停止以免空转")
                    break

        finished_n = sum(1 for x in results if x.finished)
        self.log("")
        self.log(f"===== 刷课结束：共 {len(results)} 节，{finished_n} 节播完，"
                 f"用时 {time.time() - t0:.0f} 秒 =====")
        return results
