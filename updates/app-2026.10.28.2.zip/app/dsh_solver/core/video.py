# -*- coding: utf-8 -*-
"""通用播放循环 —— 和平台无关。

从原来的 `_ai_play_video` 抽出来。里面所有"平台专属"的判断都通过
适配器接口问出去，这个文件里**不出现任何具体平台**。

这套逻辑踩过的坑都写在原处，搬过来时一起带上了，理由同样适用。
"""
from __future__ import annotations

import time

from .. import config
from .adapter import PlatformAdapter
from .models import PlayResult, VideoState


def find_video(adapter: PlatformAdapter, page, *, wait: float = 6.0) -> VideoState:
    """等播放器出现（最多等 wait 秒）。

    为什么要等：点开一条资源之后，播放器往往在**两层 iframe** 里，
    要等它逐层加载完才拿得到 <video>。
    而且只看一次是不够的 —— 上一条视频的元素可能还没被替换掉。

    ⚠ 这里也要检查"用户是否点了停止"：
      原来只有 while + sleep(0.5)，最长会把停止请求拖 `wait` 秒（默认 6，
      调用方传的是 10）才被响应 —— 用户看到的就是"点了停止没反应"。
      等待播放器是**有界**的，但期间响应停止几乎不花成本，没理由不做。
    """
    deadline = time.time() + max(0.5, wait)
    last = VideoState()
    while time.time() < deadline:
        if adapter.stopped():
            return last
        last = adapter.get_video(page)
        if last.found and last.duration > 0:
            return last
        time.sleep(0.5)
    return last


def play_until_done(adapter: PlatformAdapter, page, label: str, *,
                    speed: float, mute: bool = True,
                    quiz_total: float = 0.0,
                    chapter=None) -> PlayResult:
    r"""把当前视频看到底。返回播放结果。

    判定顺序（**顺序很重要**）：
      ① 播放器消失          → 结束（页面被收起 / 切走）
      ② 平台报 ended        → 真正播完
      ②' **平台进度说完成**  → 结束（比"播放位置到 98%"更权威）
      ③ 进度接近结尾        → 不直接算完，再等一会儿看能不能走到 ended
      ④ 进度长时间不动      → 卡住了，结束

    关于 ②' 为什么要插在中间：
      平台进度是**平台自己记的账**，而 `cur / dur >= 0.98` 只是**猜**。
      真机上见过视频播到 98%、平台一条都没记，于是同一节被反复重刷。
      读不到进度时 `progress()` 返回 found=False，行为与改动前完全一致 ——
      所以没适配过的平台不会因此变差。

    `chapter` 用于让适配器知道"现在学的是哪一节"（有的平台要按名字定位章节项）。
    """
    # ⚠ 先看用户是不是已经点了停止。
    #   否则会先走一遍 find_video（等待播放器），停下来的原因还被报成
    #   "打不开视频" —— 那是**误导性的结论**，会让排查的人去查页面结构，
    #   而真实原因只是用户按了停止。
    if adapter.stopped():
        adapter.log("  ⏹ 用户已停止，跳过本条")
        return PlayResult(title=label, finished=False, note="用户停止")

    st = find_video(adapter, page, wait=10.0)
    if not st.found:
        # 停止也可能是在 find_video 等待期间发生的 —— 同样要如实报告
        if adapter.stopped():
            adapter.log("  ⏹ 用户已停止，跳过本条")
            return PlayResult(title=label, finished=False, note="用户停止")
        adapter.log("  ⚠ 打不开视频：页面上找不到可播放的 <video>")
        return PlayResult(title=label, finished=False,
                          note="页面上找不到可播放的视频元素")

    rate_used = adapter.set_rate(page, speed)
    dur = float(st.duration or 0)
    adapter.log(f"· 视频时长 {dur:.0f} 秒"
                f"（{time.strftime('%M:%S', time.gmtime(int(dur)))}）")
    if rate_used:
        adapter.log(f"· 已设为 {rate_used}×")
    else:
        adapter.log("· ⚠ 倍速没设上（读不到实际倍速）")

    # 等待上限按视频时长动态算，不要固定值。
    # ⚠ 踩过的坑：原来固定 3 分钟，结果 13 分钟的视频播到一半就被切走。
    if dur > 0:
        wait_limit = (dur / max(rate_used or 1.0, 0.5)) * config.COURSE_WAIT_HEADROOM
        wait_limit = max(wait_limit, 300.0)
    else:
        wait_limit = config.COURSE_MAX_WAIT_MIN * 60
    adapter.log(f"· 本条最长等待 {wait_limit / 60:.1f} 分钟"
                f"（按 {dur:.0f}s ÷ {rate_used or 1}× 留 "
                f"{config.COURSE_WAIT_HEADROOM}× 余量）")

    t_start = time.time()
    waited = 0.0
    last_pos = -1.0
    stalled = 0.0
    last_report = 0.0
    last_rate_check = 0.0
    near_done_since = 0.0
    finished = False
    reason = ""
    cur = 0.0

    while True:
        time.sleep(config.COURSE_POLL_SEC)

        # ---- 课中弹题：等待期间**不计时** ----
        # 平台要求"有效学习时长"，把等题时间算进去反而可疑。
        #
        # ⚠ 这里必须有**硬上限**（原实现没有，是个死循环）：
        #   `quiz_visible` 是启发式判据，一旦命中一个永远不消失的元素
        #   （比如某个常驻的 `.el-dialog`），`while ...: sleep()` 就再也出不来，
        #   刷课永久卡住、只能用户手动点停止。
        if adapter.quiz_visible(page):
            adapter.log("  · 遇到课中弹题 —— 已暂停等待，答完会自动继续播放")
            adapter.status("等待课中弹题作答…")
            t_q = time.time()
            limit = config.COURSE_QUIZ_MAX_WAIT_MIN * 60
            timed_out = False
            stopped = False
            while adapter.quiz_visible(page):
                # 用户点停止要能立刻响应 —— 否则最长要等 limit 秒才退出，
                # 看起来就是"卡死了"
                if adapter.stopped():
                    stopped = True
                    break
                if time.time() - t_q > limit:
                    timed_out = True
                    break
                time.sleep(config.COURSE_QUIZ_POLL_SEC)
            quiz_total += time.time() - t_q
            if stopped:
                reason = "用户停止"
                break
            if timed_out:
                reason = (f"课中弹题等待超过 {config.COURSE_QUIZ_MAX_WAIT_MIN:.0f} 分钟"
                          f"仍未消失（可能判据误命中）")
                adapter.log(f"  ✘ {reason} —— 本条跳过")
                break
            adapter.log(f"  · 弹题已消失（等了 {time.time() - t_q:.0f} 秒），继续播放")
            adapter.set_rate(page, speed)
            last_rate_check = waited
            last_report = waited
            continue

        waited += config.COURSE_POLL_SEC
        st = adapter.get_video(page)
        if not st.found:
            reason = "页面上已经没有 <video> 了（播放器被收起或页面切走）"
            break

        cur = float(st.current or 0)
        dur = float(st.duration or dur or 0)

        # ② 真正播完
        if st.ended:
            finished = True
            reason = "播到结尾"
            break

        # ②' ★★★ 平台进度优先 ★★★
        #
        # 为什么放在 `ended` 之后、`98%` 之前：
        #   · `ended` 是最硬的信号（播放器自己说到结尾了），放最前
        #   · 平台进度比"播放位置到 98%"更权威 —— 后者只是**猜**。
        #     真机上见过视频播到 98%、平台一条都没记，于是同一节被反复重刷。
        #
        # `progress()` 读不到时返回 found=False，**行为与改动前完全一致**，
        # 所以没适配过的平台不会因为这次改动而变差。
        pprog = adapter.progress(page, chapter) if hasattr(adapter, "progress") else None
        if pprog is not None and pprog.complete:
            finished = True
            reason = f"平台进度显示已完成（{pprog.describe()}）"
            break

        # ③ 接近结尾：不立刻算完，再等一会儿看能不能触发 ended
        #
        # ⚠ 踩过的坑：原来 98% 就直接 break，真机日志显示四条视频全部
        #   "播完"但平台进度一条都没涨 —— 因为**从没触发过平台的结尾事件**。
        #   现在多等 20 秒；确实到不了结尾才按 98% 收尾。
        if dur and cur / dur >= config.COURSE_DONE_RATIO:
            if near_done_since <= 0:
                near_done_since = waited
                adapter.log(f"  · 已到 {cur / dur * 100:.1f}%，"
                            f"再等一会儿确认走到结尾…")
            elif waited - near_done_since >= 20.0:
                finished = True
                reason = f"进度到 {cur / dur * 100:.0f}%（未触发结尾事件）"
                break
        else:
            near_done_since = 0.0

        # 被暂停（切后台等）→ 继续播
        if st.paused:
            adapter.set_rate(page, speed)
            last_rate_check = waited
        # 倍速被平台改回去 → 立刻补设
        # （参考 Autovisor 的 video_optimize：每 2 秒轮询重设更稳）
        if rate_used and abs(float(st.rate or 1) - rate_used) > 0.05:
            adapter.set_rate(page, speed)
            last_rate_check = waited
        elif waited - last_rate_check >= 20:
            last_rate_check = waited
            now_rate = adapter.set_rate(page, speed)
            if now_rate and abs(now_rate - rate_used) > 0.05:
                rate_used = now_rate

        # 进度卡住检测
        if cur > last_pos + 0.2:
            last_pos = cur
            stalled = waited
        elif waited - stalled > 60:
            reason = f"进度卡在 {cur:.0f}s 超过 60 秒"
            break

        if waited - last_report >= 30:
            last_report = waited
            pct = (cur / dur * 100) if dur else 0
            adapter.log(f"  · 播放中 {cur:.0f}s/{dur:.0f}s（{pct:.0f}%）"
                        f" 倍速 {st.rate}×")

        if waited > wait_limit:
            reason = (f"单条等待超过上限 {wait_limit / 60:.1f} 分钟"
                      f"（时长 {dur:.0f}s ÷ 倍速 {rate_used or 1}"
                      f" ×{config.COURSE_WAIT_HEADROOM} 余量）")
            break

    secs = time.time() - t_start
    pct = f"{cur / dur * 100:.0f}%" if dur else "?"
    adapter.log(f"  {label}：{'✔ 已播完' if finished else '⚠ 未播完'}"
                f"（{pct}，用时 {secs:.0f} 秒）"
                + (f"，其中等弹题 {quiz_total:.0f} 秒" if quiz_total >= 1 else "")
                + ("" if finished else f"　停止原因：{reason or '未知'}"))
    return PlayResult(title=label, finished=finished, seconds=round(secs, 1),
                      duration=round(dur, 1), rate=rate_used,
                      note="" if finished else f"未完成（到 {cur:.0f}s / {dur:.0f}s）{reason}")
