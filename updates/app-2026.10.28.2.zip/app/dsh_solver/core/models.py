# -*- coding: utf-8 -*-
"""平台无关的数据模型。

这些东西**不包含任何平台的细节**，所有适配器都返回这几种类型，
核心引擎只认这些类型。要加新平台时不用改这里。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Course:
    """一门课。

    很多平台在"课程页直开"时只有一门课，那就返回单元素列表即可。
    """
    id: str = ""
    name: str = ""
    url: str = ""
    raw: dict[str, Any] = field(default_factory=dict)   # 平台原始数据，适配器自用


@dataclass
class Chapter:
    """一节要学的内容。

    把各平台的不同叫法统一成这一个概念：
      · 「知识点」（下面挂若干资源卡片，如资源卡片式课程页）
      · 「任务点」（如章节任务点式课程页）
      · 「课时」（如播放器式课程页）

    total / finished 是**平台自己报的进度**（形如「必学 4/6」）。
    这是判断"学完没有"的权威依据 —— 不要用 video.currentTime 猜。

    ⚠ 各平台的完成判定方式差别很大（调研结论），所以这里同时接受两种：
      · 布尔型：有没有"已完成"图标
      · 百分比型：进度文本 / aria-valuenow
    `done` 由适配器按自家规则算好，核心引擎不关心怎么算的。
    """
    id: str = ""
    name: str = ""
    url: str = ""
    done: bool = False
    total: int = -1          # -1 = 平台没给进度数字
    finished: int = -1
    percent: float = -1.0    # 百分比型进度（-1 = 未知）
    index: int = 0           # 在列表里的位置（适配器定位用）
    kind: str = ""           # 视频/文档/测验/讨论…（各平台叫法不同，做参考）
    page_type: str = ""      # 平台内部的"页面版本"标识（各平台自定义，核心只当日志）
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def need(self) -> int | None:
        """还差几条；读不到进度数字时返回 None。"""
        if self.total < 0 or self.finished < 0:
            return None
        return max(0, self.total - self.finished)

    @property
    def unknown(self) -> bool:
        """进度完全读不到（既没有 n/n 也没有百分比）。"""
        return self.need is None and self.percent < 0


@dataclass
class VideoState:
    """播放器当前状态。找不到播放器就 found=False。"""
    found: bool = False
    current: float = 0.0
    duration: float = 0.0
    ended: bool = False
    paused: bool = True
    rate: float = 1.0
    src: str = ""
    frame: Any = None        # Playwright Frame：播放器所在的框架

    @property
    def ratio(self) -> float:
        return (self.current / self.duration) if self.duration else 0.0


@dataclass
class PlayResult:
    """一条资源的播放结果（原 LessonResult 的等价物）。"""
    title: str = ""
    finished: bool = False
    seconds: float = 0.0
    duration: float = 0.0
    rate: float = 0.0
    note: str = ""


@dataclass
class ExamPage:
    """当前页是不是答题页；是就把题目/字段读出来。

    questions / fields 沿用 dsh_solver.browser 里的 PageState 结构，
    不在这里重新定义 —— 答题那条链路本来就与平台无关，没必要动。
    """
    is_exam: bool = False
    title: str = ""
    state: Any = None        # dsh_solver.browser.PageState
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class PlatformProgress:
    """**平台自己记录的学习进度** —— 判断"学完没有"的权威依据。

    为什么必须有这个类型
    --------------------
    项目里最强调的一条设计是「以平台记录的进度为完成判据，
    而不是 video.currentTime」。但这条铁律的代码写了却从未接线，
    实际生效的是 `cur / dur >= 0.98` 这个**猜测**。

    后果是真机上出现过的：视频明明播到结尾，平台一条都没记，
    于是程序一遍遍重刷同一节。

    这里把"平台进度"变成一等的返回值，让适配器去回答
    "这一节到底算不算学完了"，而不是让引擎靠播放位置猜。

    三种表达方式都要能装下（各家不一样）：
      · 计数型：`finished` / `total`（如平台写「必学 4/5」）
      · 百分比：`percent`（如进度条 60%、aria-valuenow）
      · 布尔型：`done`（如"已完成"图标）
    """
    found: bool = False          # 页面到底有没有可读的进度信息
    percent: float = -1.0        # 百分比；-1 = 未知
    finished: int = -1           # 已完成条数；-1 = 未知
    total: int = -1              # 总条数；-1 = 未知
    done: bool = False           # 这一节是否被标记为已完成
    text: str = ""               # 原始文案（打日志用，如「必学 4/5」）
    source: str = ""             # 进度是从哪读到的（便于排查）

    @property
    def need(self) -> int | None:
        """还差几条；读不到计数时返回 None。"""
        if self.total < 0 or self.finished < 0:
            return None
        return max(0, self.total - self.finished)

    @property
    def complete(self) -> bool:
        """**这一节算不算学完了。**

        判定顺序（从严到宽，任一成立即可）：
          ① 平台明确标记已完成
          ② 计数型进度显示已满
          ③ 百分比到 100（留 0.5 容差，有的平台写 99.5% 就算满）
        """
        if self.done:
            return True
        n = self.need
        if n is not None:
            return n <= 0
        if self.percent >= 0:
            return self.percent >= 99.5
        return False

    def describe(self) -> str:
        """给日志用的一句话。"""
        if not self.found:
            return "读不到平台进度"
        bits: list[str] = []
        if self.text:
            bits.append(self.text)
        if self.need is not None:
            bits.append(f"{self.finished}/{self.total}")
        elif self.percent >= 0:
            bits.append(f"{self.percent:.0f}%")
        if self.done:
            bits.append("已完成")
        if self.source:
            bits.append(f"来源:{self.source}")
        return " ".join(bits) or "有进度但内容为空"
