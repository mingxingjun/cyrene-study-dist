"""本地服务：给图形界面用的后端。

设计取向（对齐 MAA 那种「一键开始、实时看日志」的体验）：
  - 单进程、无第三方 Web 框架，只用标准库 http.server；
  - 事件走 SSE（Server-Sent Events），日志/状态/截图实时推到页面；
  - 配置持久化到 config.json，页面里填的 API Key 写进去，不用改代码；
  - 只监听 127.0.0.1，随机端口，仅本机可访问。

线程模型：
  主线程 = HTTP 服务（ThreadingHTTPServer，每个请求一个线程）
  工作线程 = SolverAgent（Playwright 的 sync API 不能跑在服务主线程里）
  两边只通过 EventBus 广播 + 一个 solvers 字典通信。
"""
from __future__ import annotations

import hmac
import json
import mimetypes
import os
import queue
import re
import secrets
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from . import announce, config, local_kb
from . import update as updater
from . import __version__ as _app_ver
from .agent import SessionResult, SolverAgent, StopFlag
from .course import CourseRunner
from .lms import LMError, LMStudioClient, meter
from .support_chat import answer_support
from .usage import fetch_balance

APP_NAME = "昔涟自习室 · Cyrene Study"
WEB_DIR = Path(__file__).resolve().parent.parent / "web"
# app\ 自己（不是程序根）：build.json 在 app\ 里，更新也只覆盖 app\
APP_ROOT = WEB_DIR.parent
CONFIG_FILE = Path(os.environ.get("DSHS_APP_CONFIG") or (config.OUT_DIR / "app_config.json"))

# ---------------------------------------------------------------------------
# API Key 落盘加密（2026-10-26 用户要求：配置文件里不能有明文 Key）
#
# 用 Windows 自带的 DPAPI（CryptProtectData）：
#   · 密钥由 Windows 按「当前用户 + 本机」派生，文件拷到别的电脑/别的账户解不开；
#   · 不需要第三方库，纯 ctypes；
#   · 解开失败时按"没填 Key"处理（不抛异常、不把密文当 Key 用）。
# 配置文件里存 `deepseek_api_key: "dpapi:<base64>"`，
# load_app_config() 读出来后解密成明文只放在**内存**里；
# save_app_config() 写盘前再加密。UI 永远只拿到掩码。
# ---------------------------------------------------------------------------
_KEY_FIELDS = ("deepseek_api_key", "kimi_api_key", "custom_api_key")
_ENC_PREFIX = "dpapi:"


def _dpapi(data: bytes, protect: bool) -> bytes:
    """CryptProtectData / CryptUnprotectData 的薄封装。失败返回 b""。"""
    try:
        import ctypes
        from ctypes import wintypes

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD),
                        ("pbData", ctypes.POINTER(ctypes.c_char))]

        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        buf = ctypes.create_string_buffer(data, max(1, len(data)))
        blob_in = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
        blob_out = DATA_BLOB()
        fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
        args = [ctypes.byref(blob_in), None, None, None, None,
                0, ctypes.byref(blob_out)]
        if not fn(*args):
            return b""
        try:
            return ctypes.string_at(blob_out.pbData, blob_out.cbData)
        finally:
            kernel32.LocalFree(blob_out.pbData)
    except Exception:
        return b""


def _encrypt_key(plain: str) -> str:
    raw = _dpapi(plain.encode("utf-8"), True)
    if not raw:
        return ""                      # 加密失败 → 由调用方决定怎么降级
    import base64
    return _ENC_PREFIX + base64.b64encode(raw).decode("ascii")


def _decrypt_key(value: str) -> str:
    if not value.startswith(_ENC_PREFIX):
        return value                   # 存量明文 / 旧配置：原样返回（下次保存会加密）
    import base64
    try:
        raw = base64.b64decode(value[len(_ENC_PREFIX):])
    except Exception:
        return ""
    plain = _dpapi(raw, False)
    try:
        return plain.decode("utf-8") if plain else ""
    except Exception:
        return ""


def _decrypt_cfg_keys(cfg: dict) -> dict:
    for k in _KEY_FIELDS:
        v = cfg.get(k)
        if isinstance(v, str) and v:
            cfg[k] = _decrypt_key(v)
    return cfg


def _encrypt_cfg_keys(cfg: dict) -> dict:
    out = dict(cfg)
    for k in _KEY_FIELDS:
        v = out.get(k)
        if isinstance(v, str) and v and not v.startswith(_ENC_PREFIX):
            enc = _encrypt_key(v)
            if enc:
                out[k] = enc
    return out


# 我们自己生成的截图文件名形如 `170925_001_trimcheck.png`。
# 与 browser.BrowserDriver._SHOT_NAME_RE 保持同一规则：截图目录被用户改成
# 「图片」之类的地方时，只允许清理这种名字的文件，用户自己的 PNG 一个都不能碰。
_OUR_SHOT_RE = re.compile(r"^\d{6}_\d{3}_.*\.png$", re.IGNORECASE)

# ---------------------------------------------------------------------------
# 本机控制面令牌（2026-10-22 安全加固）
#
# 为什么需要：服务只绑 127.0.0.1，但**本机上的其它网页**仍然能向它发请求。
# 之前只加了 X-Frame-Options / nosniff，那两条防不了「页面直接 fetch 127.0.0.1」：
# 攻击页可以用 text/plain 发一个「简单请求」，绕过 CORS 预检，改 base_url 再触发
# /api/test，把用户的 Key 送到自己的端点。绑定随机端口只能提高门槛。
#
# 做法：每次启动生成一个随机令牌，只在**服务端渲染 index.html 时**用
# SameSite=Strict + HttpOnly 的 Cookie 发给页面；之后页面发起的 /api/* 都要求它。
# 跨站页面拿不到、也带不上这个 Cookie，DNS rebinding 又会被 Host 校验拦住。
# 本机脚本（urllib/curl/诊断工具）没有浏览器来源头，仍可直连，避免弄坏回归。
# 令牌不进 URL，避免留在浏览器历史里。
_API_TOKEN = secrets.token_urlsafe(32)


# ---------------------------------------------------------------------------
# 配置持久化
# ---------------------------------------------------------------------------
DEFAULT_APP_CONFIG: dict[str, Any] = {
    "provider": config.PROVIDER,
    "deepseek_api_key": config.DEEPSEEK_API_KEY,
    "deepseek_model": config.DEEPSEEK_MODEL,
    "deepseek_base_url": config.DEEPSEEK_BASE_URL,
    "deepseek_thinking": config.DEEPSEEK_THINKING,
    # ---- Kimi（月之暗面）----
    "kimi_api_key": config.KIMI_API_KEY,
    "kimi_model": config.KIMI_MODEL,
    "kimi_base_url": config.KIMI_BASE_URL,
    # ---- 自定义（任意 OpenAI 兼容端点）----
    "custom_api_key": config.CUSTOM_API_KEY,
    "custom_model": config.CUSTOM_MODEL,
    "custom_base_url": config.CUSTOM_BASE_URL,
    "lm_base_url": config.LM_BASE_URL,
    "lm_model": config.LM_MODEL,
    "url": "",
    "headless": False,
    # 关闭窗口时：tray（最小化到托盘，默认）/ exit（完全退出程序）
    "close_action": config.CLOSE_ACTION,
    "auto_submit": config.AUTO_SUBMIT,
    "auto_next": config.AUTO_NEXT,
    "dry_run": config.DRY_RUN,
    "batch_size": config.BATCH_SIZE,
    "max_pages": config.MAX_PAGES,
    "max_rounds": config.MAX_ROUNDS,
    "pause_for_login": True,
    # 截图保存位置：留空 = 用默认（程序根目录下的「截图」文件夹）
    "shot_dir": "",
    # 每答完一轮就清掉上一轮的截图
    "clear_shots": config.CLEAR_SHOTS_EACH_ROUND,
    # ---- 自动刷课 ----
    "course_url": "",
    "course_speed": config.COURSE_SPEED,
    "course_mute": config.COURSE_MUTE,
    "course_auto_next": config.COURSE_AUTO_NEXT,
    "course_max_lessons": config.COURSE_MAX_LESSONS,
    # 防挂机：视频在播但长时间没操作时，轻移一下鼠标。
    # 只做"证明有人在"的最小动作，不伪造进度、不上报心跳。
    "course_keepalive": config.COURSE_KEEPALIVE,
    # 章节测验答完是否自动交卷（网课功能下的分支，默认开）
    "course_quiz_submit": config.COURSE_QUIZ_SUBMIT,
    # 鼠标离开播放器时别暂停（在场守卫）
    "course_presence_guard": config.COURSE_PRESENCE_GUARD,
    # 课中弹题：开着就用 AI 答掉；关掉则只等用户手动答（老行为）
    "course_quiz_auto": config.COURSE_QUIZ_AUTO,
    "course_quiz_max_wait_min": config.COURSE_QUIZ_MAX_WAIT_MIN,
    # ---- PC 模式（真·键鼠视觉模式）----
    # web = 网页里操作（DOM 主力，推荐）；pc = 整屏截图 → 模型给动作 → 真点真打字
    # ⚠ PC 模式会抢真实鼠标键盘，默认关闭、运行前二次确认。
    "mode": config.MODE,
    "pc_task": config.PC_TASK,
    "pc_max_steps": config.PC_AGENT_MAX_STEPS,
    "pc_confirm": config.PC_CONFIRM,
}


def _notify(level: str, text: str) -> None:
    """往界面推一条提示。**找不到事件总线就安静放弃**。

    ⚠ 为什么不能直接写 `BUS.emit(...)`：
      `load_app_config` / `save_app_config` 定义在文件前部（约 82/116 行），
      而 `BUS` 在 274 行才创建。函数体是**运行时**求值的，所以首次调用
      会 `NameError` —— 外面再包 try/except 的话，提示就**永远不会出现**，
      等于白写。
      这里用 `globals().get("BUS")` 做一次运行时查找，谁先谁后都不怕。
    """
    bus = globals().get("BUS")
    if bus is None:
        return
    try:
        bus.emit("log", {"level": level, "text": text})
    except Exception:
        pass


def _notify_toast(level: str, text: str) -> None:
    """同上，但推的是 toast（界面右下角的浮层）。"""
    bus = globals().get("BUS")
    if bus is None:
        return
    try:
        bus.emit("toast", {"level": level, "text": text})
    except Exception:
        pass


def load_app_config() -> dict[str, Any]:
    """读配置。**任何异常都降级成默认值**，但损坏时要让用户知道。

    ⚠ 原来这里是 `except Exception: pass` —— 配置文件截断（断电/强杀）
      时会静默回默认值，用户的 API Key、网址、所有开关**悄悄全丢**，
      而界面看起来一切正常。这种"数据丢失且用户不知道"是最糟的失败方式。
      现在：把坏文件改名留证 + 明确提示。
    """
    cfg = dict(DEFAULT_APP_CONFIG)
    if not CONFIG_FILE.exists():
        return cfg
    try:
        saved = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(saved, dict):
            cfg.update({k: v for k, v in saved.items() if k in DEFAULT_APP_CONFIG})
        # 存量明文 Key 会在下一次保存时自动加密；这里把密文解成内存明文
        return _decrypt_cfg_keys(cfg)
    except Exception as e:
        # 损坏：留一份现场，再回默认值
        bad = CONFIG_FILE.with_suffix(".json.bad")
        try:
            CONFIG_FILE.replace(bad)
        except Exception:
            bad = None
        _notify("error", f"✘ 配置文件损坏（{type(e).__name__}），已重置为默认值。"
                         + (f"原文件备份为：{bad}" if bad else ""))
        _notify_toast("error", "配置文件损坏，已重置为默认值（原文件已备份）")
        return cfg


def save_app_config(cfg: dict[str, Any]) -> bool:
    """保存配置。**失败不抛异常**，只返回 False 并提示。

    ⚠ 这里踩过一个会让程序"双击了没反应"的坑：
      原来这个函数没有任何 try/except，而 `serve()` 的**第一行**就调它。
      用户把包解压到 `C:\\Program Files\\`、只读共享盘，
      或配置文件被杀毒软件锁定时，`write_text` 抛 `PermissionError`：
        · `serve()` 直接中断 → 界面起不来
        · `main()` 的 `finally` 里 `httpd.shutdown()` 时 httpd 还不存在
          → 二次异常，用户只看到黑框一闪 + 英文 traceback
      配置写不进去**完全不影响本次运行**（内存里照样跑），
      所以这里必须降级而不是崩。

    另外把写入改成**原子替换**：直接 `write_text` 在断电/强杀时会留下
    半截 JSON，下次启动 `load_app_config()` 静默吞掉解析异常 →
     用户的 API Key、网址、所有开关全部悄悄回到默认值。
    `usage.py` 早就用了 `.tmp` + `os.replace`，这里和它保持一致。
    """
    cur = load_app_config()
    cur.update({k: v for k, v in cfg.items() if k in DEFAULT_APP_CONFIG})

    def _apply() -> None:
        """把配置写进进程内存 —— 写盘失败也要生效。"""
        config.PROVIDER = str(cur.get("provider") or config.PROVIDER)
        config.DEEPSEEK_API_KEY = str(cur.get("deepseek_api_key") or "")
        config.DEEPSEEK_MODEL = str(cur.get("deepseek_model") or config.DEEPSEEK_MODEL)
        config.DEEPSEEK_BASE_URL = str(cur.get("deepseek_base_url") or config.DEEPSEEK_BASE_URL).rstrip("/")
        config.DEEPSEEK_THINKING = bool(cur.get("deepseek_thinking"))
        # ---- Kimi ----
        config.KIMI_API_KEY = str(cur.get("kimi_api_key") or "")
        config.KIMI_MODEL = str(cur.get("kimi_model") or config.KIMI_MODEL)
        config.KIMI_BASE_URL = str(cur.get("kimi_base_url") or config.KIMI_BASE_URL).rstrip("/")
        # ---- 自定义 ----
        config.CUSTOM_API_KEY = str(cur.get("custom_api_key") or "")
        config.CUSTOM_MODEL = str(cur.get("custom_model") or "")
        config.CUSTOM_BASE_URL = str(cur.get("custom_base_url") or "").rstrip("/")
        config.LM_BASE_URL = str(cur.get("lm_base_url") or config.LM_BASE_URL).rstrip("/")
        config.LM_MODEL = str(cur.get("lm_model") or "")
        config.BATCH_SIZE = int(cur.get("batch_size") or 1)
        config.MAX_PAGES = int(cur.get("max_pages") or 80)
        config.MAX_ROUNDS = int(cur.get("max_rounds") or 60)
        config.AUTO_SUBMIT = bool(cur.get("auto_submit"))
        config.AUTO_NEXT = bool(cur.get("auto_next", True))
        config.DRY_RUN = bool(cur.get("dry_run"))
        config.CLEAR_SHOTS_EACH_ROUND = bool(cur.get("clear_shots", True))
        # ---- 自动刷课 ----
        try:
            config.COURSE_SPEED = float(cur.get("course_speed") or config.COURSE_SPEED)
        except (TypeError, ValueError):
            pass
        config.COURSE_MUTE = bool(cur.get("course_mute", True))
        config.COURSE_AUTO_NEXT = bool(cur.get("course_auto_next", True))
        config.COURSE_KEEPALIVE = bool(cur.get("course_keepalive", True))
        config.COURSE_QUIZ_SUBMIT = bool(cur.get("course_quiz_submit", True))
        config.COURSE_PRESENCE_GUARD = bool(
            cur.get("course_presence_guard", True))
        # 关闭窗口时的行为。只认 tray / exit 两个值，其它一律回落 tray ——
        # 免得配置被手改坏之后，关窗口的行为变得不可预期。
        _ca = str(cur.get("close_action") or "tray").strip().lower()
        config.CLOSE_ACTION = _ca if _ca in ("tray", "exit") else "tray"
        config.COURSE_QUIZ_AUTO = bool(cur.get("course_quiz_auto", True))
        try:
            _mw = float(cur.get("course_quiz_max_wait_min")
                        or config.COURSE_QUIZ_MAX_WAIT_MIN)
            if _mw > 0:
                config.COURSE_QUIZ_MAX_WAIT_MIN = _mw
        except (TypeError, ValueError):
            pass
        # ---- PC 模式 ----
        _mode = str(cur.get("mode") or "web").strip().lower()
        config.MODE = _mode if _mode in ("web", "pc") else "web"
        config.PC_TASK = str(cur.get("pc_task") or "")
        config.PC_CONFIRM = bool(cur.get("pc_confirm", True))
        try:
            config.PC_AGENT_MAX_STEPS = int(cur.get("pc_max_steps")
                                            or config.PC_AGENT_MAX_STEPS)
        except (TypeError, ValueError):
            pass
        try:
            config.COURSE_MAX_LESSONS = int(cur.get("course_max_lessons")
                                            or config.COURSE_MAX_LESSONS)
        except (TypeError, ValueError):
            pass
        # ★ 2026-10-23 修 B1：截图目录能在界面里改，必须**在这里**生效。
        #   原来这行写在函数最后 `return` 之后（不可达），于是
        #   「设置 → 截图保存位置」永久不生效 —— 用户以为改了，
        #   文件还是写在默认的「截图\」里，重启也一样（因为 serve() 只调本函数）。
        #   apply_shot_dir 自己会 try/except，失败就保持原目录，不会影响保存。
        config.apply_shot_dir(cur.get("shot_dir") or None)

    _apply()        # 先让内存生效，再尝试落盘

    try:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = CONFIG_FILE.with_suffix(".json.tmp")
        # 写盘前把 Key 加密（内存里 cur 仍是明文，不影响本次运行）
        tmp.write_text(json.dumps(_encrypt_cfg_keys(cur), ensure_ascii=False, indent=2),
                       encoding="utf-8")
        os.replace(tmp, CONFIG_FILE)      # 原子替换，断电也不会留半截文件
        return True
    except OSError as e:
        # 只读目录 / 杀软拦截 / 磁盘满 —— 提示一次即可，不要打断程序
        _notify("warn", f"⚠ 配置无法保存（{type(e).__name__}）：{CONFIG_FILE}")
        _notify_toast("warn", "设置无法保存到磁盘（目录只读？），本次运行仍会生效")
        return False


def mask_key(k: str) -> str:
    if not k:
        return ""
    return f"{k[:6]}...{k[-4:]}" if len(k) > 12 else "已设置"


# ---------------------------------------------------------------------------
# 事件总线（SSE）
# ---------------------------------------------------------------------------
class EventBus:
    def __init__(self) -> None:
        self._subs: list[queue.Queue] = []
        self._lock = threading.Lock()
        self.tail: list[dict] = []          # 保留最后若干条，供新连接补发
        # 自增序号（审计 C-11）。
        # ⚠ 只靠 `tail` 的**位置**没法区分"新连接"和"断线重连"：
        #   浏览器 EventSource 自动重连时会带上 `Last-Event-ID`，
        #   但我们原来不回 `id:`，于是重连被当成新连接、把最近 60 条**重放一遍**，
        #   界面日志里同一批内容重复插入（抖动几次就把上限撑满了）。
        #   有了序号就能只补"比它新的"。
        self._seq = 0

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=500)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._lock:
            if q in self._subs:
                self._subs.remove(q)

    @property
    def next_seq(self) -> int:
        with self._lock:
            return self._seq

    def backlog(self, last_id: int, limit: int = 60) -> list[dict]:
        """返回"比 last_id 新"的事件，最多 limit 条。

        `last_id<=0` 表示全新连接（只给最近 limit 条当上下文）；
        `last_id>0` 表示重连（只给它之后漏掉的，不会重复）。
        ⚠ 若 last_id 已经比 tail 里最早的还旧（断线太久、旧的被裁掉了），
          就退化成"给最近 limit 条" —— 有重叠好过丢内容。
        """
        with self._lock:
            tail = list(self.tail)
        if last_id > 0:
            newer = [e for e in tail if int(e.get("_seq") or 0) > last_id]
            if newer:
                return newer[:max(1, limit)]
            # 没有任何更新的 → 说明断线期间没有新事件，什么都不用补
            if tail and int(tail[-1].get("_seq") or 0) <= last_id:
                return []
        return tail[-limit:]

    def emit(self, kind: str, data: Any) -> None:
        with self._lock:
            self._seq += 1
            ev = {"kind": kind, "data": data, "ts": time.time(),
                  "_seq": self._seq}
            self.tail.append(ev)
            if len(self.tail) > 300:
                self.tail = self.tail[-300:]
            subs = list(self._subs)
        for q in subs:
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass
        # 顺便落盘。
        # 为什么：界面日志看得见、但**用户没地方查、也不方便复制给开发者**。
        # 出了问题时只要能拿到这个文件，就不用来回问"日志里写了什么"。
        _log_to_file(kind, data)


# 日志文件：out\logs\运行日志.txt（每次启动追加一段，超过 2MB 自动截断）
LOG_FILE = config.OUT_DIR / "logs" / "运行日志.txt"
_LOG_LOCK = threading.Lock()


def _log_to_file(kind: str, data: Any) -> None:
    if kind not in ("log", "status", "run", "result", "toast"):
        return                                   # 截图这类事件不落盘，太吵
    try:
        text = ""
        if isinstance(data, dict):
            text = str(data.get("text") or data.get("reason") or data.get("state") or "")
            if kind == "result":
                text = json.dumps(data, ensure_ascii=False)[:400]
        else:
            text = str(data)
        if not text:
            return
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{stamp}] {kind:>6} | {text}\n"
        with _LOG_LOCK:
            LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
            try:
                if LOG_FILE.exists() and LOG_FILE.stat().st_size > 2 * 1024 * 1024:
                    LOG_FILE.unlink()
            except Exception:
                pass
            with open(LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
                f.write(line)
    except Exception:
        pass                                     # 落盘失败绝不能影响主流程


BUS = EventBus()
RUN_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# 自动更新
#
# 分工：
#   update.py          查清单 / 下载 / 校验 / 解压暂存（不碰运行中的文件）
#   bootstrap_update.py 下次启动前换目录（在 server.py 里、import 之前跑）
#   这里               界面用的接口 + 启动后静默检查 + 后台下载
#
# 设计原则：
#   * 任何一步失败都只写日志/提示，绝不阻塞或打断正在进行的任务；
#   * 运行中**不替换任何程序文件**，只往 out\updates 里放暂存；
#   * 进度靠前端轮询 /api/update（700 ms 一次），不额外开 SSE 频道。
# ---------------------------------------------------------------------------
UPDATE_LOCK = threading.Lock()
UPDATE_STATE: dict[str, Any] = {
    "phase": "idle",      # idle / downloading / staged / error
    "build": "",          # 正在处理的版本
    "latest": "",         # 最近一次检查看到的远端版本
    "pct": 0,
    "error": "",
    "checked_at": 0.0,
}
_last_manifest: dict | None = None


def _update_snapshot() -> dict:
    local = updater.local_build(APP_ROOT)
    pend = updater.pending(config.OUT_DIR)
    cfg = updater.load_settings(config.OUT_DIR)
    with UPDATE_LOCK:
        st = dict(UPDATE_STATE)
    return {
        "ok": True,
        "build": local,
        "dev": local == "dev",
        "latest": str(st.get("latest") or ""),
        "newer": updater.is_newer(str(st.get("latest") or ""), local),
        "phase": str(st.get("phase") or "idle"),
        "pct": int(st.get("pct") or 0),
        "error": str(st.get("error") or ""),
        "checked_at": float(st.get("checked_at") or 0.0),
        "pending": bool(pend),
        "pending_build": str(pend.get("build") or ""),
        "enabled": bool(cfg.get("enabled")),
        "auto_download": bool(cfg.get("auto_download")),
        "manual_url": updater.MANUAL_URL,
        # 清单里带了提取码就用清单的（以后换密码不用改客户端）
        "manual_password": str((_last_manifest or {}).get("full_password")
                               or updater.MANUAL_PASSWORD),
    }


def _update_check(force: bool = False) -> dict:
    """查一次清单，把结果记进 UPDATE_STATE。失败不抛异常。"""
    global _last_manifest
    try:
        r = updater.check(config.OUT_DIR, APP_ROOT, force=force)
    except Exception as e:  # 理论上 check 内部已经兜住，这里再兜一层
        r = {"ok": False, "error": f"{type(e).__name__}: {e}",
             "skipped": False, "dev": False, "local": "", "manifest": None, "latest": ""}
    with UPDATE_LOCK:
        UPDATE_STATE["checked_at"] = time.time()
        UPDATE_STATE["latest"] = str(r.get("latest") or "")
        UPDATE_STATE["error"] = "" if r.get("ok") else str(r.get("error") or "")
    m = r.get("manifest")
    if m:
        _last_manifest = m
        with UPDATE_LOCK:
            UPDATE_STATE["latest"] = str(m.get("build") or "")
    return r


def _update_download_worker(manifest: dict) -> None:
    build = str(manifest.get("build") or "")
    with UPDATE_LOCK:
        if UPDATE_STATE.get("phase") == "downloading":
            return
        UPDATE_STATE.update(phase="downloading", pct=0, error="", build=build)

    def _prog(got: int, total: int) -> None:
        with UPDATE_LOCK:
            UPDATE_STATE["pct"] = max(0, min(100, int(got * 100 / max(1, total))))

    try:
        z = updater.download(manifest, config.OUT_DIR, progress=_prog)
        updater.stage(z, config.OUT_DIR, build)
        with UPDATE_LOCK:
            UPDATE_STATE.update(phase="staged", pct=100)
        BUS.emit("toast", {"level": "ok",
                           "text": f"新版本 {build} 已下载，重启后生效", "ms": 9000})
        _log_to_file("log", {"text": f"更新已下载并暂存：{build}"})
    except Exception as e:
        with UPDATE_LOCK:
            UPDATE_STATE.update(phase="error", error=f"{type(e).__name__}: {e}")
        BUS.emit("toast", {"level": "warn", "text": f"更新下载失败：{e}", "ms": 9000})
        _log_to_file("log", {"text": f"更新下载失败：{type(e).__name__}: {e}"})


def _update_boot_check() -> None:
    """启动后静默查一次（在后台线程里，晚 4 秒，别和启动抢资源）。"""
    time.sleep(4)
    try:
        r = _update_check(force=False)
        if r.get("skipped") or r.get("dev") or not r.get("ok"):
            return
        m = r.get("manifest")
        if not m:
            return
        if not updater.is_newer(str(m.get("build")), str(r.get("local"))):
            return
        if updater.load_settings(config.OUT_DIR).get("auto_download"):
            _update_download_worker(m)
        else:
            BUS.emit("toast", {"level": "info",
                               "text": f"发现新版本 {m.get('build')}，可在「关于」页更新", "ms": 7000})
    except Exception as e:
        _log_to_file("log", {"text": f"启动检查更新失败：{type(e).__name__}: {e}"})


def _launcher_exe() -> Path | None:
    root = Path(config.PROJECT_DIR).resolve()
    for name in LAUNCHER_NAMES:
        p = root / name
        if p.is_file():
            return p
    return None


def _restart_after_update() -> None:
    """拉起启动器 → 等旧进程退干净 → 退出。3 秒延迟是给单实例锁/端口让路。"""
    exe = _launcher_exe()
    if exe is None:
        BUS.emit("toast", {"level": "warn",
                           "text": "没找到启动器 exe，请手动关掉程序再打开", "ms": 9000})
        return
    try:
        subprocess.Popen(
            ["cmd", "/c", f'timeout /t 3 /nobreak >nul & start "" "{exe}"'],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception as e:
        BUS.emit("toast", {"level": "warn", "text": f"重启失败：{e}", "ms": 9000})
        return
    time.sleep(0.6)
    quit_app("应用更新后重启")


# ---------------------------------------------------------------------------
# 任务
# ---------------------------------------------------------------------------
def _fmt_answer(a: Any) -> str:
    if isinstance(a, list):
        return "".join(str(x) for x in a)
    return str(a)


def _keep_urls_nonempty(cfg: dict[str, Any]) -> None:
    """别让"留空"把已保存的网址冲掉。

    前端在点「开始」时会把输入框的内容一起发过来，留空就发空串。
    如果直接存下来，用户下次打开会发现网址没了 —— 而留空恰恰是**推荐用法**
    （表示"用浏览器当前那一页"），所以空白不该覆盖旧值。

    AI Key 早就按同样的思路处理了（留空 = 不改动），这里保持一致。
    """
    for key in ("url", "course_url"):
        if not str(cfg.get(key) or "").strip():
            try:
                old = load_app_config().get(key) or ""
            except Exception:
                old = ""
            if str(old).strip():
                cfg[key] = old


def run_course_task(cfg: dict[str, Any], *, once: bool = False) -> None:
    """独立线程里跑自动刷课，并把过程广播出去。"""
    url = str(cfg.get("course_url") or cfg.get("url") or "").strip()

    BUS.emit("run", {"state": "starting", "reason": ""})

    flag = StopFlag()
    with RUN_LOCK:
        ACTIVE["course_stop"] = flag

    def log(s: str) -> None:
        BUS.emit("log", {"level": _guess_level(s), "text": s})

    # ★ 课中弹题自动作答要一个模型客户端。
    #   ⚠ 单独 try：没配 API Key 时**不该让整个刷课起不来** ——
    #     自动作答只是锦上添花，没有它就退化成"等用户手动答"。
    _qclient = None
    if config.COURSE_QUIZ_AUTO:
        try:
            _qclient = LMStudioClient()
        except Exception as e:
            log(f"提示：课中弹题自动作答拿不到模型客户端"
                f"（{type(e).__name__}: {str(e)[:60]}）—— 本次改为等你手动答")

    # ⚠ 不要直接读 `PREP["running"]` —— 它可能被 `proc.poll()` 误判成 False
    #   （见 `prep_status()` 里那段说明）。`prep_status()` 会先探端口再回答，
    #   拿它给的 cdp_url 才可靠。
    _prep = prep_status()
    _prep_cdp = _prep.get("cdp_url") or _best_cdp() or None
    if _prep_cdp:
        log(f"· 复用准备阶段的浏览器（{_prep_cdp}），不用重新登录")
    runner = CourseRunner(
        headless=bool(cfg.get("headless")),
        cdp_url=_prep_cdp,
        log=log,
        status=lambda s: BUS.emit("status", {"text": s}),
        stop=flag,
        client=_qclient,
        auto_quiz=bool(config.COURSE_QUIZ_AUTO),
        quiz_submit=bool(config.COURSE_QUIZ_SUBMIT),
        single_page=bool(once),
        discuss_force=bool(once),
    )
    # 记下 driver：退出时要靠它关掉 Playwright（否则 node.exe 一直留着）
    ACTIVE["driver"] = getattr(runner, "driver", None)
    BUS.emit("run", {"state": "running", "reason": ""})

    try:
        if not url:
            log("提示：没填课程网址，将直接接管当前已打开的浏览器页面。")
        res = runner.run(
            url or None,
            speed=float(cfg.get("course_speed") or config.COURSE_SPEED),
            mute=bool(cfg.get("course_mute", True)),
            auto_next=bool(cfg.get("course_auto_next", True)),
            max_lessons=int(cfg.get("course_max_lessons") or config.COURSE_MAX_LESSONS),
        )
        BUS.emit("result", {
            "kind": "course",
            "ok": res.ok,
            "lessons": len(res.lessons),
            "finished": sum(1 for x in res.lessons if x.finished),
            "reason": res.stopped_reason,
            "error": res.error,
        })
    except Exception as e:
        log(f"✘ 出错：{type(e).__name__}: {e}")
        BUS.emit("result", {"kind": "course", "ok": False, "lessons": 0,
                            "finished": 0, "error": str(e)})
    finally:
        with RUN_LOCK:
            ACTIVE["course_stop"] = None
        BUS.emit("run", {"state": "idle", "reason": ""})


def run_web_task(cfg: dict[str, Any]) -> None:
    """在一个独立线程里跑网页答题任务，并把过程广播出去。"""
    url = str(cfg.get("url") or "").strip()
    # ⚠ 这里原来"没网址就直接拒绝"。但那和本文件自己的设计矛盾：
    #   `_keep_urls_nonempty` 的注释明确写着「留空恰恰是**推荐用法**
    #   （表示"用浏览器当前那一页"）」，而 `agent.run_web(url=None)`
    #   也确实支持不导航、直接接管当前页。
    #   所以正确的规则是：
    #     · 已经用「打开浏览器登录」备好了浏览器 → **允许留空**（接管当前页）
    #     · 没有备好浏览器 → 留空会新开一个空白窗口，等于什么都没法做 → 必须填
    # ⚠ 别直接读 PREP["running"] —— 它可能被误判成 False（见 prep_status）
    prep_ready = bool(prep_status().get("cdp_url"))
    if not url and not prep_ready:
        BUS.emit("log", {"level": "warn",
                         "text": "没填网址，而且还没有已登录的浏览器。"
                                 "请先点「打开浏览器登录」，或直接填写作业网址。"})
        BUS.emit("toast", {"level": "error", "text": "请填写网址，或先点「打开浏览器登录」"})
        BUS.emit("run", {"state": "idle", "reason": "缺少网址"})
        return

    BUS.emit("run", {"state": "starting", "reason": ""})
    try:
        client = LMStudioClient()
    except LMError as e:
        BUS.emit("log", {"level": "error", "text": str(e)})
        BUS.emit("toast", {"level": "error", "text": "模型配置有问题，请到「设置」检查"})
        BUS.emit("run", {"state": "idle", "reason": "模型不可用"})
        return
    except Exception as e:
        BUS.emit("log", {"level": "error", "text": f"初始化失败：{e}"})
        BUS.emit("run", {"state": "idle", "reason": "初始化失败"})
        return

    BUS.emit("log", {"level": "info",
                     "text": f"模型：{client.model}（{client.provider}）｜视觉：{'支持' if client.is_vision_capable() else '不支持'}"})

    def on_shot(p: Path) -> None:
        try:
            BUS.emit("shot", {"name": Path(p).name})
        except Exception:
            pass

    def on_answer(stem: str, ans: str, reason: str = "",
                  confidence: float = 0.0) -> None:
        # ★ 2026-10-22：多传 reason / confidence（都是可选参数，旧调用方式不受影响）。
        #   之前只传 stem/answer，界面上就只能看到一个字母。
        try:
            _conf = round(float(confidence or 0), 2)
        except (TypeError, ValueError):
            _conf = 0.0
        BUS.emit("answer", {
            "stem": (stem or "")[:120],
            "answer": ans,
            "reason": (reason or "")[:400],
            "confidence": _conf,
        })

    agent = SolverAgent(
        client,
        log=lambda s: BUS.emit("log", {"level": _guess_level(s), "text": s}),
        status=lambda s: BUS.emit("status", {"text": s}),
        on_shot=on_shot,
        on_answer=on_answer,
        # 不用弹窗阻塞：登录没做完就让它干净地停下，并告诉用户该点哪个按钮
        ask_user=None,
        auto_submit=bool(cfg.get("auto_submit")),
        dry_run=bool(cfg.get("dry_run")),
        batch_size=int(cfg.get("batch_size") or 1),
        max_rounds=int(cfg.get("max_rounds") or 60),
        auto_next=bool(cfg.get("auto_next", True)),
        max_pages=int(cfg.get("max_pages") or 80),
    )
    with RUN_LOCK:
        ACTIVE["agent"] = agent
    BUS.emit("run", {"state": "running", "reason": ""})

    # 每轮都同步一次 driver，保证退出时拿得到（agent 的 driver 是懒建的）
    def _sync_driver() -> None:
        try:
            ACTIVE["driver"] = getattr(agent, "driver", None)
        except Exception:
            pass

    _sync_driver()
    # 用一个低频守护线程同步：比在 run_web 里插桩更省事，
    # 而且 agent 建 driver 的时机不受我们控制。
    def _watch_driver() -> None:
        while ACTIVE.get("agent") is agent:
            _sync_driver()
            time.sleep(1.0)

    threading.Thread(target=_watch_driver, daemon=True).start()

    try:
        res: SessionResult = agent.run_web(
            url,
            headless=bool(cfg.get("headless")),
            # 已经用「打开浏览器登录」备好浏览器（带调试端口）时，直接接管它，
            # 这样登录态天然复用；否则才另起一个（新窗口必然是未登录的，
            # 所以那种情况下遇到登录页会明确停下来提示用户）。
            # 同刷课那条：prep_status() 会探端口，别直接信 PREP["running"]
        cdp_url=(prep_status().get("cdp_url") or _best_cdp() or None),
            pause_for_login=False,          # 界面里不阻塞等待，由 preflight 提前解决
        )
        BUS.emit("result", {
            "ok": res.ok, "answered": len(res.answered), "failed": len(res.failed),
            "rounds": res.rounds, "seconds": round(res.seconds, 1), "error": res.error,
            "items": res.answered, "failed_items": res.failed,
        })
    except Exception as e:
        BUS.emit("log", {"level": "error", "text": f"任务异常：{type(e).__name__}: {e}"})
        BUS.emit("log", {"level": "debug", "text": traceback.format_exc()})
        BUS.emit("result", {"ok": False, "answered": 0, "failed": 0, "error": str(e)})
    finally:
        with RUN_LOCK:
            ACTIVE["agent"] = None
        BUS.emit("run", {"state": "idle", "reason": ""})


def run_pc_task(cfg: dict[str, Any]) -> None:
    """在独立线程里跑 **PC 模式**（真·键鼠视觉代理）。

    这是《视觉化改造》文档的 P0：把一直只被旧 Tk 界面调用的
    `SolverAgent.run_pc()` 接进 Web 界面，让它从死代码变成可用入口。

    ⚠ PC 模式的三条硬约束（文档要求，缺一不可）：
      ① **独占**：它会抢真实鼠标键盘，绝不能和 Playwright 任务同时跑；
      ② **运行前确认**：默认要用户点一次确认（`pc_confirm`）；
      ③ **步数上限**：防止模型跑飞（`pc_max_steps`）。

    另外按文档三条铁律：PC 模式**不做考试自动作答** ——
    这里只执行模型给出的通用动作（点击/输入/滚动），不针对考试页面做特化。
    """
    task = str(cfg.get("pc_task") or "").strip()
    if not task:
        BUS.emit("toast", {"level": "error", "text": "PC 模式需要填写「任务描述」"})
        BUS.emit("run", {"state": "idle", "reason": "缺少任务描述"})
        return

    # ---- ① 独占检查 ----
    # PC 模式会移动真实鼠标、发真实按键。如果这时还有个 Playwright 任务在跑，
    # 两边会互相干扰（而且 PC 模式根本不知道浏览器窗口在哪）。
    with RUN_LOCK:
        busy = (ACTIVE.get("agent") is not None
                or ACTIVE.get("course_stop") is not None)
    if busy:
        BUS.emit("log", {"level": "warn",
                         "text": "⚠ 已有任务在运行。PC 模式会接管鼠标键盘，"
                                 "必须先等它结束（或点停止）。"})
        BUS.emit("toast", {"level": "warn", "text": "已有任务在跑，请先停止它"})
        BUS.emit("run", {"state": "idle", "reason": "已被其它任务占用"})
        return

    BUS.emit("run", {"state": "starting", "reason": ""})
    try:
        client = LMStudioClient()
    except LMError as e:
        BUS.emit("log", {"level": "error", "text": str(e)})
        BUS.emit("toast", {"level": "error", "text": "模型配置有问题，请到「设置」检查"})
        BUS.emit("run", {"state": "idle", "reason": "模型不可用"})
        return
    except Exception as e:
        BUS.emit("log", {"level": "error", "text": f"初始化失败：{e}"})
        BUS.emit("run", {"state": "idle", "reason": "初始化失败"})
        return

    # ---- 视觉能力检查 ----
    # 这一步很重要：PC 模式**完全依赖**读图。模型不能看图的话，
    # 它拿不到任何屏幕信息，只会瞎猜坐标 —— 与其让它乱点，不如现在就说清。
    if not client.is_vision_capable():
        BUS.emit("log", {"level": "error",
                         "text": f"✘ 当前模型「{client.model}」不支持读图，PC 模式无法工作。"})
        BUS.emit("log", {"level": "info",
                         "text": "  换一个支持视觉的模型：DeepSeek 用 deepseek-flash；"
                                 "Kimi 用 moonshot-v1-*-vision-preview。"})
        BUS.emit("toast", {"level": "error", "text": "当前模型不支持读图，PC 模式用不了"})
        BUS.emit("run", {"state": "idle", "reason": "模型不支持视觉"})
        return

    BUS.emit("log", {"level": "info",
                     "text": f"模型：{client.model}（{client.provider}）｜视觉：支持"})
    BUS.emit("log", {"level": "warn",
                     "text": "⚠ PC 模式会接管真实鼠标键盘 —— 运行期间请不要碰电脑、"
                             "不要把别的窗口切到前台。"})

    def on_shot(p: Path) -> None:
        """每一步的截图都推给界面，右侧预览就能跟着动。"""
        try:
            BUS.emit("shot", {"name": Path(p).name})
        except Exception:
            pass

    def _ask(q: str) -> bool:
        """模型说"需要人工处理"时问用户。

        ⚠ 返回 False = "不继续"，`run_pc` 会**干净地停下来并把原因写进结果**。
          原实现在 `ask_user` 为 None 时直接 `raise Stopped()`，
          等于"一遇到要人工就整个停掉"、还不说明原因。
          现在明确告诉用户要做什么，让他处理后重新发起。
        """
        BUS.emit("log", {"level": "warn", "text": f"⏸ 需要你手动处理：{q}"})
        BUS.emit("toast", {"level": "warn",
                           "text": "PC 模式需要你手动处理一下，已暂停"})
        return False

    agent = SolverAgent(
        client,
        log=lambda s: BUS.emit("log", {"level": _guess_level(s), "text": s}),
        status=lambda s: BUS.emit("status", {"text": s}),
        on_shot=on_shot,
        on_answer=None,
        ask_user=_ask,
        auto_submit=False,          # PC 模式不自动提交（铁律 3）
        dry_run=bool(cfg.get("dry_run")),
    )
    # ⚠ agent 在 __init__ 里已经建好了自己的 StopFlag，这里**不要**替换它 ——
    #   `/api/stop` 走的是 `agent.stop_now()`（内部 set 的就是这个 flag）。
    #   另外塞一个没人读的 flag 只会让人以为"停不了"。
    flag = agent.stop

    with RUN_LOCK:
        ACTIVE["agent"] = agent
        ACTIVE["pc_stop"] = flag
    BUS.emit("run", {"state": "running", "reason": ""})

    try:
        res: SessionResult = agent.run_pc(
            task,
            max_steps=int(cfg.get("pc_max_steps") or config.PC_AGENT_MAX_STEPS),
        )
        BUS.emit("result", {
            "kind": "pc",
            "ok": res.ok, "answered": 0, "failed": 0,
            "rounds": res.rounds, "seconds": round(res.seconds, 1),
            "error": res.error,
            "steps": getattr(agent, "vision_used", 0),
        })
    except Exception as e:
        BUS.emit("log", {"level": "error", "text": f"任务异常：{type(e).__name__}: {e}"})
        BUS.emit("log", {"level": "debug", "text": traceback.format_exc()})
        BUS.emit("result", {"kind": "pc", "ok": False, "error": str(e)})
    finally:
        with RUN_LOCK:
            ACTIVE["agent"] = None
            ACTIVE["pc_stop"] = None
        BUS.emit("run", {"state": "idle", "reason": ""})


def _guess_level(s: str) -> str:
    if s.startswith("✘") or "出错" in s or "失败" in s:
        return "error"
    if s.startswith("⚠"):
        return "warn"
    if s.startswith("✔") or s.startswith("→"):
        return "ok"
    return "info"


ACTIVE: dict[str, Any] = {"agent": None, "thread": None, "course_stop": None,
                          "pc_stop": None, "driver": None}

# ---------------------------------------------------------------------------
# 准备阶段：先把浏览器开起来让用户登录
#
# 为什么必须有这一步：作业网站基本都要登录，而"开始答题时新开的浏览器窗口"
# 必然是未登录状态 —— 用户还没输完账号密码，agent 就把用户名/密码框当成
# 填空题去作答了，整个流程就断在那里。这是设计缺陷，不是小 bug。
#
# 做法：用带 --remote-debugging-port 的方式启动浏览器，用户在这个窗口里
# 从容登录、进入作业页；然后 agent 通过 CDP 挂上同一个浏览器继续答题，
# 登录态天然复用（cookie 在浏览器里，不在我们进程里）。
# ---------------------------------------------------------------------------
PREP: dict[str, Any] = {
    "running": False,
    # 后台线程正在探调试端口（审计 C-4）。`prep_open` 立刻返回，
    # 前端看到 starting=True 就显示"正在启动"，而不是干等一个卡住的请求。
    "starting": False,
    "cdp_url": "",
    "port": 0,
    "browser": "",
    "profile": "",
    "process": None,
}

# 我们自己启动、需要负责关掉的浏览器进程 PID。
# ⚠ 原来 `open_app_window` 的 Popen 句柄被直接丢弃，
#   于是"关掉界面"之后那些窗口还留在任务管理器里 —— 见 shutdown_all。
_OWNED_BROWSERS: set[int] = set()

# 准备浏览器就绪后，把调试端口**写进文件**。
#
# ⚠ 为什么需要：端口是 `_free_port()` 随机选的（实测 63001/63082 这种），
#   只存在内存里。而外部诊断工具（`_诊断\copy_page_info.py` 等）要连上这个
#   浏览器去采集页面结构，它们**没法知道端口** ——
#   那些工具原来只在固定端口 9222~9333 上找，永远找不到，等于不可用。
#   把端口落盘后，工具读这个文件就能连上"用户已经登录好的那个浏览器"。
PREP_FILE = config.OUT_DIR / "prep.json"


def _save_prep_info() -> None:
    try:
        if not (PREP.get("running") and PREP.get("cdp_url")):
            return
        PREP_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = PREP_FILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({
            "cdp_url": PREP["cdp_url"],
            "port": PREP.get("port") or 0,
            "browser": PREP.get("browser") or "",
            "pid": getattr(PREP.get("process"), "pid", 0),
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, PREP_FILE)      # 原子替换，避免工具读到半截文件
    except Exception:
        pass


def _clear_prep_info() -> None:
    try:
        PREP_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def _find_browser_exe() -> str:
    """找一个可用的 Edge / Chrome 可执行文件。"""
    import shutil as _sh

    cands = [
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                     r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                     r"Google\Chrome\Application\chrome.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     r"Google\Chrome\Application\chrome.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""),
                     r"Google\Chrome\Application\chrome.exe"),
    ]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    for name in ("msedge", "chrome"):
        p = _sh.which(name)
        if p:
            return p
    return ""


def _free_port() -> int:
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def prep_status() -> dict:
    """准备阶段浏览器的状态。

    ⚠ 审计 C-18：这里原来在"进程句柄丢了"时会**同步探一次 CDP 端口**，
      而 `prep_status()` 被 `/api/state` 每 5 秒调用一次 ——
      也就是每 5 秒可能阻塞 2 秒。
      现在：句柄还在就用 `proc.poll()`（瞬时、不联网）；
      句柄丢了才探端口，且结果**缓存 5 秒**，避免连续请求反复打网络。
    """
    if PREP.get("starting"):
        # 后台线程还在探端口 → 对外报"正在启动"，前端据此显示进度
        return {"running": False, "starting": True, "cdp_url": "",
                "browser": PREP["browser"]}
    alive = False
    if PREP["running"]:
        proc = PREP.get("process")
        if proc is not None:
            try:
                alive = proc.poll() is None
            except Exception:
                alive = False
            if not alive:
                # ⚠⚠ **进程句柄没了 ≠ 浏览器死了。**
                #
                #   2026-10-17 实测（用户日志 12:17:56 → 12:17:58）：
                #   Edge 已经在跑时，新起的 `msedge.exe --remote-debugging-port=59201`
                #   会**立刻退出**（命令转交给已有实例），而浏览器和调试端口
                #   都还活着 —— 日志里刚确认过 59201 可用。
                #
                #   原来这里直接 `running = False; return`，等于把刚就绪的
                #   浏览器判死；刷课那边拿到的 cdp_url 就成了 None，
                #   回落到默认的 9222 → 连不上 → 新开一个没登录态的浏览器
                #   → 弹登录页 → "找不到可播放的视频"。
                #   用户看到的就是"登录界面闪一下、窗口关了、提示失败"。
                #
                #   所以这里**不 return**，落到下面"探端口"那条路，让端口说话。
                #   探端口有 5 秒缓存，不会被每 5 秒一次的 /api/state 打穿。
                alive = False
        if not alive and PREP["cdp_url"]:
            # 句柄丢了（比如程序重启过）：只能探端口，但**带缓存**
            now = time.time()
            cached_at = PREP.get("_probe_at") or 0.0
            if cached_at and (now - cached_at) < 5.0:
                alive = bool(PREP.get("_probe_ok"))
            else:
                import urllib.request
                try:
                    with urllib.request.urlopen(
                            PREP["cdp_url"] + "/json/version", timeout=2):
                        alive = True
                except Exception:
                    alive = False
                PREP["_probe_at"], PREP["_probe_ok"] = now, alive
        PREP["running"] = alive
    return {
        "running": PREP["running"],
        "starting": False,
        "cdp_url": PREP["cdp_url"] if PREP["running"] else "",
        "browser": PREP["browser"],
    }


def _adopt_running_browser() -> dict:
    r"""如果**已经有浏览器在用我们这套档案**，直接接管它的调试端口。

    ## 为什么必须有这一步（客户日志实证，2026-10-23）

    客户日志里 `❌ 浏览器启动后立刻退出了` 连续出现 **9 次**，之后每次刷课都
    "尝试接管 9222 → 连不上 → 新开一个没登录态的浏览器 → 弹登录页 →
    找不到可播放的视频"。

    真实原因是 Chromium 的**单实例机制**：我们带着 `--user-data-dir=<我们的档案>`
    再起一个 msedge 时，它发现这个档案已经被一个运行中的实例占用，就把命令行
    转交给那个实例、**自己立刻退出**。于是：
      · 新进程"启动后立刻退出"（我们判成失败）；
      · 但**浏览器和调试端口其实都活着**，端口号写在档案目录的
        `DevToolsActivePort` 文件里（Chromium 的约定，第一行是端口）。
    这一步就是去读那个文件、探一下端口，能连上就当场接管。

    ## 判据

      · 文件 `<档案>/DevToolsActivePort` 存在且第一行是 1~65535 的整数；
      · `http://127.0.0.1:<port>/json/version` 能通。
    两条都满足才接管 —— 端口文件可能是上次残留的，**不能只看文件**。
    """
    import urllib.request

    try:
        pf = Path(config.PROFILE_DIR) / "DevToolsActivePort"
        if not pf.exists():
            return {"ok": False, "why": "没有 DevToolsActivePort（上次没留浏览器）"}
        raw = pf.read_text(encoding="utf-8", errors="replace").splitlines()
        port = int((raw[0] if raw else "").strip())
        if not (1 <= port <= 65535):
            return {"ok": False, "why": f"端口文件内容不对：{raw[:1]}"}
    except Exception as e:
        return {"ok": False, "why": f"读端口文件失败：{type(e).__name__}"}

    cdp = f"http://127.0.0.1:{port}"
    try:
        with urllib.request.urlopen(cdp + "/json/version", timeout=2):
            pass
    except Exception as e:
        return {"ok": False, "why": f"端口 {port} 连不上（{type(e).__name__}）"}

    PREP.update({
        "running": True, "starting": False,
        "cdp_url": cdp, "port": port,
        "browser": PREP.get("browser") or "msedge",
        "process": None,                 # 不是我们起的，别去 kill
        "_probe_at": time.time(), "_probe_ok": True,
    })
    _save_prep_info()
    try:
        BUS.emit("log", {"level": "ok",
                         "text": f"✔ 接管了已经开着的浏览器（调试端口 {port}），"
                                 f"登录态直接复用"})
    except Exception:
        pass
    return {"ok": True, "already": True, "cdp_url": cdp, "port": port,
            "browser": PREP.get("browser") or "msedge"}


def _best_cdp() -> str:
    """尽量拿一个**带登录态**的调试端口：先问准备阶段，再试接管已开着的浏览器。

    为什么刷课/答题两条路都要用它：
      客户日志里"点开始"时 PREP 是空的（应用刚重启过），于是新开一个
      **没有登录态**的浏览器 → 弹登录页 → "找不到可播放的视频"。
      而那个已登录的浏览器其实还开着，只是我们没去接管。
    """
    try:
        cdp = prep_status().get("cdp_url") or ""
    except Exception:
        cdp = ""
    if cdp:
        return cdp
    got = _adopt_running_browser()
    return got.get("cdp_url", "") if got.get("ok") else ""


def prep_open(url: str) -> dict:
    """启动一个可被接管的浏览器（带远程调试端口）并打开目标网址。"""
    import subprocess

    cur = prep_status()
    if cur["running"]:
        return {"ok": True, "already": True, **cur}
    # ★ 正在等端口的时候又点了一次 —— **不能再起一个进程**。
    #
    #   客户日志 12:20:45 / 12:20:46 两次点击相隔 1 秒：第一个把浏览器起来了，
    #   第二个因为档案被占，转交参数后立刻退出 → 我们判成"启动失败"，
    #   还把 PREP 清空 → 后面的刷课只好回落到 9222（连不上）。
    #   这里直接返回"正在启动"，让前端继续转圈即可。
    if cur.get("starting"):
        return {"ok": True, "starting": True, "already": True, **cur}

    # ★ 起进程**之前**先看有没有已经在跑的（应用重启后 PREP 是空的，
    #   但浏览器窗口可能还开着）。见 _adopt_running_browser 的说明。
    got = _adopt_running_browser()
    if got.get("ok"):
        return got

    exe = _find_browser_exe()
    if not exe:
        return {"ok": False, "error": "找不到 Edge 或 Chrome。可先用「补装浏览器内核」装内置 Chromium。"}

    port = _free_port()
    profile = config.PROFILE_DIR
    profile.mkdir(parents=True, exist_ok=True)

    args = [
        exe,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile}",
        "--no-first-run",
        "--no-default-browser-check",
        "--start-maximized",
    ]
    if url:
        args.append(url)
    try:
        proc = subprocess.Popen(args, close_fds=True)
    except Exception as e:
        return {"ok": False, "error": f"启动浏览器失败：{e}"}
    PREP["process"] = proc       # 记下句柄，退出时要能收掉（见 shutdown_all）

    cdp = f"http://127.0.0.1:{port}"
    PREP.update({
        "process": proc,          # 记下句柄，退出时要能收掉（见 shutdown_all）
        "starting": True,
        "_watch_cancel": False,
        "port": port,
        "cdp_url": "",            # 还没确认可用，先不给
        "browser": os.path.basename(exe),
        "profile": str(profile),
    })
    threading.Thread(target=_prep_watch,
                     args=(proc, cdp, port, os.path.basename(exe)),
                     daemon=True).start()
    return {"ok": True, "starting": True, "port": port,
            "browser": os.path.basename(exe)}


def _prep_watch(proc, cdp: str, port: int, exe_name: str) -> None:
    """后台线程：等调试端口起来，成功/失败都通过 BUS 通知界面。

    ⚠ 审计 C-4：这一步原来是在 **HTTP 请求线程里同步等**的
      （60 × (1.5s 探测 + 0.5s 间隔) ≈ 最坏 120 秒）。
      期间前端按钮全程禁用、界面没有任何反馈；用户等不到就会反复点，
      于是又启动一个浏览器进程 —— 越点越乱。
      现在 `prep_open` 立刻返回 {starting:true}，等待挪到这里。
    """
    import urllib.request
    deadline = time.time() + 90.0
    while time.time() < deadline:
        if PREP.get("_watch_cancel"):
            PREP["starting"] = False
            return
        try:
            if proc.poll() is not None:
                # 最常见的真实原因其实是**档案被另一个实例占用了**
                # （用户双击了两次 exe）：Chromium 发现 --user-data-dir 被占用，
                # 会把参数转给已有进程然后自己立刻退出。
                #
                # ★ 但"自己退出"**不等于失败** —— 那个已有实例可能就是我们
                #   上一次起的浏览器（应用重启后 PREP 清空了，窗口还在）。
                #   客户日志里这一幕连续出现 9 次，每次都判失败并把 PREP 清掉，
                #   于是刷课只能回落到 9222 → 新开未登录浏览器 → 弹登录页。
                #   所以先试着接管那个还活着的实例，接管不到才报错。
                got = _adopt_running_browser()
                if got.get("ok"):
                    BUS.emit("prep", {"running": True, "starting": False,
                                      "cdp_url": got.get("cdp_url", ""),
                                      "browser": exe_name})
                    return
                PREP["starting"] = False
                PREP.update({"running": False, "cdp_url": "", "port": 0})
                BUS.emit("log", {
                    "level": "error",
                    "text": "❌ 浏览器启动后立刻退出了（接管已有实例也失败："
                            f"{got.get('why', '未知')}）。常见原因："
                            "① 已经有一个本程序在运行（双击了两次）；"
                            "② 浏览器档案被占用或损坏（设置里有「清空浏览器档案」）；"
                            "③ 被杀毒软件拦截（把程序目录加入白名单）。"})
                BUS.emit("toast", {"level": "error",
                                   "text": "浏览器启动失败，详见日志"})
                BUS.emit("prep", {"running": False, "starting": False,
                                  "cdp_url": "", "browser": exe_name})
                return
        except Exception:
            pass
        try:
            with urllib.request.urlopen(cdp + "/json/version", timeout=1.5):
                PREP.update({"running": True, "starting": False,
                             "cdp_url": cdp, "port": port,
                             "process": proc, "browser": exe_name,
                             "_probe_at": time.time(), "_probe_ok": True})
                # ★ 把端口落盘，让外部诊断工具能连上这个"已登录的浏览器"
                _save_prep_info()
                BUS.emit("log", {"level": "ok",
                                 "text": f"✔ 浏览器已就绪（{exe_name}，调试端口 {port}），"
                                         f"可以登录了"})
                BUS.emit("prep", {"running": True, "starting": False,
                                  "cdp_url": cdp, "browser": exe_name})
                return
        except Exception:
            pass
        time.sleep(0.5)

    PREP["starting"] = False
    BUS.emit("log", {"level": "error",
                     "text": "❌ 浏览器起来了，但调试端口 90 秒内没响应。"
                             "请关掉多余的浏览器窗口后重试。"})
    BUS.emit("prep", {"running": False, "starting": False,
                      "cdp_url": "", "browser": exe_name})



def pick_folder(initial: str = "") -> str:
    """弹出系统"选择文件夹"对话框，返回选中的路径（取消则返回空串）。

    用 Tkinter 自带的对话框：独立版的运行时里 Tk 是可选的，所以整段都做了
    兜底 —— 拿不到对话框时前端会退化成"手动输入路径"，功能不受影响。
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return ""

    result = {"path": ""}

    def work() -> None:
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            init = initial if initial and Path(initial).is_dir() else None
            chosen = filedialog.askdirectory(
                title="选择截图保存位置", initialdir=init, mustexist=False)
            result["path"] = chosen or ""
            root.destroy()
        except Exception:
            result["path"] = ""

    t = threading.Thread(target=work, daemon=True)
    t.start()
    # 审计 C-19：原来是 180 秒。
    # 用户不点那个对话框（或对话框弹在别的显示器/被挡住）时，
    # 这个 HTTP 请求线程会被挂满 3 分钟 —— 线程不回收，点几次就多几个卡死的线程；
    # 界面上表现为按钮一直转圈，最后还可能超时。
    # 现在降到 60 秒：够慢手用户选完路径，超时就返回空串，
    # 前端本来就有"手动输入路径"的兜底分支（`app.js` 已处理空返回）。
    t.join(timeout=60)
    return result["path"]


def prep_close() -> dict:
    """关掉准备阶段的浏览器。

    ⚠ 这里原本有个键名不一致的 bug：写在 `PREP["proc"]`、读却在
      `PREP.get("process")` —— 于是**永远拿到 None，浏览器从来没被关过**。
      这正是用户反馈"关了软件还有一堆 chrome.exe"的来源之一。
      现在统一用 `PREP["process"]`。
    """
    proc = PREP.get("process")
    if proc is not None:
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except Exception:
                    proc.kill()
        except Exception:
            pass
    PREP.update({"running": False, "cdp_url": "", "port": 0, "process": None})
    # 端口信息也要清掉 —— 否则诊断工具会拿着一个已经关掉的端口去连
    _clear_prep_info()
    return {"ok": True}


# ---------------------------------------------------------------------------
# 退出清理：把"我们启动过的东西"全部收掉
# ---------------------------------------------------------------------------
_SHUT_DONE = False


def shutdown_all(reason: str = "") -> None:
    """统一退出清理。**幂等**，重复调用无副作用。

    ⚠ 为什么必须集中做这一件事：
      原来的退出路径只有 `httpd.shutdown()`，而我们启动过的东西有四种：
        ① 运行中的答题/刷课任务（后台线程 + Playwright）
        ② `--app` 模式开的独立窗口浏览器（句柄被丢弃）
        ③ 准备阶段登录用的浏览器（`PREP["process"]`）
        ④ 用量统计（`meter().save()`）
      用户直接点控制台 X 或任务管理器结束时，这个 `finally` **根本不会执行**
      （所以下面还用 atexit/signal 兜了一层），
      于是"关了软件还有一堆 chrome.exe / node.exe"。
    """
    global _SHUT_DONE
    if _SHUT_DONE:
        return
    _SHUT_DONE = True
    if reason:
        try:
            print(f"\n  正在退出（{reason}）…")
        except Exception:
            pass

    # ① 停掉运行中的任务
    try:
        ag = ACTIVE.get("agent")
        if ag is not None and hasattr(ag, "stop_now"):
            ag.stop_now()
    except Exception:
        pass
    try:
        stop = ACTIVE.get("course_stop")
        if stop is not None and hasattr(stop, "set"):
            stop.set()
    except Exception:
        pass

    # ② 收掉我们开出去的浏览器窗口
    try:
        prep_close()
    except Exception:
        pass
    for pid in list(_OWNED_BROWSERS):
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=8)
        except Exception:
            pass
    _OWNED_BROWSERS.clear()

    # ③ 关掉 Playwright（它会连带结束 node 驱动进程）
    try:
        drv = ACTIVE.get("driver")
        if drv is not None and hasattr(drv, "close"):
            drv.close()
    except Exception:
        pass

    # ④ 存一次用量
    try:
        from .lms import meter
        meter().save()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 关闭窗口时：完全退出 / 最小化到托盘
#
# ⚠ 这一段是**重建**的。原本的实现（另一个会话写的）在 2026-10-16
#   被我误覆盖丢失，两边都无副本可恢复。规格见 docs-local\升级说明-本地二次开发.md。
# ---------------------------------------------------------------------------
# 启动器进程名（2026-10-26 改名后新名在前；旧名保留 —— 老快捷方式 / 老目录
# 升级上来的用户点「完全退出」时也能把启动器一起收掉）
LAUNCHER_NAMES = ("昔涟自习室.exe", "MRS Study Assistant.exe")
LAUNCHER_NAME = LAUNCHER_NAMES[0]              # 兼容旧引用（日志/文档里用）
_LAUNCHER_NAMES_LC = {n.lower() for n in LAUNCHER_NAMES}
# 宽限期从 config 取（默认 15 秒；DSHS_QUIT_GRACE 可覆盖，只为测试）
QUIT_GRACE = config.QUIT_GRACE

_quit_lock = threading.Lock()
_quit_timer: threading.Timer | None = None     # 已排的退出定时器（None = 没有待退出）


def _launcher_pid() -> int | None:
    """找到**启动器**进程的 pid；找不到返回 None。

    ## 为什么不能直接杀父进程

    `os.getppid()` 给的是**直接父进程**。命令行跑
    `runtime\\python.exe app\\server.py` 调试时，父进程是**终端** ——
    照着杀会把用户自己的窗口关掉。

    所以这里一路向上找，但**只认进程名完全等于 `LAUNCHER_NAME` 的那个**。
    名字对不上就一个都不杀，交给调用方如实记一行。

    ## 为什么用 QueryFullProcessImageNameW 而不是 tasklist

    `tasklist` 的输出编码随系统语言/代码页变（中文 Windows 上是 GBK），
    解析它要么乱码要么要额外处理编码。直接问内核拿路径最稳。

    ⚠ 进程句柄是 64 位的：ctypes 对没声明 `restype` 的函数按 `c_int` 处理，
      HANDLE 会被**截断成 32 位**，之后传给别的 API 就是垃圾。
      所以下面把用到的手柄函数都声明齐。
    """
    try:
        import ctypes
        from ctypes import wintypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k32.CloseHandle.argtypes = [wintypes.HANDLE]
        k32.QueryFullProcessImageNameW.argtypes = [
            wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
            ctypes.POINTER(wintypes.DWORD)]
        k32.QueryFullProcessImageNameW.restype = wintypes.BOOL

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        pid = os.getpid()
        for _ in range(4):                     # 最多向上找 4 层
            pid = _parent_pid(pid)
            if not pid:
                break
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                continue
            try:
                buf = ctypes.create_unicode_buffer(1024)
                size = wintypes.DWORD(len(buf))
                if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                    name = os.path.basename(buf.value)
                    if name.lower() in _LAUNCHER_NAMES_LC:
                        return pid
            finally:
                try:
                    k32.CloseHandle(h)
                except Exception:
                    pass
    except Exception:
        return None
    return None


def _parent_pid(pid: int) -> int:
    """取某个进程的父 pid。用 Toolhelp 快照，不依赖 psutil。"""
    try:
        import ctypes
        from ctypes import wintypes

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD),
                        ("cntUsage", wintypes.DWORD),
                        ("th32ProcessID", wintypes.DWORD),
                        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                        ("th32ModuleID", wintypes.DWORD),
                        ("cntThreads", wintypes.DWORD),
                        ("th32ParentProcessID", wintypes.DWORD),
                        ("pcPriClassBase", ctypes.c_long),
                        ("dwFlags", wintypes.DWORD),
                        ("szExeFile", wintypes.WCHAR * 260)]

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        k32.Process32FirstW.argtypes = [wintypes.HANDLE,
                                        ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32NextW.argtypes = [wintypes.HANDLE,
                                       ctypes.POINTER(PROCESSENTRY32W)]
        k32.CloseHandle.argtypes = [wintypes.HANDLE]

        TH32CS_SNAPPROCESS = 0x2
        snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if not snap or snap == wintypes.HANDLE(-1).value:
            return 0
        try:
            e = PROCESSENTRY32W()
            e.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            if not k32.Process32FirstW(snap, ctypes.byref(e)):
                return 0
            while True:
                if e.th32ProcessID == pid:
                    return int(e.th32ParentProcessID)
                if not k32.Process32NextW(snap, ctypes.byref(e)):
                    return 0
        finally:
            try:
                k32.CloseHandle(snap)
            except Exception:
                pass
    except Exception:
        return 0


def quit_app(reason: str = "") -> None:
    """**彻底**退出：先收干净，再结束启动器，最后硬退。

    ⚠ 顺序不能反：
      ① 先 `shutdown_all()` —— 停任务、关浏览器、存用量统计
      ② 再杀**启动器** —— 否则"窗口没了、托盘图标还在"，
         用户看来就是**没关掉**
      ③ 最后 `os._exit(0)` 兜底 —— 可能有非守护线程卡着不退

    这个函数**不返回**。
    """
    def _say(msg: str) -> None:
        try:
            _log_to_file("log", {"text": msg})
            BUS.emit("log", {"level": "warn", "text": msg})
        except Exception:
            pass

    _say(f"正在完全退出程序…（{reason or '用户点了退出'}）")
    try:
        shutdown_all(reason or "完全退出")
    except Exception:
        pass

    pid = _launcher_pid()
    if pid:
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/F", "/T"],
                           capture_output=True, timeout=10)
        except Exception as e:
            _say(f"结束启动器失败（{type(e).__name__}）—— 只结束服务端")
    else:
        # 如实说清楚：命令行直接跑的时候本来就没有启动器，这是正常情况
        _say("没找到启动器进程（多半是命令行直接跑的），只结束服务端")

    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    os._exit(0)


def schedule_quit() -> None:
    """**预约**退出（pagehide 时用）。宽限 `QUIT_GRACE` 秒。"""
    global _quit_timer
    with _quit_lock:
        if _quit_timer is not None and _quit_timer.is_alive():
            return                       # 已经排了一个，别排第二个
        t = threading.Timer(QUIT_GRACE, _fire_quit)
        t.daemon = True
        _quit_timer = t
        t.start()


def cancel_quit() -> bool:
    """取消预约好的退出。返回**是否真的取消了**。

    ⚠ 返回值决定要不要写日志：只有"确实取消掉了一个待退出"才写。
      否则用户每按一次 F5 都刷一条，把日志淹掉。
    """
    global _quit_timer
    with _quit_lock:
        if _quit_timer is None:
            return False
        _quit_timer.cancel()
        _quit_timer = None
        return True


def _fire_quit() -> None:
    """宽限期到了：真的退出。"""
    global _quit_timer
    with _quit_lock:
        if _quit_timer is None:
            return                       # 期间被 hello 取消了
        _quit_timer = None
    quit_app("关闭了界面窗口")


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    # ⚠ 版本号**只有一处真源**（`dsh_solver/__init__.py` 的 `__version__`）。
    #   这里原来硬编码 "MSMStudyAssistant/1.0.2" —— 和界面角标各改各的，
    #   很容易出现"界面显示 1.0.3、HTTP 头还是 1.0.2"这种自相矛盾。
    #   用别名 `_app_ver` 是为了不和本模块内的其它名字撞车。
    server_version = "MSMStudyAssistant/" + _app_ver

    # ---- 小工具 ----
    # 安全响应头（审计 C-20）。
    # ⚠ 服务只绑 127.0.0.1，外网本来就碰不到；但**本机上的其它网页**可以
    #   用 <iframe>/<img> 去请求这些接口（DNS rebinding / CSRF 面），
    #   而这些接口里有"开始作答""提交""改配置"这种有副作用的操作。
    #   nosniff 防内容嗅探；DENY 直接禁掉被别的页面嵌进 iframe。
    #   这两条对本程序自己的界面**没有任何影响**（它是顶层页面、不嵌套）。
    _SECURITY_HEADERS = (
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "no-referrer"),
    )

    def _json(self, obj: Any, code: int = 200) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in self._SECURITY_HEADERS:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _client_token(self) -> str:
        """从 Cookie 或 X-MRS-Token 取令牌。

        优先 Cookie：页面里的 fetch / EventSource / sendBeacon 都会自动带上，
        前端一行不用改；X-MRS-Token 留给本机脚本和排查用。
        """
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            k, _, v = part.strip().partition("=")
            if k == "mrs_token":
                return v.strip()
        return (self.headers.get("X-MRS-Token") or "").strip()

    def _host_ok(self) -> bool:
        """Host 必须是本机地址 —— 挡 DNS rebinding 的最后一道。"""
        host = (self.headers.get("Host") or "").strip().lower()
        if not host:
            return True                      # HTTP/1.0 或本机脚本没带 Host
        name, _, port = host.partition(":")
        if name not in ("127.0.0.1", "localhost"):
            return False
        try:
            actual = str(self.server.server_address[1])
        except Exception:
            actual = ""
        return (not port) or (not actual) or (port == actual)

    def _guard(self, need_token: bool = True) -> bool:
        """控制面守卫：Host → 令牌 → Origin → Content-Type。

        浏览器请求必须带令牌；没有 Origin / Referer / Sec-Fetch-* 的本机脚本
        走兼容路径（它们本来就能直接读配置文件，不靠这道门挡）。
        返回 False 时**已经把响应写出去**，调用方直接 return。
        """
        if not self._host_ok():
            self._json({"error": "forbidden"}, 403)
            return False
        if not need_token:
            return True
        tok = self._client_token()
        if tok:
            if not hmac.compare_digest(tok, _API_TOKEN):
                self._json({"error": "unauthorized"}, 401)
                return False
        elif any(self.headers.get(h) for h in
                 ("Origin", "Referer", "Sec-Fetch-Site", "Sec-Fetch-Mode")):
            # 浏览器请求必须带令牌（页面首次加载就会拿到 Cookie）。
            # 本机脚本（urllib / curl / 诊断工具）没有任何来源头，放行 ——
            # 它们本来就能直接读配置文件，多一道令牌只会把回归工具弄坏。
            self._json({"error": "unauthorized"}, 401)
            return False
        # 同源页面的 POST 会带 Origin；跨源页面带的是它自己的源，直接拒。
        # 本机脚本通常不带 Origin，放行（它们已经过了令牌这一关）。
        origin = (self.headers.get("Origin") or "").strip().lower()
        if origin:
            port = self.server.server_address[1]
            allowed = {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}
            if origin not in allowed:
                self._json({"error": "forbidden"}, 403)
                return False
        # 有 body 的 POST 必须是 JSON。这一条专门堵「text/plain 简单请求」：
        # 浏览器不会为它发 CORS 预检，服务端如果不看 Content-Type 就会照单全收。
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0
        if n:
            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if ctype != "application/json":
                self._json({"error": "forbidden"}, 403)
                return False
        return True

    def _read_json(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def log_message(self, fmt: str, *args: Any) -> None:   # 别刷屏
        pass

    # ---- 静态文件 ----
    def _serve_static(self, rel: str) -> None:
        if rel in ("", "/"):
            rel = "index.html"
        rel = rel.lstrip("/")
        p = (WEB_DIR / rel).resolve()
        try:
            p.relative_to(WEB_DIR.resolve())
        except ValueError:
            self._json({"error": "forbidden"}, 403)
            return
        if not p.is_file():
            self._json({"error": "not found", "path": rel}, 404)
            return
        data = p.read_bytes()
        ctype = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        if p.suffix in (".html", ".css", ".js"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in self._SECURITY_HEADERS:
            self.send_header(k, v)
        # 只在发页面时下发控制面令牌；静态资源不带，减少暴露面。
        # SameSite=Strict：跨站请求（含 DNS rebinding 页面）带不上它。
        if rel == "index.html":
            self.send_header(
                "Set-Cookie",
                f"mrs_token={_API_TOKEN}; Path=/; HttpOnly; SameSite=Strict")
        self.end_headers()
        self.wfile.write(data)

    # ---- 路由 ----
    def do_GET(self) -> None:  # noqa: N802
        u = urlparse(self.path)
        path = u.path
        # 静态页与 /api/health 不要令牌（否则页面根本加载不出来）；
        # 其余 /api/* 一律要，包括 SSE 与截图。
        if not self._guard(need_token=path.startswith("/api/") and path != "/api/health"):
            return
        if path == "/api/health":
            # 版本号定义在包的 __init__ 里，不在 config —— 从包本身取才对
            try:
                from . import __version__ as _app_ver
            except Exception:
                _app_ver = ""
            self._json({"ok": True, "app": APP_NAME, "version": _app_ver})
        elif path == "/api/config":
            cfg = load_app_config()
            safe = dict(cfg)
            # ⚠ 所有 Key 都**只回传"是否已设置 + 掩码"，绝不回传明文** ——
            #   界面不需要明文，回传它就等于把 Key 暴露在浏览器里。
            #   新增接口时记得往这张表里加一行，别漏。
            for field in ("deepseek_api_key", "kimi_api_key", "custom_api_key"):
                raw = str(cfg.get(field) or "")
                safe[field + "_masked"] = mask_key(raw)
                safe[field + "_set"] = bool(raw)
                safe.pop(field, None)
            safe["config_file"] = str(CONFIG_FILE)
            self._json(safe)
        elif path == "/api/state":
            with RUN_LOCK:
                # 刷课任务也要算"运行中"，否则界面会以为空闲了
                running = (ACTIVE["agent"] is not None
                           or ACTIVE.get("course_stop") is not None)
            self._json({"running": running, "prep": prep_status()})
        elif path == "/api/update":
            # 更新状态快照：当前版本、远端版本、下载进度、暂存状态、手动下载入口
            self._json(_update_snapshot())
        elif path == "/api/prep/status":
            self._json(prep_status())
        elif path == "/api/events":
            self._sse()
        elif path == "/api/announcement":
            # 公告：默认走缓存（界面刷新时不每次都联网）。
            # ?force=1 才真的去拉一次；拉不到就用上次缓存，失败也返回 200，
            # 免得前端把它当错误弹提示。
            force = "force=1" in (self.path or "")
            try:
                data = announce.get_announcement(force=force)
            except Exception as e:
                data = {"items": [], "unread": [], "updated": "",
                        "source": f"error:{type(e).__name__}"}
            self._json(data)
        elif path == "/api/latest-shot":
            self._latest_shot()
        elif path == "/api/usage":
            self._json(self._usage_payload())
        elif path == "/api/budget":
            # 预算护栏状态（只读）。护栏装在 lms.chat 入口；
            # 未设 DSHS_MAX_* 时默认不限额 —— 这里回 enabled=false。
            try:
                from . import budget
                self._json(budget.status())
            except Exception as e:
                self._json({"enabled": False,
                            "error": f"{type(e).__name__}: {e}"})
        elif path == "/api/balance/baseline":
            # 纯读操作：把"当前余额"记为基线，不触发外部请求
            v = meter().set_baseline()
            if v is None:
                self._json({"ok": False,
                            "error": "还没有余额数据，先点「刷新余额」"}, 400)
            else:
                BUS.emit("toast", {"level": "ok", "text": f"已记录余额基线：{v}"})
                self._json({"ok": True, "baseline": v})
        elif path == "/api/shot-dir":
            self._json({
                "dir": str(config.SHOT_DIR),
                "exists": config.SHOT_DIR.exists(),
                "count": len(list(config.SHOT_DIR.glob("*.png"))),
                "clear_each_round": config.CLEAR_SHOTS_EACH_ROUND,
            })
        elif path.startswith("/api/"):
            self._json({"error": "unknown endpoint"}, 404)
        else:
            self._serve_static(path)

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if not self._guard():
            return
        if path == "/api/config":
            data = self._read_json()
            cur = load_app_config()
            # 传空字符串 = 不改动 Key（页面回显的是掩码，不能拿它覆盖真值）
            if not str(data.get("deepseek_api_key") or "").strip():
                data.pop("deepseek_api_key", None)
            cur.update({k: v for k, v in data.items() if k in DEFAULT_APP_CONFIG})
            save_app_config(cur)
            BUS.emit("toast", {"level": "ok", "text": "设置已保存"})
            self._json({"ok": True})
        elif path == "/api/test":
            self._json(self._do_test_model())
        elif path == "/api/update/check":
            r = _update_check(force=True)
            snap = _update_snapshot()
            snap["checked"] = bool(r.get("ok"))
            snap["check_error"] = str(r.get("error") or "")
            self._json(snap)
        elif path == "/api/update/download":
            m = _last_manifest
            if not m:
                m = _update_check(force=True).get("manifest")
            if not m:
                self._json({"ok": False, "error": "没拿到更新清单，请先点「检查更新」"}, 400)
                return
            if not updater.is_newer(str(m.get("build")),
                                    updater.local_build(APP_ROOT)):
                self._json({"ok": True, "phase": "idle", "message": "已经是最新版本"})
                return
            threading.Thread(target=_update_download_worker, args=(m,),
                             daemon=True).start()
            self._json({"ok": True, "phase": "downloading",
                        "build": m.get("build")})
        elif path == "/api/update/settings":
            data = self._read_json()
            patch = {}
            if "enabled" in data:
                patch["enabled"] = bool(data["enabled"])
            if "auto_download" in data:
                patch["auto_download"] = bool(data["auto_download"])
            cfg = updater.save_settings(config.OUT_DIR, patch)
            self._json({"ok": True, "enabled": bool(cfg.get("enabled")),
                        "auto_download": bool(cfg.get("auto_download"))})
        elif path == "/api/update/restart":
            # 先回响应再重启，否则前端 fetch 会报连接被重置
            self._json({"ok": True, "action": "restart"})
            threading.Thread(target=_restart_after_update, daemon=True).start()
        elif path == "/api/support/chat":
            # MRS自助解答：只把问题交给 support_chat，Key / provider / 模型
            # 全部沿用「设置」里已保存的那一套，**不新增、不回传任何密钥**。
            data = self._read_json()
            r = answer_support(
                str(data.get("message") or ""),
                str(data.get("session") or ""),
            )
            self._json(r)
        elif path == "/api/support/kb":
            # 本地资料库：从软件包内的 README / docs / 更新说明建索引。
            # 不联网、不上传任何东西；`reload=true` 强制重读文件。
            data = self._read_json()
            if data.get("reload"):
                self._json(local_kb.reload())
            else:
                self._json(local_kb.stats())
        elif path == "/api/export/notebook":
            # ★ 2026-10-23 新增：导出「作答记录 / 待复核」Markdown。
            #   只读 out\runs\*.json + out\answer_cache.json，写 out\notes\*.md；
            #   不联网、不调模型、不改任何运行记录。
            #   body 可选：{"mode": "record"|"review", "out_dir": "…"}。
            #   mode 不认识时按 record 处理；out_dir 留空 = 默认 out\notes。
            data = self._read_json()
            mode = str(data.get("mode") or "record").strip().lower()
            if mode not in ("record", "review"):
                mode = "record"
            out_dir = str(data.get("out_dir") or "").strip()
            try:
                from .notebook import export_all
                result = export_all(out_dir or None, mode=mode)
            except Exception as exc:      # 导出失败必须回一个能显示的原因，不能 500
                result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
            self._json(result)
        elif path == "/api/start":
            with RUN_LOCK:
                if ACTIVE["agent"] is not None:
                    self._json({"ok": False, "error": "已有任务在运行"})
                    return
            cfg = load_app_config()
            # ⚠ body 只能读一次！原来这里调了两遍 _read_json()，
            #   第二次必然拿到空 dict —— 于是 PC 模式的确认标记读不到，
            #   永远返回"需要先确认"。先读一次、存成变量再用。
            body = self._read_json()
            cfg.update({k: v for k, v in body.items() if k in DEFAULT_APP_CONFIG})
            # ⚠ 注意顺序：`_keep_urls_nonempty` 会把**空网址还原成上次保存的值**
            #   （它的用途是"别让留空把已保存的网址冲掉"）。
            #   所以"用户这次是不是真的没填网址"，必须用**原始 body** 判断，
            #   不能用被还原过的 cfg —— 否则下面的空网址检查永远触发不到。
            raw_url = str(body.get("url") or "").strip() if "url" in body else None
            _keep_urls_nonempty(cfg)
            save_app_config(cfg)
            # ★ 按运行模式分派：web = 网页 DOM 主力；pc = 真·键鼠视觉模式。
            #   这是 P0 的接线点 —— 在此之前 PC 模式在 Web 端**完全不可达**
            #   （`/api/start` 恒走 `run_web_task`）。
            mode = str(cfg.get("mode") or "web").lower()
            if mode == "pc":
                # ⚠ 这两项**必须在这里同步校验**，不能只留给后台线程 ——
                #   后台报错时接口早就回过 ok:True 了，界面只会看到
                #   "启动成功"，然后任务悄无声息地失败（用户完全无从下手）。
                if not str(cfg.get("pc_task") or "").strip():
                    self._json({"ok": False,
                                "error": "PC 模式需要填写「任务描述」"})
                    return
                # PC 模式运行前确认（它要接管真实鼠标键盘）。
                if config.PC_CONFIRM and not body.get("pc_confirm_ok"):
                    self._json({"ok": False, "need_confirm": True,
                                "error": "PC 模式会接管鼠标键盘，需要先确认"})
                    return
                target = run_pc_task
            else:
                # 网页模式：留空表示"接管浏览器当前那一页"，但前提是
                # 已经用「打开浏览器登录」备好了浏览器；否则新开一个空白窗口
                # 什么也做不了，不如现在就说清楚。
                # ⚠ 别直接读 PREP["running"] —— 它可能被误判成 False（见 prep_status）
                prep_ready = bool(prep_status().get("cdp_url"))
                if raw_url == "" and not prep_ready:
                    self._json({"ok": False,
                                "error": "请填写作业网址，或先点「打开浏览器登录」"})
                    return
                target = run_web_task
            t = threading.Thread(target=target, args=(cfg,), daemon=True)
            with RUN_LOCK:
                ACTIVE["thread"] = t
            t.start()
            self._json({"ok": True, "mode": mode})
        elif path == "/api/course/start":
            with RUN_LOCK:
                if ACTIVE["agent"] is not None:
                    self._json({"ok": False, "error": "已有任务在运行"})
                    return
            cfg = load_app_config()
            body = self._read_json()
            cfg.update({k: v for k, v in body.items() if k in DEFAULT_APP_CONFIG})
            # ⚠ 同 `/api/start`：`_keep_urls_nonempty` 会把空网址还原成上次保存的值，
            #   所以"这次是不是真的没填"要用**原始 body** 判断。
            #   这里更要紧：如果上次存的是个**作业页**网址，留空刷课会拿着它去
            #   当课程页用 —— 表现就是"打开了一个奇怪的页面然后卡住"。
            raw_course = (str(body.get("course_url") or "").strip()
                          if "course_url" in body else None)
            _keep_urls_nonempty(cfg)
            save_app_config(cfg)
            # 留空 = 接管浏览器当前那一页，但前提是已经备好了浏览器；
            # 否则新开一个空白窗口刷课，等于什么都没发生。
            # ⚠ 别直接读 PREP["running"] —— 它可能被误判成 False（见 prep_status）
            prep_ready = bool(prep_status().get("cdp_url"))
            if raw_course == "" and not prep_ready:
                self._json({"ok": False,
                            "error": "请填写课程网址，或先点「打开浏览器登录」"})
                return
            t = threading.Thread(target=run_course_task, args=(cfg,), daemon=True)
            with RUN_LOCK:
                ACTIVE["thread"] = t
            t.start()
            self._json({"ok": True})
        elif path == "/api/course/once":
            # 单页自动：只处理浏览器当前这一页（视频/文档/测验/讨论），
            # 不翻章、不切节；讨论强制处理（目录打勾不可信）。
            with RUN_LOCK:
                if ACTIVE["agent"] is not None:
                    self._json({"ok": False, "error": "已有任务在运行"})
                    return
            cfg = load_app_config()
            body = self._read_json()
            cfg.update({k: v for k, v in body.items() if k in DEFAULT_APP_CONFIG})
            _keep_urls_nonempty(cfg)
            save_app_config(cfg)
            prep_ready = bool(prep_status().get("cdp_url"))
            if not prep_ready:
                self._json({"ok": False,
                            "error": "单页模式需要先在浏览器里打开要处理的页面："
                                     "先点「打开浏览器登录」"})
                return
            t = threading.Thread(target=run_course_task, args=(cfg,),
                                 kwargs={"once": True}, daemon=True)
            with RUN_LOCK:
                ACTIVE["thread"] = t
            t.start()
            self._json({"ok": True})
        elif path == "/api/stop":
            with RUN_LOCK:
                a = ACTIVE["agent"]
                cs = ACTIVE.get("course_stop")
            if a is not None:
                a.stop_now()
                BUS.emit("log", {"level": "warn", "text": "收到停止指令，正在收尾…"})
            elif cs is not None:
                cs.set()
                BUS.emit("log", {"level": "warn", "text": "收到停止指令，正在停下刷课…"})
            self._json({"ok": True})
        elif path == "/api/prep/open":
            data = self._read_json()
            url = str(data.get("url") or "").strip()
            BUS.emit("log", {"level": "info", "text": "正在打开浏览器（准备登录）…"})
            r = prep_open(url)
            # ⚠ 审计 C-4：这里**不再**同步等调试端口，所以 ok 可能只是
            #   "已经发起启动"。真正就绪由后台线程 `_prep_watch` 通过
            #   BUS 推 `prep` 事件，前端据此更新提示。
            #   这里只负责"发起成功/发起失败"两种反馈。
            if r.get("ok"):
                if r.get("starting") and not r.get("already"):
                    BUS.emit("log", {"level": "info",
                                     "text": "浏览器正在启动，就绪后会提示你登录…"})
                    BUS.emit("toast", {"level": "info",
                                       "text": "浏览器正在启动，稍等一下"})
                else:
                    BUS.emit("log", {"level": "ok",
                                     "text": "浏览器已打开。请在这个窗口里登录、进入作业页面，"
                                             "完成后回到本界面点「开始答题」。"})
                    BUS.emit("toast", {"level": "ok", "text": "浏览器已打开，请先登录"})
            else:
                BUS.emit("log", {"level": "error", "text": r.get("error", "打开失败")})
                BUS.emit("toast", {"level": "error", "text": r.get("error", "打开失败")})

            self._json(r)
        elif path == "/api/prep/close":
            r = prep_close()
            BUS.emit("log", {"level": "info", "text": "已关闭准备阶段的浏览器"})
            self._json(r)
        elif path == "/api/pick-folder":
            data = self._read_json()
            picked = pick_folder(str(data.get("initial") or config.SHOT_DIR))
            self._json({"ok": bool(picked), "dir": picked})
        elif path == "/api/open-folder":
            data = self._read_json()
            which = str(data.get("which") or "shots")
            target = {
                "shots": config.SHOT_DIR,
                "out": config.OUT_DIR,
                "root": config.PROJECT_DIR,
            }.get(which, config.SHOT_DIR)
            try:
                os.startfile(str(target))       # noqa: S606
                self._json({"ok": True, "dir": str(target)})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        elif path == "/api/announcement/seen":
            # 用户点了"知道了" → 记住这些 id，以后不再主动弹
            data = self._read_json()
            ids = data.get("ids")
            if not isinstance(ids, list):
                ids = []
            try:
                announce.mark_seen([str(i) for i in ids])
                self._json({"ok": True, "count": len(ids)})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        elif path == "/api/announcement/mute":
            # 「下次不再提示」：记住这个偏好。
            # ⚠ 与 /seen 分开是有意的 —— 用户可能"确认"了但**不**勾不再提示。
            #   那是两件事：一个是"这条我看了"，一个是"以后别自动弹"。
            data = self._read_json()
            muted = bool(data.get("muted"))
            try:
                announce.set_muted(muted)
                self._json({"ok": True, "muted": muted})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        elif path == "/api/pagehide":
            # 页面正在关（或正在刷新）。**只预约，不立刻退** ——
            # 刷新也会触发 pagehide，收到就退的话按一次 F5 程序就没了。
            # 新页面加载完会立刻调 /api/hello 把这次预约取消掉。
            if config.CLOSE_ACTION != "exit":
                # 托盘模式：什么都不做（= 改动以前的行为）
                self._json({"ok": True, "action": "tray"})
            else:
                schedule_quit()
                self._json({"ok": True, "action": "exit",
                            "grace": QUIT_GRACE})
        elif path == "/api/hello":
            # 新页面来了：把上一次 pagehide 预约的退出取消掉。
            # ⚠ 只有**真的取消掉了一个**才写日志 ——
            #   否则每次刷新都刷一条，把日志淹掉。
            cancelled = cancel_quit()
            if cancelled:
                try:
                    _log_to_file("log", {"text": "新页面已接手，取消退出"})
                except Exception:
                    pass
            self._json({"ok": True, "cancelled": cancelled,
                        "action": config.CLOSE_ACTION})
        elif path == "/api/ready":
            # 页面铺好了 → 让开屏动画淡出。
            # ⚠ 失败绝不能影响主流程：开屏窗口自己有超时兜底。
            ok = False
            try:
                from . import splash
                splash.request_close()
                ok = True
            except Exception:
                ok = False
            self._json({"ok": True, "splash_closed": ok})
        elif path == "/api/quit":
            # 点「完全退出程序」按钮：直接退，不等宽限。
            # 先回一个响应再退 —— 否则前端那个 fetch 会报"连接被重置"，
            # 用户看到的是"退出请求没送到"，明明已经退了。
            self._json({"ok": True})
            try:
                self.wfile.flush()
            except Exception:
                pass
            threading.Thread(target=quit_app, args=("用户点了「完全退出程序」",),
                             daemon=True).start()
        elif path == "/api/clear-shots":
            # ★ 2026-10-23 修 B3：原来这里直接 `SHOT_DIR.glob("*.png")` 全删。
            #   截图目录是**用户可配置**的（界面里指到「图片」「桌面」都很自然），
            #   于是点「清空截图」会把用户自己的照片一起删掉。
            #   browser.py::_shots_dir_owned() 早就有这道护栏（:4563），
            #   这里与它对齐：
            #     · 默认截图目录（程序自己的「截图」）→ 可以全删
            #     · 其它目录 → 只删符合我们命名规则（170925_001_xxx.png）的
            try:
                default_dir = (config.PROJECT_DIR / "截图").resolve()
                owned = config.SHOT_DIR.resolve() == default_dir
                n = 0
                for f in config.SHOT_DIR.glob("*.png"):
                    if not owned and not _OUR_SHOT_RE.match(f.name):
                        continue
                    try:
                        f.unlink()
                        n += 1
                    except Exception:
                        pass
                self._json({"ok": True, "deleted": n, "owned_dir": owned})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        # ---- 用量监控 ----
        # 这两个会触发外部网络调用（刷新余额）或改写统计（清零），按语义放 POST。
        # 「记录基线」是纯读当前余额，放在 do_GET 里。
        elif path == "/api/balance/refresh":
            self._json(self._refresh_balance())
        elif path == "/api/usage/reset":
            meter().reset()
            BUS.emit("toast", {"level": "ok", "text": "用量统计已清零"})
            self._json({"ok": True})
        elif path == "/api/clear":
            BUS.tail.clear()
            self._json({"ok": True})
        else:
            self._json({"error": "unknown endpoint"}, 404)

    # ---- 用量监控 ----
    def _usage_payload(self) -> dict:
        """用量快照。顺带带上当前 provider / model，前端好显示上下文。

        ⚠ 这里原来把 provider 判断硬编码成 `in ("deepseek","openai","cloud")`，
          和 `lms.py` 里**已经修好**的口径（"不是本机就算云端"）自相矛盾。
          后果：切到 Kimi / 自定义接口后，
            · 模型名会去取本机 LM Studio 的（通常是空）→ 界面显示成"本机模型"；
            · `is_cloud` 判成 False → 前端显示"不产生余额消耗"，误导用户。
          新增一个 provider 就会再踩一次，所以这里改成**从 provider 表取**，
          不再手写名单。
        """
        snap = meter().snapshot()
        prov = (config.PROVIDER or "").lower()
        info = config.provider_info(prov)
        snap["provider"] = prov
        # 云端 = 不是本机。这条口径和 lms.py 完全一致
        is_cloud = prov not in ("lmstudio", "local", "")
        snap["is_cloud"] = is_cloud
        # 模型名：优先级 = 各 provider 的配置常量 > provider 表里的默认值
        if is_cloud:
            up = prov.upper()
            snap["model"] = (getattr(config, f"{up}_MODEL", "")
                             or info.get("model", ""))
        else:
            snap["model"] = config.LM_MODEL
        # 有没有 Key 也要看**当前这家**的，不能永远看 DeepSeek 的
        if is_cloud:
            up = prov.upper()
            snap["has_key"] = bool(
                (getattr(config, f"{up}_API_KEY", "")
                 or config.provider_api_key(prov) or "").strip())
        else:
            snap["has_key"] = True          # 本机不需要 Key
        return snap

    def _refresh_balance(self) -> dict:
        """查一次余额并记进统计。失败时把原因原样带回去（前端好解释）。

        ⚠ 余额查询目前只有 DeepSeek 有公开接口。切到别家时**不要**
          拿 DeepSeek 的 Key 去查 DeepSeek 的接口 —— 那会返回 401，
          而用户看到的是"余额查询失败"，完全对不上原因。
        """
        if (config.PROVIDER or "").lower() != "deepseek":
            info = config.provider_info(config.PROVIDER)
            msg = (f"「{info.get('name') or config.PROVIDER}」没有公开的余额查询接口，"
                   "本条仅统计本程序自己的调用量。")
            BUS.emit("log", {"level": "info", "text": msg})
            return {"ok": False, "error": msg}
        r = fetch_balance((config.DEEPSEEK_API_KEY or "").strip(),
                          base_url=config.DEEPSEEK_BASE_URL or "https://api.deepseek.com")
        if r.get("ok"):
            meter().update_balance(r)
            BUS.emit("log", {"level": "info",
                             "text": f"余额：{r.get('total_balance')} {r.get('currency')}"})
        else:
            BUS.emit("log", {"level": "warn",
                             "text": "余额查询失败：" + str(r.get("error"))})
        return r

    # ---- 模型连通性测试 ----
    def _do_test_model(self) -> dict:
        try:
            c = LMStudioClient()
        except LMError as e:
            return {"ok": False, "stage": "构造客户端", "error": str(e)}
        except Exception as e:
            return {"ok": False, "stage": "构造客户端", "error": f"{type(e).__name__}: {e}"}

        out: dict[str, Any] = {
            "ok": False, "provider": c.provider, "base_url": c.base_url,
            "model": c.model, "vision": c.is_vision_capable(), "steps": [],
        }
        try:
            t0 = time.time()
            r = c.ask('只输出 JSON：{"ok":true,"n":3+4}', max_tokens=128, timeout=60)
            out["steps"].append({"name": "纯文本", "ok": True,
                                 "detail": f"{r.seconds:.1f}s，返回 {r.text.strip()[:60]}"})
            out["text_seconds"] = round(time.time() - t0, 1)
        except Exception as e:
            out["steps"].append({"name": "纯文本", "ok": False, "detail": f"{type(e).__name__}: {e}"})
            out["error"] = str(e)
            out["stage"] = "纯文本请求"
            return out

        try:
            r = c.ask("单选：HTTP 默认端口是？ A. 21 B. 22 C. 80 D. 443\n"
                      '只输出 JSON：{"answer":"C"}', max_tokens=256, timeout=60)
            ans = r.json().get("answer") if isinstance(r.json(), dict) else r.text[:20]
            out["steps"].append({"name": "JSON 答题", "ok": True, "detail": f"答 {ans}"})
        except Exception as e:
            out["steps"].append({"name": "JSON 答题", "ok": False, "detail": f"{type(e).__name__}: {e}"})

        # 找一张测试图做视觉验证。候选顺序：
        #   程序自带样例 → out 下的样例 → 用户最近的截图
        # 独立版没有 tests\ 目录，所以必须有后两条，否则这项会被静默跳过，
        # 用户就不知道"看图到底行不行"。
        img = None
        for cand in (
            config.PROJECT_DIR / "tests" / "chart.png",
            config.PROJECT_DIR / "out" / "selftest" / "chart.png",
            CONFIG_FILE.parent / "selftest" / "chart.png",
        ):
            if cand.exists():
                img = cand
                break
        if img is None:
            shots = sorted(config.SHOT_DIR.glob("*.png"),
                           key=lambda p: p.stat().st_mtime, reverse=True)
            img = shots[0] if shots else None

        if not c.is_vision_capable():
            out["steps"].append({"name": "看图", "ok": True,
                                 "detail": f"当前模型 {c.model} 不支持图片，已跳过（deepseek-flash 支持）"})
        elif img is None:
            out["steps"].append({"name": "看图", "ok": True,
                                 "detail": "还没有可用图片（跑过一次任务后就能测），已跳过"})
        else:
            try:
                r = c.ask('这张图里有什么？只输出 JSON：{"desc":"一句话"}',
                          images=[str(img)], max_tokens=256, timeout=90)
                desc = r.text.strip()
                try:
                    parsed = r.json()
                    if isinstance(parsed, dict) and parsed.get("desc"):
                        desc = str(parsed["desc"])
                except Exception:
                    pass
                out["steps"].append({"name": "看图", "ok": True,
                                     "detail": f"{img.name}：{desc[:60]}"})
            except Exception as e:
                out["steps"].append({"name": "看图", "ok": False,
                                     "detail": f"{type(e).__name__}: {e}"})

        out["ok"] = all(s["ok"] for s in out["steps"])
        return out

    # ---- SSE ----
    def _sse(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        for k, v in self._SECURITY_HEADERS:
            self.send_header(k, v)
        self.end_headers()

        # 浏览器 EventSource 重连时会自动带上 `Last-Event-ID`；
        # 有它就只补"之后漏掉的"，没有才是全新连接（给最近 60 条当上下文）。
        # 见 `EventBus.backlog` 与 C-11 的说明。
        last_id = 0
        try:
            raw = self.headers.get("Last-Event-ID") or "0"
            last_id = int(str(raw).strip() or 0)
        except Exception:
            last_id = 0

        q = BUS.subscribe()
        try:
            for ev in BUS.backlog(last_id, 60):
                self._sse_send(ev)
            last_ping = time.time()
            while True:
                try:
                    ev = q.get(timeout=1.0)
                    self._sse_send(ev)
                except queue.Empty:
                    if time.time() - last_ping > 15:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                        last_ping = time.time()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            BUS.unsubscribe(q)

    def _sse_send(self, ev: dict) -> None:
        payload = json.dumps(ev, ensure_ascii=False)
        # `id:` 让浏览器记住位置，重连时通过 Last-Event-ID 带回来。
        # ⚠ 必须写在 `data:` **之前**，这是 SSE 的格式要求。
        seq = int(ev.get("_seq") or 0)
        head = f"id: {seq}\n" if seq else ""
        self.wfile.write(f"{head}data: {payload}\n\n".encode("utf-8"))
        self.wfile.flush()

    # ---- 最新截图 ----
    # 审计 C-18：`SHOT_DIR` 是用户可配目录，可能累积几百上千张 PNG；
    #   而 `sorted(glob(...), key=st_mtime)` 是"每张都 stat 一遍 + 全量排序"，
    #   前端每次截图事件都会请求这里，长时间跑会明显卡。
    #   这里缓存"最近一次扫描的结果"，用**目录自身的 mtime** 做失效判断：
    #   目录内容一变（新增/删除文件），mtime 就会变 → 自动重扫。
    #   ⚠ 不改语义：仍然是"取目录里最新的那张 PNG"，不是"取我们生成的那张" ——
    #     用户手动往目录里放图也会被正确显示。
    _shot_cache: tuple[float, str] | None = None

    def _latest_shot(self) -> None:
        try:
            pick = ""
            try:
                dm = config.SHOT_DIR.stat().st_mtime
            except Exception:
                dm = 0.0
            cached = Handler._shot_cache
            if cached is not None and cached[0] == dm and cached[1]:
                pick = cached[1]
            else:
                shots = sorted(config.SHOT_DIR.glob("*.png"),
                               key=lambda p: p.stat().st_mtime)
                if shots:
                    pick = str(shots[-1])
                    Handler._shot_cache = (dm, pick)
                else:
                    Handler._shot_cache = (dm, "")
            if not pick:
                self._json({"error": "no shot"}, 404)
                return
            data = Path(pick).read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            for k, v in self._SECURITY_HEADERS:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._json({"error": str(e)}, 500)


# ---------------------------------------------------------------------------
def check_browser_available() -> tuple[bool, str]:
    """确认有能用的浏览器。

    独立版不打包 Chromium（那要多 130MB），靠系统自带的 Edge / Chrome。
    这里提前探测一次，好在界面上给出人话提示，而不是答题时才莫名失败。

    ⚠ 审计 C-15：这个函数会在启动路径上跑，而它**真的启动浏览器**来试。
      `CHROME_CHANNEL` 默认是 "msedge,chrome"（可以是逗号分隔的多个渠道），
      机器上只有 Edge 时，chrome 那次要等 Playwright 报错（数秒），
      最后还要试"内置 Chromium" —— 而交付版**没有**内置内核，必然再等一次超时。
      用户双击后要盯着空白等十几秒，期间没有窗口也没有可见日志。
      现在加**总时间预算**：超了就直接返回已有结论，不再无限往下试。
    """
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        return False, f"Playwright 组件缺失：{e}"

    # 整个探测最多花这么久。正常机器第一次就命中（约 1-3 秒）。
    budget_sec = 12.0
    t0 = time.time()
    tried: list[str] = []
    channels = [c.strip() for c in str(config.CHROME_CHANNEL or "").split(",") if c.strip()]
    try:
        with sync_playwright() as pw:
            for chan in channels:
                if time.time() - t0 > budget_sec:
                    tried.append(f"{chan}(跳过:超出探测预算)")
                    break
                try:
                    b = pw.chromium.launch(channel=chan, headless=True)
                    b.close()
                    return True, chan
                except Exception as e:
                    tried.append(f"{chan}({str(e).splitlines()[0][:60]})")
            # 内置 Chromium：只有在预算内、且**看起来真装了**才试。
            # 交付版不带它，试也是白等一次启动超时。
            if time.time() - t0 <= budget_sec:
                try:
                    b = pw.chromium.launch(headless=True)
                    b.close()
                    return True, "chromium(内置)"
                except Exception as e:
                    tried.append(f"内置chromium({str(e).splitlines()[0][:60]})")
            else:
                tried.append("内置chromium(跳过:超出探测预算)")
    except Exception as e:
        return False, f"启动浏览器引擎出错：{e}"

    return False, ("找不到可用的浏览器。请安装 Microsoft Edge 或 Google Chrome。已尝试："
                   + "；".join(tried))


def _build_fingerprint() -> str:
    """一行日志说清"这是哪天的包"。

    为什么要有它（2026-10-23 客户日志诊断）：版本号长期保持 1.1.0，光看日志
    **分不出客户跑的是哪天的包** —— 上次是靠"缺哪三行日志"反推的，太脆。
    这里把版本 + 关键文件的修改时间 + 哈希前 10 位打出来，客户发日志时
    一眼就能对上"他跑的是不是新包"。
    """
    import hashlib

    root = Path(__file__).resolve().parent
    names = ["course.py", "videoquiz.py", "agent.py", "browser.py"]
    bits: list[str] = [f"版本 {_app_ver}"]
    newest = 0.0
    hashes: list[str] = []
    for name in names:
        p = root / name
        try:
            st = p.stat()
            newest = max(newest, float(st.st_mtime))
            h = hashlib.sha1(p.read_bytes()).hexdigest()[:10].upper()
            hashes.append(f"{name} {h}")
        except Exception:
            continue
    if newest:
        bits.append("代码日期 " + time.strftime("%Y-%m-%d %H:%M",
                                               time.localtime(newest)))
    bits.extend(hashes)
    return " · ".join(bits)


def serve(port: int = 0, open_browser: bool = True) -> tuple[ThreadingHTTPServer, str]:
    save_app_config(load_app_config())      # 首次运行落一份配置文件，方便用户手改

    # 开一段新的日志段落，并告诉用户日志在哪 —— 出问题时直接把这个文件发过来
    try:
        with _LOG_LOCK:
            LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
                f.write("\n" + "=" * 60 + "\n")
                f.write("启动 %s\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
                f.write("=" * 60 + "\n")
    except Exception:
        pass

    # 清掉上次残留的浏览器锁、临时目录、超量截图 —— 被强杀后这些会越积越多
    try:
        from .browser import cleanup_stale_state
        cleanup_stale_state(log=lambda s: BUS.emit("log", {"level": "info", "text": s}))
    except Exception:
        pass

    BUS.emit("log", {"level": "info",
                     "text": f"运行日志：{LOG_FILE}（出问题时把这份日志留好，方便对照排查）"})
    # ★ 构建指纹：客户发日志时，一眼就能判断他跑的是不是新包
    try:
        BUS.emit("log", {"level": "info", "text": _build_fingerprint()})
    except Exception:
        pass

    # ★ 2026-10-26：公告功能已整体删除，这里不再有任何对仓库的自动网络请求。

    # 后台建本地资料索引 —— 答疑页打开时就能显示文件数。
    # 纯本地读文件，不联网；失败也静默，不影响启动。
    try:
        local_kb.warmup_async()
    except Exception:
        pass

    ok, detail = check_browser_available()
    if ok:
        BUS.emit("log", {"level": "info", "text": f"浏览器就绪：{detail}"})
    else:
        BUS.emit("log", {"level": "error", "text": detail})
        BUS.emit("toast", {"level": "error", "text": "没有可用的浏览器，答题会失败", })

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    actual = httpd.server_address[1]
    url = f"http://127.0.0.1:{actual}/"
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    return httpd, url


def open_app_window(url: str, browser_exe: str) -> None:
    """用 Edge/Chrome 的 --app 模式开一个独立窗口。

    这样界面看起来就是一个桌面软件（没有地址栏、没有标签页），
    比在浏览器里开标签页体面得多，也不需要额外引入 GUI 框架。
    """
    import subprocess

    profile = config.OUT_DIR / "ui-profile"
    profile.mkdir(parents=True, exist_ok=True)
    args = [
        browser_exe,
        f"--app={url}",
        f"--user-data-dir={profile}",
        "--window-size=1280,860",
        "--no-first-run",
        "--no-default-browser-check",
        # 界面窗口只是个本地网页壳，把后台服务全关掉：
        # 省内存（实测界面浏览器会拉起好几个后台进程）
        # 也省磁盘（组件更新会在 ui-profile 里下上百 MB 的模型缓存）。
        "--disable-component-update",
        "--disable-background-networking",
        "--disable-sync",
        "--disable-breakpad",
        "--disable-crash-reporter",
        "--no-service-autorun",
        "--disable-domain-reliability",
        "--metrics-recording-only",
        "--disable-features=OptimizationGuideModelDownloading,OptimizationHints,"
        "MediaRouter,Translate,InterestFeedContentSuggestions",
    ]
    try:
        proc = subprocess.Popen(args, close_fds=True)
        # 记下 PID：退出时要把它关掉，否则用户会看到"软件关了窗口还在"
        if proc.pid:
            _OWNED_BROWSERS.add(proc.pid)
    except Exception as e:
        print(f"  （独立窗口打开失败，改用默认浏览器：{e}）")
        webbrowser.open(url)


def prepare_browsers() -> int:
    """下载 Playwright 自带的 Chromium 到程序目录里。

    给"目标机器上没有 Edge/Chrome"的情况兜底：装完之后程序就能在任意 Windows
    上跑，完全不依赖系统浏览器。需要联网（约 130MB），所以做成手动触发的动作。
    """
    browsers = config.OUT_DIR / "ms-playwright"
    browsers.mkdir(parents=True, exist_ok=True)
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(browsers)
    print(f"\n  正在下载 Chromium 到：{browsers}")
    print("  约 130 MB，请保持网络畅通…\n")
    try:
        from playwright.__main__ import main as pw_main
        sys_argv_backup = sys.argv[:]
        sys.argv = ["playwright", "install", "chromium"]
        try:
            pw_main()
        finally:
            sys.argv = sys_argv_backup
    except SystemExit as e:
        if e.code not in (0, None):
            print(f"\n  ✘ 下载失败（退出码 {e.code}）。可以手动执行：")
            print(f'     set PLAYWRIGHT_BROWSERS_PATH={browsers}')
            print("     runtime\\python.exe -m playwright install chromium")
            return 1
    except Exception as e:
        print(f"\n  ✘ 下载出错：{type(e).__name__}: {e}")
        return 1

    print("\n  ✔ Chromium 已就绪。之后即使没有 Edge/Chrome 也能运行。")
    # 让主流程优先用内置内核
    os.environ["DSHS_CHROME_CHANNEL"] = ""
    return 0


def _acquire_single_instance() -> bool:
    """单实例保护：已经在跑就返回 False。

    为什么必须有：用户双击两次 exe 是**最常见的误操作**，而两个实例会
      ① 各起一个 HTTP 服务、各开一个窗口；
      ② **共享同一个 `out\\`**：配置文件互相覆盖；
      ③ **抢同一个 `out\\browser-profile`**：Chromium 发现 `--user-data-dir`
         被占用，会把参数转给已有进程然后**自己立刻退出**，界面于是报
         "浏览器意外退出（疑似被杀毒软件拦截）" —— 误导性极强；
      ④ agent 还可能连到一个**未登录**的浏览器上去答题。

    用 Windows 命名互斥体实现（纯 ctypes，不引第三方依赖）。
    非 Windows 平台直接放行（本项目只发 Windows 包）。
    """
    global _SINGLE_MUTEX
    if os.name != "nt":
        return True
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        kernel32.CreateMutexW.argtypes = [wintypes.LPCVOID, wintypes.BOOL,
                                          wintypes.LPCWSTR]
        # Global\ 前缀 = 跨会话；名字固定，同一个用户下只会有一个实例
        h = kernel32.CreateMutexW(None, False, "Global\\MRSStudyAssistant_Mutex")
        ERROR_ALREADY_EXISTS = 183
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS or h == 0:
            return False
        _SINGLE_MUTEX = h          # 持有到进程结束（不要 close，否则互斥失效）
        return True
    except Exception:
        # 拿不到互斥体不该阻止用户使用，放行
        return True


_SINGLE_MUTEX: Any = None


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description=APP_NAME)
    ap.add_argument("--port", type=int, default=0, help="0 = 自动选空闲端口")
    ap.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    ap.add_argument("--open-app", default="", metavar="浏览器路径",
                    help="用指定浏览器的 --app 模式开独立窗口")
    ap.add_argument("--prepare", action="store_true",
                    help="下载自带浏览器内核（目标机器没有 Edge/Chrome 时用）")
    ap.add_argument("--allow-multi", action="store_true",
                    help="允许同时运行多个实例（默认不允许，防止抢档案）")
    args = ap.parse_args()

    if args.prepare:
        return prepare_browsers()

    # ---- 单实例检查 ----
    if not args.allow_multi and not _acquire_single_instance():
        print(f"\n  ⚠ {APP_NAME} 已经在运行中了。")
        print("  请用已经打开的那个窗口；如果找不到它，"
              "请在任务管理器里结束所有「昔涟自习室」或「MRS Study Assistant」再重试。")
        print("  （同时开两个会让它们抢同一份浏览器档案，导致登录状态丢失）\n")
        try:
            # 尽力把已有窗口带到前面
            webbrowser.open("http://127.0.0.1:0")
        except Exception:
            pass
        return 0

    # ⚠ httpd 必须先初始化成 None：原来 `serve()` 抛异常时，
    #   `finally: httpd.shutdown()` 会因变量未绑定再抛一次，
    #   用户只看到黑框一闪 + 英文 traceback，完全看不出真正原因。
    httpd = None
    # 双保险：无论从哪条路径退出，都尽量把浏览器/Playwright 收掉。
    # atexit 管"正常 return / 未捕获异常"，signal 管"Ctrl+C / 关控制台窗口"。
    import atexit
    atexit.register(shutdown_all, "进程退出")

    def _on_signal(signum, _frame=None):
        shutdown_all(f"收到信号 {signum}")
        # 不要在这里 sys.exit()：让主循环自然结束，避免和 atexit 重复跑清理

    import signal as _signal
    for _name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        _sig = getattr(_signal, _name, None)
        if _sig is None:
            continue
        try:
            _signal.signal(_sig, _on_signal)
        except Exception:
            pass

    try:
        httpd, url = serve(args.port, open_browser=False)
    except Exception as e:
        print(f"\n  ✘ 启动失败：{type(e).__name__}: {e}")
        print("  常见原因：端口被占用 / 目录只读 / 缺少浏览器。")
        shutdown_all("启动失败")
        return 1

    if args.open_app:
        open_app_window(url, args.open_app)
    elif not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    print(f"\n  {APP_NAME} 已启动")
    print(f"  界面地址：{url}")
    print(f"  配置文件：{CONFIG_FILE}")
    print(f"  数据目录：{config.OUT_DIR}")
    print("\n  关闭本窗口即可退出程序。\n")

    # 启动后静默检查更新：后台线程、晚 4 秒、失败完全静默。
    # 绝不影响软件启动 —— 查更新只是锦上添花。
    threading.Thread(target=_update_boot_check, daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n  正在退出…")
    finally:
        shutdown_all("正常退出")
        if httpd is not None:
            try:
                httpd.shutdown()
            except Exception:
                pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
