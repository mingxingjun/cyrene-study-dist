"""LM Studio 客户端。

只依赖 HTTP（requests），走 LM Studio 的 OpenAI 兼容端点：
    GET  /v1/models
    POST /v1/chat/completions     (支持多模态 image_url + base64 data URI)

为什么不用 openai / lmstudio 官方 SDK：
  - 少一个依赖，少一层版本冲突；
  - 本工具只需要 chat/completions 一个能力；
  - 便于打印原始报文来调试模型输出格式。
"""
from __future__ import annotations

import base64
import io
import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any

import requests

from . import config
from .usage import UsageMeter


class LMError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# 全局用量计数器（整个进程共享）。
# 任务跑在后台线程、服务在主线程读快照，所以需要线程安全 —— UsageMeter 内部有锁。
# 用惰性单例：这样不需要在服务启动流程里额外做初始化，也避免循环导入。
_METER: UsageMeter | None = None
# ⚠ 审计 C-8：单例本身也要加锁。
#   原来是裸的 `if _METER is None: _METER = UsageMeter(...)` ——
#   `ThreadingHTTPServer` 的请求线程与后台任务线程可能**同时**首次调用，
#   于是构造出两个实例；被淘汰那个在 GC 时会用它的旧快照覆盖磁盘统计
#   （`UsageMeter.__del__` 现在已有 owner 判定兜底，但这里从源头堵住更好）。
#   用"双检锁"：先无锁快路径，避免每次取用都抢锁。
_METER_LOCK = threading.Lock()


def meter() -> UsageMeter:
    global _METER
    m = _METER
    if m is not None:
        return m
    with _METER_LOCK:
        if _METER is None:
            _METER = UsageMeter(config.OUT_DIR / "usage.json")
        return _METER


# --------------------------------------------------------------------------
# JSON 提取：本地模型最常见的失败不是"答错"而是"话多"，这里做多层兜底
# --------------------------------------------------------------------------
_FENCE_RE = re.compile(r"```(?:json|JSON)?\s*(.*?)```", re.S)


def _loads_lenient(s: str) -> Any:
    try:
        return json.loads(s)
    except Exception:
        pass
    # 去掉对象/数组末尾多余的逗号
    fixed = re.sub(r",\s*([}\]])", r"\1", s)
    return json.loads(fixed)


def extract_json(text: str) -> Any:
    """从模型输出里抠出第一个合法 JSON 对象/数组。失败抛 ValueError。"""
    if text is None:
        raise ValueError("模型返回为空")
    t = text.strip()

    # 1) 直接就是 JSON
    for cand in (t,):
        try:
            return _loads_lenient(cand)
        except Exception:
            pass

    # 2) ```json ... ``` 代码块
    for m in _FENCE_RE.finditer(t):
        try:
            return _loads_lenient(m.group(1).strip())
        except Exception:
            continue

    # 3) 括号配对扫描（跳过字符串里的括号）
    for open_ch, close_ch in (("{", "}"), ("[", "]")):
        start = t.find(open_ch)
        while start != -1:
            depth = 0
            in_str = False
            esc = False
            for i in range(start, len(t)):
                c = t[i]
                if in_str:
                    if esc:
                        esc = False
                    elif c == "\\":
                        esc = True
                    elif c == '"':
                        in_str = False
                    continue
                if c == '"':
                    in_str = True
                elif c == open_ch:
                    depth += 1
                elif c == close_ch:
                    depth -= 1
                    if depth == 0:
                        try:
                            return _loads_lenient(t[start : i + 1])
                        except Exception:
                            break
            start = t.find(open_ch, start + 1)

    raise ValueError(f"无法从模型输出中解析 JSON（前 400 字符）：{t[:400]}")


# --------------------------------------------------------------------------
@dataclass
class ChatResult:
    text: str = ""
    reasoning: str = ""
    raw: dict = field(default_factory=dict)
    seconds: float = 0.0
    usage: dict = field(default_factory=dict)

    def json(self) -> Any:
        """优先解析 content；content 为空/不是 JSON 时，从 reasoning 里抢救。

        这不是奇技淫巧：推理型模型（qwen3.5 这类）在 max_tokens 被思考烧完时，
        content 会是空字符串，而答案往往已经写在 reasoning 里了。
        """
        if self.text and self.text.strip():
            try:
                return extract_json(self.text)
            except ValueError:
                pass
        if self.reasoning and self.reasoning.strip():
            return extract_json(self.reasoning)
        raise ValueError(f"模型既没有 content 也没有 reasoning（finish_reason="
                         f"{self.finish_reason()!r}，用量={self.usage}）")

    def finish_reason(self) -> str:
        try:
            return self.raw["choices"][0].get("finish_reason") or ""
        except Exception:
            return ""

    def truncated(self) -> bool:
        return self.finish_reason() == "length"


class LMStudioClient:
    """OpenAI 兼容客户端。可连本地 LM Studio，也可连各家云 API。

    各家的 Chat Completions 协议同构，差异只在：
      - 鉴权：云端需要真实 API Key；个别家（Azure 系）用 api-key 头而不是 Bearer
      - 视觉：哪些模型能读图，各家不同
      - 限流：云端会 429，需要退避重试
      - 采样参数：推理型模型（reasoner 类）不支持 temperature/top_p
      - 思考字段：只有部分家认 `thinking`，**发给别家会直接 400**
      - 模型列表：云端只有 /models，没有 LM Studio 的 /api/v0/models

    ⚠ 这些差异**统一由 config.PROVIDERS 那张表描述**，
      不再散落成一堆 `if self.is_cloud`。
      加一个新接口 = 在表里加一行，这个类不用改。
    """

    def __init__(
        self,
        base_url: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
        timeout: float | None = None,
        provider: str | None = None,
    ) -> None:
        self.provider = (provider or config.PROVIDER or "lmstudio").strip().lower()
        self.info = config.provider_info(self.provider)
        is_cloud = self.is_cloud

        # ---- 按 provider 选 base_url / model / api_key ----
        #
        # ⚠ 这里踩过一个坑：原来的写法是"只要是云端就用 DEEPSEEK_*"。
        #   接上第二家（Kimi）之后，它会拿着 DeepSeek 的 base_url 和 Key
        #   去请求月之暗面 —— 报出来是 401，但看日志完全想不到是这个原因。
        #   现在按 provider 名去 config 里取对应的那一组。
        cfg_base = cfg_model = cfg_key = ""
        if is_cloud:
            if self.provider == config.CUSTOM_PROVIDER:
                cfg_base = config.CUSTOM_BASE_URL
                cfg_model = config.CUSTOM_MODEL
                cfg_key = config.CUSTOM_API_KEY
            else:
                # 表里登记过的家：约定常量名是 <PROVIDER>_BASE_URL 等
                up = self.provider.upper()
                cfg_base = getattr(config, f"{up}_BASE_URL", "") or self.info.get("base", "")
                cfg_model = getattr(config, f"{up}_MODEL", "") or self.info.get("model", "")
                cfg_key = (getattr(config, f"{up}_API_KEY", "")
                           or config.provider_api_key(self.provider))
        else:
            cfg_base, cfg_model, cfg_key = (
                config.LM_BASE_URL, config.LM_MODEL, config.LM_API_KEY)

        self.base_url = (base_url or cfg_base or self.info.get("base", "")).rstrip("/")
        self.model = model or cfg_model or ""
        self.api_key = api_key or cfg_key or ""

        # ⚠ 鉴权方式随 provider 而变（Azure 系用 api-key 头而不是 Bearer）。
        self.auth_style = str(self.info.get("auth") or "bearer")

        self.timeout = timeout or config.LM_TIMEOUT
        self._session = requests.Session()
        # 有些 LM Studio 版本只接受 response_format.type ∈ {json_schema, text}，
        # 发 {"type":"json_object"} 会直接 400。第一次撞上就永久关掉，不再发。
        self._response_format_ok = True
        # 推理型模型不接受 temperature，发了会报错
        self._sends_temperature = "reasoner" not in (self.model or "").lower()

        if not self.model:
            self.model = self.autodetect_model()

        if is_cloud and not self.api_key:
            hint = ("请在「设置」里填入它的 API Key，"
                    "或设环境变量 DSHS_%s_API_KEY"
                    % self.provider.upper())
            raise LMError(
                f"走「{self.info.get('name') or self.provider}」需要 API Key。\n"
                f"  · {hint}\n"
                f"  · 当前 base_url：{self.base_url or '(未填，请到「设置」里填)'}\n"
                "  · 想完全离线不花钱：把「模型来源」改成「本机 LM Studio」"
            )

    @property
    def is_cloud(self) -> bool:
        """是不是云端接口（本地 LM Studio 之外的都算）。

        ⚠ 原来这里是硬编码白名单 `in ("deepseek","openai","cloud")` ——
          新加的接口名（如 kimi）不在里面，于是被当成"本地"，
          会去连 127.0.0.1 然后报"连不上 LM Studio"，很难看出真正原因。
          现在改成"**只要不是本地的，就算云端**"，加接口不会再踩这个坑。
        """
        return self.provider not in ("lmstudio", "local", "")

    # ---------------------------------------------------------------- 基础
    @property
    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        style = (self.auth_style or "bearer").lower()
        if style == "none":
            return h
        if style == "api-key":
            # Azure OpenAI 这类用 api-key 头
            h["api-key"] = self.api_key
        else:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def list_models(self) -> list[dict]:
        try:
            r = self._session.get(f"{self.base_url}/models", headers=self._headers, timeout=15)
            r.raise_for_status()
            return r.json().get("data", [])
        except requests.RequestException as e:
            if self.is_cloud:
                raise LMError(
                    f"连不上 {self.provider}（{self.base_url}）。请检查："
                    f"① 网络能访问外网 ② API Key 是否正确/有余额。原始错误：{e}"
                ) from e
            raise LMError(
                f"连不上 LM Studio（{self.base_url}）。请确认："
                f"① LM Studio 已打开 ② 左侧 Developer/开发者 页签里 Local Server 已 Start。原始错误：{e}"
            ) from e

    def native_models(self) -> list[dict]:
        """LM Studio 原生 /api/v0/models，能拿到 type=vlm/llm、state、量化等信息。

        云端没有这个端点，直接返回空（上层会退化为用 /v1/models）。
        """
        if self.is_cloud:
            return []
        root = self.base_url[: -len("/v1")] if self.base_url.endswith("/v1") else self.base_url
        try:
            r = self._session.get(f"{root}/api/v0/models", headers=self._headers, timeout=10)
            r.raise_for_status()
            return r.json().get("data", [])
        except requests.RequestException:
            return []

    def autodetect_model(self) -> str:
        """云端：用**本 provider 的**默认模型。本地：挑一个已加载的 vlm/llm。"""
        if self.is_cloud:
            # ⚠ 原来写死 DeepSeek 的默认模型 —— 换成别的接口后，
            #   用户没填模型名就会拿 DeepSeek 的模型名去请求别家，必然 400。
            return (self.info.get("model") or "").strip()
        native = self.native_models()
        if native:
            usable = [m for m in native if m.get("type") in ("vlm", "llm")]
            for m in usable:
                if m.get("state") == "loaded":
                    return m["id"]
            if usable:
                return usable[0]["id"]
        for m in self.list_models():
            mid = m.get("id", "")
            if "embed" in mid.lower():
                continue
            return mid
        raise LMError("LM Studio 里没有可用的对话模型，请先在 LM Studio 里加载一个模型。")

    def is_vision_capable(self) -> bool:
        """能不能读图。

        本地：看 LM Studio 的 type 是不是 vlm。
        云端：按**本 provider 的**视觉模型关键字判断（各家不同）。
        """
        if self.is_cloud:
            name = (self.model or "").lower()
            words = tuple(self.info.get("vision") or ())
            # 表里没写视觉关键字 → 保守判为"不能读图"，避免发图过去白等一次失败
            return any(k in name for k in words) if words else False
        for m in self.native_models():
            if m.get("id") == self.model:
                return m.get("type") == "vlm"
        return False

    # ---------------------------------------------------------------- 对话
    def chat(
        self,
        messages: list[dict],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        json_mode: bool = False,
        extra_body: dict | None = None,
    ) -> ChatResult:
        # 预算护栏（进程级调用/Token/成本上限，默认全 0 = 不限制）。
        # ⚠ fail-open：预算模块缺失或自身任何异常都不许影响正常请求；
        #   只有"确实超限"才转成 LMError，由 agent 按"模型作答失败"友好提示。
        #   注意 except 要接住 BudgetExceeded 转出来的 LMError，别让它被 fail-open 吞掉。
        try:
            from . import budget as _budget
            try:
                _budget.check()
            except _budget.BudgetExceeded as e:
                raise LMError(str(e)) from e
        except LMError:
            raise
        except Exception:
            pass

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "max_tokens": config.LM_MAX_TOKENS if max_tokens is None else max_tokens,
            "stream": False,
        }
        # deepseek-reasoner 这类不支持采样参数，发了会被拒
        if self._sends_temperature:
            payload["temperature"] = config.LM_TEMPERATURE if temperature is None else temperature
        # ⚠ `thinking` 是 DeepSeek 专有字段 —— **发给别家会直接 400**。
        #   原来只在 is_cloud 时判断，于是加了新接口就会被拒。
        #   现在按 provider 表里的 think 标记决定。
        if self.info.get("think") and not config.DEEPSEEK_THINKING:
            payload["thinking"] = {"type": "disabled"}
        # 注意：很多本地模型 + 新版 LM Studio 对 response_format 支持不一致，
        # 所以 json_mode 只做"尽力而为"，真正的保障是 extract_json()。
        if json_mode and self._response_format_ok:
            payload["response_format"] = {"type": "json_object"}
        if extra_body:
            payload.update(extra_body)

        t0 = time.time()
        r = None
        last_err: Exception | None = None
        # 云端 API 会被限流（429），偶发 5xx 也要重试。本地 LM Studio 一般不需要，
        # 但重试逻辑对两者都无害（失败重试次数由 DSHS_RETRY_MAX 控制）。
        for attempt in range(max(1, config.RETRY_MAX)):
            try:
                r = self._session.post(
                    f"{self.base_url}/chat/completions",
                    headers=self._headers,
                    json=payload,
                    timeout=timeout or self.timeout,
                )
            except requests.Timeout as e:
                last_err = e
                if attempt + 1 >= config.RETRY_MAX:
                    raise LMError(
                        f"模型响应超时（{timeout or self.timeout}s）。"
                        "可调大 DSHS_LM_TIMEOUT，或减少批量 / 关闭思考模式。"
                    ) from e
                time.sleep(config.RETRY_BACKOFF * (2 ** attempt))
                continue
            except requests.RequestException as e:
                last_err = e
                if attempt + 1 >= config.RETRY_MAX:
                    raise LMError(f"请求 {self.provider} 失败：{e}") from e
                time.sleep(config.RETRY_BACKOFF * (2 ** attempt))
                continue

            # 撞到 response_format 不被支持 → 关掉它并立刻重发（不计入重试次数）
            if r.status_code == 400 and "response_format" in payload and "response_format" in r.text:
                self._response_format_ok = False
                payload.pop("response_format", None)
                continue

            if r.status_code in (429, 500, 502, 503, 504) and attempt + 1 < config.RETRY_MAX:
                wait = config.RETRY_BACKOFF * (2 ** attempt)
                retry_after = r.headers.get("Retry-After")
                if retry_after:
                    try:
                        wait = max(wait, float(retry_after))
                    except ValueError:
                        pass
                time.sleep(min(wait, 60.0))
                continue
            break

        if r is None:
            raise LMError(f"请求 {self.provider} 失败（无响应）：{last_err}")

        if r.status_code >= 400:
            raise LMError(f"{self.provider} 返回 {r.status_code}：{r.text[:600]}")

        data = r.json()
        try:
            msg = data["choices"][0]["message"]
        except (KeyError, IndexError) as e:
            raise LMError(f"{self.provider} 返回结构异常：{json.dumps(data, ensure_ascii=False)[:600]}") from e

        res = ChatResult(
            text=msg.get("content") or "",
            reasoning=msg.get("reasoning_content") or msg.get("reasoning") or "",
            raw=data,
            seconds=time.time() - t0,
            usage=data.get("usage") or {},
        )
        # 用量统计：云端才有意义（本地 LM Studio 不产生费用）。
        # DeepSeek 没有用量查询接口（实测 /user/usage 是 404），
        # 所以只能这样在本地累计每次调用返回的 usage。
        if self.is_cloud:
            try:
                meter().add(self.model, res.usage)
            except Exception:
                pass
        return res

    def ask(
        self,
        prompt: str,
        *,
        system: str | None = None,
        images: list[str | bytes] | None = None,
        **kw,
    ) -> ChatResult:
        """纯文本/图文问答。images 可以是本地路径或原始 bytes。"""
        content: list[dict] = [{"type": "text", "text": prompt}]
        for img in images or []:
            content.append({"type": "image_url", "image_url": {"url": _to_data_uri(img)}})
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append(
            {"role": "user", "content": content if images else prompt}
        )
        return self.chat(messages, **kw)

    def ask_json(self, prompt: str, *, system: str | None = None, images=None, retries: int = 2, **kw) -> Any:
        """要 JSON，解析失败就把错误回灌给模型重试。"""
        last_err: Exception | None = None
        for attempt in range(retries + 1):
            p = prompt
            if attempt:
                p = (
                    prompt
                    + f"\n\n[系统提示] 上一次你的输出无法被解析为 JSON（{last_err}）。"
                    "请只输出一个合法 JSON，不要任何解释文字、不要 markdown 代码块。"
                )
            res = self.ask(p, system=system, images=images, json_mode=(attempt == 0), **kw)
            try:
                return res.json()
            except ValueError as e:
                last_err = e
                # 被 max_tokens 截断时，重试同一提示只会再被截断一次 —— 直说，让上层调大预算
                if res.truncated() and not res.text.strip():
                    raise LMError(
                        f"模型输出被 max_tokens 截断（思考吃掉了全部 {kw.get('max_tokens', config.LM_MAX_TOKENS)} "
                        f"tokens，content 为空）。请调大 DSHS_LM_MAX_TOKENS，或降低题目批量。"
                    ) from e
        raise LMError(f"连续 {retries + 1} 次都无法得到合法 JSON：{last_err}")


# --------------------------------------------------------------------------
def _sniff_mime(raw: bytes) -> str:
    """按文件头判断图片类型。

    ⚠ 为什么需要它：`_to_data_uri` 原来对 bytes 一律标成 `image/png`。
      PC 模式为了省流量已改成发 **JPEG**，如果还声明成 PNG，
      有的模型端会直接拒绝或按错误格式解码。
      按魔数判断比"相信调用方"稳。
    """
    try:
        if raw[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if raw[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
            return "image/webp"
        if raw[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif"
        if raw[:2] == b"BM":
            return "image/bmp"
    except Exception:
        pass
    return "image/png"          # 认不出来就按 PNG（维持原来的一贯行为）


_IMAGE_MAX_BYTES = 30 * 1024 * 1024    # 单图 32 MiB 上限，留一点余量


def _fit_image(raw: bytes) -> bytes:
    """发图前的最后一道尺寸护栏：保证单边不超过 `config.IMAGE_MAX_EDGE`。

    ⚠ 为什么需要它（2026-10-23 客户日志 `114404.txt`）：
      字体加密页的元素截图是一整张卷子（25 题，约 1 万像素高），
      超过 DeepSeek 的"单边最长 8192px"硬限制，接口直接返回
      400 `You have uploaded an unsupported image` —— **整批题一道都答不了**。
      `agent._obf_shot_slice()` 已经从源头按 1600px 切开；这里再兜一层，
      保证任何调用方（PC 模式、以后新加的图）都不会再因为尺寸被拒。

    ⚠ 只在**超限时**才重新编码：正常图片原样返回（字节完全一致），
      不重新压缩、不改变现有行为，也不损失清晰度。
    """
    try:
        from PIL import Image  # noqa: PLC0415
    except Exception:
        return raw

    try:
        im = Image.open(io.BytesIO(raw))
        im.load()
    except Exception:
        # 解不开就原样发：服务端会给明确错误，但这里不要自己把图吞掉
        return raw

    max_edge = int(getattr(config, "IMAGE_MAX_EDGE", 8000) or 8000)
    if max(im.size) <= max_edge and len(raw) <= _IMAGE_MAX_BYTES:
        return raw

    try:
        w, h = im.size
        if im.mode in ("RGBA", "LA", "P"):
            # 带透明通道的图直接转 RGB 会把透明区变黑；先垫白底
            bg = Image.new("RGB", (w, h), "white")
            rgba = im.convert("RGBA")
            bg.paste(rgba, mask=rgba.split()[-1])
            im = bg
        else:
            im = im.convert("RGB")
        scale = min(1.0, max_edge / float(max(w, h)))
        if scale < 1.0:
            im = im.resize((max(1, int(w * scale)), max(1, int(h * scale))),
                           Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True)
        out = buf.getvalue()
        if len(out) <= _IMAGE_MAX_BYTES:
            return out
        # PNG 还太大（照片类图）→ 退 JPEG；文字截图一般走不到这一步
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=88, optimize=True)
        out = buf.getvalue()
        return out if len(out) <= _IMAGE_MAX_BYTES else raw
    except Exception:
        return raw


def _to_data_uri(img: str | bytes | Any) -> str:
    """把一张图变成 data URI。**宽容地接受三种输入**。

    ⚠ 为什么这里要容忍 PIL.Image：
      调用方（PC 模式）拿到的是 `ImageGrab.grab()` 的 **PIL.Image 对象**，
      而本函数原来只处理"路径字符串 / bytes"，于是 `open(PIL对象, "rb")`
      抛 TypeError —— PC 模式每一步都失败，功能完全不可用。
      调用点已经改成传 `png_bytes()`，但**这里也做一层防御**：
      以后任何地方再传 PIL 对象进来也不会炸。
    """
    if isinstance(img, bytes):
        # 按魔数判断类型，不要一律写 png（发给模型的可能是 JPEG）
        # 超尺寸的图先缩放（否则云端直接 400，见 `_fit_image`）
        img = _fit_image(img)
        return ("data:" + _sniff_mime(img) + ";base64,"
                + base64.b64encode(img).decode("ascii"))
    # PIL.Image（或任何"有 save() 方法"的图对象）
    if hasattr(img, "save") and not isinstance(img, (str, os.PathLike)):
        buf = io.BytesIO()
        try:
            img.save(buf, format="PNG")
        except Exception:
            img.convert("RGB").save(buf, format="PNG")
        return ("data:image/png;base64,"
                + base64.b64encode(buf.getvalue()).decode("ascii"))
    with open(img, "rb") as f:
        raw = f.read()
    # 超尺寸（单边 > IMAGE_MAX_EDGE）的图在这里缩放，避免云端 400
    raw = _fit_image(raw)
    # 缩放后格式可能变了（例如大 JPEG 被转成 PNG），所以按**实际字节**判类型
    mime = _sniff_mime(raw)
    return f"data:{mime};base64," + base64.b64encode(raw).decode("ascii")


# --------------------------------------------------------------------------
if __name__ == "__main__":  # 自检： python -m dsh_solver.lms [lmstudio|deepseek]
    import sys as _sys

    _prov = _sys.argv[1] if len(_sys.argv) > 1 else "lmstudio"
    print(f"provider = {_prov}")
    c = LMStudioClient(provider=_prov)
    print(f"base_url = {c.base_url}")
    print(f"model    = {c.model}")
    print(f"vision   = {c.is_vision_capable()}")
    r = c.ask("只回答一个 JSON：{\"ok\": true, \"n\": 3+4}")
    print(f"reply    = {r.text!r}  ({r.seconds:.1f}s)")
    print(f"parsed   = {r.json()}")
