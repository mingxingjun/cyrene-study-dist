"""作答记录导出：把 `out\\runs\\run_*.json` 整理成 Obsidian 友好的 Markdown。

## 定位（为什么叫「作答记录 / 待复核」而不是「错题本」）

程序只知道自己**答了什么**、**有没有把握**、**有没有真正落笔**，
**不知道对错** —— 对错要等平台判分。所以：

- 导出文件里写「作答记录」+「待复核」，**不叫错题本**（诚实命名）；
- 文件头固定声明「本文件由程序作答记录导出，不含平台判分结果」；
- 「待复核」= `failed[]` 里程序没落笔的题 + `confidence < 0.35` 的题
  + `verified == false`（回读没确认落进页面）的题。

## 对外 API（集成方按这些名字调用）

```python
scan_runs(runs_dir=None) -> list[dict]           # 读 run_*.json，坏文件跳过并记 warnings
load_cache(cache_path=None) -> dict              # 读 answer_cache.json（不存在返回 {}）
join_cache(run, cache) -> dict                   # 用 AnswerCache.key_for 重算 key 做 join（仅选择题）
render_markdown(run, *, mode="record", index=1) -> str
render_index(runs) -> str                        # Obsidian 索引页（[[文件名]] 双链）
export_all(out_dir=None, *, runs_dir=None, cache_path=None, mode="record") -> dict
```

## 命令行

```bat
runtime\\python.exe -m dsh_solver.notebook --mode record --out out\\notes
```

## 边界

- **只读** `out\\runs\\*.json` 与 `out\\answer_cache.json`，只写 `out\\notes\\*.md`；
  不联网、不调模型、不改任何运行记录。
- 纯标准库；只有 `join_cache()` 需要 `AnswerCache.key_for()` 时才会惰性 import
  `agent`（不复制哈希算法 —— 缓存 key 的唯一真源在 `agent.py`）。
- 老 run JSON 没有 `meta` 时，站点/网址/模型写 `(未知)`，**不报错**。
"""
from __future__ import annotations

import argparse
import ast
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

# ── 入口兼容（本便携包的内嵌 Python 是 isolated 模式）──────────────────────────
#   `runtime\python312._pth` 固定了 sys.path，`python -m dsh_solver.notebook`
#   不会把当前目录加进去 —— 于是命令行的等价写法是**直接跑脚本路径**：
#
#       runtime\python.exe app\dsh_solver\notebook.py --mode record
#
#   直接跑时 `__package__` 是空的，相对的 `from . import config` 会失败；
#   这里先补上包名与 sys.path，两种入口共用同一份代码。
if __package__ in (None, ""):
    import sys as _sys
    from pathlib import Path as _Path

    _sys.path.insert(0, str(_Path(__file__).resolve().parent.parent))
    __package__ = "dsh_solver"

from . import config

__all__ = [
    "scan_runs",
    "load_cache",
    "join_cache",
    "render_markdown",
    "render_index",
    "export_all",
]

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
APP_NAME = "昔涟自习室 · Cyrene Study"

# 诚实命名：导出的文件名前缀。**不要**改成「错题本」——
# 程序不知道对错（只有平台判分后才知道），叫错题本会误导复习。
NOTE_PREFIX = "作答记录"
INDEX_NAME = "作答记录索引.md"
NOTES_DIRNAME = "notes"

_UNKNOWN = "(未知)"
# 与 agent.py / 界面里的落笔门槛保持同一个数（QUIZ_MIN_CONFIDENCE 默认 0.35）。
# 这里不直接读 config：导出器要能脱离运行环境单独使用，且门槛是"验收口径"而非可调项。
_LOW_CONFIDENCE = 0.35
# 超过这个字数的答案折叠展示（简答/论述常常几百字，堆在正文里没法看）。
_LONG_ANSWER = 120
# 「已作答」类题型的集合（只有它们能拿 options 去和缓存 join）。
_CHOICE_KINDS = {"radio", "checkbox", "select"}

# scan_runs() 不返回 warnings（对外签名固定），所以顺手留一份"最近一次扫描的警告"，
# 便于只调用 scan_runs 的脚本排查；export_all() 自己显式传 list，不依赖这个全局量。
_LAST_SCAN_WARNINGS: list[str] = []


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------
def _app_version() -> str:
    """包版本号（唯一真源 `dsh_solver/__init__.py`），取不到就退回 1.1.0。"""
    try:
        from . import __version__ as ver
        return str(ver or "1.1.0")
    except Exception:
        return "1.1.0"


def _source_line() -> str:
    return f"{APP_NAME} v{_app_version()}"


def _unknown(value: object) -> str:
    """空值统一显示 `(未知)` —— 老 run JSON 没有 meta，不能因此报错。"""
    text = str(value or "").strip()
    return text or _UNKNOWN


def _yaml_str(value: object) -> str:
    """YAML 双引号标量。用 json.dumps 生成：中文不转义，冒号/引号安全。"""
    return json.dumps(str(value), ensure_ascii=False)


def _cell(value: object) -> str:
    """Markdown 表格单元格：竖线、换行必须转义，否则表格会断。"""
    text = str(value if value is not None else "")
    return text.replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip()


def _inline(value: object) -> str:
    """正文行内文本：压平换行 + 转义 Obsidian 双链，避免题干被当成链接。"""
    text = str(value if value is not None else "").replace("\r", " ").replace("\n", " ").strip()
    return text.replace("[[", "\\[\\[").replace("]]", "\\]\\]")


def _heading(value: object, limit: int = 160) -> str:
    """小节标题里的题干：压平换行 + 转义双链（含 `|` 在标题里不需要转义）。"""
    text = _inline(value)
    if len(text) > limit:
        text = text[:limit].rstrip() + "…"
    return text


def _clip(value: object, limit: int) -> str:
    text = str(value if value is not None else "").strip()
    return text if len(text) <= limit else text[:limit].rstrip() + "…"


def _strip_leading_number(text: str) -> str:
    r"""去掉题干开头的题号（`1. 下列…` → `下列…`），避免标题出现「1. 1. …」。

    只吃 1~3 位数字 + 明确的序号分隔符，所以「2024 年…」这类不会被误删。
    """
    return re.sub(r"^\s*[（(]?\s*\d{1,3}\s*[)）.、．]\s*", "", (text or "").strip())


def _stem_of(item: dict) -> str:
    """题干：优先完整题干 `full_stem`，回退截断的 `stem`（v1.1.0 两种都可能）。"""
    return str(item.get("full_stem") or item.get("stem") or "").strip()


def _kind_cn(kind: object) -> str:
    key = str(kind or "").strip().lower()
    return {
        "radio": "单选",
        "checkbox": "多选",
        "select": "下拉选择",
        "text": "填空",
        "textarea": "填空",
        "contenteditable": "简答",
        "essay": "简答/论述",
    }.get(key, key or _UNKNOWN)


def _answer_letters(answer: object) -> tuple[set[str], bool]:
    r"""把 `answer` 解析成"选中了哪些选项字母"。

    多选存的是 **Python list 的 str**（形如 `"['A', 'B', 'D']"`，见 agent.py:1804），
    这里用 `ast.literal_eval` 安全解析（**绝不 eval**）；解析失败就原样展示，
    不猜、不抛。返回 `(字母集合, 是否解析成功)`。
    """
    raw = str(answer if answer is not None else "").strip()
    if not raw:
        return set(), True
    if raw[0] in "[({":
        try:
            value = ast.literal_eval(raw)
        except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
            return set(), False
        if isinstance(value, (list, tuple, set)):
            return {str(x).strip() for x in value if str(x).strip()}, True
        return {str(value).strip()}, True
    return {raw}, True


def _is_choice(item: dict) -> bool:
    """这条记录是不是"有选项的题"（join 缓存只对这类可靠）。"""
    kind = str(item.get("type") or "").strip().lower()
    return kind in _CHOICE_KINDS and bool(item.get("options"))


def _answer_display(item: dict) -> str:
    """人类可读答案：选择题把字母映射成选项原文；解析失败原样返回。"""
    raw = str(item.get("answer") if item.get("answer") is not None else "").strip()
    if not raw or not _is_choice(item):
        return raw
    letters, parsed_ok = _answer_letters(raw)
    if not parsed_ok or not letters:
        return raw
    options = [o for o in (item.get("options") or []) if isinstance(o, dict)]
    picked: list[str] = []
    mapping: list[str] = []
    for opt in options:
        key = str(opt.get("key") or "").strip()
        text = str(opt.get("text") or "").strip()
        if key and any(key.lower() == want.lower() for want in letters):
            picked.append(key)
            mapping.append(f"{key}. {_clip(text, 60)}")
    if not picked:
        return raw
    head = "、".join(picked)
    return f"{head}（{'；'.join(mapping)}）" if mapping else head


def _quote_detail(label: str, value: object) -> str:
    """Obsidian callout 里的一行：`> **label**：value`（多行压平）。"""
    return f"> **{label}**：{_inline(value)}"


# ---------------------------------------------------------------------------
# 数据源：runs / 缓存
# ---------------------------------------------------------------------------
def _parse_run_stamp(name: str) -> datetime | None:
    r"""从 `run_YYYYmmdd_HHMMSS.json` 的文件名解析时间。

    文件名是 v1.1.0 里**唯一可靠**的时间线索（老 run JSON 内部没有时间字段，
    新的有 `meta.started_at`，但那是"开始时刻"、文件名是"落盘时刻"，都留一手）。
    """
    match = re.match(r"^run_(\d{8})_(\d{6})\.json$", Path(str(name or "")).name)
    if not match:
        return None
    try:
        naive = datetime.strptime(match.group(1) + match.group(2), "%Y%m%d%H%M%S")
    except ValueError:
        return None
    try:
        return naive.astimezone()          # naive → 本机时区的 aware 时间
    except Exception:
        return naive


def _run_datetime(run: dict) -> datetime:
    """run 的时间：文件名 → meta.started_at → 文件 mtime → 现在。"""
    dt = _parse_run_stamp(str(run.get("_name") or ""))
    if dt is not None:
        return dt
    meta = run.get("meta") if isinstance(run.get("meta"), dict) else {}
    started = str(meta.get("started_at") or "").strip()
    if started:
        try:
            parsed = datetime.fromisoformat(started.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo else parsed.astimezone()
        except ValueError:
            pass
    ts = run.get("_ts")
    try:
        if ts:
            return datetime.fromtimestamp(float(ts)).astimezone()
    except (TypeError, ValueError, OSError):
        pass
    try:
        return datetime.now().astimezone()
    except Exception:
        return datetime.now()


def _now() -> datetime:
    try:
        return datetime.now().astimezone()
    except Exception:
        return datetime.now()


def scan_runs(runs_dir: str | Path | None = None,
              warnings: list[str] | None = None) -> list[dict]:
    r"""读 `out\\runs\\run_*.json`，按时间升序返回。

    - 目录不存在 / 没有文件 → 返回 `[]`（不抛异常）；
    - 空文件、半截 JSON（掉电/进程被杀）、顶层不是对象、缺 `answered/failed`
      字段 → **跳过**并往 `warnings` 里记一条，绝不抛；
    - 每条有效记录会额外带内部字段 `_path` / `_name` / `_ts`（下划线前缀，
      导出前会用 `_public_run()` 剔掉），供导出器取时间、写索引。
    """
    _LAST_SCAN_WARNINGS.clear()
    sink = _LAST_SCAN_WARNINGS if warnings is None else warnings
    base = Path(runs_dir) if runs_dir else config.RUNS_DIR
    runs: list[dict] = []
    try:
        files = sorted(Path(base).glob("run_*.json"))
    except Exception as exc:                       # 目录不可读 / 路径非法
        sink.append(f"无法扫描 runs 目录（{base}）：{type(exc).__name__}: {exc}")
        return []
    if not files:
        sink.append(f"runs 目录里没有 run_*.json：{base}")
        return []
    for path in files:
        try:
            raw = path.read_text(encoding="utf-8")
        except Exception as exc:
            sink.append(f"跳过 {path.name}：读取失败（{type(exc).__name__}）")
            continue
        if not raw.strip():
            sink.append(f"跳过 {path.name}：空文件")
            continue
        try:
            data = json.loads(raw)
        except Exception as exc:
            sink.append(f"跳过 {path.name}：JSON 不完整或损坏（{type(exc).__name__}）")
            continue
        if not isinstance(data, dict):
            sink.append(f"跳过 {path.name}：顶层不是 JSON 对象")
            continue
        # 老/新 schema 都至少要有这两个列表之一，否则就是半截记录。
        if not isinstance(data.get("answered"), list) and not isinstance(data.get("failed"), list):
            sink.append(f"跳过 {path.name}：缺 answered/failed 字段（半截记录？）")
            continue
        data["_path"] = str(path)
        data["_name"] = path.name
        try:
            data["_ts"] = path.stat().st_mtime
        except OSError:
            data["_ts"] = 0.0
        runs.append(data)
    runs.sort(key=lambda r: (_run_datetime(r).timestamp(), str(r.get("_name") or "")))
    if warnings is not None:
        _LAST_SCAN_WARNINGS[:] = warnings
    return runs


def load_cache(cache_path: str | Path | None = None) -> dict:
    """读 `out\\answer_cache.json`；不存在/损坏/顶层不是对象 → 空 dict（不抛）。"""
    path = Path(cache_path) if cache_path else (config.OUT_DIR / "answer_cache.json")
    try:
        if not path.exists():
            return {}
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _cache_key(item: dict) -> str:
    """用 `AnswerCache.key_for()` 重算缓存 key（**不复制算法**，唯一真源在 agent.py）。"""
    try:
        from .agent import AnswerCache          # 惰性 import：本模块纯标准库可用
        return str(AnswerCache.key_for(_stem_of(item), item.get("options") or []))
    except Exception:
        return ""


def join_cache(run: dict, cache: dict) -> dict:
    r"""把缓存里的 `model` / `created_at` / `source` 补到每条 `answered`。

    ★ 为什么能 join：缓存 key = `sha1(去前导序号的题干[:300] + 每个选项 text[:80])`，
       而 runs 里有 `full_stem` + `options`，重算一次就能对上（`agent.AnswerCache.key_for`）。
    ★ 为什么只对**选择题**可靠：`put()` 时填空题的 stem 用的是 `stem or label`
       （label 不总在 runs 里），所以填空/简答一律不 join —— **宁缺勿错**。

    不修改传入的 run（返回新的 dict、新的 answered 列表）；命中时补充：
    `cache_key` / `cache_hit` / `model` / `created_at` / `source`。
    """
    source_run = run if isinstance(run, dict) else {}
    joined = dict(source_run)
    answered: list[dict] = []
    for raw_item in source_run.get("answered") or []:
        if not isinstance(raw_item, dict):
            continue
        item = dict(raw_item)
        if _is_choice(item) and cache:
            key = _cache_key(item)
            hit = cache.get(key) if key else None
            if isinstance(hit, dict):
                item["cache_key"] = key
                item["cache_hit"] = True
                for field in ("model", "created_at", "source"):
                    value = hit.get(field)
                    if value in (None, "") or field in item:
                        continue
                    item[field] = value
        answered.append(item)
    joined["answered"] = answered
    return joined


# ---------------------------------------------------------------------------
# 待复核判定
# ---------------------------------------------------------------------------
def _to_float(value: object) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def needs_review_items(run: dict) -> list[dict]:
    r"""收集「待复核」条目（failed + 低置信度 + verified=false）。

    去重键是 `(ref, 题干[:80])`：B7 的坑是同一道题可能既在 `answered` 又在
    `failed`（history 是跨页总账，回读失败只从 attempts 摘除）—— 这种由 `failed`
    那条统一展示（它带 `why`），不再重复列出。题干为空的 failed 项不去猜它是哪道题，
    保留原样（宁可多列一条待复核，也不能漏）。
    """
    answered = [x for x in (run.get("answered") or []) if isinstance(x, dict)]
    failed = [x for x in (run.get("failed") or []) if isinstance(x, dict)]
    items: list[dict] = []
    failed_keys: set[str] = set()
    for raw in failed:
        ref = str(raw.get("ref") or "")
        stem = _stem_of(raw)
        failed_keys.add(f"{ref}|{stem[:80]}")
        why = str(raw.get("why") or "").strip() or _UNKNOWN
        items.append({
            "source": "failed",
            "ref": ref,
            "stem": stem,
            "answer": raw.get("answer"),
            "type": str(raw.get("type") or ""),
            "confidence": None,
            "verified": False,
            "reasons": [f"未落笔：{why}"],
            "raw": raw,
        })
    for raw in answered:
        ref = str(raw.get("ref") or "")
        stem = _stem_of(raw)
        if f"{ref}|{stem[:80]}" in failed_keys:
            continue
        reasons: list[str] = []
        confidence = _to_float(raw.get("confidence"))
        if confidence is not None and confidence < _LOW_CONFIDENCE:
            reasons.append(
                f"置信度 {confidence:.2f} 低于落笔门槛 {_LOW_CONFIDENCE:.2f}")
        if raw.get("verified") is False:
            reasons.append("页面回读未确认落笔（verified=false）")
        if not reasons:
            continue
        items.append({
            "source": "answered",
            "ref": ref,
            "stem": stem,
            "answer": raw.get("answer"),
            "type": str(raw.get("type") or ""),
            "confidence": confidence,
            "verified": raw.get("verified"),
            "reasons": reasons,
            "raw": raw,
        })
    return items


# ---------------------------------------------------------------------------
# 元信息
# ---------------------------------------------------------------------------
def _run_meta(run: dict) -> dict:
    meta = run.get("meta") if isinstance(run.get("meta"), dict) else {}
    url = str(meta.get("url") or "").strip()
    site = ""
    if url:
        try:
            site = urlparse(url).hostname or ""
        except Exception:
            site = ""
    model = str(meta.get("model") or "").strip()
    if not model:
        # 新 run 的 meta 里没有模型时，退而求其次：join 出来的缓存条目带 model。
        for item in run.get("answered") or []:
            if isinstance(item, dict) and item.get("model"):
                model = str(item.get("model"))
                break
    return {
        "url": url,
        "site": site,
        "title": str(meta.get("title") or "").strip(),
        "model": model,
        "provider": str(meta.get("provider") or "").strip(),
        "app_version": str(meta.get("app_version") or "").strip(),
        "started_at": str(meta.get("started_at") or "").strip(),
    }


def _submitted_text(run: dict) -> str:
    """是否交卷：true/false 如实写；字段缺失写 unknown（不含糊其辞）。"""
    value = run.get("submitted")
    if value is True:
        return "true"
    if value is False:
        return "false"
    return "unknown"


def _duration_text(run: dict) -> str:
    seconds = _to_float(run.get("seconds"))
    rounds = run.get("rounds")
    parts: list[str] = []
    if seconds is not None:
        parts.append(f"{seconds:.1f} 秒")
    if rounds not in (None, ""):
        try:
            parts.append(f"{int(rounds)} 轮")
        except (TypeError, ValueError):
            pass
    return " · ".join(parts) or _UNKNOWN


# ---------------------------------------------------------------------------
# Markdown 渲染
# ---------------------------------------------------------------------------
def _frontmatter(lines: list[str]) -> list[str]:
    return ["---", *lines, "---", ""]


def _raw_json_block(payload: object, summary: str = "原始 JSON（可回读）") -> list[str]:
    r"""折叠的原始 JSON 块。

    围栏用 **4 个反引号**：JSON 里的简答答案可能包含 ``` 三个反引号，
    3 个反引号的围栏会被提前闭合、把后面整篇结构搞坏。
    """
    try:
        text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
    except Exception:
        text = json.dumps({"_error": "原始记录无法序列化"}, ensure_ascii=False)
    return [
        f"<details><summary>{summary}</summary>",
        "",
        "````json",
        text,
        "````",
        "",
        "</details>",
    ]


def _overview_table(run: dict, review_items: list[dict], index: int) -> list[str]:
    meta = _run_meta(run)
    answered = [x for x in (run.get("answered") or []) if isinstance(x, dict)]
    return [
        "| 项目 | 值 |",
        "|---|---|",
        f"| 导出序号 | 第 {index} 篇 |",
        f"| 记录文件 | `{_cell(run.get('_name') or _UNKNOWN)}` |",
        f"| 站点 | {_cell(_unknown(meta['site']))} |",
        f"| 页面标题 | {_cell(_unknown(meta['title']))} |",
        f"| 网址 | {_cell(_unknown(meta['url']))} |",
        f"| 模型 | {_cell(_unknown(meta['model']))} |",
        f"| 提供方 | {_cell(_unknown(meta['provider']))} |",
        f"| 题数 | 已作答 {len(answered)} 题 · 待复核 {len(review_items)} 题 |",
        f"| 交卷 / 耗时 | {_submitted_text(run)} · {_cell(_duration_text(run))} |",
        f"| 导出时间 | {_now().isoformat(timespec='seconds')} |",
    ]


def _render_answered_item(item: dict, number: int) -> list[str]:
    stem = _strip_leading_number(_stem_of(item)) or "(题干未识别)"
    lines = [f"### {number}. {_heading(stem)}", ""]
    options = [o for o in (item.get("options") or []) if isinstance(o, dict)]
    letters, parsed_ok = _answer_letters(item.get("answer"))
    if options:
        for opt in options:
            key = str(opt.get("key") or "").strip()
            text = str(opt.get("text") or "").strip()
            picked = bool(key) and parsed_ok and any(
                key.lower() == want.lower() for want in letters)
            mark = "  ✅" if picked else ""
            label = f"{key}. " if key else ""
            lines.append(f"- {label}{_inline(text)}{mark}")
        lines.append("")

    raw_answer = str(item.get("answer") if item.get("answer") is not None else "").strip()
    answer_text = _answer_display(item)
    if not raw_answer:
        lines.append("- **答案**：（空）")
    elif len(raw_answer) > _LONG_ANSWER:
        lines.append(
            f"- **答案**：{_inline(_clip(answer_text, 60))}（共 {len(raw_answer)} 字，已折叠，见下）")
    else:
        lines.append(f"- **答案**：{_inline(answer_text or raw_answer)}")
    lines.append(f"- **题型**：{_kind_cn(item.get('type'))}")
    confidence = _to_float(item.get("confidence"))
    if confidence is not None:
        lines.append(f"- **置信度**：{confidence:.2f}")
    reason = str(item.get("reason") or "").strip()
    if reason:
        lines.append(f"- **模型解析**：{_inline(reason)}")
    if item.get("verified") is False:
        lines.append("- **落笔状态**：⚠️ 未确认落笔（该题同时列入「待复核」）")
    if item.get("cache_hit"):
        cache_bits: list[str] = []
        if item.get("model"):
            cache_bits.append(str(item.get("model")))
        if item.get("source"):
            cache_bits.append(f"source={item.get('source')}")
        created = item.get("created_at")
        stamp = ""
        try:
            if created not in (None, ""):
                stamp = datetime.fromtimestamp(float(created)).strftime("%Y-%m-%d %H:%M")
        except (TypeError, ValueError, OSError):
            stamp = ""
        if stamp:
            cache_bits.append(stamp)
        if cache_bits:
            lines.append(f"- **缓存来源**：{' · '.join(cache_bits)}")
    lines.append("")

    if len(raw_answer) > _LONG_ANSWER:
        lines += [
            f"<details><summary>答案（{len(raw_answer)} 字）</summary>",
            "",
            raw_answer,
            "",
            "</details>",
            "",
        ]
    lines += _raw_json_block(item)
    lines.append("")
    return lines


def _render_review_item(item: dict, number: int) -> list[str]:
    stem = _strip_leading_number(item.get("stem") or "") or "(该分支未记录题干，请回看原始 JSON)"
    lines = [f"### {number}. {_heading(stem)}", ""]
    if item.get("source") == "failed":
        lines.append("> [!warning] 待复核 · 未落笔")
        lines.append(_quote_detail("程序答案", _answer_display(item) or "（空）"))
        for reason in item.get("reasons") or []:
            text = str(reason)
            if text.startswith("未落笔："):
                lines.append(_quote_detail("未落笔原因", text[len("未落笔："):]))
            else:
                lines.append(_quote_detail("待复核原因", text))
    else:
        lines.append("> [!question] 待复核 · 已作答但没把握")
        lines.append(_quote_detail("程序答案", _answer_display(item) or "（空）"))
        for reason in item.get("reasons") or []:
            lines.append(_quote_detail("待复核原因", reason))
        confidence = item.get("confidence")
        if confidence is not None:
            lines.append(_quote_detail("置信度", f"{confidence:.2f}"))
        lines.append(_quote_detail("题型", _kind_cn(item.get("type"))))
    if item.get("ref"):
        lines.append(_quote_detail("页面内编号", item.get("ref")))
    lines.append("")
    lines += _raw_json_block(item.get("raw"), "原始 JSON（这一条）")
    lines.append("")
    return lines


def _public_run(run: dict) -> dict:
    """去掉导出器内部字段（`_path` / `_name` / `_ts` / `_note_name`），还原成 run JSON。"""
    return {k: v for k, v in (run or {}).items() if not str(k).startswith("_")}


def render_markdown(run: dict, *, mode: str = "record", index: int = 1) -> str:
    r"""把一条 run 渲染成 Markdown。

    `mode="record"`：全量（已作答 + 待复核）；`mode="review"`：**只导出待复核项**。
    两种模式的概览表和原始记录都保留（方便回读）。
    """
    run = run if isinstance(run, dict) else {}
    mode = "review" if str(mode).lower() == "review" else "record"
    answered = [x for x in (run.get("answered") or []) if isinstance(x, dict)]
    review_items = needs_review_items(run)
    dt = _run_datetime(run)
    meta = _run_meta(run)
    title = f"{NOTE_PREFIX} {dt.strftime('%Y-%m-%d %H:%M')}"
    article = f"{title} · 待复核 {len(review_items)} 题"

    lines: list[str] = []
    lines += _frontmatter([
        f"title: {_yaml_str(article)}",
        f"date: {dt.isoformat(timespec='seconds')}",
        f"source: {_yaml_str(_source_line())}",
        f"site: {_yaml_str(_unknown(meta['site']))}",
        f"url: {_yaml_str(_unknown(meta['url']))}",
        f"model: {_yaml_str(_unknown(meta['model']))}",
        f"provider: {_yaml_str(_unknown(meta['provider']))}",
        f"answered: {len(answered)}",
        f"needs_review: {len(review_items)}",
        f"submitted: {_submitted_text(run)}",
        'tags: ["作答记录", "待复核", "昔涟自习室"]',
    ])
    lines.append(f"# {article}")
    lines.append("")
    lines.append("> 本文件由程序作答记录导出，**不含平台判分结果**。"
                 "「待复核」= 程序没把握或没落笔的题。")
    if mode == "review":
        lines.append(">")
        lines.append("> 本次为「仅待复核」导出：已作答题目的明细没有写进本文件。")
    lines.append("")

    section = 1
    lines.append(f"## {'一二三四五'[section - 1]}、概览")
    lines.append("")
    lines += _overview_table(run, review_items, index)
    lines.append("")
    section += 1

    if mode == "record":
        lines.append(f"## {'一二三四五'[section - 1]}、已作答（{len(answered)} 题）")
        lines.append("")
        if answered:
            for number, item in enumerate(answered, 1):
                lines += _render_answered_item(item, number)
        else:
            lines.append("（本轮没有成功落笔的题目。）")
            lines.append("")
        section += 1

    lines.append(f"## {'一二三四五'[section - 1]}、待复核（{len(review_items)} 题）")
    lines.append("")
    if review_items:
        lines.append("> 这里只列程序**没把握 / 没落笔 / 没确认落笔**的题 —— "
                     "不代表答错，平台判分后请以平台结果为准。")
        lines.append("")
        for number, item in enumerate(review_items, 1):
            lines += _render_review_item(item, number)
    else:
        lines.append("（没有需要复核的题：已作答项都确认落笔，且置信度都达标。）")
        lines.append("")
    section += 1

    lines.append(f"## {'一二三四五'[section - 1]}、原始记录（可回读，勿手改）")
    lines.append("")
    lines += _raw_json_block(_public_run(run), "完整 run JSON（导出器内部字段已剔除）")
    lines.append("")
    return "\n".join(lines)


def render_index(runs: list[dict]) -> str:
    r"""生成 Obsidian 索引页：每份记录一个 `[[文件名]]` 双链。"""
    records = [r for r in (runs or []) if isinstance(r, dict)]
    lines = _frontmatter([
        f"title: {_yaml_str('作答记录索引')}",
        f"date: {_now().isoformat(timespec='seconds')}",
        f"source: {_yaml_str(_source_line())}",
        f"count: {len(records)}",
        'tags: ["作答记录", "索引", "昔涟自习室"]',
    ])
    lines.append("# 作答记录索引")
    lines.append("")
    lines.append("> 本索引由程序自动生成，**不含平台判分结果**。"
                 "点笔记名即可在 Obsidian 中打开。")
    lines.append("")
    lines.append("| 时间 | 站点 | 模型 | 已作答 | 待复核 | 交卷 | 笔记 |")
    lines.append("|---|---|---|---|---|---|---|")
    for run in reversed(records):                  # 最新在前
        dt = _run_datetime(run)
        meta = _run_meta(run)
        answered = [x for x in (run.get("answered") or []) if isinstance(x, dict)]
        review_items = needs_review_items(run)
        note_name = str(run.get("_note_name") or "").strip()
        if not note_name:
            # 单独调用 render_index()（没经过 export_all）时也能给出可用双链：
            # 按 run 的时间推一个和导出文件名同构的名字。
            note_name = f"{NOTE_PREFIX}-{dt.strftime('%Y%m%d-%H%M%S')}"
        link = f"[[{note_name}]]"
        lines.append(
            f"| {dt.strftime('%Y-%m-%d %H:%M')} | {_cell(_unknown(meta['site']))} "
            f"| {_cell(_unknown(meta['model']))} | {len(answered)} | {len(review_items)} "
            f"| {_submitted_text(run)} | {link} |")
    lines.append("")
    lines.append(f"<!-- 由 notebook.py 生成，共 {len(records)} 份记录 -->")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 批量导出
# ---------------------------------------------------------------------------
def _note_name_for(run: dict, used: set[str], out_dir: Path) -> str:
    r"""`作答记录-YYYYmmdd-HHMMSS.md`。

    同一秒内重复导出、或 record / review 两种模式先后导出时会撞名 ——
    追加 `-2` / `-3`，**绝不覆盖**上一次导出的笔记（笔记可能被用户手动补过内容）。
    """
    stamp = _run_datetime(run).strftime("%Y%m%d-%H%M%S")
    name = f"{NOTE_PREFIX}-{stamp}.md"
    seq = 1
    while name in used or (out_dir / name).exists():
        seq += 1
        name = f"{NOTE_PREFIX}-{stamp}-{seq}.md"
    used.add(name)
    return name


def export_all(out_dir: str | Path | None = None, *,
               runs_dir: str | Path | None = None,
               cache_path: str | Path | None = None,
               mode: str = "record") -> dict:
    r"""把 `out\\runs\\` 下所有记录导出成 Markdown（一跑一个文件 + 一个索引页）。

    返回（成功）：

    ```python
    {"ok": True, "dir": "…\\out\\notes",
     "files": [{"path": "…", "questions": 3, "needs_review": 2}, …],
     "total_questions": 4, "warnings": [...], "mode": "record", "index": "…"}
    ```

    - `questions` = 该文件**正文里实际写了多少条**（record=已作答数，review=待复核数）；
      `total_questions` = 所有文件的 `questions` 之和。
    - 失败（目录建不出来 / 一条都写不出 / 没有可导出记录）：

      ```python
      {"ok": False, "error": "…", "dir": "…", "files": [], "total_questions": 0,
       "warnings": [...]}
      ```

    - review 模式下没有待复核项的 run 不写空文件；若所有 run 都没有待复核项，
      返回 `ok=False`（诚实告诉用户"没有需要复核的题"，而不是伪造一份空文件）。
    """
    warnings: list[str] = []
    mode = "review" if str(mode).lower() == "review" else "record"
    runs = scan_runs(runs_dir, warnings)
    cache = load_cache(cache_path)
    out = Path(out_dir) if out_dir else (config.OUT_DIR / NOTES_DIRNAME)
    try:
        out.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        return {"ok": False, "error": f"无法创建导出目录 {out}：{exc}",
                "dir": str(out), "files": [], "total_questions": 0,
                "warnings": warnings, "mode": mode}

    if not runs:
        return {"ok": False,
                "error": "没有找到可导出的作答记录（out\\runs 下没有有效的 run_*.json）",
                "dir": str(out), "files": [], "total_questions": 0,
                "warnings": warnings, "mode": mode}

    files: list[dict] = []
    exported_runs: list[dict] = []
    used_names: set[str] = set()
    total_questions = 0
    skipped_clean = 0
    for index, run in enumerate(runs, 1):
        joined = join_cache(run, cache)
        review_items = needs_review_items(joined)
        answered = [x for x in (joined.get("answered") or []) if isinstance(x, dict)]
        if mode == "review" and not review_items:
            skipped_clean += 1                  # 没待复核项的 run 不写空笔记
            continue
        name = _note_name_for(run, used_names, out)
        path = out / name
        try:
            text = render_markdown(joined, mode=mode, index=index)
            path.write_text(text, encoding="utf-8")
        except Exception as exc:
            warnings.append(f"导出 {run.get('_name') or name} 失败：{type(exc).__name__}: {exc}")
            used_names.discard(name)
            continue
        questions = len(review_items) if mode == "review" else len(answered)
        files.append({"path": str(path), "questions": questions,
                      "needs_review": len(review_items)})
        total_questions += questions
        run["_note_name"] = path.stem
        exported_runs.append(run)

    if skipped_clean:
        warnings.append(f"已跳过 {skipped_clean} 份没有待复核项的记录（review 模式）")
    if not files:
        hint = ("没有需要复核的题：所有记录都已确认落笔且置信度达标"
                if mode == "review" else "所有记录都没能写出（详见 warnings）")
        return {"ok": False, "error": f"导出未完成：{hint}",
                "dir": str(out), "files": [], "total_questions": 0,
                "warnings": warnings, "mode": mode}

    index_path = out / INDEX_NAME
    try:
        index_path.write_text(render_index(exported_runs), encoding="utf-8")
    except Exception as exc:
        warnings.append(f"索引页写入失败：{type(exc).__name__}: {exc}")

    return {
        "ok": True,
        "dir": str(out),
        "files": files,
        "total_questions": total_questions,
        "warnings": warnings,
        "mode": mode,
        "index": str(index_path),
    }


# ---------------------------------------------------------------------------
# 命令行：python -m dsh_solver.notebook --mode record --out out\notes
# ---------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m dsh_solver.notebook",
        description="把 out\\runs\\run_*.json 导出成 Markdown 作答记录"
                    "（只读运行记录，不联网、不调模型）。")
    parser.add_argument("--mode", choices=["record", "review"], default="record",
                        help="record=全部作答 + 待复核（默认）；review=只导出待复核")
    parser.add_argument("--out", default="",
                        help=f"输出目录（默认 <out>\\{NOTES_DIRNAME}）")
    parser.add_argument("--runs", default="", help="runs 目录（默认 <out>\\runs）")
    parser.add_argument("--cache", default="",
                        help="answer_cache.json 路径（默认 <out>\\answer_cache.json）")
    args = parser.parse_args(argv)

    result = export_all(args.out or None,
                        runs_dir=args.runs or None,
                        cache_path=args.cache or None,
                        mode=args.mode)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    for warning in result.get("warnings") or []:
        print(f"  - {warning}")
    if result.get("ok"):
        print(f"已导出 {len(result.get('files') or [])} 篇 -> {result.get('dir')}")
        return 0
    print(f"导出失败：{result.get('error')}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
