r"""独立版入口：把 app 目录加入模块搜索路径，然后启动本地服务。

打包后的目录结构：
    昔涟自习室\
      ├─ 昔涟自习室.exe            双击这个
      ├─ runtime\           嵌入式 Python + 依赖（自带，不用装 Python）
      ├─ app\               dsh_solver 包 + web 前端 + 本文件
      ├─ 截图\              网页截图（位置可在设置里改）
      └─ out\               运行记录 / app_config.json / 登录档案

说明文档**只在界面里** —— 左栏「使用方式」那一页就是完整教程。
这样内容永远跟版本一致，不会出现"外面那份是旧的"。目录里不再放任何 txt。

（这个 docstring 用了 r 前缀：路径里的 \r \a 之类会被当成转义序列。）
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

# ⚠ 禁止写 .pyc 字节码缓存。
#
# 为什么要专门做这件事：
#   嵌入式 Python 会把 `runtime\Lib\site-packages\sitecustomize.py` 编译成
#   `__pycache__\sitecustomize.cpython-312.pyc`。也就是说 ——
#   **用户每运行一次，软件目录里就会多出 __pycache__ 文件夹**。
#   对一个"拷贝即用"的便携软件来说，这会让目录越来越乱，
#   用户也会疑惑"这些多出来的东西是什么、能不能删"。
#
#   必须在**导入任何自己的模块之前**设置，否则 sitecustomize 已经缓存过了。
#   代价：每次启动多解析一遍源码（这个体量下是毫秒级，感知不到）。
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True


def main() -> int:
    root = APP_DIR.parent
    # 运行数据统一放在程序目录下的 out\，便携、好找
    os.environ.setdefault("DSHS_OUT_DIR", str(root / "out"))
    # 临时目录也放程序目录里：受限环境（公司策略/沙箱）下系统 TEMP 可能不可写，
    # 而 Playwright 启动浏览器必须能建临时目录。
    os.environ.setdefault("DSHS_TMP_DIR", str(root / "out" / "tmp"))
    # 浏览器档案也要放 out\ 里 —— 否则默认会建到 app\.chrome-profile，
    # 把程序目录撑大，而且用户备份 out\ 时会漏掉登录状态。
    os.environ.setdefault("DSHS_PROFILE_DIR", str(root / "out" / "browser-profile"))
    # 截图放**软件根目录**下的「截图」文件夹，不要埋在 app\ 里。
    # （config.PROJECT_DIR 在独立版里指的是 app\，所以必须显式指定。）
    os.environ.setdefault("DSHS_SHOT_DIR", str(root / "截图"))

    # ★ 先把上次下好的更新换上去 —— **必须在 import dsh_solver 之前**。
    #   否则 dsh_solver 包按旧路径进了 sys.modules，目录换完了跑的仍是旧代码。
    #   失败只写 out\updates\update.log，绝不挡住启动：打不开比版本旧严重得多。
    try:
        import bootstrap_update
        bootstrap_update.apply_pending(APP_DIR)
    except Exception:
        pass

    # ★ 先把开屏动画弹出来，再干重活。
    #
    # 从双击图标到界面出现之间：启动器找浏览器/起 python → python 起服务 →
    # 启动器用 Edge 的 --app 开窗口 → 页面加载。**真正慢的是两头**
    # （启动器自己的准备 + Edge 冷启动，常常 2~5 秒），那几秒屏幕上什么都没有，
    # 用户看到的就是"点了没反应"。所以这里尽量早地弹一个原生小窗口出来，
    # 等页面自己报"我加载好了"再关掉（见 app_server 的 /api/ready）。
    #
    # 放在 import app_server **之前**：那一步还要 0.2~0.3 秒，能省一点是一点。
    try:
        from dsh_solver import splash
        splash.start()
    except Exception:
        pass                                # 开屏动画坏了绝不能影响启动

    try:
        from dsh_solver.app_server import main as server_main
    except Exception as e:
        try:
            from dsh_solver import splash as _sp
            _sp.request_close()
        except Exception:
            pass
        print("\n  [启动失败] 载入程序模块出错：")
        print(f"    {type(e).__name__}: {e}\n")
        import traceback
        traceback.print_exc()
        return 1

    return server_main()


if __name__ == "__main__":
    raise SystemExit(main())
