"""启动前把暂存的新版本换到 `app\\` 上（昔涟自习室）。

为什么单独一个文件、而且不 import `dsh_solver`：
  `server.py` 必须在**导入任何 dsh_solver 模块之前**跑完这一步。
  否则包已经按旧路径进了 sys.modules / sys.path，目录换完了，跑的还是旧代码。

流程（全部是本地文件操作，不联网）：
  1. 读 out\\updates\\pending.json（update.py 下载并解压后写的）
  2. 校验暂存目录在 out\\updates 之内、build 号对得上、server.py 在
  3. app → app.old（旧的挪开，留作回滚）
  4. out\\updates\\staged\\<build>\\app → app
  5. 成功写 last.json、删 pending；失败自动把 app.old 换回去

任何异常都只写日志、不抛给启动流程 —— 更新坏了绝不能连累软件打不开。
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

LOG_NAME = "update.log"


def _log(out_dir: Path, text: str) -> None:
    try:
        upd = out_dir / "updates"
        upd.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(upd / LOG_NAME, "a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {text}\n")
    except Exception:
        pass


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def apply_pending(app_dir: str | Path, out_dir: str | Path | None = None) -> str | None:
    """有暂存更新就换上去，返回新 build 号；没有/失败返回 None。"""
    app_dir = Path(app_dir).resolve()
    if out_dir is None:
        out_dir = Path(os.environ.get("DSHS_OUT_DIR") or (app_dir.parent / "out"))
    out_dir = Path(out_dir).resolve()
    upd = out_dir / "updates"

    pending = _read_json(upd / "pending.json")
    if not pending:
        return None

    build = str(pending.get("build") or "")
    try:
        staged = Path(str(pending.get("staged") or "")).resolve()
    except Exception:
        staged = Path("")

    # ---- 校验 ----
    try:
        staged.relative_to(upd.resolve())
    except Exception:
        _log(out_dir, f"放弃：暂存路径越界 {staged}")
        _drop_pending(upd)
        return None

    if not build or not staged.is_dir() or not (staged / "server.py").is_file():
        _log(out_dir, f"放弃：暂存目录不完整（build={build!r}，{staged}）")
        _drop_pending(upd)
        return None

    info = _read_json(staged / "build.json")
    if str(info.get("build") or "") != build:
        _log(out_dir, f"放弃：暂存 build 号不符（{info.get('build')!r} != {build!r}）")
        _drop_pending(upd)
        return None

    old_build = str(_read_json(app_dir / "build.json").get("build") or "")
    if old_build == build:
        _log(out_dir, f"跳过：已经是 {build}")
        _drop_pending(upd)
        return None

    # ---- 换目录（带回滚） ----
    bak = app_dir.with_name(app_dir.name + ".old")
    try:
        if bak.exists():
            shutil.rmtree(bak)
        os.rename(app_dir, bak)
    except Exception as e:  # 旧目录挪不开（被占用/权限），本次放弃，下次启动再试
        _log(out_dir, f"备份旧版本失败：{type(e).__name__}: {e}（保留 pending，下次再试）")
        return None

    try:
        shutil.move(str(staged), str(app_dir))
    except Exception as e:
        _log(out_dir, f"替换失败：{type(e).__name__}: {e}，开始回滚")
        try:
            if app_dir.exists():
                shutil.rmtree(app_dir)
            os.rename(bak, app_dir)
            _log(out_dir, "回滚完成，仍是旧版本")
        except Exception as e2:
            _log(out_dir, f"⚠ 回滚也失败：{type(e2).__name__}: {e2}；"
                          f"旧版本在 {bak}")
        return None

    # ---- 成功 ----
    _write_json(upd / "last.json", {
        "build": build, "from": old_build, "at": time.time(),
    })
    _log(out_dir, f"更新完成：{old_build or '未知'} → {build}")
    _drop_pending(upd)
    # 暂存和下载缓存都不必留着（回滚靠 app.old）
    shutil.rmtree(upd / "staged", ignore_errors=True)
    shutil.rmtree(upd / "download", ignore_errors=True)
    return build


def _drop_pending(upd: Path) -> None:
    try:
        (upd / "pending.json").unlink()
    except Exception:
        pass
    shutil.rmtree(upd / "staged", ignore_errors=True)