"""答题引擎：把"网页结构 / 屏幕画面"翻译成"模型的判断"，再翻译成"键鼠动作"。

两种模式：
  WebMode  —— Playwright 读 DOM → 文本作答 → 精准落笔（主力，快且准）
  PcMode   —— 截屏 → 视觉模型选动作 → 真键鼠执行（兜底，任何界面都能用）

两者共用同一个"停止开关"和同一份作答记忆，避免重复劳动。
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import config
from .browser import BrowserDriver, PageState, Question
from .desktop import Desktop

LogFn = Callable[[str], None]
StatusFn = Callable[[str], None]
ShotFn = Callable[[Path], None]
AskFn = Callable[[str], bool]           # 人工确认（GUI 里弹窗）
AnswerFn = Callable[[str, str], None]   # 记录最终答案（题干, 答案）


class PageStructureAbort(Exception):
    r"""页面结构与预期不符（例如选项被拆成多个部分），主动中止本轮作答。

    为什么不能用 Stopped：`Stopped` 的语义是**用户**要停 → 不交卷、不收尾。
    而这里是**程序**判断"继续磨也没意义"，必须**照常收尾**
    （截图、小结、按设置交卷）。用错了的后果很荒唐：
    实测明明点中了 17 道，报告里却是 "answered": []、页面也不交卷，
    用户看到的就是"答了却报 0 道、也不结束"。
    """


class Stopped(RuntimeError):
    """用户点了停止。"""


class StopFlag:
    def __init__(self) -> None:
        self._e = threading.Event()

    def set(self) -> None:
        self._e.set()

    def clear(self) -> None:
        self._e.clear()

    def check(self) -> None:
        if self._e.is_set():
            raise Stopped()

    @property
    def stopped(self) -> bool:
        return self._e.is_set()

    def sleep(self, sec: float, step: float = 0.1) -> None:
        end = time.time() + sec
        while time.time() < end:
            self.check()
            time.sleep(min(step, max(0.0, end - time.time())))


# ---------------------------------------------------------------------------
# 这段会随**每一次**请求重发，所以刻意写得紧凑（原来 464 字符 ≈302 token，
# 一次作业几十道题就是上万 token 的纯重复开销）。约束一条没少，只是去掉了
# 客套话和重复表述 —— 精简后约 200 字符 ≈130 token。
SYSTEM_PROMPT = """答题助手。只输出 JSON，无 markdown、无解释文字。
每题必答，不许漏；id 必须用题目给的（q0/f1），不要重新编号。
单选 answer 为单个字母；多选为字母数组；判断为"对"或"错"。
填空（题面含"填空题"）：只给该空要填的词/短语（≤15 字），不要解释、不要写整段；
多个空用"；"分隔；题面标了"第N空"就只填那一个空。
简答/论述（题面含"简答/论述/分析/谈谈/不少于N字"）：80~300 字，可分点。
confidence 给 0~1 的实数（不确定就低分）。reason ≤20 字。
看不清或缺少必要信息时，confidence 压到 0.3 以下并在 reason 说明。
直接给答案，不要长篇推导（会被 token 上限截断）。"""


# 也压缩过：原来 214 字符，现在约 120。
ANSWER_SCHEMA_HINT = """输出：{"answers":[{"id":"q0","answer":"B","reason":"...","confidence":0.95}]}
多选 answer 示例 ["A","C"]，填空示例 "半结构化数据"（只填一个空）。
简答/论述示例 {"id":"f0","answer":"第一，……；第二，……","confidence":0.8}"""


# ---------------------------------------------------------------------------
class AnswerCache:
    """按"题干 + 选项"缓存答案，同一道题重跑时不再问模型。

    对"反复刷同一套题"的场景提速极其明显（第二次几乎瞬时），
    也让网络抖动/模型偶发抽风时结果更稳定。

    刻意不用题干文字做 key 的全部：题干里的题号（"第 3 题"）会变，
    去掉开头的序号再哈希，命中率更高。选项也参与 key，
    避免"同题干不同选项"被错误复用。
    """

    def __init__(self, path: Path, enabled: bool = True) -> None:
        self.path = path
        self.enabled = enabled
        self.data: dict[str, dict] = {}
        self.hits = 0
        # 加载时**丢掉低置信度的旧条目**，返回丢掉几条。
        #
        # ⚠ 为什么要清（2026-10-17 15:36 实测）：
        #   缓存里躺着一条 `confidence=0.30` 的答案（题干是字体加密后的乱码），
        #   于是第二道题**直接命中缓存、根本没问模型** —— 明明这一轮已经把
        #   整页截图送到模型手里了，却用了一条旧的瞎猜结果。
        #   而 `QUIZ_MIN_CONFIDENCE`（默认 0.35）意味着这种答案**现在根本不允许落笔**，
        #   那它也不该留在缓存里冒充"知识"。
        self.purged = 0
        if enabled:
            try:
                if path.exists():
                    raw = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(raw, dict):
                        self.data = raw
            except Exception:
                self.data = {}
            self._purge_weak()

    def _purge_weak(self) -> None:
        """丢掉置信度低于"落笔门槛"的旧缓存条目。"""
        try:
            floor = float(getattr(config, "QUIZ_MIN_CONFIDENCE", 0.35))
        except Exception:
            floor = 0.35
        keep: dict[str, dict] = {}
        for k, v in (self.data or {}).items():
            try:
                conf = float((v or {}).get("confidence") or 0.0)
            except Exception:
                conf = 0.0
            if conf >= floor:
                keep[k] = v
        self.purged = len(self.data or {}) - len(keep)
        self.data = keep

    @staticmethod
    def _norm(text: str) -> str:
        t = re.sub(r"^\s*[（(]?\s*\d{1,3}\s*[)）.、．]\s*", "", (text or "").strip())
        return re.sub(r"\s+", " ", t)[:300]

    @classmethod
    def key_for(cls, stem: str, options: list[dict] | None = None,
                label: str = "") -> str:
        parts = [cls._norm(stem or label)]
        if options:
            parts += [str(o.get("text", ""))[:80] for o in options]
        return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:20]

    def get(self, key: str) -> dict | None:
        if not self.enabled:
            return None
        v = self.data.get(key)
        if v:
            self.hits += 1
        return v

    def put(self, key: str, answer: Any, reason: str = "", confidence: float = 0.0,
            *, stem: str = "", options: list[dict] | None = None,
            qtype: str = "", model: str = "", source: str = "model") -> None:
        """写一条缓存。

        ★ 2026-10-22 起条目自带题干/选项/题型/模型/时间（schema v2）：
          旧版只存 answer/reason/confidence，出问题时只有一个 20 位哈希，
          既看不出它对应哪道题，也没法在复核台展示原始题干。
          新字段是**纯新增**，旧缓存照常能读；旧条目没有 schema 字段，
          需要时按 v1 处理即可。
        """
        if not self.enabled:
            return
        opts: list[dict] = []
        for o in (options or [])[:8]:
            if isinstance(o, dict):
                opts.append({"key": str(o.get("key", ""))[:4],
                             "text": str(o.get("text", ""))[:200]})
        self.data[key] = {
            "schema": 2,
            "answer": answer,
            "reason": reason[:120],
            "confidence": confidence,
            "stem": str(stem or "")[:600],
            "options": opts,
            "qtype": str(qtype or "")[:16],
            "model": str(model or "")[:64],
            "created_at": round(time.time(), 3),
            "source": str(source or "model")[:16],
        }

    def save(self) -> None:
        if not self.enabled or not self.data:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(
                json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass


@dataclass
class Decision:
    id: str
    answer: Any
    reason: str = ""
    confidence: float = 0.0


@dataclass
class Attempt:
    ref: str
    kind: str          # radio / checkbox / select / text / textarea
    stem: str
    answer: str        # 人类可读形式（"B" / ["A","C"] / "42"）
    confidence: float = 0.0
    # ★ 2026-10-22 新增（可选、向后兼容）：选项原文。
    #
    #   为什么加：`out/runs/*.json` 是「本地题库」唯一的冷启动数据源，
    #   但原来只记了截断到 160 字的 stem、**完全没有选项** ——
    #   没有选项就没法算「选项集合指纹」，也就没法判"同题不同选项"。
    #   形如 [{"key": "A", "text": "从1840年…"}, …]。
    #   老代码不传这个参数照样能跑（默认 None）。
    options: list[dict] | None = None
    # ★ 2026-10-22 新增：模型给的一句话解析。
    #
    #   `ANSWER_SCHEMA_HINT` 一直都要求模型返回 reason，`Decision` 也一直带着，
    #   但存 Attempt 时**把它丢了** —— 于是界面只能显示字母。
    #   这件方案 S4 说的就是这回事：「schema 里有 reason，界面不展示」。
    reason: str = ""


# ---------------------------------------------------------------------------
# 「多道题共用同一个题干」的护栏（纯逻辑，可脱浏览器单测）。
#
# 2026-10-23 真机：一页 4 道填空题，4 个空格里被写进**同一段**话
# （"该段代码用于在视频任务点完成后……"）。机制是：
#   ① 题干抽取失败 → 4 道题拿到同一个 stem（甚至是页面脚本源码）；
#   ② `AnswerCache.key_for()` 只吃 stem(+label) → 4 道算出**同一个缓存键**；
#   ③ 第一道拿到答案写进缓存，后三道直接命中 → 抄了同一份。
#
# 这里做两件事（都是"少做"，不会让原本能答的题变不能答）：
#   · 同题干 → 禁止走缓存（各问各的）；
#   · 同题干 + 答案是长文本 + 不是简答/论述 → **不落笔**，留给人工。
#     理由：填空题的答案是一个词/一句话，40 字以上的"填空答案"几乎必然是
#     模型在解释某段它看到的文字，而这类错误一旦落笔就是 4 个格子全错。
# ---------------------------------------------------------------------------
def _stem_fingerprint(text: str) -> str:
    """题干指纹：去掉所有空白，避免"排版差异"把同一段话算成两道题。"""
    return re.sub(r"\s+", "", str(text or ""))


# 「第1空：准；第2空：快」这种标记 —— 模型给多空填空题时最常这么写。
_BLANK_MARK_RE = re.compile(r"第\s*(\d{1,2})\s*空\s*[:：]?\s*")


def split_blank_answer(text: object, total: int) -> list[str]:
    r"""把一段答案拆成 `total` 个空各自的内容；拆不出来返回 `[]`。

    顺序：① 按「第N空：X」标记切 → ② 按分号/顿号切。

    ★ 返回 `[]` 是**有意**的设计：调用方必须据此"不落笔"，
      绝不能把整段话抄进每一个格子 —— 2026-11-04 真机就是这么错的
      （4 个空各写进同一段 300 字解释）。
    """
    t = str(text or "").strip()
    if not t or total < 2:
        return []
    marks = list(_BLANK_MARK_RE.finditer(t))
    if len(marks) >= 2:
        got: dict[int, str] = {}
        for i, m in enumerate(marks):
            end = marks[i + 1].start() if i + 1 < len(marks) else len(t)
            seg = t[m.end():end]
            seg = re.split(r"[。\n]", seg)[0].strip(" \t；;、,，。:：")
            k = int(m.group(1))
            if 1 <= k <= total and seg:
                got.setdefault(k, seg)
        if len(got) == total:
            return [got[i + 1] for i in range(total)]
    parts = [p.strip(" \t；;、,，。") for p in re.split(r"[；;、]", t)]
    parts = [p for p in parts if p]
    if len(parts) == total:
        return parts
    return []


def dup_answer_guard(obj: object, value: object) -> str:
    r"""同题干的长答案要不要拒绝落笔。返回理由（空串 = 允许落笔）。

    ⚠ 只在对象被 `_mark_dup_stems()` 打过标记时生效 —— 单独的题不受影响。
    """
    if not getattr(obj, "_dsh_dup_stem", False):
        return ""
    if getattr(obj, "essay", False) or str(getattr(obj, "kind", "")) == "essay":
        return ""            # 简答/论述本来就该是长文本
    v = str(value or "")
    if len(v) < 40:
        return ""
    return f"题干与其他题重复，且答案有 {len(v)} 字（不像填空答案）"


@dataclass
class SessionResult:
    ok: bool = False
    answered: list[dict] = field(default_factory=list)
    failed: list[dict] = field(default_factory=list)
    rounds: int = 0
    seconds: float = 0.0
    error: str = ""
    # ★ 提交到底成没成。**必须如实填** —— 调用方（网课的章节测验）
    #   要靠它说"已交卷"还是"已填好、未交卷"。原来只看开关，
    #   于是日志里明明写着"三次尝试都没能确认提交成功"，
    #   报告却照样说"（已交卷）"—— 那是在骗用户。
    submitted: bool = False
    # ★ 2026-10-23 新增（纯新增字段，老消费者忽略即可）：
    #   本次运行的环境元信息 url / title / model / provider / app_version / started_at。
    #   为什么加：`out\runs\run_*.json` 原来只有文件名的秒级时间戳 ——
    #   导出成笔记或做本地题库时，回答不了"这是哪个站/哪门课/用的哪个模型"。
    #   全部在 `run_web()` 里 try/except 填充，取不到就留空，绝不影响作答主流程。
    meta: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# 逐帧点提交用的文字判据（和浏览器扫描那边的关键词保持同源）
_SUBMIT_WORD_SRC = r"提交|交卷|确定提交|保存并提交|submit|finish"

# 交卷时的「确认提交」二次确认框。
#
# 用户 2026-10-17 反馈：点了「提交」之后还会弹出确认框，
# 不点它 `_submit_succeeded()` 就判定"页面没有变化"。
#
# 判据：优先在**对话框容器**里找（.el-message-box / .ant-modal / [role=dialog] …），
# 找不到容器时只在文字**明确是确认类**（确认/确定/是的）时才点 ——
# 绝不能把原来那个「提交」再点一遍（可能重复提交）。
_CONFIRM_DIALOG_JS = r"""
(reSrc) => {
  const re = new RegExp(reSrc);
  // 取消类文字 —— 用来证明"这是一层对话框"（同层有取消才算）
  const CANCEL = /^(取消|关闭|×|x|X|返回|暂不|再想想)$/;
  function txt(e) {
    return (e.innerText || e.textContent || '').replace(/\s+/g, '').trim();
  }
  function vis(e) {
    try {
      const s = getComputedStyle(e);
      const r = e.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden'
        && parseFloat(s.opacity || '1') > 0.05
        && r.width > 2 && r.height > 2;
    } catch (err) { return false; }
  }
  // ★ 命中测试：此刻这个坐标真的能点到它吗？
  //   被遮罩盖住的背景按钮在这一步就被干掉。
  function hit(e) {
    try {
      const r = e.getBoundingClientRect();
      const x = r.left + Math.min(r.width / 2, 6);
      const y = r.top + Math.min(r.height / 2, 6);
      const t = document.elementFromPoint(x, y);
      return !!t && (t === e || e.contains(t));
    } catch (err) { return false; }
  }
  // ★ 往上 4 层内必须有一个「取消/关闭」—— 证明这是对话框，
  //   而不是页面上那个主「提交」按钮。这是"不重复交卷"的保证。
  function inDialog(e) {
    let n = e.parentElement, hop = 0;
    while (n && hop < 4) {
      const t = txt(n);
      if (t.length > 80) break;              // 太大就不是弹层了
      let kids = [];
      try { kids = n.querySelectorAll('span,a,button,div'); } catch (err) { kids = []; }
      for (const c of kids) {
        if (c !== e && vis(c) && CANCEL.test(txt(c))) return true;
      }
      n = n.parentElement; hop++;
    }
    return false;
  }

  // ⚠⚠ 不再"先找一个弹层容器、再往里找按钮"。
  //
  //   2026-10-17 16:26 的日志把两件事对照得很清楚：
  //     · 打现场的（遍历所有容器、跳过空文字的）能认出框：
  //         对话框[1] 提示 确认提交？ 提交 取消
  //     · `_confirm_dialog()` 认不出 —— 它只看**第一个可见的**匹配元素，
  //       而学习通那个框是「遮罩 popMask 在前、popBox 在后」，
  //       遮罩也可见、也没文字 → 被选中 → 里面一个按钮都没有 → 返回空串。
  //
  //   现在从**按钮**出发：可见 → 文字对 → 命中测试 → 同层有取消 → 取最深。
  const SEL = 'button,a,span,div,input[type=button],input[type=submit],[role=button]';
  let best = null, bestDepth = -1;
  for (const e of document.querySelectorAll(SEL)) {
    if (!vis(e)) continue;
    const t = txt(e);
    if (!t || t.length > 8) continue;
    if (!re.test(t)) continue;
    if (!hit(e)) continue;                   // 被遮罩盖住的不要
    if (!inDialog(e)) continue;              // 不是对话框里的按钮不要
    let d = 0, n = e;
    while ((n = n.parentElement)) d++;       // 取最深的（按钮本体，不是容器）
    if (d > bestDepth) { bestDepth = d; best = e; }
  }
  if (!best) return null;
  const r = best.getBoundingClientRect();
  const opt = {
    bubbles: true, cancelable: true, view: window,
    clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
  };
  ['pointerover', 'pointerenter', 'pointerdown', 'mousedown',
   'pointerup', 'mouseup', 'click'].forEach(function (ty) {
    try {
      const ev = (ty.indexOf('pointer') === 0 && typeof PointerEvent === 'function')
        ? new PointerEvent(ty, opt) : new MouseEvent(ty, opt);
      best.dispatchEvent(ev);
    } catch (e) {}
  });
  // ⚠ 不再补 best.click()：上面派发的 click 事件本身就会触发监听器，
  //   再调一次 = 点两次（自测实测计数是 2）。
  //   合成事件没生效时，调用方会用真实鼠标再点一次（`_click_confirm`）。
  return {text: txt(best), x: r.left + r.width / 2, y: r.top + r.height / 2,
          tag: String(best.tagName || '').toLowerCase()};
}
"""

_SUBMIT_ANYWHERE_JS = r"""
(reSrc) => {
  let re;
  try { re = new RegExp(reSrc, 'i'); } catch (e) { return ''; }
  const SEL = 'button,a,div,span,input[type=submit],input[type=button],.btn';
  const hits = [];
  document.querySelectorAll(SEL).forEach(function (e) {
    const t = (e.innerText || e.textContent || e.value || '')
      .replace(/\s+/g, ' ').trim();
    if (!t || t.length > 16) return;          // 「提交」这种按钮文字都很短
    if (!re.test(t)) return;
    if (e.disabled) return;
    const r = e.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return;
    const s = getComputedStyle(e);
    if (s.display === 'none' || s.visibility === 'hidden') return;
    if (parseFloat(s.opacity || '1') <= 0.05) return;
    // 排除"提交记录 / 提交时间"这类说明文字
    if (/记录|时间|列表|详情/.test(t)) return;
    hits.push(e);
  });
  if (!hits.length) return '';
  const e = hits[hits.length - 1];
  try { e.scrollIntoView({ block: 'center' }); } catch (err) {}
  const opts = { bubbles: true, cancelable: true, view: window };
  ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (k) {
    try {
      if (k.indexOf('mouse') === 0) {
        e.dispatchEvent(new MouseEvent(k, opts));
      } else if (typeof PointerEvent === 'function') {
        e.dispatchEvent(new PointerEvent(k, opts));
      }
    } catch (err) {}
  });
  try { e.click(); } catch (err) {}
  return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 20);
}
"""


class SolverAgent:
    def __init__(
        self,
        client,
        *,
        log: LogFn = print,
        status: StatusFn | None = None,
        on_shot: ShotFn | None = None,
        ask_user: AskFn | None = None,
        on_answer: AnswerFn | None = None,
        auto_submit: bool = False,
        dry_run: bool = False,
        batch_size: int | None = None,
        max_rounds: int | None = None,
        auto_next: bool = True,
        max_pages: int | None = None,
        use_cache: bool | None = None,
    ) -> None:
        self.client = client
        self.log = log
        self.status = status or (lambda s: None)
        self.on_shot = on_shot or (lambda p: None)
        self.ask_user = ask_user
        self.on_answer = on_answer or (lambda q, a: None)
        # None = 还没判断过；True/False = 回调接不接受 reason/confidence
        self._ans_detail: bool | None = None
        self.auto_submit = auto_submit
        self.dry_run = dry_run
        self.batch_size = batch_size or config.BATCH_SIZE
        self.max_rounds = max_rounds or config.MAX_ROUNDS
        self.auto_next = auto_next
        self.max_pages = max_pages or config.MAX_PAGES
        self.stop = StopFlag()
        self.driver: BrowserDriver | None = None
        # attempts 是"当前这一页"的作答状态，翻页会清空（题号体系变了）。
        # history 是跨页的完整记录，用于最终汇报 —— 逐题分页的作业一页一题，
        # 只看 attempts 会得到"落笔 1 次"这种误导性结论。
        self.attempts: dict[str, Attempt] = {}
        self.history: list[Attempt] = []
        self.vision_used = 0
        # 「字体加密」页的整页截图（见 `_web_loop`）。None = 这一页没加密。
        # 加密只改 DOM 文字，屏幕显示是对的 —— 所以截图就是真答案。
        self._obf_shot = None
        # 整页太长时会被切成几张（每张 ≤1600px），这里存全部
        self._obf_shots = []
        # 这一页是不是被平台做了字体加密（决定"拿不到图就别猜"）
        self._obf_page = False
        # 答案缓存：同一道题（题干+选项相同）重跑时直接复用，不再问模型。
        # 对"反复刷同一套题"提速极明显，也让偶发的模型抽风不影响第二次结果。
        enabled = config.USE_ANSWER_CACHE if use_cache is None else use_cache
        self.cache = AnswerCache(config.OUT_DIR / "answer_cache.json", enabled=enabled)

    # ================================================================ 工具
    def _answer_questions(self, state: PageState) -> list[Decision]:
        """把一页题目切成小批，逐批问模型。小批 = 准确率。"""
        items: list[tuple[str, object]] = []
        items += [(f"q{q.qid}", q) for q in state.questions]
        items += [(f"f{f.fid}", f) for f in state.fields]
        # 已经答过的就不再问
        items = [(ref, obj) for ref, obj in items if ref not in self.attempts]
        if not items:
            return []

        # ★ 同一页里"题干完全相同"的填空题：先打标记（见文件头的说明）。
        #   必须在分批之前做 —— 缓存判断在 `_ask_batch` 里、落笔判断在
        #   `_apply_decisions` 里，两处都要看到这个标记。
        self._mark_dup_stems(state)

        decisions: list[Decision] = []
        b = max(1, self.batch_size)
        _t0 = time.time()
        for i in range(0, len(items), b):
            self.stop.check()
            chunk = items[i : i + b]
            self.status(f"LM Studio 正在作答 {i + 1}-{i + len(chunk)} / {len(items)} …")
            decisions += self._ask_batch(chunk, state)

        # ══════════════════════════════════════════════════════════════════
        # 以下全是**新增**（叠加）。上面那个循环一个字没动。
        # ══════════════════════════════════════════════════════════════════
        #
        # 2026-10-19 用户反馈「答题速度太慢」—— 根因是 `BATCH_SIZE=1`：
        # 一道题一次请求，12 题就 12 次往返。
        #
        # 但直接把批量调大有个已知代价（config.py 里记着）：
        #   · 模型偶尔**漏答**其中一两道
        #   · 模型偶尔回**不带题号的裸数组**（按位置猜，置信度 0.3）
        #
        # 所以这里**不打乱原来的分批逻辑**，只在它跑完之后补一刀：
        #   **这一轮里没拿到"可靠答案"的题，逐题再问一次。**
        #   判"可靠"的门槛和落笔门槛同一个常量，避免两处口径打架。
        #
        # 好处：常见情况一批答完（快）；模型不听话时退回逐题（和 batch=1 一样准），
        #       **最坏也不会比改之前更慢**。
        if b > 1 and decisions:
            try:
                _floor = float(getattr(config, "QUIZ_MIN_CONFIDENCE", 0.35))
            except Exception:
                _floor = 0.35
            _ok = {d.id for d in decisions
                   if float(getattr(d, "confidence", 0) or 0) >= _floor}
            _missing = [(r, o) for r, o in items if r not in _ok]
            if _missing:
                self.log(f"· 这一轮有 {len(_missing)} 道没拿到可靠答案"
                         f"（{[r for r, _ in _missing]}）→ 逐题补问")
                for r, o in _missing:
                    self.stop.check()
                    decisions += self._ask_batch([(r, o)], state)

            # 补问可能给同一题留下两条记录（一条低置信 + 一条高置信）。
            # 按 id 去重，**留置信度最高的那条** —— 只做去重，不改原有结果。
            _best: dict[str, Decision] = {}
            for d in decisions:
                old = _best.get(d.id)
                if old is None or float(d.confidence or 0) > float(old.confidence or 0):
                    _best[d.id] = d
            if len(_best) != len(decisions):
                self.log(f"· 去重：{len(decisions)} 条 → {len(_best)} 条（每题留最高置信度）")
            decisions = list(_best.values())

        if len(items) > 1:
            self.log(f"· 作答用时 {time.time() - _t0:.0f} 秒"
                     f"（{len(items)} 题，每批最多 {b} 题）")
        try:
            decisions = self._fix_multi_blank(state, decisions)
        except Exception as e:
            self.log(f"  (多空填空整理失败：{type(e).__name__})")
        try:
            self._assign_multi_blank(state, decisions)
        except Exception as e:
            self.log(f"  (多空填空归位失败：{type(e).__name__})")
        return decisions

    def _fire_answer(self, stem: str, ans: str,
                     reason: str = "", confidence: float = 0.0) -> None:
        """调用 `on_answer`：**新旧签名都能跑**。

        ⚠ 为什么不能直接多传两个参数：`on_answer` 是外部注入的回调，
          老代码写的是 `def f(stem, ans)`，多传会 TypeError。
          这里用 `inspect` 判断一次（结果记在 `_ans_detail`），
          之后每道题直接走对的那条路，不做"试错"。

        为什么必须兼容：这个回调是界面实时画「作答记录」的唯一来源，
        它一挂，用户就看不到任何作答过程 —— 那是比"没有解析"严重得多的问题。
        """
        fn = self.on_answer
        if not callable(fn):
            return
        try:
            if self._ans_detail is None:
                import inspect
                try:
                    ps = list(inspect.signature(fn).parameters.values())
                    has_kw = any(p.kind == p.VAR_KEYWORD for p in ps)
                    npos = len([p for p in ps
                                if p.kind in (p.POSITIONAL_ONLY,
                                              p.POSITIONAL_OR_KEYWORD)])
                    self._ans_detail = bool(has_kw or npos >= 4)
                except Exception:
                    # 拿不到签名（内置函数/lambda 的怪情况）→ 按老签名来，最安全
                    self._ans_detail = False
            if self._ans_detail:
                fn(stem, ans, reason=reason, confidence=confidence)
            else:
                fn(stem, ans)
        except Exception:
            # 界面回调出错绝不能影响作答主流程
            pass

    def _mark_dup_stems(self, state: PageState) -> None:
        r"""标出"题干完全相同"的填空题，并在日志里说清这不是真的有重复题。

        为什么按**整页**而不是按批：缓存键是全局的，跨批也会互相抄。
        只在 `len(fingerprint) >= 8` 时才判 —— 太短的题干（"第1空"）本来就
        没有区分度，判重没有意义，反而会误伤。
        """
        try:
            groups: dict[str, list[object]] = {}
            for f in (getattr(state, "fields", []) or []):
                stem = str(getattr(f, "stem", "") or getattr(f, "label", "") or "")
                fp = _stem_fingerprint(stem)
                if "题干未识别" in fp or len(fp) < 8:
                    continue
                groups.setdefault(fp, []).append(f)
            dups = [g for g in groups.values() if len(g) > 1]
            if not dups:
                return
            refs: list[str] = []
            for g in dups:
                g_sorted = sorted(g, key=lambda x: int(getattr(x, "fid", 0) or 0))
                for _idx, f in enumerate(g_sorted):
                    try:
                        setattr(f, "_dsh_dup_stem", True)
                        setattr(f, "_dsh_dup_index", _idx)
                        setattr(f, "_dsh_dup_total", len(g_sorted))
                    except Exception:
                        pass
                    refs.append(f"f{getattr(f, 'fid', '?')}")
            sample = str(getattr(dups[0][0], "stem", ""))[:48]
            self.log(f"⚠ {len(refs)} 道填空题的题干**完全相同**（{refs[:8]}）"
                     f"—— 这通常是题干抽取失败，不是真的有重复题。"
                     f"本次：这些题不共用缓存；答案是长文本就不落笔。"
                     f"题干示例：{sample!r}")
        except Exception:
            pass

    def _cache_key(self, obj: object) -> str | None:
        r"""取缓存键。**返回 None 表示这道题禁止走缓存**。

        ⚠ 为什么必须能返回 None（这是"看起来修好了、实际更糟"的一类坑）：
          6 道简答/论述的 `stem` 全是同一个字符串 "(填空题，题干未识别)"、
          `label` 全是空串 → 它们会算出**同一个缓存键**。
          一旦某道题偶然给出了答案并被 `cache.put()` 写进去，
          后面 5 道就会直接命中缓存、抄到**别人的答案** —— 交上去 6 份一样的。
          所以题干没识别出来的字段一律不查也不写缓存。
        """
        if isinstance(obj, Question):
            # ★ 加密页**一律不走缓存**。
            #
            #   为什么用页面级判据而不是文字启发式（2026-10-17 15:36 实测）：
            #   两道题的乱码只有 **36%~39%** 生僻字，而 `looks_obfuscated`
            #   的阈值是 45% → **被判成"正常"** → 旧缓存（confidence=0.30 的瞎猜）
            #   被读了出来，**模型根本没被问** —— 而这一轮整页截图明明已经
            #   送到它手里了。`font-cxsecret` 是**确定**信号，用它不会漏。
            if getattr(self, "_obf_page", False):
                return None
            # 文字层面的兜底（页面改版、判据漏了时）
            if BrowserDriver.looks_obfuscated(obj.stem):
                return None
            return AnswerCache.key_for(obj.stem, obj.options)
        stem = str(getattr(obj, "stem", "") or getattr(obj, "label", "") or "")
        if not stem.strip() or "题干未识别" in stem:
            return None
        # 同题干的题**绝不共用缓存**：否则第一道的答案会被后面几道抄走
        # （2026-10-23 真机就是 4 个空格写进同一段话）。
        if getattr(obj, "_dsh_dup_stem", False):
            return None
        return AnswerCache.key_for(stem, None, getattr(obj, "label", ""))

    def _ask_batch(self, chunk: list[tuple[str, object]], state: PageState) -> list[Decision]:
        # ---- 先查缓存：命中就不必问模型 ----
        cached: list[Decision] = []
        misses: list[tuple[str, object]] = []
        for ref, obj in chunk:
            key = self._cache_key(obj)
            # key 为 None = 禁止走缓存（题干未识别的填空/论述题 stem 全一样，
            # 共用 key 会互相抄答案，见 _cache_key 的说明）
            hit = self.cache.get(key) if key else None
            # ★ 2026-10-28：旧缓存里「填空题 = 300 字小作文」的条目不能再用。
            #   填空题的答案不该超过 40 字；超了就当没有缓存、重新问模型。
            if (hit and hit.get("answer") not in (None, "", [])
                    and not isinstance(obj, Question)
                    and not getattr(obj, "essay", False)
                    and len(str(hit.get("answer"))) > 40):
                hit = None
            if hit and hit.get("answer") not in (None, "", []):
                cached.append(Decision(ref, hit["answer"], hit.get("reason", "来自缓存"),
                                       float(hit.get("confidence") or 0.9)))
            else:
                misses.append((ref, obj))
        if cached:
            self.log(f"· 命中缓存 {len(cached)} 题（不再请求模型）："
                     f"{[d.id for d in cached]}")
        if not misses:
            return cached
        chunk = misses

        lines: list[str] = []
        for ref, obj in chunk:
            if isinstance(obj, Question):
                lines.append(obj.render())
            else:
                lines.append(obj.render())
        body = "\n".join(lines)

        images: list[Path] = []
        prompt = f"网页：{state.title or state.url}\n\n以下是需要你作答的题目：\n{body}"
        image_note = ""
        if state.images and self._is_vlm() and self._cloud_images_ok():
            imgs = self._images_for(chunk, state)
            images = self._shoot_images([im.get("idx") for im in imgs if im.get("idx") is not None])
            if images:
                self.vision_used += len(images)
                image_note = (
                    f"\n\n注意：本次附带 {len(images)} 张页面配图，"
                    "它们按页面从上到下的顺序排列。请结合图片内容作答"
                    "（例如几何图、统计图、需要读图的题干）。"
                )
                self.log(f"· 附带 {len(images)} 张配图送视觉模型")

        # ★ 字体加密页：这张整页截图就是**唯一的可信来源** ——
        #   DOM 里的题干/选项全是"一字换一字"的假字（如 `GAN悝悞悘`），
        #   屏幕上显示的才是真文字。所以既要附图，也要明确告诉模型"别信文字"。
        _obf = getattr(self, "_obf_shot", None)
        # ⚠ 再验一次：文件可能在两轮之间被清理掉（`_trim_shots`）。
        #   发一个不存在的路径 → 整个请求在发出去之前就炸，一题都答不了。
        if _obf:
            try:
                if not (Path(_obf).exists() and Path(_obf).stat().st_size > 800):
                    self.log("· 加密页截图文件不在了（可能被清理），本次不带图")
                    _obf = None
            except Exception:
                _obf = None
        # ⚠⚠ `shots` 必须在 `if` **外面**定义 —— 下面"拿不到图就不猜"的护栏要用它。
        #   上一版把护栏写在了 `if _obf and ...:` 里面，而 `_obf` 为 None
        #   恰好就是"图没了"的情况 → 护栏永远进不来 → 模型照样拿乱码猜。
        #   自测 ⑧ 抓到的就是这个。
        shots: list[Path] = []
        if _obf and self._is_vlm() and self._cloud_images_ok():
            shots = [Path(x) for x in (getattr(self, "_obf_shots", None) or [_obf])
                     if Path(x).exists() and Path(x).stat().st_size > 800]
        if shots:
            images = shots + list(images)
            self.vision_used += len(shots)
            image_note += (
                "\n\n⚠ **特别重要**：这一页的题干和选项在网页源码里是"
                "平台**字体加密**后的乱码（一字换一字，例如「GAN悝悞悘」），"
                "**真实文字只存在于屏幕上**。\n"
                "附带的图就是**卷子区域**的截图（只含题目，不含页面其它部分）。\n"
                "图里**从上到下的题目顺序，就是 q0 / q1 / q2 … 的顺序**。\n"
                "如果附了多张图，它们是**同一张卷子从上到下切开的连续几段**，"
                "请按图的先后顺序接着看（一道题可能横跨两张图）。\n"
                "**请只看图片里显示的中文**来理解题干和各选项，"
                "不要依据上面那堆乱码推断。\n"
                "答案仍然按选项字母作答（A/B/C/D，多选写多个字母）。"
            )
            self.log("· 字体加密页：已附整页截图，模型按屏幕文字作答")

        # ★ 加密页 + 没有可用图 → **一题都不猜**。
        #
        #   为什么必须在这里（而不是上面那个 if 里）：
        #   图丢了的时候 `_obf` 就是 None，那个 `if` 根本不会执行。
        #   2026-10-17 15:09 实测：没图时模型照样对乱码题给了 >0.35 的置信度，
        #   于是程序**落笔了 A/B/C 三个选项** —— 护栏被绕过。
        #   宁可空着交给用户，也不能靠蒙。
        if getattr(self, "_obf_page", False) and not shots:
            self.model_errors = int(getattr(self, "model_errors", 0)) + 1
            self.log("· ⚠ 加密页拿不到可用截图 —— **本次一题都不猜**，"
                     "整批跳过（交给你手动作答）")
            return []

        prompt += image_note + "\n\n" + ANSWER_SCHEMA_HINT

        try:
            data = self.client.ask_json(
                prompt, system=SYSTEM_PROMPT, images=images or None,
                max_tokens=config.LM_MAX_TOKENS,
                timeout=config.LM_VISION_TIMEOUT if images else config.LM_TIMEOUT,
            )
        except Exception as e:
            # 记下来，让上层别再把"请求失败"说成"可能是纯文本页面"。
            self.model_errors = int(getattr(self, "model_errors", 0)) + 1
            self.log(f"✘ 模型作答失败：{e}")
            return []

        # ------------------------------------------------------------------
        # 把模型的各种返回形态归一成 list[dict]。
        # 实测 batch=1 时模型**经常直接回一个单对象**而不是 {"answers":[...]}：
        #   {"id":"q8","answer":"A","reason":"...","confidence":0.92}
        # 早期实现要求必须是 list，于是把这几个答案整个丢掉 —— 表现为
        # 页面上某几题是空的（q3/q8/q12 全空就是这么来的），而不是答错。
        # ------------------------------------------------------------------
        # 正确取 answers：不能写成 data.get("answers") if isinstance(data, dict) else data
        # —— 单对象时 {"id":...,"answer":...} 根本没有 "answers" 键，会取到 None，
        # 于是"单对象"分支永远不可达（这个 off-by-key 的坑害我查了很久）。
        raw = data.get("answers") if isinstance(data, dict) else data
        if raw is None and isinstance(data, dict):
            raw = data          # 单对象 / id→对象 映射，交给下面归一化
        self.log(f"   ↳[调试] type(data)={type(data).__name__} type(raw)={type(raw).__name__}")
        # 诊断埋点：把这一批发出去的题目映射和模型回传的 id 都记下来。
        # 坐标错位类问题（模型按自己的编号回答）只有看到这两行才能定位。
        # ★ 截断到 40 字（原来 16 字）：题干抽取失败时，16 字常常只剩
        #   "该段代码用于在视频任务点完"这种前缀，看不出到底是哪一段；
        #   40 字足够认出"这一段是源码/别的题"。日志量只多一点点。
        sent = " | ".join(f"{ref}={str(getattr(o, 'stem', ''))[:40]}" for ref, o in chunk)
        self.log(f"   ↳ 发给模型：{sent}")
        if isinstance(raw, list):
            self.log(f"   ↳ 模型回传 id：{[str(a.get('id')) for a in raw if isinstance(a, dict)]}"
                     f"（本批合法 id：{sorted({r for r, _ in chunk})}）")
        if isinstance(raw, dict):
            # 形如 {"0": {...}} 或 {"q0": {...}} 的字典映射也要认
            self.log(f"   ↳[调试] raw 是 dict，键={list(raw.keys())}")
            if "id" in raw or "answer" in raw:
                self.log("· 模型返回单个对象（非数组），已按单题处理")
                raw = [raw]
            else:
                vals = [v for v in raw.values() if isinstance(v, dict)]
                if vals:
                    self.log(f"· 模型返回 id→对象 映射，已展开 {len(vals)} 条")
                    raw = vals
        if not isinstance(raw, list):
            self.log(f"✘ 模型返回结构不对：{str(data)[:200]}")
            return []

        # 兜底：模型有时不按 schema 给 {"id":...,"answer":...}，而是直接返回
        # 一个裸数组（如 [1,2,3] 或 ["C","A","BD"]）。这时**没有可靠的题号信息**，
        # 只能按位置对回题目 —— 有猜错的风险，所以给低置信度并明确记日志，
        # 让用户知道这几题必须复核。想彻底避免就设 DSHS_BATCH_SIZE=1。
        if raw and not any(isinstance(a, dict) for a in raw):
            refs = [ref for ref, _ in chunk]
            self.log(f"⚠ 模型返回裸数组（无题号），按位置对回 {refs} —— 顺序不保证，"
                     f"这几题请务必复核；想避免请设 DSHS_BATCH_SIZE=1")
            raw = [
                {"id": refs[i], "answer": a, "reason": "裸数组按位置映射",
                 "confidence": 0.3}
                for i, a in enumerate(raw) if i < len(refs)
            ]

        # 兼容模型把 id 写成 "0" / "q0" / "question0" 的各种变体
        valid = {ref for ref, _ in chunk}
        out: list[Decision] = []
        for a in raw:
            if not isinstance(a, dict):
                continue
            rid = str(a.get("id", "")).strip()
            ref = _normalize_ref(rid, valid)
            if ref is None:
                continue
            # 必须有 answer 字段。实测模型偶尔只回 {"id":"q0"}，
            # 这种空壳如果放过去，会占据 attempts 名额导致该题永远不再被问。
            if "answer" not in a or a.get("answer") in (None, "", []):
                self.log(f"· {ref} 的返回缺 answer 字段（id={rid!r}），本题留待重问")
                continue
            try:
                conf = float(a.get("confidence", 0) or 0)
            except (TypeError, ValueError):
                conf = 0.0
            out.append(Decision(ref, a.get("answer"), str(a.get("reason", ""))[:200], conf))
        if not out:
            self.log(f"✘ 模型没给出任何可用的 id（原始：{str(raw)[:200]}）")

        # ---- 把新拿到的答案写进缓存，下次遇到同一题直接复用 ----
        ref_to_obj = dict(chunk)
        for d in out:
            obj = ref_to_obj.get(d.id)
            if obj is not None:
                _k = self._cache_key(obj)
                # key 为 None 就不写 —— 否则这 6 道题干未识别的题会互相抄答案
                #
                # ⚠ 另外两条也不写：
                #   · 加密页：题干是乱码，写进去下次也读不出意义
                #   · 低于落笔门槛的置信度：那本来就是猜的，
                #     让它进缓存 = 以后每次都抄同一个猜测
                #     （2026-10-17 15:36 就是被一条 confidence=0.30 的旧缓存
                #       顶掉了本该问模型的那道题）
                _conf = float(getattr(d, "confidence", 0) or 0)
                _floor = float(getattr(config, "QUIZ_MIN_CONFIDENCE", 0.35))
                if (_k and not getattr(self, "_obf_page", False)
                        and _conf >= _floor):
                    self.cache.put(
                        _k, d.answer, d.reason, d.confidence,
                        stem=str(getattr(obj, "stem", "")
                                 or getattr(obj, "label", "") or ""),
                        options=getattr(obj, "options", None),
                        qtype=str(getattr(obj, "kind", "") or ""),
                        model=str(getattr(getattr(self, "client", None),
                                         "model", "") or ""),
                    )

        return cached + out

    def _images_for(self, chunk: list[tuple[str, object]], state: PageState) -> list[dict]:
        """挑出真正和这批题相关的配图。

        原来的做法是把页面上所有图都塞给每一批，结果是那张柱状图被送了 12 次 ——
        12 次视觉推理，每次都慢且可能干扰纯文字题的判断。
        现在按**纵向位置**匹配：只把和本批题目的 y 区间有重叠的图送过去；
        本批一道题都没配图，就干脆不带图（纯文字题反而更准）。
        """
        cand = [
            im for im in state.images
            if im.get("box") and im["box"].get("w", 0) >= 60
        ]
        if not cand:
            return []

        # 本批题目覆盖的 y 区间（含一点余量，图文通常紧挨着）
        spans: list[tuple[int, int]] = []
        for _, obj in chunk:
            box = getattr(obj, "box", None) or {}
            if not box:
                continue
            top = int(box.get("y", 0))
            spans.append((top, top + int(box.get("h", 0))))
        if not spans:
            return []

        # 相邻题目的间距：用它当"图属于这道题"的容差
        tops = sorted(t for t, _ in spans)
        gaps = [b - a for a, b in zip(tops, tops[1:]) if b > a]
        tol = max(120, min(gaps) if gaps else 300)

        picked: list[dict] = []
        for im in cand:
            bx = im["box"]
            iy1, iy2 = int(bx.get("y", 0)), int(bx.get("y", 0) + bx.get("h", 0))
            for qy1, qy2 in spans:
                if iy2 >= qy1 - tol and iy1 <= qy2 + tol:
                    picked.append(im)
                    break
        return sorted(picked, key=lambda im: im["box"]["y"])[:3]

    def _is_vlm(self) -> bool:
        try:
            return self.client.is_vision_capable()
        except Exception:
            return False

    def _cloud_images_ok(self) -> bool:
        """严格本地模式（`DSHS_ALLOW_CLOUD_IMAGES=0`）下，云端 provider 不附图。

        ★ 2026-10-23 修 B2：`config.ALLOW_CLOUD_IMAGES` 原来**全仓没人读**
          —— 用户在「严格本地/隐私」的预期下把它设成 0，截图照样被 base64
          编码后发给 DeepSeek/Kimi，等于一句空承诺。这里让它真正生效：
            · 开关为 1（默认）→ 行为完全不变；
            · 开关为 0 且当前 provider 是云端 → 不送图，日志说明一次。
          取不到 provider 信息时**放行**（fail-open）：宁可照旧，也不要因为
          一个读不到的属性把正常答题搞坏。
        """
        try:
            if getattr(config, "ALLOW_CLOUD_IMAGES", True):
                return True
            if not bool(getattr(self.client, "is_cloud", False)):
                return True          # 本机 LM Studio：图不出机器，允许
            if not getattr(self, "_cloud_img_warned", False):
                self._cloud_img_warned = True
                self.log("· 已开启「不把图片发到云端」(DSHS_ALLOW_CLOUD_IMAGES=0)，"
                         "本次不附配图；遇到字体加密页会改为不猜、留给你手动作答")
            return False
        except Exception:
            return True

    def _obf_shot_slice(self, src: Path, *, max_h: int | None = None) -> list[Path]:
        r"""把过高的卷子截图切成几张（自上而下），返回路径列表。

        ## 为什么必须切

        2026-10-23 11:44 客户日志（`114404.txt`）：
            识别到 25 道选择题
            · 题目区域截图已就绪：114404_fr_obf.png（943 KB，只含卷子）
            ✘ 模型作答失败：deepseek 返回 400：
              ".messages[1].image[0]: You have uploaded an unsupported image."

        那张图是**整个 iframe 元素**的截图，25 道题一张卷子 ≈ 1 万像素高。
        DeepSeek 官方文档的硬限制是**单边最长 8192px**（单请求 ≥15 张图时
        还会降到 4096），超了就是上面那个 400 —— 整个模型请求在发出前被拒，
        一题都答不了。

        历史旁证：10-17 那三张真机元素截图是 1590×1740 / 1869 / 2628，都能正常发；
        这张 943 KB 按同样的压缩密度估算约 1 万像素高，正好越线。

        ## 为什么不只是"缩到 8192"

        服务端会把每张图缩到总像素 ≈1300×1300。一张 1590×10000 的图缩完
        宽只剩 ~400px，中文根本看不清 —— 就算不报 400，答案也是瞎猜。
        切成 1600 高的小图后，每张缩放比例接近 1:1，字是清楚的。

        ## 切点怎么选

        不按固定网格硬切（会把一行字拦腰截断），而是在目标位置上下 240px
        的带状区域里找**墨迹最少的一行**（接近纯白）下刀。
        每张仍保证不超过 `max_h`。
        """
        from PIL import Image  # noqa: PLC0415

        try:
            src = Path(src)
            if not (src.exists() and src.stat().st_size > 800):
                return [src]
            im = Image.open(src)
            im.load()
        except Exception as e:
            self.log(f"    · 截图切片失败（读图）：{type(e).__name__}: {str(e)[:70]}")
            return [src]

        limit = int(max_h or getattr(config, "OBF_SLICE_H", 1600) or 1600)
        w, h = im.size
        # 只有"确实很高"才切：2 屏以内保持原样（旧行为，图也不算糊）。
        # 超过 2 屏后服务端会把整张缩到 ~1300×1300，字开始看不清，才值得切。
        if h <= limit * 2:
            return [src]

        # 提前算好每行的"墨迹"：每 3 个像素采一次，够判断空白行，速度也快。
        rgb = im.convert("RGB")
        step_x = 3
        # 忽略左右各 12px：页面的边框/滚动条会让**每一行**都有墨迹，
        # 不剔掉就永远找不到真正的空白行。
        x0, x1 = min(12, w // 10), max(w - 12, w // 2)

        def cut_near(target: int) -> int:
            """在 [target-240, target] 里找最空的一行；找不到就取 target。"""
            lo = max(1, target - 240)
            hi = min(h - 1, target)
            if hi <= lo:
                return max(1, min(target, h - 1))
            band = rgb.crop((x0, lo, x1, hi + 1)).convert("L")
            px = band.load()
            bw, bh = band.size
            best_y, best_ink = target, None
            for yy in range(bh):
                ink = 0
                for xx in range(0, bw, step_x):
                    if px[xx, yy] < 180:
                        ink += 1
                if best_ink is None or ink <= best_ink:
                    best_ink, best_y = ink, lo + yy
            return max(1, best_y)

        cuts: list[int] = []
        y = limit
        while y < h:
            c = cut_near(y)
            # 必须往前走，否则死循环（极端整页全黑时可能选回同一点）
            c = max(c, (cuts[-1] if cuts else 0) + limit // 2)
            c = min(c, h - 1)
            cuts.append(c)
            y = c + limit

        bounds = [0] + cuts + [h]
        out: list[Path] = []
        try:
            for k in range(len(bounds) - 1):
                y0, y1 = bounds[k], bounds[k + 1]
                if y1 <= y0:
                    continue
                dst = src.with_name(f"{src.stem}_p{k}{src.suffix or '.png'}")
                rgb.crop((0, y0, w, y1)).save(dst)
                if dst.exists() and dst.stat().st_size > 800:
                    out.append(dst)
        except Exception as e:
            self.log(f"    · 截图切片失败（写盘）：{type(e).__name__}: {str(e)[:70]}")
            return [src]
        if len(out) <= 1:
            return [src]
        self.log(f"    · 卷子截图过高（{w}×{h}px，单边上限 "
                 f"{getattr(config, 'IMAGE_MAX_EDGE', 8000)}px）→ "
                 f"已切成 {len(out)} 张 ≤{limit}px，保证字看得清")
        return out

    def _obf_shot_save(self, src):
        r"""把一张截图拷进 `out\tmp\` 再返回。拷不到返回 None。

        为什么必须拷走：`_trim_shots()` 默认 `keep=1`，会把 `截图\` 里
        **除了最新那张之外的全删掉**。加密页的图要跨好几轮用，
        放在那儿随时会被删（2026-10-17 15:09 实测就是这么丢的）。
        `out\tmp\` 不在清理范围内。
        """
        from datetime import datetime  # noqa: PLC0415
        from shutil import copyfile     # noqa: PLC0415

        try:
            if not (src and Path(src).exists() and Path(src).stat().st_size > 800):
                return None
            config.TMP_DIR.mkdir(parents=True, exist_ok=True)
            dst = config.TMP_DIR / (
                f"{datetime.now().strftime('%H%M%S')}_{Path(src).name}")
            copyfile(str(src), str(dst))
            if dst.exists() and dst.stat().st_size > 800:
                return dst
        except Exception as e:
            self.log(f"    · 截图另存失败：{type(e).__name__}: {str(e)[:70]}")
        return None

    def _obf_shot_stitch(self, *, max_tiles: int = 12,
                         slice_h: int = 1600, max_slices: int = 4):
        """滚动截整页再拼接，按高度切片返回若干张图。失败返回 []。

        ## 为什么要自己拼

        `page.screenshot(full_page=True)` 在复杂页面上会失败
        （2026-10-17 14:51 实测），而 `BrowserDriver.screenshot()` 的
        退路**带着同样的 `full_page=True`**，所以两次都挂、文件没写成。

        滚动拼接不依赖那条路：按视口高度一段段截，再纵向拼起来。

        ## 为什么切片而不是缩成一张

        一页 8000px 高的图缩到 2000px，中文就看不清了。
        **切片保留原分辨率**，模型能读；代价是可能多发几张图。
        """
        from PIL import Image  # noqa: PLC0415

        assert self.driver is not None
        page = self.driver.page
        try:
            h = int(page.evaluate(
                "() => Math.max(document.body.scrollHeight,"
                " document.documentElement.scrollHeight)") or 0)
            vh = int(page.evaluate("() => window.innerHeight") or 0)
        except Exception as e:
            self.log(f"    · 拼接失败（读不到页面高度）：{type(e).__name__}")
            return []
        if h <= 0 or vh <= 0:
            return []
        step = max(200, vh - 40)          # 留 40px 重叠，避免把一行字切断
        n_tiles = min(max_tiles, max(1, (h + step - 1) // step))
        self.log(f"    · 页面高 {h}px / 视口 {vh}px → 分 {n_tiles} 段截")

        blobs = []
        try:
            for k in range(n_tiles):
                page.evaluate("(y) => window.scrollTo(0, y)", k * step)
                page.wait_for_timeout(160)
                blobs.append(page.screenshot())
        except Exception as e:
            self.log(f"    · 拼接失败（截图阶段）：{type(e).__name__}: {str(e)[:80]}")
            blobs = []
        finally:
            try:
                page.evaluate("() => window.scrollTo(0, 0)")
            except Exception:
                pass
        if not blobs:
            return []

        try:
            imgs = [Image.open(io.BytesIO(b)).convert("RGB") for b in blobs]
            w = max(i.width for i in imgs)
            total = step * (len(imgs) - 1) + imgs[-1].height
            canvas = Image.new("RGB", (w, total), "white")
            for k, im in enumerate(imgs):
                canvas.paste(im, (0, k * step))
        except Exception as e:
            self.log(f"    · 拼接失败（合成的{type(e).__name__}）：{str(e)[:80]}")
            return []

        out: list[Path] = []
        try:
            from datetime import datetime  # noqa: PLC0415
            stamp = datetime.now().strftime("%H%M%S")
            ys = list(range(0, canvas.height, slice_h))[:max_slices]
            for k, y0 in enumerate(ys):
                box = (0, y0, canvas.width, min(canvas.height, y0 + slice_h))
                config.TMP_DIR.mkdir(parents=True, exist_ok=True)
                p = config.TMP_DIR / f"{stamp}_st{k}_obf.png"
                canvas.crop(box).save(p)
                out.append(p)
        except Exception as e:
            self.log(f"    · 切片失败：{type(e).__name__}: {str(e)[:80]}")
            return []
        return out

    def _obf_shot_take(self, frames=None):
        """给「字体加密」页拍一张能读的截图。返回 Path 列表（可能为空）。

        ## 为什么优先截**题目所在的 iframe 元素**，而不是整页

        2026-10-17 16:48 实测：整页截图 **318 KB**，而卷子只占其中一小块 ——
        图里还有课程页外壳、右侧整个目录、视频区。后果是两个：
          · 模型要在 318KB 里找那一小块题，**每次要 30 秒**；
          · 字被缩得很小 → **读错**。用户反馈"三次都没有做到全对"。

        所以第一优先：把**装着题目的那个 iframe 元素本身**截下来 ——
        干净、字大、只含题目。

        ## 为什么不能直接用 `driver.screenshot()`

        `screenshot()` 的设计是「**失败也绝不抛**」—— 失败时**照样返回路径**，
        于是调用方拿到的是个指向不存在文件的占位路径。
        2026-10-17 14:51 就是这么炸的：

            ✘ 模型作答失败：[Errno 2] No such file or directory:
               '...\截图\145138_002_obf.png'

        所以每一层都必须**验文件**（存在 + 大小够）。
        """
        assert self.driver is not None
        from datetime import datetime  # noqa: PLC0415

        # ⓪ 最优先：题目所在框架的**元素截图**
        for fr in (frames or []):
            try:
                el = fr.frame_element()
            except Exception:
                continue
            try:
                config.TMP_DIR.mkdir(parents=True, exist_ok=True)
                dst = config.TMP_DIR / (
                    f"{datetime.now().strftime('%H%M%S')}_fr_obf.png")
                el.screenshot(path=str(dst))
                if dst.exists() and dst.stat().st_size > 800:
                    self.log(f"    · 题目区域截图已就绪：{dst.name}"
                             f"（{dst.stat().st_size // 1024} KB，只含卷子）")
                    # ★ 25 道题的卷子 ≈ 1 万像素高，超过接口的 8192px 上限
                    #   → 会被 400 拒绝。这里按空白行切成几张（短图原样返回）。
                    return self._obf_shot_slice(dst)
            except Exception as e:
                self.log(f"    · 题目区域截图失败：{type(e).__name__}: "
                         f"{str(e)[:70]}")

        # ① 先试最省事的：整页一张
        #
        # ⚠ 必须**复制到 `out\tmp\`** 再返回。
        #   `_trim_shots()` 默认 keep=1（"每轮只留最新 1 张"），而 `_web_loop`
        #   每轮还会截一张预览 —— 2026-10-17 15:09 实测：obf 那张 79 KB 刚截好，
        #   下一秒就被当"旧的"删了，然后模型读乱码瞎猜、还落笔了。
        #   截图清理只动 `截图\`（SHOT_DIR），**不会碰 tmp**。
        try:
            p = self.driver.screenshot(tag="obf", full_page=True)
            safe = self._obf_shot_save(p)
            if safe:
                self.log(f"    · 整页截图已就绪：{safe.name}"
                         f"（{safe.stat().st_size // 1024} KB）")
                return self._obf_shot_slice(safe)
        except Exception as e:
            self.log(f"    · 整页截图失败：{type(e).__name__}: {str(e)[:90]}")

        # ② 整页不行就**滚动拼接** —— 这条一定拿得到整页内容。
        #    为什么不能只退回"视口单张"：屏幕外的题根本不在图里，
        #    模型看不见 → 还是答不了。
        tiles = self._obf_shot_stitch()
        if tiles:
            self.log(f"    · 改用滚动拼接：{len(tiles)} 张（覆盖整页）")
            return tiles

        # ③ 最后兜底：视口一张（可能看不到屏幕外的题，但总比没有强）
        for label, kw in (("视口", {}),):
            try:
                p = self.driver.screenshot(tag="obf", **kw)
            except Exception as e:
                self.log(f"    · {label}截图抛异常（{type(e).__name__}）")
                continue
            safe = self._obf_shot_save(p)
            if safe:
                self.log(f"    · {label}截图已就绪：{safe.name}"
                         f"（{safe.stat().st_size // 1024} KB）")
                return [safe]
            # 走到这里 = 返回了占位路径但文件不存在。
            # ⚠ driver.screenshot() 把异常吞了，只说"没落盘"根本不够。
            #   2026-10-17 14:51 真机上就是这样，日志里只剩一个

            #   No such file or directory，根本不知道截图为什么失败。
            #   这里**直接调 page.screenshot**再试一次，并把真实异常打出来。
            try:
                from datetime import datetime as _dt
                _qp = config.SHOT_DIR / (
                    f"{_dt.now().strftime('%H%M%S')}_q_{len(label)}_obf.png")
                self.driver.page.screenshot(
                    path=str(_qp), full_page=bool(kw.get("full_page")))
                if _qp.exists() and _qp.stat().st_size > 800:
                    self.log(f"    · {label}截图直接写盘成功：{_qp.name}")
                    return [_qp]
                self.log(f"    · {label}截图直接写盘后仍无文件（{_qp}）")
            except Exception as e2:
                self.log(f"    · {label}截图失败："
                         f"{type(e2).__name__}: {str(e2)[:110]}")
            self.log(f"    · {label}截图拿不到，换一种")
        return None

    def _shoot_images(self, indexes: list[int]) -> list[Path]:
        """用浏览器原生元素截图抓配图，并把过小的图放大。

        为什么不用 crop_regions：首屏之外的图，用"视口截图 + 文档坐标"裁剪会得到
        一条细缝（实测 444x36），模型看不见内容，看图题必然答错。
        """
        if not self.driver or not indexes:
            return []
        try:
            paths = self.driver.shoot_images([i for i in indexes if i is not None], tag="q")
        except Exception as e:
            self.log(f"· 抓配图失败（忽略）：{e}")
            return []
        try:
            paths = self.driver.upscale_small(paths)
        except Exception:
            pass
        for p in paths:
            try:
                from PIL import Image
                self.log(f"· 配图 {p.name}  尺寸 {Image.open(p).size}")
            except Exception:
                pass
        return paths

    @staticmethod
    def _letters_to_indices(ans: Any, n: int, multi: bool,
                            options: list[dict] | None = None) -> list[int]:
        """把模型的答案转成选项下标。

        'B' / ['A','C'] / 'A,C' / 1 / '1'  →  [1] / [0,2]

        优先**按选项文字里的字母匹配**，找不到才退回按位置推算。
        理由：模型答的是"选项 C"，而位置是按 DOM 顺序数的；真实站点里
        CSS order / flex-row-reverse / 自定义样式都可能让 DOM 顺序与视觉顺序
        不一致，此时按位置取就会点错。用选项自己显示出来的字母去定位，
        无论 DOM 怎么排都能找对。
        """
        if ans is None:
            return []

        def by_letter(letter: str) -> int | None:
            """在 options 里找"显示字母就是 letter"的那个下标。"""
            if not options:
                return None
            up = letter.upper()
            for o in options:
                if str(o.get("key") or "").upper() == up:
                    return int(o.get("id", 0))
            return None

        def by_letter_or_pos(letter: str) -> int:
            i = by_letter(letter)
            if i is not None and 0 <= i < n:
                return i
            return ord(letter.upper()) - ord("A")

        if isinstance(ans, (int, float)) and not isinstance(ans, bool):
            i = int(ans)
            return [i] if 0 <= i < n else []
        if isinstance(ans, list):
            out: list[int] = []
            for x in ans:
                out += SolverAgent._letters_to_indices(x, n, True, options)
            return sorted(set(out))

        s = str(ans).strip()
        if not s:
            return []
        # 纯数字：按 0-based 下标处理。
        # 不要试图猜 1-based（原来写过 `int(s)-1 if int(s) > n else int(s)`）——
        # "3" 到底是第 3 个还是下标 3 本身就有歧义，猜错就是点错选项。
        # 选择题本来就要求模型给字母，数字只可能来自填空题，走不到这里。
        if re.fullmatch(r"\d+", s):
            i = int(s)
            return [i] if 0 <= i < n else []

        letters = re.findall(r"[A-Za-z]", s)
        idx: list[int] = []
        for L in letters:
            i = by_letter_or_pos(L)
            if 0 <= i < n:
                idx.append(i)
        if not multi:
            return idx[:1]
        return sorted(set(idx))

    # ================================================================ Web 模式
    def run_web(
        self,
        url: str | None = None,
        *,
        headless: bool | None = None,
        cdp_url: str | None = None,
        pause_for_login: bool = True,
        driver=None,
    ) -> SessionResult:
        """跑一轮网页作答。

        `driver` 不为空时**借用调用方的 driver**（不新建、不关闭）——
        网课的「章节测验」就是这么用的：共用课程页那一个 driver，
        开个临时标签页答完再关掉，不留残留标签、不多起进程。

        `driver=None` 时行为与以前**完全一样**：自己建、跑完 `close()`。
        """
        t0 = time.time()
        _borrowed = driver is not None
        res = SessionResult()
        # ★ 2026-10-23 新增：给本次运行留一份「这是哪个站 / 哪门课 / 用的什么模型」。
        #   url/title 要等浏览器打开后才准，这里先放网址占位，
        #   `wait_for_load()` 之后再补页面实际地址与标题（见下面那一小段）。
        #   全部 try/except 兜底：任何一项取不到就留空，绝不影响作答主流程。
        try:
            from . import __version__ as _pkg_ver      # 版本号唯一真源
        except Exception:
            _pkg_ver = ""
        try:
            res.meta = {
                "url": str(url or ""),
                "title": "",
                "model": str(getattr(self.client, "model", "") or ""),
                "provider": str(getattr(config, "PROVIDER", "") or ""),
                "app_version": str(_pkg_ver or ""),
                "started_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(t0)),
            }
        except Exception:
            res.meta = {}
        # 用户可能直接粘一个本地路径（E:\x\y.html），转成合法的 file:// URL，
        # 否则浏览器不认、页面比对也会失败。http(s) 原样保留。
        url = BrowserDriver.to_file_url(url) if url else url
        try:
            if _borrowed:
                # 借来的：直接用，不新建、不 open（调用方已经把页面开好了）
                self.driver = driver
            else:
                self.driver = BrowserDriver(headless=headless, cdp_url=cdp_url,
                                        log=self.log)
                self.status("正在启动浏览器…")
                self.driver.open(url)
            self.driver.wait_for_load()
            # ★ meta 补页面实际地址/标题（浏览器打开之前拿不到）。只读，不改任何状态。
            try:
                res.meta["url"] = str(self.driver.page.url or "")
                res.meta["title"] = str(self.driver.page.title() or "")
            except Exception:
                pass
            if url:
                self.log(f"已打开：{url}")

            # ★ 等页面**真的渲染出内容**再截图/扫描。
            #
            # ⚠ 实测踩到（用户报"点了开始答题后页面变纯白、网页模式无法作答"）：
            #   学习通的「作业作答」页是 **JS 异步填内容**的 —— 打开后先是个白壳，
            #   题目几秒后才被写进去。而 `wait_for_load()` 只等 networkidle，
            #   在 SPA 上几乎立刻返回，于是：
            #     页面标题：作业作答            ← 地址和标题都对
            #     识别到 0 道选择题、6 个填空    ← 但扫的是白页
            #     截图 2549x1352 全白（13KB）
            #     模型回传 'reason': '题目内容缺失，仅含样式代码'
            #   等一次内容检测就能避免这类"扫到空壳"。
            got_content, chars = self.driver.wait_for_content(
                timeout=config.WEB_CONTENT_WAIT_SEC)
            if got_content:
                self.log(f"· 页面内容已就绪（可见文字 {chars} 字）")
            else:
                self.log(f"⚠ 等了 {config.WEB_CONTENT_WAIT_SEC:.0f} 秒，"
                         f"页面仍几乎没内容（可见文字 {chars} 字）——"
                         f"可能题目还没加载完，或这一页需要先手动操作。")

            self.on_shot(self.driver.screenshot(tag="start"))

            first = self.driver.scan()
            # 白页要说清楚，否则用户只看到"识别到 0 道题"完全摸不着头脑
            if self.driver.looks_blank():
                self.log("⚠ 当前页面看起来是**空白页**（几乎没有可见文字）。"
                         "常见原因：① 题目还在加载 → 稍等后重试；"
                         "② 需要先在浏览器里点一下「开始答题」之类的按钮；"
                         "③ 页面被重定向了（回到登录页时本程序会另行提示）。")
            actual = ""
            try:
                actual = self.driver.page.url
            except Exception:
                pass
            self.log(f"页面标题：{self.driver.page.title()}")
            self.log(f"正在作答的页面：{actual}")
            if url and not BrowserDriver._same_url(actual, url):
                self.log(f"⚠ 注意：当前页面和你填的网址不一致（你填的是 {url}）——"
                         f"如果答错页面，请检查浏览器里开了哪些标签页。")

            # ---- 登录页拦截 ----
            # 必须在答题之前拦住：登录页的用户名/密码框也是 input，
            # 放任下去会被当成"填空题"填写，把登录流程搅断然后卡死。
            signals = self.driver.login_signals(first)
            if signals:
                self.log("⚠ 当前页面看起来是登录页：" + "；".join(signals))
                if pause_for_login and self.ask_user:
                    self.log("请在浏览器窗口里完成登录，然后点「确定」继续。")
                    if not self.ask_user("请在已打开的浏览器里完成登录/进入作业页面，完成后点击「确定」继续。"):
                        raise Stopped()
                    self.driver.wait_for_load()
                    first = self.driver.scan()
                    signals = self.driver.login_signals(first)
                    if signals:
                        raise RuntimeError(
                            "登录仍未完成（" + "；".join(signals) + "）。"
                            "请改用「先打开浏览器登录」的方式：登录好之后再点「开始答题」。"
                        )
                else:
                    raise RuntimeError(
                        "检测到登录页，已停止以免把账号密码框当成题目填写。\n"
                        "解决办法：回到界面点「① 打开浏览器登录」，在那个窗口里登录并进入作业页面，"
                        "然后点「② 开始答题」。"
                    )

            res = self._web_loop(first, res, t_start=t0)
            res.ok = not res.failed
        except Stopped:
            res.error = "用户已停止"
            self.log("⏹ 已停止")
        except Exception as e:
            import traceback
            res.error = f"{type(e).__name__}: {e}"
            self.log(f"✘ 出错：{res.error}")
            self.log(traceback.format_exc())
        finally:
            res.seconds = time.time() - t0
            self.cache.save()
            # ★ 模型请求全挂了的话，`res.error` 是空的，上层就会把它
            #   说成「没扫到可作答的题（可能是纯文本页面）」—— 完全误导。
            #   2026-10-17 14:51 就是这样：截图路径不存在 → 请求失败 →
            #   日志说"可能是纯文本页面"。
            if getattr(self, "model_errors", 0) and not res.error:
                res.error = f"模型请求失败 {self.model_errors} 次（看上面的具体原因）"

            # ★ 启动时清掉的低置信度旧缓存要报出来 —— 否则用户会疑惑
            #   "为什么缓存条数变少了"。
            #   这些条目是**以前瞎猜写的**（低于现在的落笔门槛），
            #   留着只会让以后的运行抄同一个猜测。
            if getattr(self.cache, "purged", 0):
                self.log(f"· 清掉 {self.cache.purged} 条低置信度旧缓存"
                         f"（低于 {float(getattr(config, 'QUIZ_MIN_CONFIDENCE', 0.35)):.2f} "
                         f"的答案现在不允许落笔，也不该留在缓存里）")
            if self.cache.hits:
                self.log(f"· 本次命中答案缓存 {self.cache.hits} 题（省下同样次数的模型请求）")
            # ⚠ audit C-23：**这里原来没有关浏览器。**
            #   后果：每答一次就多留一个 node.exe（Playwright 的驱动进程）
            #   和一个浏览器进程；答十次就是十几个进程堆在任务管理器里，
            #   用户完全不知道那是什么。
            #   `course.py` 的 `finally` 里本来就有这句 —— 两条路径不一致。
            #
            #   注意：`BrowserDriver.close()` 现在会区分"自己启动的"和
            #   "CDP 接管的"（audit C-38）—— 接管的只断开连接，
            #   **不会关掉用户自己开着的那个浏览器**。
            try:
                # ⚠ **借来的不关** —— 那是网课那边正在用的 driver，
                #   关掉等于把用户的浏览器断开，刷课当场崩。
                if self.driver is not None and not _borrowed:
                    self.driver.close()
            except Exception:
                pass
            self.driver = None
            self._dump(res)
        return res

    def _check_challenge(self) -> bool:
        """开跑前看一眼有没有人机校验。有就**停下并说清楚**，返回 True。

        ⚠ 绝不去识别或填写验证码 —— 那是平台的人机校验，
          自动解等于绕过反爬，与"不绕过人脸识别与活体检测"是同一条铁律。
        """
        try:
            ch = self.driver.detect_challenge()
        except Exception:
            return False
        if not ch.get("found"):
            return False
        self.log("✘ 页面出现**人机校验 / 验证码** —— 已停止，不会替你识别。")
        self.log(f"   命中特征：{ch.get('how')}"
                 + (f"　附近的文字：{ch.get('hint')}" if ch.get("hint") else ""))
        self.log("   平台会因为你操作得太快/太规律而弹这个。")
        self.log("   **请到浏览器窗口里手动输入验证码**，再点一次「开始答题」。")
        return True

    def _web_loop(self, state: PageState, res: SessionResult, *, t_start: float) -> SessionResult:
        assert self.driver is not None

        # 先滚到底触发懒加载，再回到顶部开始
        self.status("预扫描：触发懒加载…")
        try:
            h = state.scroll_h
            y = 0
            while y < h and y < 40000:
                self.stop.check()
                self.driver.scroll_by(700)
                y += 700
                time.sleep(0.12)
            self.driver.scroll_to_top()
            state = self.driver.scan()
        except Stopped:
            raise
        except Exception as e:
            self.log(f"· 预扫描失败（忽略）：{e}")

        self.log(f"识别到 {len(state.questions)} 道选择题、{len(state.fields)} 个填空/下拉框。")
        # ★ 开跑前先看有没有人机校验。
        #   有就**停下并说清楚**（绝不去解）—— 否则表现是"扫到了题却一道都点不中"，
        #   用户完全看不出是验证码拦住了。
        if self._check_challenge():
            res.error = "人机校验 / 验证码（需你手动处理）"
            return res

        # ★ 字体加密：DOM 里取到的是乱码，屏幕上才是对的。
        #
        #   2026-10-17 实测（学习通章节测验）：两道题的题干都是
        #     "GAN悝“悚悞悘”悡比悜悞悛么?" / confidence=0.2
        #   模型只能瞎猜，而原来的代码**照样点选、照样交卷**。
        #   比答错更糟的是：错答案会被写进答案缓存，下次重跑还抄错的。
        #
        #   所以这里**直接停**：不猜、不答、不交卷，并把原因说清楚。
        #   照 `_check_challenge()` 的早退模式 —— 宁可没做，也不能交错的。
        try:
            _obf = self.driver.page_font_obfuscated()
        except Exception:
            _obf = False
        self._obf_shot = None
        self._obf_shots = []
        self._obf_page = bool(_obf)
        if _obf:
            self.log("⚠ 这一页的题目被平台做了「字体加密」（font-cxsecret）：")
            self.log("    DOM 里取到的是乱码，屏幕上才是对的文字。")
            # ★ 不再直接放弃 —— 加密只改 DOM，**屏幕显示是对的**。
            #   拍一张整页截图给模型看，它按屏幕上的中文理解题意即可。
            #   前提是当前模型认图（deepseek-flash 认）。
            if self._is_vlm():
                # ⚠ 必须验文件 —— `screenshot()` 失败时**照样返回路径**，
                #   直接拿去发图会报 `No such file or directory`。
                #
                # ★ 把「题目所在的 frame」传进去：优先截**那个 iframe 元素本身**。
                #   整页截图 318 KB，题只占一小块 → 模型每次要 30 秒、还读错。
                _qframes = []
                for _q in (state.questions or []):
                    _f = getattr(_q, "frame", None)
                    if _f is not None and _f not in _qframes:
                        _qframes.append(_f)
                self._obf_shots = self._obf_shot_take(frames=_qframes) or []
                self._obf_shot = self._obf_shots[0] if self._obf_shots else None
                if self._obf_shots:
                    self.log(f"    → 截图就绪（{len(self._obf_shots)} 张）："
                             f"模型会**按屏幕上的文字**作答（不再读乱码）")
            if not self._obf_shot:
                self.log("    ⚠ 当前模型不能读图，也没截到图 —— 只能跳过。")
                self.log("       办法：换一个认图的模型（如 deepseek-flash），"
                         "或这一份手动作答。")
                res.error = ("字体加密（题目文本不可读，且当前模型不能读图）"
                             "→ 已跳过：未作答、未交卷、未写缓存")
                return res
        # 去重统计进日志：用户和作者都需要一眼看出"这一页的选项结构是不是被识别错了"。
        # 丢弃数很大 = 页面上有大量"选项被拆开"的假题，是结构适配问题的强信号。
        # 控件分布：一眼看出"这一帧里几个控件" —— 错位类 bug 与它直接相关
        try:
            _mf = sum(1 for f in state.fields if getattr(f, "frame", None) is None)
            _mq = sum(1 for q in state.questions if getattr(q, "frame", None) is None)
            self.log(f"· 控件分布：主文档 题{_mq}/字段{_mf}；"
                     f"{len(self.page.frames) - 1} 个子 frame 共 "
                     f"题{len(state.questions) - _mq}/字段{len(state.fields) - _mf}")
        except Exception:
            pass
        _dd = getattr(state, "deduped", 0) or 0
        _df = getattr(state, "deduped_frag", 0) or 0
        if _dd or _df:
            self.log(f"· 扫描去重：合并 {_dd} 道重复渲染、丢弃 {_df} 道残片"
                     f"（选项被拆开的假题）——丢弃数很大说明这一页的选项结构仍需适配")
        if state.empty:
            self.log("⚠ 没有识别到任何可作答控件。可能原因：题目在 canvas 里、需要先进入考试、或已被作答并锁定。")
            self.on_shot(self.driver.screenshot(tag="no_controls"))

        # 预扫描已经拿到一份 state，第一轮就不必再扫一次了
        preloaded: PageState | None = state

        # ------------------------------------------------------------------
        # 主循环。要同时支持两种作业形态：
        #   A. 一页多题  —— 一轮扫完、全部落笔，然后结束
        #   B. 一页一题  —— 落笔后点"下一题"翻页，直到没有下一页
        #
        # 关键状态：
        #   page_sig  当前页指纹；变了说明翻页了，attempts 要重置
        #   filled    本轮真的写进去了几笔；有写才有资格翻页
        #   stagnant  连续几轮没能作答也没能翻页 —— 这才是真正的结束信号
        #   total_pages / page_no 页数统计，翻到 max_pages 强制停，防死循环
        # ------------------------------------------------------------------
        page_sig = ""
        stagnant = 0
        page_no = 0
        last_hint = ""
        pending_check: tuple[PageState, dict[str, Attempt], str] | None = None
        for rnd in range(1, self.max_rounds + 1):
            self.stop.check()
            res.rounds = rnd
            if preloaded is not None:
                # 预扫描刚扫过，第一轮直接复用，省掉一次完整 DOM 扫描
                state = preloaded
                preloaded = None
            else:
                self.status(f"第 {rnd} 轮：扫描页面…")
                state = self.driver.scan()

            # ------------------------------------------------------------------
            # 核验上一轮的落笔（滑动窗口）
            # 用"这一轮的扫描结果"去核对"上一轮写进去的答案"，省掉每轮一次完整
            # DOM 扫描。
            #
            # ⚠ 必须同时比对 URL **和页面指纹**：一页一题的站点（我们的主要场景）
            # 所有题共用同一个 URL，只比 URL 会把"第 2 题的选项"拿去验"第 1 题的
            # 答案，得出满屏"落笔不一致"的假警报。
            # ------------------------------------------------------------------
            cur_sig = self.driver.page_signature()
            if pending_check is not None:
                prev_state, prev_attempts, prev_sig = pending_check
                pending_check = None
                same_page = self.driver._same_url(self.driver.page.url, prev_state.url)
                if same_page and (not prev_sig or not cur_sig or prev_sig == cur_sig):
                    self._verify_with(state, prev_attempts, res)
                # 页面确实翻了 → 上一轮的答案已经不在屏幕上，无从核对，跳过

            # 截图：保留几张由 BrowserDriver._trim_shots 统一决定
            #   开启「每轮清理」→ 只留当前这张（磁盘占用最小，界面预览不空）
            #   关闭           → 保留最近 8 张，方便事后排查
            # 这里不要再自己全清一遍，否则关掉选项也会被清成一张。
            self.on_shot(self.driver.screenshot(tag=f"r{rnd}"))

            # ---- 翻页检测 ----
            sig = cur_sig
            if sig and sig != page_sig:
                if page_sig:
                    page_no += 1
                    self.log(f"—— 翻到新一页（第 {page_no + 1} 页）——")
                page_sig = sig
                # 只清 attempts，**history 绝不动** —— history 是跨页总账，
                # 报告"成功落笔几题"全靠它。清掉它就会出现"明明答了却报 0 题"。
                self.attempts.clear()          # 新题目、新编号，旧记录作废

            hint = self.driver.progress_hint()
            if hint and hint != last_hint:
                last_hint = hint
                self.log(f"· 页面进度显示：{hint}")

            todo_q = [q for q in state.questions if f"q{q.qid}" not in self.attempts]
            todo_f = [f for f in state.fields if f"f{f.fid}" not in self.attempts]
            already = len(self.attempts)

            if not todo_q and not todo_f:
                self.log(f"— 第 {rnd} 轮：本页 {already} 个控件都已作答")
            else:
                self.log(f"— 第 {rnd} 轮：本页待答 {len(todo_q)} 选择 + {len(todo_f)} 填空")

            filled_before = len(self.attempts)
            if todo_q or todo_f:
                decisions = self._answer_questions(state)
                if decisions:
                    try:
                        self._apply_decisions(state, decisions, res)
                    except PageStructureAbort as e:
                        # ⚠ 这里必须 break 而不是 raise：break 会落到本方法末尾的
                        #   正常收尾（_final_scan_and_report + 按设置交卷），
                        #   这样已点中的题才会进 answered，页面才会按设置交卷。
                        #   抛出去会被 run_web 当成别的情况，用户就看不到收尾了。
                        self.log(f"⏹ 已中止本轮（{e}）—— 下面照常收尾")
                        break
                    # 这里原本还有一次 wait_for_load —— 已经去掉：
                    # 下一轮的 scan() 本来就会重新读 DOM，多等一次纯属浪费
                    # （原来每轮白等 250~1500ms，几十轮就是几十秒）。
                    pending_check = (state, dict(self.attempts), sig)
                else:
                    self.log("· 本轮模型没有给出可用答案。")
            filled = len(self.attempts) - filled_before

            # ---- 该不该翻页 ----
            has_next = bool(self.driver.next_candidates())
            if not self.auto_next:
                if not todo_q and not todo_f:
                    self.log("✔ 本页已答完，且未开启「自动下一题」，作答阶段结束。")
                    break
                stagnant += 1
                if stagnant >= 2:
                    break
                continue

            if not has_next:
                self.log("✔ 页面上没有「下一题」按钮了，作答阶段结束。")
                break

            if filled == 0 and not todo_q and not todo_f:
                # 本页早答完了却还停在这儿 → 试着翻页；翻不动就结束
                pass
            elif filled == 0:
                stagnant += 1
                self.log(f"· 本页没能落笔（连续 {stagnant} 次），仍尝试翻页")
                if stagnant >= 3:
                    self.log("✘ 连续多轮既写不进去也翻不动，停止以免死循环。")
                    break

            if page_no + 1 >= self.max_pages:
                self.log(f"⚠ 已翻到第 {page_no + 1} 页，达到上限 {self.max_pages}，停止。")
                break

            self.status("点击「下一题」…")
            r = self.driver.advance_next()
            # 诊断埋点：翻页结果写进日志。之前这里静默退出过一次，
            # 没有这行就无法区分"没按钮"和"点了没反应"。
            self.log(f"· 翻页结果 = {r}")
            if r == "ok":
                stagnant = 0
                # 题号体系已变，下面一轮会通过指纹检测清空 attempts
                time.sleep(0.3)
                continue
            if r == "no_button":
                self.log("✔ 没有可用的「下一题」，作答阶段结束。")
                break
            self.log("⚠ 点了「下一题」但页面没变化，可能已到最后一题（或该按钮不可用）。")
            break
        else:
            # for 正常跑完（没 break）—— 说明撞上了 max_rounds 上限
            self.log(f"⚠ 达到轮数上限 {self.max_rounds}，停止（题目更多请调大 DSHS_MAX_ROUNDS）。")

        # 收尾
        self._final_scan_and_report(res, state)
        if self.auto_submit:
            self._try_submit(res)
        else:
            self.log("ℹ 未自动交卷（可在界面里勾选「自动提交」）。请在浏览器里复核后自行提交。")
        return res

    @staticmethod
    def _first_decision_answer(data) -> str:
        """从模型 JSON 里取第一条字符串答案（多空补问用）。"""
        arr = []
        if isinstance(data, dict):
            for k in ("answers", "data", "items"):
                v = data.get(k)
                if isinstance(v, list):
                    arr = v
                    break
        elif isinstance(data, list):
            arr = data
        for it in arr:
            if not isinstance(it, dict):
                continue
            v = it.get("answer")
            if isinstance(v, str) and v.strip():
                return v.strip()
            if isinstance(v, list) and v:
                return "；".join(str(x) for x in v if str(x).strip())
        return ""

    def _fix_multi_blank(self, state: PageState,
                         decisions: list[Decision]) -> list[Decision]:
        """同一道填空题有多个空时，模型常给每个空都塞同一句。

        2026-10-28 真机：两个空都填了「半结构化数据」。这里在作答结果出来之后
        再问一次「按空顺序列出」，把答案拆开重新分配到第 1/2 空。
        """
        import re as _re
        fmap = {f"f{f.fid}": f for f in state.fields}
        groups: dict[tuple, list] = {}
        for d in decisions:
            obj = fmap.get(d.id)
            if obj is None:
                continue
            tot = int(getattr(obj, "_dsh_dup_total", 0) or 0)
            if tot < 2:
                continue
            stem = str(getattr(obj, "stem", "") or "")
            groups.setdefault((tot, stem), []).append((d, obj))

        for (tot, stem), items in groups.items():
            if len(items) < tot:
                continue
            items.sort(key=lambda x: int(getattr(x[1], "_dsh_dup_index", 0) or 0))
            answers = [str(d.answer).strip() for d, _ in items]
            if len(set(answers)) != 1:
                continue
            first = answers[0]
            if not first or any(sep in first for sep in "；;、，,|/"):
                continue
            self.log(f"· 同一个填空题 {tot} 个空的答案完全相同（{first!r}）"
                     f"→ 再问一次按空排序")
            prompt = (
                f"这是一道填空题，共 {tot} 个空。请按顺序给出每个空要填的内容"
                f"（每个空一个词/短语，用「；」分隔，不要解释，各空内容不要重复）。\n"
                f"题干：{stem}\n"
                f"已确定第 1 空填「{first}」，请给出第 2 到第 {tot} 空。"
            )
            try:
                data = self.client.ask_json(prompt, system=SYSTEM_PROMPT,
                                            temperature=0.3)
            except Exception as e:
                self.log(f"  (多空补问失败：{type(e).__name__})")
                continue
            extra = self._first_decision_answer(data)
            if not extra:
                continue
            parts = [p.strip() for p in _re.split(r"[；;、，,|/]", extra) if p.strip()]
            parts = [p for p in parts if p not in stem and p != first]
            seq = [first] + parts
            if len(seq) != tot:
                seq = [first] + parts[: tot - 1]
            if len(seq) < tot:
                continue
            for (d, obj), val in zip(items, seq):
                d.answer = val
                d.reason = "多空补问"
                d.confidence = max(float(d.confidence or 0), 0.8)
            self.log("  → 按空分配：" + "；".join(seq))
        return decisions

    def _assign_multi_blank(self, state: PageState,
                            decisions: list[Decision]) -> None:
        r"""一道填空题有 n 个空时，把答案**按空归位**；拆不开就不落笔。

        ## 真机现场（2026-11-04 14:12，学习通作业·第 3 题 4 个空）
        模型一次给了整段解释：
            "第1空：准；第2空：快；第3空：稳态（准确性）；第4空：动态（快速性）。
             要点一：时域分析法评价控制系统性能的三个基本要求是「稳、准、快」…"
        旧逻辑只在"答案里恰好有 n-1 个分号、切出来正好 n 段"时才拆，
        这段话切出来每段都带着「第N空：」前缀和后缀解释，于是拆不准；
        4 个空各自拿到整段（**同一段话写进 4 个格子**），而且因为当时
        `essay=True`，连"超过 60 字就截断"那道闸也没走。

        现在：① 优先按「第N空：」标记归位；② 退到分号切段；
        ③ 都失败且答案偏长 → 打上 `_dsh_skip`，`_apply_decisions` 会跳过它，
        留成空格给用户手填（写错一格比空着难收拾）。
        """
        fmap = {f"f{f.fid}": f for f in (getattr(state, "fields", None) or [])}
        groups: dict[int, list[tuple[Decision, object]]] = {}
        for d in decisions:
            f = fmap.get(d.id)
            if f is None:
                continue
            tot = int(getattr(f, "_dsh_dup_total", 0) or 0)
            if tot < 2:
                continue
            groups.setdefault(tot, []).append((d, f))
        for tot, items in groups.items():
            if len(items) < tot:
                continue
            items.sort(key=lambda x: int(getattr(x[1], "_dsh_dup_index", 0) or 0))
            got: dict[int, str] = {}
            for d, _f in items:
                for i, part in enumerate(split_blank_answer(d.answer, tot)):
                    got.setdefault(i, part)
            if len(got) < tot:
                # 也可能各条答案本身就是一个词（模型已经按空分开答了）
                vals = [str(d.answer or "").strip() for d, _f in items]
                if (len(vals) == tot and all(vals)
                        and all(len(v) <= 24 and not re.search(r"[；;。\n]", v)
                                for v in vals)):
                    got = {i: v for i, v in enumerate(vals)}
            if len(got) == tot:
                for i, (d, _f) in enumerate(items):
                    old = str(d.answer or "").strip()
                    new = got[i]
                    if not new or new == old:
                        continue
                    if len(old) > 40:
                        self.log(f"· {d.id} 多空答案按标记归位 → "
                                 f"第{i + 1}空 {new!r}")
                    d.answer = new
                continue
            for d, _f in items:
                if len(str(d.answer or "").strip()) > 40:
                    try:
                        setattr(d, "_dsh_skip", True)
                    except Exception:
                        pass
                    self.log(f"⚠ {d.id} {tot} 个空但答案拆不出来"
                             f"（{len(str(d.answer))} 字）—— 这一格不落笔，"
                             f"留给你手填")

    def _apply_decisions(self, state: PageState, decisions: list[Decision], res: SessionResult) -> None:
        assert self.driver is not None
        qmap = {f"q{q.qid}": q for q in state.questions}
        fmap = {f"f{f.fid}": f for f in state.fields}

        # 浏览器死了就立刻止损：否则会为每道题刷一条同样的错误，日志全废
        self.driver.assert_alive()

        # ------------------------------------------------------------------
        # 熔断：连续落笔失败太多就停下来，别再一题一题地空转。
        #
        # ⚠ 实测踩到（用户报"答完以后不会结束，卡在一道题"）：
        #   学习通作业页上有几道题的选项被拆错了（字母 A 和它的文字成了两个
        #   独立选项），于是这题四条落笔策略全失败，**每题白花约 3.5 秒**
        #   （②③各等 0.9 秒超时 + 两次状态回读）。
        #   实测那次 69 道题里有 52 道是这种，跑完就是 3 分钟的"毫无进展"，
        #   用户看到的就是"卡住了"。
        #
        #   继续磨下去没有任何意义 —— 同一页的结构问题不会自己好。
        #   所以连续失败到阈值就**如实停下并说清原因**，而不是假装还在干活。
        #   阈值取 10：个别难题失败很正常，连着 10 道就不是运气问题了。
        CONSEC_FAIL_LIMIT = 10
        consec_fail = 0

        for d in decisions:
            self.stop.check()
            obj = qmap.get(d.id) or fmap.get(d.id)
            if obj is None:
                continue
            if not self.driver.is_alive():
                self.log("✘ 浏览器在作答过程中关闭，停止本轮（已作答的部分会保留）")
                res.failed.append({"ref": d.id, "stem": "", "answer": d.answer, "why": "浏览器已关闭"})
                break
            # ★ 低置信度**不落笔**。
            #
            #   原来是"打一行日志、照样点" —— 2026-10-17 那两道 confidence=0.20
            #   的题就是这样被点选并交卷的（一错一对，纯蒙）。
            #   现在的规矩：没把握就不动，交给人。
            #   （正常题一般在 0.85~0.98，0.35 这个阈值不会误伤。）
            if d.confidence and d.confidence < config.QUIZ_MIN_CONFIDENCE:
                self.log(f"⚠ {d.id} 置信度只有 {d.confidence:.2f}"
                         f"（{d.reason}）—— **不落笔**，留给你手动答")
                res.failed.append({"ref": d.id,
                                   "stem": str(getattr(obj, "stem", "") or ""),
                                   "answer": str(d.answer),
                                   "why": f"置信度低（{d.confidence:.2f}）未落笔"})
                continue

            if isinstance(obj, Question):
                idxs = self._letters_to_indices(d.answer, len(obj.options),
                                               obj.kind == "checkbox", obj.options)
                if not idxs:
                    if not getattr(obj, "options", None):
                        # 学习通把「填空题」也扫成了一道没有选项的题（真实控件在
                        # 填空字段 f0/f1 上）—— 重复渲染，不是错误，别报警。
                        self.log(f"· {d.id} 是填空题的重复渲染（无选项），交给填空控件处理")
                        continue
                    self.log(f"✘ {d.id} 答案无法映射到选项：{d.answer!r}（{self._vlm_note()}）")
                    res.failed.append({"ref": d.id, "stem": obj.stem, "answer": d.answer, "why": "选项映射失败"})
                    continue
                letters = "".join(obj.letter(i) for i in idxs)
                human = letters if obj.kind == "radio" else list(letters)

                # ------------------------------------------------------------------
                # 正确性护栏：核对"我们点的那个选项"是不是模型要的那个。
                #
                # 注意别搞错比对对象：字母是按 DOM 顺序推的，而 label 文字里的字母
                # 也正是同一批（CSS order 打乱视觉顺序也不影响这个对应关系），
                # 所以"位置"不是风险点 —— 实测验证过。
                #
                # 真正的风险是 **value 属性与显示字母不一致**：有些站点把 value
                # 写成数字索引（value="0/1/2/3"）或与字母无关的内部 id，
                # 一旦代码里某处按 value 匹配，就会点错选项。
                # ------------------------------------------------------------------
                mismatched = [
                    (obj.letter(i), obj.options[i].get("value"), obj.options[i].get("key"))
                    for i in idxs
                    if obj.options[i].get("value")
                    and obj.options[i].get("key")
                    and str(obj.options[i]["value"]).strip().upper() != obj.options[i]["key"]
                ]
                if mismatched:
                    detail = "；".join(f"显示{b[2]} 但 value={b[1]!r}" for b in mismatched)
                    self.log(f"⚠ {d.id} 选项的 value 与显示字母不一致（{detail}）——"
                             f"已按显示字母点选，如结果异常请复核该题")

                if self.dry_run:
                    self.log(f"[演练] {d.id} → {human}  ({d.reason})")
                else:
                    # hidden_hint 只是给个提示，choose() 内部还会逐级尝试
                    # "可见容器 → 父元素 → input 本身"，并用 checked 自查是否真生效
                    hidden = all(bool(obj.options[i].get("hidden")) for i in idxs) if idxs else False
                    msg = self.driver.choose(obj.qid, idxs, hidden_hint=hidden)
                    self.log(f"→ {d.id} 选 {human}：{'；'.join(msg)}")
                    # 自查失败的题目如实记账 —— 不要让"点了但没生效"混进成功里
                    if any("✘" in m for m in msg):
                        why = next((m.split("(", 1)[-1].rstrip(")") for m in msg if "✘" in m), "落笔未生效")
                        res.failed.append({"ref": d.id, "stem": obj.stem,
                                           "answer": str(human), "why": why})
                        consec_fail += 1
                        if consec_fail >= CONSEC_FAIL_LIMIT:
                            self.log(
                                f"✘ 连续 {consec_fail} 道题点了没生效，停止本轮以免继续空转。"
                                f"这通常说明**这一页的题目结构和程序预期不一致**"
                                f"（例如选项文字被拆成了多个部分），"
                                f"继续跑只是重复失败。"
                                f"建议：把运行日志发给作者，"
                                f"或用 _诊断\\dump_quiz_dom.py 导一份页面结构对账单。")
                            raise PageStructureAbort(
                                f"连续 {consec_fail} 道落笔未生效")
                    else:
                        consec_fail = 0
                # ★ 2026-10-22：把选项原文一起存下来（题库冷启动要用）。
                #   只取 key/text 两个字段，且各自截断 —— 不让 runs 文件膨胀。
                _opts: list[dict] = []
                try:
                    for _o in (getattr(obj, "options", None) or []):
                        if not isinstance(_o, dict):
                            continue
                        _opts.append({
                            "key": str(_o.get("key") or _o.get("value") or "")[:8],
                            "text": str(_o.get("text") or "")[:300],
                        })
                except Exception:
                    _opts = []
                att = Attempt(d.id, obj.kind, obj.stem, str(human),
                              d.confidence or 0, options=_opts or None,
                              reason=str(getattr(d, "reason", "") or "")[:400])
                self.attempts[d.id] = att
                self.history.append(att)
                self._fire_answer(obj.stem, str(human),
                                  att.reason, att.confidence)
            else:
                if getattr(d, "_dsh_skip", False):
                    # 多空填空题、答案拆不出来（见 _assign_multi_blank）：
                    # 空着让用户填，别把整段解释写进一个格里。
                    _raw = str(d.answer or "")
                    self.log(f"⚠ {d.id} 多空答案拆不出来 —— 不落笔，留给你手填："
                             f"{_raw[:40]}…")
                    res.failed.append({"ref": d.id,
                                       "stem": str(getattr(obj, "stem", "") or ""),
                                       "answer": _raw,
                                       "why": "多空填空答案拆不出来，未落笔"})
                    continue
                val = d.answer if isinstance(d.answer, str) else json.dumps(d.answer, ensure_ascii=False)
                val = val.strip().strip('"').strip()
                # ★ 同题干 + 长答案 → 不落笔（见文件头 dup_answer_guard 的说明）。
                #   4 个空格一起写错，比空着严重得多 —— 空着用户还能手填。
                _why = dup_answer_guard(obj, val)
                if _why:
                    self.log(f"⚠ {d.id} {_why} —— **不落笔**，留给你手工确认"
                             f"（多半是题干抽取失败，模型在解释它看到的源码）")
                    res.failed.append({"ref": d.id,
                                       "stem": str(getattr(obj, "stem", "") or ""),
                                       "answer": val, "why": _why})
                    continue
                # ★ 题干取不到的填空/论述题：把 DOM 现场记一次（只记一次）。
                #   这类题最费人工（要手写几段话），而日志只有一句"题干未识别"，
                #   完全看不出题干在哪一层。摊开一次，作者就能精准修。
                if not getattr(self, "_field_dumped", False) and \
                        "题干未识别" in str(obj.stem or ""):
                    self._field_dumped = True
                    try:
                        self.log("—— 填空题干未识别的现场快照（只记一次）——")
                        for line in self.driver._dump_field_dom(obj.fid):
                            self.log("   " + line)
                    except Exception as e:
                        self.log(f"   (快照失败：{type(e).__name__})")
                # ★ 2026-10-28 真机：同一道填空题的多个空共用题干，模型常把
                #   「半结构化数据；非结构化数据」整串塞进每个空。这里按分号
                #   拆开，按「第几空」取对应段（第 1 空取第 1 段）。
                _tot = int(getattr(obj, "_dsh_dup_total", 0) or 0)
                _idx = int(getattr(obj, "_dsh_dup_index", 0) or 0)
                if _tot > 1 and val:
                    import re as _re2
                    _parts = [p.strip() for p in
                              _re2.split(r"[；;、，,|/]", val) if p.strip()]
                    # 模型有时把题干里已经写出的「结构化数据」也列进来；
                    # 先剔掉题干里出现过的段，剩下的才是空要填的。
                    _stem = str(getattr(obj, "stem", "") or "")
                    _parts = [p for p in _parts if p and p not in _stem]
                    if len(_parts) == _tot:
                        _one = _parts[_idx]
                        if _one and _one != val:
                            self.log(f"· {d.id} 多空答案拆分：{val!r} → "
                                     f"第{_idx + 1}空填 {_one!r}")
                            val = _one
                if (not getattr(obj, "essay", False)
                        and str(getattr(obj, "kind", "")) != "essay"
                        and len(val) > 60):
                    import re as _re
                    _first = _re.split(r"[。；;\n]", val)[0].strip()
                    if _first and len(_first) <= 60:
                        self.log(f"⚠ {d.id} 填空答案过长（{len(val)} 字）→ 只填第一句："
                                 f"{_first[:30]}")
                        val = _first
                if self.dry_run:
                    self.log(f"[演练] {d.id} → {val!r}  ({d.reason})")
                else:
                    msg = self.driver.fill(obj.fid, val)
                    # 论述题的答案是长文本，原样打会把日志刷爆
                    shown = val if len(val) <= 40 else val[:40] + "…"
                    self.log(f"→ {d.id} 填 {shown!r}：{msg}")
                val2 = Attempt(d.id, obj.kind, obj.stem or obj.label, val,
                               d.confidence or 0,
                               reason=str(getattr(d, "reason", "") or "")[:400])
                self.attempts[d.id] = val2
                self.history.append(val2)
                self._fire_answer(obj.stem or obj.label, val,
                                  val2.reason, val2.confidence)

    def _verify_with(self, fresh: PageState, attempts: dict[str, Attempt],
                     res: SessionResult) -> None:
        """用**已有的**扫描结果核对落笔是否真的写进去了。

        调用方传入的这一份 fresh 就是本轮刚扫的状态，所以这里不再扫第二次
        （原来每轮要扫两遍 DOM，是端到端耗时里可观的一块）。
        核对失败会把该题从 attempts 里摘掉，下一轮自然会重问。
        """
        assert self.driver is not None
        qmap = {f"q{q.qid}": q for q in fresh.questions}
        fmap = {f"f{f.fid}": f for f in fresh.fields}

        for ref, att in list(attempts.items()):
            if ref.startswith("q"):
                q = qmap.get(ref)
                if not q:
                    continue
                checked = {i for i, o in enumerate(q.options) if o.get("checked")}
                want = set(self._letters_to_indices(att.answer, len(q.options),
                                                    q.kind == "checkbox", q.options))
                if checked != want:
                    obs = "".join(q.letter(i) for i in sorted(checked)) or "空"
                    self.log(f"⚠ {ref} 落笔不一致：期望 {att.answer}，页面实际 {obs} —— 下一轮会重试")
                    self.attempts.pop(ref, None)
                    res.failed.append({"ref": ref, "stem": att.stem, "answer": att.answer, "why": f"落笔失败(实际{obs})"})
            else:
                f = fmap.get(ref)
                if not f:
                    continue
                got = (f.value or "").strip()
                want = str(att.answer).strip()
                if want and got != want:
                    self.log(f"⚠ {ref} 填充不一致：期望 {want!r}，页面实际 {got!r} —— 下一轮会重试")
                    self.attempts.pop(ref, None)
                    res.failed.append({"ref": ref, "stem": att.stem, "answer": want, "why": f"填充失败(实际{got!r})"})
                elif got:
                    # 填成功了，从失败清单里摘掉
                    res.failed = [x for x in res.failed if x.get("ref") != ref]

    def _final_scan_and_report(self, res: SessionResult, state: PageState) -> None:
        """汇总本次作答，生成人类可读的记录。

        关键点：一页一题的站点上，**每页的题号都从 q0 起**，所以历史里会出现
        一大串 q0。直接照搬 ref 会得到 "q0 → A、q0 → B、q0 → C…" 这种没法读的
        报告，也难以和页面上的题号对应。所以这里：
          · 按 (ref, 题干, 答案) 去重（同一题被重答时只留一份）
          · 输出时给出**全局序号** seq，并把原始 ref 留在 page_ref 里备查
        """
        seen: set[str] = set()
        answered: list[dict] = []
        for a in self.history or list(self.attempts.values()):
            key = f"{a.ref}|{a.stem[:80]}|{a.answer}"
            if key in seen:
                continue
            seen.add(key)
            answered.append({
                "seq": len(answered) + 1,
                "ref": a.ref,
                "type": a.kind,
                # ⚠ 原来只有截断到 160 字的 stem，且**没有选项** ——
                #   本地题库拿它当冷启动数据源时，算不出「选项集合指纹」。
                #   2026-10-22 补两个字段（**纯新增**，老消费者忽略即可）：
                #     full_stem : 完整题干（不截断）
                #     options   : [{"key": "A", "text": "…"}, …]
                "stem": a.stem[:160],
                "full_stem": a.stem,
                "options": getattr(a, "options", None) or [],
                # ★ 2026-10-22：模型给的一句话解析（早就有，之前没存）
                "reason": getattr(a, "reason", "") or "",
                "answer": a.answer,
                "confidence": round(a.confidence, 2),
            })
        res.answered = answered
        # 去重失败项（按 ref + 题干，避免同一题被反复记）
        seen_f = set()
        uniq = []
        for x in res.failed:
            k = f"{x.get('ref')}|{str(x.get('stem'))[:80]}"
            if k in seen_f:
                continue
            seen_f.add(k)
            uniq.append(x)
        res.failed = uniq
        # ★ 2026-10-23 新增（纯新增字段）：这条答案**有没有真的落进页面**。
        #   背景（B7）：`self.history` 是跨页总账，回读核验失败只从 `attempts`
        #   摘除、`history` 不动 —— 于是同一道题可能既在 `answered` 里、又在
        #   `failed` 里（"落笔失败"）。导出/题库若直接消费 `answered`，会把没真正
        #   落笔的答案当成有效答案。用 `failed` 的 ref 集合标一个 verified=False。
        _failed_refs = {str(x.get("ref") or "") for x in res.failed if isinstance(x, dict)}
        for item in res.answered:
            if isinstance(item, dict):
                item["verified"] = str(item.get("ref") or "") not in _failed_refs
        self.log("")
        self.log(f"===== 小结：成功落笔 {len(res.answered)} 题，待人工复核 {len(res.failed)} 题 =====")
        for x in res.failed:
            self.log(f"  ⚠ {x.get('ref')} {str(x.get('stem'))[:60]} | 我的答案={x.get('answer')} | {x.get('why')}")

    def _submit_succeeded(self) -> bool:
        r"""判断"提交到底生效了没有"。**逐帧**看。

        没有统一的成功标志，只能看几种常见信号：
          · 页面出现"得分/成绩/已完成/提交成功"之类文案
          · 弹出了确认框
          · 页面上出现被隐藏的结果区

        ⚠⚠ 必须**逐帧**（2026-10-17 修的那个坑）：
          原来只跑 `self.driver.page.evaluate(...)` —— 那只在主文档里找。
          而章节测验的提交按钮本身就在 **iframe** 里（日志里
          `在 iframe 里按文字点到了「提交」` 就是证据），
          如果交卷成功的提示也渲染在同一个 iframe 里，这里就**永远判"没交上"**，
          于是程序反复点、最后报 `submitted=false` —— 明明已经交上了。

        判不出来时返回 True（宁可放过，也不要因为误判反复点提交）。
        """
        assert self.driver is not None
        js = r"""() => {
            const pat = /得分|成绩|提交成功|已完成|已交卷|正确率|你的答案/;
            // ① 可见文字里出现结果字样
            const els = document.querySelectorAll(
                '#result,.result,.score,[class*=result],[class*=score]');
            for (const e of els) {
                const s = getComputedStyle(e);
                if (s.display === 'none' || s.visibility === 'hidden') continue;
                if (pat.test(e.innerText || '')) return true;
            }
            // ② 页面上有可见的"得分：x / y"
            const body = document.body ? (document.body.innerText || '') : '';
            if (/得分\s*[:：]\s*\d+\s*\/\s*\d+/.test(body)) return true;
            if (/提交成功|已完成作答|已交卷/.test(body)) return true;
            // ③ 有确认弹窗（还没点确定）
            const dlg = document.querySelector(
                '.el-message-box,.el-dialog,[role=dialog]');
            if (dlg) {
                const s = getComputedStyle(dlg);
                if (s.display !== 'none' && s.visibility !== 'hidden') return true;
            }
            return false;
        }"""
        try:
            frames = list(self.driver.page.frames)
        except Exception:
            frames = []
        if not frames:
            return True                      # 判断不了就当成功，避免重复提交
        for i, fr in enumerate(frames):
            try:
                if fr.evaluate(js):
                    if i:
                        self.log(f"· 结果出现在 frame {i}（不在主文档）")
                    return True
            except Exception:
                continue
        # 一个帧都判断不了 → 当成功（宁可放过也不要反复点提交）
        try:
            self.driver.page.evaluate("() => 1")
        except Exception:
            return True
        return False

    def _watch_submit_responses(self) -> None:
        r"""开始记录"提交相关"的网络响应（只记状态码，不碰请求内容）。

        ## 为什么要它（方案 P0-2）

        `_submit_succeeded()` 只能看页面。可平台常常是
        **后端拒绝、前端不提示** —— 页面一点变化都没有，
        于是程序只会说"没能确认提交成功"，用户完全不知道发生了什么。

        这里把提交类请求的**状态码**记下来：`4xx/5xx` 就是最直接的证据。

        ## 为什么不读响应体

        Playwright 的**同步** API 里，事件回调中**不能**调用 `resp.text()` ——
        那要回到事件循环，回调本身就在那个循环上跑，会死锁。
        所以这里只记状态码/方法/URL（都是已有属性，无往返），
        要看响应体请按 F12 → Network（方案 §7 也是这么建议的）。
        """
        if getattr(self, "_resp_hooked", False):
            return
        self._resp_hooked = True
        self._resp_log: list[tuple[int, str, str]] = []

        def _on_resp(r) -> None:      # noqa: ANN001
            try:
                u = r.url or ""
                if not any(k in u for k in ("submit", "work", "exam", "test",
                                            "card", "ans", "job")):
                    return
                method = ""
                try:
                    method = str(r.request.method)
                except Exception:
                    method = ""
                self._resp_log.append((int(r.status), method, u[:130]))
            except Exception:
                pass

        try:
            self.driver.page.on("response", _on_resp)
            self.log("· 已开始记录提交类请求的状态码（4xx/5xx = 被拒）")
        except Exception:
            pass

    def _wait_challenge(self, seconds: float = 4.0) -> dict:
        """点完提交后**等一会儿**再看有没有验证码。

        为什么必须等：验证码弹层是异步渲染的，点完立刻看往往看不到
        （方案 §1.3 的第三种可能）。
        `detect_challenge()` 自己会遍历所有帧，所以这里只管轮询。
        """
        end = time.time() + max(0.0, float(seconds))
        while time.time() < end:
            try:
                ch = self.driver.detect_challenge() or {"found": False}
            except Exception:
                ch = {"found": False}
            if ch.get("found"):
                return ch
            if self._stop_requested():
                break
            time.sleep(0.5)
        return {"found": False}

    def _stop_requested(self) -> bool:
        """用户是不是已经点了停止。"""
        st = getattr(self, "stop", None)
        if st is None:
            return False
        try:
            st.check()
            return False
        except Exception:
            return True

    def _try_submit(self, res: SessionResult) -> None:
        assert self.driver is not None
        # ⚠ 必须重新扫一次再点。
        # 调用方传进来的 state 可能是"作最后一题之前"的快照，而页面在作答过程中
        # 可能已经滚动或重排 —— 拿旧坐标去点新页面会点空（实测出现过
        # "日志说已点击提交、但页面毫无反应、结果区一直不显示分数"）。
        state = self.driver.scan()
        cands = state.submit_candidates()
        if not cands:
            self.log("ℹ 没找到「提交/下一步」按钮，跳过自动提交。")
            return
        target = cands[0]
        self.log(f"▶ 自动提交：点击「{target['text']}」")
        # ★ 开始记录提交类请求的状态码（后端拒绝时只有这里有证据）
        self._watch_submit_responses()

        # 依次尝试三种打法，每轮之后都**回读页面**确认是否真的交上去了
        for attempt, how in enumerate(("按文字(role)", "按文字(text)", "按坐标"), 1):
            # ★ 用户已经点了停止 → 别再硬试。
            #   2026-10-17 15:42 实测：用户 15:42:02 按下停止，
            #   这里还在 15:42:04~15:42:09 连试 4 次、最后报"没能确认提交成功"，
            #   看着像程序出错了，其实是他自己停的。
            if self._stop_requested():
                self.log("⏹ 已停止 —— 不再尝试提交")
                return
            try:
                if how == "按文字(role)":
                    loc = self.driver.page.get_by_role(
                        "button", name=re.compile(re.escape(target["text"]), re.I)).first
                    loc.click(timeout=3000)
                elif how == "按文字(text)":
                    self.driver.page.get_by_text(target["text"], exact=True).first.click(
                        timeout=2500)
                else:
                    box = target.get("box") or {}
                    if not box:
                        continue
                    self.driver.page.mouse.click(box["x"] + box["w"] / 2,
                                                 box["y"] + box["h"] / 2)
            except Exception as e:
                self.log(f"· 提交第 {attempt} 次（{how}）没点到：{type(e).__name__}")
                continue

            self.driver.wait_for_load(extra_ms=900)
            try:
                self.driver.page.wait_for_timeout(500)
            except Exception:
                pass
            # ★ 交卷通常还有一层「确认提交」。不点它页面不会变，
            #   下面 `_submit_succeeded()` 就会误判成"没交上"。
            #   用户 2026-10-17 反馈的正是这个。
            _cf = self._confirm_dialog()
            if _cf:
                self.log(f"· 已点确认框「{_cf.get('text')}」")
            else:
                self.log("· 没有可点的确认框（或点了没反应）")
                try:
                    self.driver.wait_for_load(extra_ms=700)
                except Exception:
                    pass

            # ★ 点完提交之后，**先看有没有冒出人机校验 / 验证码**。
            #
            #   2026-10-17 用户那份 quiz_dom.txt 里就有一个：
            #     <input class='Inp fl' placeholder='请输入验证码'>
            #     上三层文字：为保障您的账号安全，请输入验证码 … 继续学习
            #
            #   这种情况 `_submit_succeeded()` 永远判不出来（页面不会出现"提交成功"），
            #   于是日志会一直说"没能确认提交成功" —— 完全误导。
            #   按铁律：**不识别、不填写**，立刻停手并说清楚。
            # ★ 必须**等一会儿再看**：验证码弹层是异步渲染的，
            #   点完立刻看往往看不到（方案 §1.3 的第三种可能）。
            ch = self._wait_challenge(4.0)
            if ch.get("found"):
                self.log("✘ 提交时出现**人机校验 / 验证码** —— 已停下，"
                         "不会替你识别或填写。")
                if ch.get('how'):
                    self.log(f"   命中：{ch.get('how')}"
                             + (f"　附近：{ch.get('hint')}" if ch.get('hint') else ""))
                self.log("   请在弹出的验证码框里手动完成，交卷也就随之完成了。")
                res.error = "提交需要验证码（需你手动完成）→ 停止自动提交"
                return

            if self._submit_succeeded():
                self.log(f"✔ 已提交（第 {attempt} 次尝试，{how}）")
                res.submitted = True
                break
            self.log(f"· 第 {attempt} 次点击（{how}）后页面没有变化，换个打法再试")
        else:
            # ★ 三次都只用主文档。而这道题的按钮常常在 **iframe** 里 ——
            #   扫描能穿透 iframe 找到题目，但 `page.get_by_role()` /
            #   `get_by_text()` 都只认主文档，坐标点击又落到主文档上错位。
            #   所以补最后一次：**逐帧按文字点**。
            hit = ""
            try:
                hit = self._click_submit_in_frames()
            except Exception as e:
                self.log(f"· 逐帧点击提交异常（{type(e).__name__}）")
            if hit:
                self.log(f"· 在 iframe 里按文字点到了「{hit}」")
                try:
                    self.driver.wait_for_load(extra_ms=900)
                except Exception:
                    pass
                _cf = self._confirm_dialog()
                if _cf:
                    self.log(f"· 已点确认框「{_cf.get('text')}」")
                else:
                    self.log("· 没有可点的确认框（或点了没反应）")
                    try:
                        self.driver.wait_for_load(extra_ms=700)
                    except Exception:
                        pass
                # ★ 同样先查验证码（见上面那段注释）。
                ch = self._wait_challenge(4.0)
                if ch.get("found"):
                    self.log("✘ 提交时出现**人机校验 / 验证码** —— 已停下，"
                             "不会替你识别或填写。")
                    self.log("   请在弹出的验证码框里手动完成，交卷也就随之完成了。")
                    res.error = "提交需要验证码（需你手动完成）→ 停止自动提交"
                    return
                if self._submit_succeeded():
                    self.log("✔ 已提交（iframe 内按文字点击）")
                    res.submitted = True
            if not res.submitted and not res.error:
                self.log("⚠ 全部尝试都没能确认提交成功，请手动检查页面是否已交卷"
                         "（本次记录里 submitted=false）")
                # ★ 光说"没成功"等于没说。把**现场**打出来 ——
                #   下一次就能直接看出是"弹了确认框没点"、"按钮点了没反应"、
                #   还是"其实已经交上去了、只是判据没认出来"。
                self._log_submit_scene()

    def _log_submit_scene(self) -> None:
        """提交失败时把页面上"看到的"打出来（只读，不点击）。"""
        assert self.driver is not None
        js = r"""() => {
            const out = [];
            const vis = (e) => {
                try {
                    const s = getComputedStyle(e);
                    const r = e.getBoundingClientRect();
                    return s.display !== 'none' && s.visibility !== 'hidden'
                        && parseFloat(s.opacity || '1') > 0.05
                        && r.width > 2 && r.height > 2;
                } catch (err) { return false; }
            };
            out.push('url=' + location.href.slice(0, 110));

            // ① 可见的对话框 / 遮罩
            const DLG = '.el-message-box,.el-dialog,.ant-modal,.layui-layer,'
                      + '.weui-dialog,.modal,.dialog,[role=dialog],'
                      + '[class*=confirm],[class*=Confirm],[class*=dialog],'
                      + '[class*=pop],[class*=mask]';
            let dlgN = 0;
            try {
                for (const d of document.querySelectorAll(DLG)) {
                    if (!vis(d)) continue;
                    const t = (d.innerText || '').replace(/\s+/g, ' ').trim();
                    if (t.length < 2) continue;
                    dlgN++;
                    if (dlgN <= 3) out.push('  对话框[' + dlgN + '] ' + t.slice(0, 120));
                }
            } catch (e) {}
            if (!dlgN) out.push('  对话框: 无');

            // ② 页面上还能点的「提交/确定/确认/继续」类按钮
            const WORD = /提交|交卷|确定|确认|继续|保存|完成/;
            let btnN = 0;
            try {
                for (const e of document.querySelectorAll(
                        'button,a,span,div,input[type=button],input[type=submit],[role=button]')) {
                    if (!vis(e)) continue;
                    const t = (e.innerText || e.value || '').replace(/\s+/g, '').trim();
                    if (!t || t.length > 8 || !WORD.test(t)) continue;
                    btnN++;
                    if (btnN <= 6) {
                        out.push('  可点[' + btnN + '] 「' + t + '」 <'
                                 + e.tagName.toLowerCase()
                                 + (e.className && typeof e.className === 'string'
                                    ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.')
                                    : '') + '>');
                    }
                }
            } catch (e) {}
            if (!btnN) out.push('  可点的提交类按钮: 无（可能已经交上去了）');

            // ③ 结果字样
            try {
                const body = (document.body && document.body.innerText) || '';
                const m = body.match(/得分[：:]\s*\d+\s*\/\s*\d+|提交成功|已完成作答|已交卷|正确率\s*\d+%/);
                out.push('  结果字样: ' + (m ? m[0] : '未出现'));
            } catch (e) {}
            return out.join('\n');
        }"""
        try:
            frames = list(self.driver.page.frames)
        except Exception:
            frames = []
        for i, fr in enumerate(frames):
            try:
                got = fr.evaluate(js) or ""
            except Exception:
                continue
            if got:
                self.log(f"    ── 现场（frame {i}）──")
                for line in str(got).split("\n"):
                    self.log(f"    {line}")

        # ⑤ 最近记录到的「提交类」请求状态码 —— **后端拒绝时只有这里有证据**。
        #    4xx/5xx 说明平台拒绝了这次提交；2xx 却页面没变，
        #    多半是成功判据没认出来（现在已逐帧）。
        rows = getattr(self, "_resp_log", None) or []
        if rows:
            self.log("    ── 最近的相关请求 ──")
            for st, m, u in rows[-8:]:
                flag = "   ← 被拒（4xx/5xx）" if st >= 400 else ""
                self.log(f"    {st} {m} {u}{flag}")
        else:
            self.log("    ── 最近的相关请求：无（没抓到提交类请求）──")

        # 提交后网页往往要算分再渲染，稍等一下再截图，免得截到空白
        try:
            self.driver.page.wait_for_timeout(600)
        except Exception:
            pass
        self.on_shot(self.driver.screenshot(tag="after_submit"))

    # 确认框里那个按钮的文字。
    #
    # ⚠ 为什么敢把「提交」放进来（旧版是故意排除的）：
    #   学习通那个确认键的文字**就是「提交」**，不是「确定」。
    #   而现在 _CONFIRM_DIALOG_JS 里有 inDialog() 过滤（往上 4 层必须有取消/关闭），
    #   所以页面背景那个主「提交」**不会**被选中 —— 不会重复交卷。
    _CONFIRM_WORD_SRC = (r"提交|交卷|保存|确认|确定|是的|"
                         r"确认提交|确定提交|继续提交|仍要提交|继续|完成")

    def _confirm_dialog(self):
        """点掉交卷后的「确认提交」二次确认框。

        返回 `{"text","frame","x","y"}`；没有框 / 点不动 返回 `None`。

        ## 为什么要"三档点击 + 逐档复核"

        学习通那个框是**组件**渲染的，有些版本忽略合成事件（`isTrusted=false`）。
        所以：合成事件（JS 里已派发）→ 元素 `.click()` → **真实鼠标坐标**，
        每档点完都复核"框消失了没有"，不生效才换下一档。

        ## 为什么点不到就放弃，而不是一直重试

        无限重试只会把账号刷成"异常操作"。点不动就打现场、交给人。
        """
        assert self.driver is not None
        # 框是**异步渲染**的，必须轮询（16:15 那次只等 900ms 就去看，太早）。
        end = time.time() + 6.0
        while True:
            try:
                frames = list(self.driver.page.frames)
            except Exception:
                return None
            for fr in frames:
                try:
                    hit = fr.evaluate(_CONFIRM_DIALOG_JS, self._CONFIRM_WORD_SRC)
                except Exception:
                    continue
                if not hit or not isinstance(hit, dict):
                    continue
                self.log(f"· 检测到确认框按钮「{hit.get('text')}」"
                         f" <{hit.get('tag')}>")
                if self._click_confirm(fr, hit):
                    hit["frame"] = fr
                    return hit
                self.log("· 确认键点了但框还在，换一种点法")
            if time.time() >= end or self._stop_requested():
                return None
            time.sleep(0.4)

    def _dialog_gone(self, fr) -> bool:
        """确认框是不是已经关掉了。"""
        js = r"""() => {
            const SEL = '[class*=popBox],[class*=pop],[role=dialog],'
                      + '.el-message-box,.el-dialog,.ant-modal,.layui-layer';
            for (const d of document.querySelectorAll(SEL)) {
                const s = getComputedStyle(d);
                const r = d.getBoundingClientRect();
                if (s.display === 'none' || s.visibility === 'hidden') continue;
                if (r.width <= 2 || r.height <= 2) continue;
                if (/取消|关闭/.test(d.innerText || '')) return false;  // 还开着
            }
            return true;
        }"""
        try:
            return bool(fr.evaluate(js))
        except Exception:
            return False

    def _wait_gone(self, fr, seconds: float) -> bool:
        end = time.time() + max(0.0, seconds)
        while time.time() < end:
            if self._dialog_gone(fr):
                return True
            try:
                if self._submit_succeeded():
                    return True
            except Exception:
                pass
            time.sleep(0.2)
        return False

    def _click_confirm(self, fr, hit: dict) -> bool:
        """三档点击。返回 True = 框已经消失（或已经判定交上）。"""
        # ① 合成事件已经在 JS 里派发过，这里只复核
        if self._wait_gone(fr, 0.8):
            return True
        # ② 元素 .click()（**只一次**，用属性防重复）
        try:
            fr.evaluate(
                r"""(a) => {
                    const e = document.elementFromPoint(a[0], a[1]);
                    if (!e) return false;
                    if (e.getAttribute('data-dsh-cf-done')) return true;
                    e.setAttribute('data-dsh-cf-done', '1');
                    e.click();
                    return true;
                }""", [hit["x"], hit["y"]])
        except Exception:
            pass
        if self._wait_gone(fr, 0.8):
            return True
        # ③ 真实鼠标（trusted 事件）—— 有些组件只认这个
        try:
            self.driver.click_in_frame(fr, hit["x"], hit["y"])
        except Exception as e:
            self.log(f"    · 真实鼠标点击失败（{type(e).__name__}）")
            return False
        return self._wait_gone(fr, 1.2)

    def _click_submit_in_frames(self) -> str:
        """在每个框架里找「提交/交卷」并点它。点到了返回它的文字。

        ## 为什么需要

        `_try_submit` 原来那三种打法（`get_by_role` / `get_by_text` / 鼠标坐标）
        **都只作用于主文档**。而学习通这类页面的按钮常在 iframe 里，
        于是日志里永远是「没点到：TimeoutError」。

        这里逐帧跑一段 JS：找文字匹配「提交/交卷」的可见元素，
        **派发完整指针事件**（pointerdown/mousedown/pointerup/mouseup/click）
        再补一次 `.click()` —— 有些框架只监听其中一种。

        ## 为什么取"最后一个"

        页面顶部也可能有个「提交」之类的东西；真正交卷的按钮通常在内容底部。
        取最后一个命中的更稳。（脚本里先 `scrollIntoView`。）
        """
        assert self.driver is not None
        # ⚠ 帧列表在 `driver.page.frames` 上（Playwright 的属性），
        #   `BrowserDriver` 自己**没有** `frames()` 方法 ——
        #   我第一版写成 `self.driver.frames()`，直接 AttributeError。
        #   （`course.py` 里那个 `_frames()` 是 CourseRunner 自己的包装。）
        try:
            frames = list(self.driver.page.frames)
        except Exception:
            return ""
        for fr in frames:
            try:
                # ⚠ `_SUBMIT_WORD_SRC` 是**模块级**常量，不是类属性 ——
                #   写成 `self._SUBMIT_WORD_SRC` 会 AttributeError，
                #   而下面那个 `except: continue` 会把它**静默吞掉**，
                #   表现是"每一帧都跳过、返回空"，看起来像"按钮不存在"。
                #   所以：别用 self. 前缀，而且异常要说话。
                got = fr.evaluate(_SUBMIT_ANYWHERE_JS, _SUBMIT_WORD_SRC) or ""
            except Exception as e:
                self.log(f"    · 某一帧里找提交按钮失败（{type(e).__name__}: "
                         f"{str(e)[:60]}）")
                continue
            if got:
                return str(got)
        return ""

    def _vlm_note(self) -> str:
        if not self._is_vlm():
            return "当前模型不支持看图，若题目依赖图片建议换 vlm"
        return f"已送 {self.vision_used} 张图"

    # ================================================================ PC 模式
    def run_pc(self, task: str, *, max_steps: int | None = None) -> SessionResult:
        """真·键鼠模式：截屏 → 模型给一个动作 → 执行 → 再截屏。

        适合没走 Playwright 的场景（非浏览器窗口、远程桌面、客户端）。
        """
        t0 = time.time()
        res = SessionResult()
        d = Desktop()
        steps = max_steps or config.PC_AGENT_MAX_STEPS
        history: list[str] = []

        system = """你是一个通过截图操控 Windows 电脑的代理。你一次只能执行一个动作。

可用动作（任选一个，输出 JSON）：
{"thought":"简述你的判断","action":"click","x":100,"y":200}
{"thought":"...","action":"type","text":"要输入的内容"}
{"thought":"...","action":"key","keys":["enter"]}       // 如 ["ctrl","c"] 或 ["enter"]
{"thought":"...","action":"scroll","amount":-600}
{"thought":"...","action":"wait","seconds":1.5}
{"thought":"...","action":"ask_user","question":"需要用户处理的事情"}
{"thought":"...","action":"done","summary":"任务已完成"}

规则：
- **坐标一律按你收到的那张图来标**（那张图可能已被等比缩小）。
  以图片左上角为原点，单位是图片像素，落在你要点击的元素中心。
  程序会自动把图片坐标换算回真实屏幕，**你不需要也不要去猜原图尺寸**。
- 先把输入焦点点进去，再 type。
- 涉及中文输入时用 type，程序会自动走剪贴板。
- 只输出一个 JSON 对象，不要 markdown，不要多余文字。"""

        self.log(f"PC 模式启动，最多 {steps} 步。任务：{task}")
        self.log("⚠ PC 模式会接管真实鼠标键盘 —— 运行期间请不要碰电脑。")
        # ★ 坐标系一致性自检（启动时一次）。
        #
        # 为什么必须有：`GetSystemMetrics`（后端点击用的坐标系）和
        # `ImageGrab`（截图用的坐标系）在 **DPI 感知没设对**时可能不一致 ——
        # 那会让每一次点击都整体偏移一个固定比例（比如全部往右下角跑 20%），
        # 而日志里看到的是"模型点的位置明明对，就是没点中"。
        # 一次性比出来并说清楚，比让人去猜"是不是模型不准"强得多。
        try:
            _probe = d.screenshot(save=False)
            _bs = d.size
            if tuple(_probe.size) != tuple(_bs):
                self.log(f"⚠ 坐标系不一致：截图 {_probe.size[0]}x{_probe.size[1]}、"
                         f"点击空间 {_bs[0]}x{_bs[1]} —— 点击可能整体偏移。"
                         f"常见原因是显示缩放（DPI）或远程桌面；"
                         f"把显示缩放设为 100% 通常可解。")
            else:
                self.log(f"· 坐标系自检通过（{_bs[0]}x{_bs[1]}）")
        except Exception as e:
            self.log(f"· 坐标系自检跳过（{type(e).__name__}）")
        if not config.PC_CONFIRM:
            self.log("  （已在设置里关闭了运行前确认）")
        try:
            for i in range(1, steps + 1):
                self.stop.check()
                self.status(f"PC 模式 第 {i}/{steps} 步")
                # ⚠ 截图失败**不该把整场会话带走**。
                #   屏幕锁定、远程桌面断开、UAC 安全桌面都会让它抛异常；
                #   重试一次，仍不行就**明确停下并说清原因**（而不是抛出去）。
                img = None
                for _try in (1, 2):
                    try:
                        img = d.screenshot(save=False)
                        break
                    except Exception as e:
                        if _try == 2:
                            res.error = (f"截屏失败（{type(e).__name__}）："
                                         f"屏幕可能已锁定、远程桌面断开或处于 "
                                         f"UAC 安全桌面。请解锁屏幕后重试。")
                            self.log(f"✘ {res.error}")
                            break
                        self.log(f"  (截屏失败，重试一次：{type(e).__name__})")
                        self.stop.sleep(0.8)
                if img is None:
                    break
                w, h = img.size
                # 存盘用**原图**（保留原始分辨率，方便事后人工核对）。
                # ⚠ 截图目录可能不可写（用户把它指到 U 盘/网络盘，或盘被拔了）。
                #   原来这里没有保护，`save()` 抛 OSError 会一路冒到外层
                #   except → **整个 PC 会话直接结束**。
                #   而"存一张核对用的图"只是旁支功能，失败了不该影响任务。
                try:
                    shot_path = d.save(img, f"pc{i:02d}")
                    if shot_path:
                        self.on_shot(shot_path)
                except Exception as e:
                    self.log(f"  (截图存盘失败，不影响继续：{type(e).__name__})")
                # 发给模型用**降采样图**：整屏 2560x1600 的 data URI 有 2.3 MB，
                # 每步都发一次太慢太贵，而模型对超大图也不见得更准。
                small = d.shrink(img)
                sw, sh = small.size
                # ★ 缩放比例。模型看到的是 sw x sh、并按那张图给坐标；
                #   `sx` 就是"把缩略图坐标放大回原图"的倍数（见下面 click 分支）。
                sx = (w / sw) if sw else 1.0
                sy = (h / sh) if sh else 1.0
                hist = "\n".join(history[-6:]) or "(无)"
                # ⚠ 坐标契约必须写死、不能模棱两可（这点我踩过）：
                #   截图被缩小后，"按原图给坐标"和"按缩略图给坐标"两种做法
                #   在数值上**可能完全重叠** —— 比如原图 2560x1600 缩到 1600x1000，
                #   模型若返回 (1280,800)，它既可能是原图坐标、也可能是缩略图坐标
                #   （1280<=1600 且 800<=1000）。程序**无法从数值上分辨**。
                #   所以只能约定一种：**按它看到的那张图（缩略图）给**，
                #   由程序统一放大回原图。这样规则唯一、可预期。
                prompt = f"""【任务】{task}

【屏幕截图】你看到的这张图是 {sw}x{sh} 像素。
真实屏幕是 {w}x{h} 像素（比图大 {sx:.2f} 倍）。
**坐标请按你看到的这张图（{sw}x{sh}）来标**，程序会自己换算回真实屏幕。
（左上角为原点，x 向右，y 向下）
【你已经做过的动作（最近几条）】
{hist}

请给出下一步动作（只输出一个 JSON）。如果任务已完成，用 done。"""
                self.vision_used += 1
                try:
                    step = self.client.ask_json(
                        # ⚠ 必须在这里就转成 PNG 字节。
                        #   `d.screenshot()` 返回的是 **PIL.Image 对象**，
                        #   而 `lms._to_data_uri()` 原来只接受"路径字符串 / bytes"，
                        #   它会对 PIL 对象执行 `open(img, "rb")` → TypeError。
                        #   异常被下面的 except 吃掉并 break，
                        #   表现就是 **PC 模式每一步都在第 1 步失败**、功能完全不可用。
                        #   `desktop.py` 里早就写好了 `png_bytes()`，只是一直没人调。
                        prompt, system=system,
                        images=[d.jpeg_bytes(small)], max_tokens=768,
                        timeout=config.LM_VISION_TIMEOUT,
                    )
                except Exception as e:
                    self.log(f"✘ 第 {i} 步模型失败：{e}")
                    break
                if not isinstance(step, dict):
                    self.log(f"✘ 第 {i} 步返回非对象：{str(step)[:200]}")
                    break

                act = str(step.get("action", "")).lower()
                thought = str(step.get("thought", ""))[:120]
                self.log(f"[{i}] {act} — {thought}")
                history.append(f"{i}. {act} {json.dumps({k: v for k, v in step.items() if k != 'thought'}, ensure_ascii=False)[:160]}")

                if act == "done":
                    self.log(f"✔ 任务完成：{step.get('summary', '')}")
                    res.ok = True
                    break
                if act == "click":
                    # ⚠ 坐标解析必须宽容（原来直接 int()，会整场中断）：
                    #   模型常返回 {"x": null} / {"x": "100px"} / {"x": "abc"}，
                    #   int() 抛异常 → 被外层 except 抓走 → **整个 PC 会话结束**，
                    #   而不是"跳过这一步重来"。这类解析失败应该只丢一步。
                    x = _as_int(step.get("x"), None)
                    y = _as_int(step.get("y"), None)
                    if x is None or y is None:
                        self.log(f"  (坐标无法解析，跳过这一步："
                                 f"x={step.get('x')!r} y={step.get('y')!r})")
                    else:
                        # ★ 换算：模型按"它看到的那张缩略图"给坐标，
                        #   必须先放大回**原图尺寸**才能点真实屏幕。
                        #
                        # ⚠ 这里原先是直接把模型坐标拿去点，**没有任何换算** ——
                        #   而提示词里明明写着"程序会自己换算"，那句话没有实现。
                        #   实测（2560x1600 屏幕、长边降到 1600）：
                        #     目标真实位置 (1280,800)，程序却点在 (800,500)，
                        #     偏差 566 像素 —— 等于点到完全无关的位置。
                        #   而且放大倍数随分辨率变化（1.2x ~ 2.4x），
                        #   没有任何固定系数能补偿，只能运行时按实际尺寸算。
                        #
                        # 注：**不做"看起来像原图坐标就跳过换算"的猜测**。
                        #   两种坐标系在数值上可能重叠，猜错就是点飞；
                        #   提示词已明确要求按缩略图给，这里就确定性地换算。
                        if sx > 1.001 or sy > 1.001:
                            rx, ry = int(round(x * sx)), int(round(y * sy))
                            self.log(f"  · 坐标换算：缩略图 ({x},{y})"
                                     f" → 原图 ({rx},{ry})")
                            x, y = rx, ry
                        if 0 <= x <= w and 0 <= y <= h:
                            # ⚠ 单步失败只丢一步，不终止整场。
                            #   后端抛异常的原因多半是系统层的（SendInput 被拦、
                            #   UAC 提权窗口抢焦点…），跟"任务本身"无关。
                            try:
                                d.click(x, y)
                            except Exception as e:
                                self.log(f"  (点击失败，跳过这一步："
                                         f"{type(e).__name__})")
                        else:
                            self.log(f"  (坐标越界，忽略：{x},{y})")
                elif act == "type":
                    try:
                        d.type_text(str(step.get("text", "")))
                    except Exception as e:
                        self.log(f"  (输入失败，跳过这一步：{type(e).__name__})")
                elif act == "key":
                    keys = step.get("keys") or []
                    if isinstance(keys, str):
                        keys = [keys]
                    if keys:
                        try:
                            d.key(*[str(k).lower() for k in keys])
                        except Exception as e:
                            self.log(f"  (按键失败，跳过这一步："
                                     f"{type(e).__name__})")
                elif act == "scroll":
                    try:
                        d.scroll(_as_int(step.get("amount"), -500) or -500)
                    except Exception as e:
                        self.log(f"  (滚轮失败，跳过这一步：{type(e).__name__})")
                elif act == "wait":
                    secs = _as_int(step.get("seconds"), 1) or 1
                    self.stop.sleep(float(max(0, min(30, secs))))
                elif act == "ask_user":
                    q = str(step.get("question", "需要你手动处理一下屏幕上的内容。"))
                    self.log(f"⏸ 需要人工：{q}")
                    # Web 端没有 Tk 弹窗，ask_user 通常传 None。
                    # 原来这时直接 raise Stopped()，等于"一遇到要人工就整个停掉"。
                    # 现在：有回调就问，没有就**明确停下来并说清原因**，
                    # 让用户处理完再点继续 —— 而不是让它瞎猜着往下点。
                    if not self.ask_user or not self.ask_user(q):
                        self.log("  已暂停 PC 模式（需要你处理后重试）")
                        res.error = f"需要人工处理：{q}"
                        break
                else:
                    self.log(f"  (未知动作 {act!r}，跳过)")
                # 记一步。PC 模式没有"题"的概念，但**必须有个进度数字** ——
                # 否则结束摘要只能显示"无作答结果"，跑了多少步都看不出来
                # （和之前"答了却报 0 道"是同一类观感问题）。
                res.answered.append({"seq": i, "type": "pc_step",
                                     "stem": f"[{act}] {thought}"[:120],
                                     "answer": "已执行", "confidence": 1.0})
                # ⚠ 用 stop.sleep 而不是 time.sleep：点停止后不该还卡 0.6 秒
                self.stop.sleep(0.6)
            else:
                self.log(f"⚠ 达到 {steps} 步上限，仍未收到 done。")
        except Stopped:
            res.error = "用户已停止"
            self.log("⏹ 已停止")
        except Exception as e:
            res.error = f"{type(e).__name__}: {e}"
            self.log(f"✘ 出错：{res.error}")
        finally:
            res.seconds = time.time() - t0
            self._dump(res)
        return res

    # ================================================================ 收尾
    def _dump(self, res: SessionResult) -> None:
        try:
            p = config.RUNS_DIR / f"run_{time.strftime('%Y%m%d_%H%M%S')}.json"
            # ★ 2026-10-23：改成**原子写**（先 `.tmp` 再 replace，和 usage.py 一致）。
            #   原来直接 write_text：掉电/进程被结束时会在 out\runs\ 留半截 JSON，
            #   导出器/题库读到就是一条坏记录。os.replace 在同分区上是原子的。
            tmp = p.with_suffix(".json.tmp")
            tmp.write_text(res.to_json(), encoding="utf-8")
            tmp.replace(p)
            self.log(f"记录已保存：{p}")
        except Exception:
            pass

    def stop_now(self) -> None:
        self.stop.set()


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
def _as_int(v, default):
    """把模型给的"大概是数字"的东西变成 int。**失败返回 default，不抛异常。**

    ⚠ 为什么需要它（审计 C-36）：
      PC 模式原来直接写 `int(step.get("x", 0))`。而模型经常返回
        {"x": null}       → int(None) → TypeError
        {"x": "100px"}    → int("100px") → ValueError
        {"x": "大约 100"}  → ValueError
      这些异常会一路抛到 `run_pc` 的外层 except，
      **整个 PC 会话就此结束** —— 而不是"跳过这一步、让模型重出一次"。
      一个字段格式不对就葬送整个任务，代价太大了。

      这里尽量救：支持数字、数字字符串、带单位（100px / 100 %）、
      全角数字、以及"字符串里能抠出的第一个数"。
    """
    if v is None:
        return default
    if isinstance(v, bool):          # bool 是 int 的子类，先排掉
        return int(v)
    if isinstance(v, (int, float)):
        try:
            return int(v)
        except (TypeError, ValueError, OverflowError):
            return default
    s = str(v).strip()
    if not s:
        return default
    # 全角数字 → 半角
    try:
        s = s.translate(str.maketrans("０１２３４５６７８９．－", "0123456789.-"))
    except Exception:
        pass
    try:
        return int(float(s))         # "100" / "100.0"
    except (TypeError, ValueError):
        pass
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s)   # "100px" / "约 100 像素"
    if m:
        try:
            return int(float(m.group(0)))
        except (TypeError, ValueError):
            return default
    return default


def _normalize_ref(rid: str, valid: set[str]) -> str | None:
    """把模型写的各种 id 变体归一成 'q0' / 'f1'。"""
    if rid in valid:
        return rid
    s = rid.strip().lower().replace(" ", "")
    s = re.sub(r"^(question|题目|题|ans|answer)", "", s)
    s = s.strip("[](){}:：#")
    if s in valid:
        return s
    m = re.search(r"([qf])\D*(\d+)", s)
    if m:
        cand = f"{m.group(1)}{int(m.group(2))}"
        if cand in valid:
            return cand
    if re.fullmatch(r"\d+", s):
        for pre in ("q", "f"):
            if f"{pre}{s}" in valid:
                return f"{pre}{s}"
    return None
